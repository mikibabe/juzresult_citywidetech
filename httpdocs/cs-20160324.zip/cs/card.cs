
<script runat=server>

DataSet ds;	//for creating Temp talbes templated on an existing sql table
string m_cardType = "2";
string m_job = "";

string m_sOrderBy = "trading_name";
bool m_bDescent = false; //order by xxx DESC
bool m_bRestrict = false;
int m_members = 0;
string m_dealer_level = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	//if(!SecurityCheck("administrator"))
	//	return;

     ds = new DataSet();

	string sstrict = GetSiteSettings("secure_employee_card", "0");
	if(MyBooleanParse(sstrict))
		m_bRestrict = true;
	if(m_bRestrict)
	{
		string al = Session[m_sCompanyName + "AccessLevel"].ToString();
		if(al == "10" || al == "7")
			m_bRestrict = false; //administrator or manager have access
	}
	
	if(Request.QueryString["type"] != null)
		m_cardType = Request.QueryString["type"];
	if(Request.QueryString["dl"] != null)
		m_dealer_level = Request.QueryString["dl"];

	if(m_bRestrict)
	{
		if(m_cardType != null && m_cardType != "" && MyIntParse(m_cardType) > 2)
		{
			Response.Write("<h3>ACCESS DENIED");
			return;
		}
	}

	if(Request.QueryString["j"] != null)
		m_job = Request.QueryString["j"];

	if(Request.QueryString["ob"] != null)
	{
		m_sOrderBy = Request.QueryString["ob"];
		Session["card_list_order_by"] = m_sOrderBy;
	}
	else if(Session["card_list_order_by"] != null)
		m_sOrderBy = Session["card_list_order_by"].ToString();
	
	if(Request.QueryString["desc"] == "1")
		m_bDescent = true;

	if(m_cardType == "-1")
	{
		if(!GetExtraLogins())
			return;
	}
	else if(!DoSearch())
	{
		return;
	}

	PrintAdminHeader();
	PrintAdminMenu();
	
	string sType = "Card List -- <font class=blueFont2>";//ALL</font>";
	if(m_cardType == "-1")
		sType += "Extra Logins";
	else if(m_cardType != "")
		sType += GetEnumValue("card_type", m_cardType).ToUpper();
	else
		sType += "ALL";
	sType += "</font>";
	
	Response.Write("<br><center><h3>" + sType + "</h3></center>");
//	Response.Write("<br><img border=0 src='/i/cf.gif'>");
	Response.Write("<table width=100%>");
	Response.Write("<tr><td width=30%>");
	Response.Write("<b>Member in this class : </b>" + m_members.ToString() + "");
	Response.Write("</td>");
	Response.Write("<td width=70% align=right id=memberHolder>");
	if(MyBooleanParse(GetSiteSettings("show_dealer_level_in_card", "0", true)))
	{
		Response.Write("<img src=r.gif>Dealer Level : ");
		string suri = Request.QueryString["URL"];
		suri += "?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
		if(m_cardType != "")
			suri += "&type="+ m_cardType;
		Response.Write("<select name=dlevel onchange=\"window.location=('"+ suri +"&dl=' + this.options[this.selectedIndex].value)\">");
		Response.Write(sDealerLevel());
		Response.Write("</select>");
		Response.Write(" &nbsp; ");
	}
	DataSet dsEnum = new DataSet();
	string sc = "SELECT id, name FROM enum WHERE class='card_type'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsEnum, "enum");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return;
	}
	
	string s_href = "";
	if(Request.QueryString["approved"] != null && Request.QueryString["approved"] == "0")
		s_href = "<a href=card.aspx?approved=0&type=";
	else
		s_href = "<a href=card.aspx?type=";
	for(int i=0; i<dsEnum.Tables["enum"].Rows.Count; i++)
	{
		string id = dsEnum.Tables["enum"].Rows[i]["id"].ToString();
		string name = dsEnum.Tables["enum"].Rows[i]["name"].ToString().ToUpper();
		if(m_bRestrict)
		{
			if(name == "CUSTOMER" || name == "DEALER")
			{
				Response.Write("<img src=r.gif>" + s_href + id + " >" + name + "</a>&nbsp;&nbsp;&nbsp;");
			}
		}
		else
			Response.Write("<img src=r.gif>" + s_href + id + " >" + name + "</a>&nbsp;&nbsp;&nbsp;");
	}
	Response.Write("<img src=r.gif><a href=card.aspx?type=-1 >EXTRALOGIN</a>&nbsp;&nbsp;&nbsp;");
	if(!m_bRestrict)
		Response.Write("<img src=r.gif>" + s_href + " >ALL</a>&nbsp;&nbsp;&nbsp;");

	Response.Write("</td></tr></table>");
	displayForm();
	
	if(!IsPostBack)
	{
		if(m_job == "payment")
			BindGridPayment();
		else
			BindGrid();
	}

//	if(m_job == "")
	/*{
			LAddNewButton.Text = @"
		<form action=ecard.aspx target=_new method=post>
		<input type=submit name=cmd value='Add New' >
		</form>
		";
	}*/
	LFooter.Text = m_sAdminFooter;
	
}
string sDealerLevel()
{
	string s = "";

	string sc = " SELECT COUNT(dealer_level) AS t_dealer_level, dealer_level FROM card WHERE 1 = 1 ";
	if(m_cardType != "")
	sc += " AND type = "+ m_cardType;
//	if(Request.QueryString["dl"] != null && Request.QueryString["dl"] != "")
	{
		//if(TSIsDigit(Request.QueryString["dl"].ToString()))
//			sc += " AND dealer_level = "+ Request.QueryString["dl"].ToString();
	}
	sc += " GROUP BY dealer_level ";
//DEBUG("s c=", sc);
	int nrows = 0;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		nrows = myCommand.Fill(ds, "tdealer");
	}
	catch(Exception e) 
	{
		//	ShowExp(sc, e);
		return "Error Query Database";
	}
	
	for(int i=0; i<nrows; i++)
	{
		DataRow dr = ds.Tables["tdealer"].Rows[i];
		string dlevel = dr["dealer_level"].ToString();
		string tdlevel = dr["t_dealer_level"].ToString();
	
	//	s +" <option value='"+ dlevel +"'>"+ tdlevel +" in "+ dlevel +"</option>";
		Response.Write(" <option value='"+ dlevel +"'");
		if(Request.QueryString["dl"] != null && Request.QueryString["dl"] != "")
		{
			if(TSIsDigit(Request.QueryString["dl"].ToString()))
			{
				if(dlevel == Request.QueryString["dl"].ToString())
					Response.Write(" selected ");
			}
		}
		Response.Write(">"+ dlevel +" TOTAL: "+ tdlevel +"</option>");
	}

	return s;
}

void displayForm()
{
	//Response.Write("<tr><td>");
	//Response.Write("<asp:Label id=LAddNewButton runat=server/>");
	//Response.Write("</td><td>");
	//Response.Write("<asp:Label id=LShowAllButton runat=server/>");
	//Response.Write("</td><td>");
	//Response.Write("&nbsp;&nbsp;&nbsp;");
	//Response.Write("</td><td>");
	string type = "";
	if(Request.QueryString["type"] != null && Request.QueryString["type"] != "")
		type = Request.QueryString["type"].ToString();

	Response.Write("<form name=form1 method=post action=card.aspx?type="+ type +" id=form1>");
	Response.Write("<table><tr><td><select name=card_type>");
	Response.Write(GetEnumOptions("card_type", "1", false, false));
	Response.Write("</select></td>");
//	Response.Write("<input type=button value='Add New' "+ Session["button_style"] +"");
//	Response.Write(" onclick=\"javascript:ecard_window=window.open('ecard.aspx?a=new&n='+ document.form1.card_type.value, '', '');\">");
	Response.Write("<td><input type=button value='Add New' class=addButton title='Add New'");
	Response.Write(" onclick=\"window.location=('ecard.aspx?a=new&n='+ document.form1.card_type.value);\"></td>");
	Response.Write("<td><input type=button value='Show ALL' class=linkButton title='Show ALL'");
	Response.Write(" onclick=\"window.location=('card.aspx?type=');\"></td>");
	//Response.Write("<table cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	//Response.Write("style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed>");
	//Response.Write("<tr><td>");
	Response.Write("<td><input type=hidden name=t value=search></td>");
	Response.Write("<td><select name='select_card'>");
	Response.Write("<option value='all'>All</option><option value='name'>Name</option><option value='id'>ID</option><option value='phone'>Phone</option>");
	Response.Write("<option value='email'>Email</option><option value='trading_name'>Trading Name</option><option value='company'>Company</option>");
	Response.Write("</select></td><td><input type=text name=keyword></td>");
	//set session for export customer csv
	Session["AllowExportCustomerCsv"] = true; 
	Response.Write("<td><input type=submit value=' Search ' class=searchButton2 title=' Search '></td><td><a href='/admin/exportcostomer.aspx' class='linkButton' target='_blank'>Export All Customers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href='/admin/exportdealer.aspx' class='linkButton' target='_blank'>Export All Dealers</a></td></tr></table>");
	//Response.Write("</td></tr>");
	//Response.Write("</table>");
	Response.Write("</form>");
	//Response.Write("</td></tr>");
}

bool CheckAccountType(string card_id)
{
	DataSet acDss = new DataSet();
	if(acDss.Tables["type"] != null)
		acDss.Tables["type"].Clear();

	bool bisValid = false;
	if(card_id == "")
		return false;
	if(!TSIsDigit(card_id))
		return false;

	string sc = " SELECT access_level FROM card WHERE id = '" + card_id +"' AND type = 4";
//DEBUG("sc =", sc);	
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(acDss, "type") == 1)
			if(MyIntParse(acDss.Tables["type"].Rows[0]["access_level"].ToString()) >= MyIntParse(GetSiteSettings("set_privilege_on_access_cardlist", "5", false)))
				bisValid = true;

	}
	catch(Exception e) 
	{
	//	ShowExp(sc, e);
		return false;
	}
	return bisValid;
}


Boolean DoSearch()
{
	string sortDescent = m_bDescent?"&desc=0":"&desc=1";	
	string r = sortDescent + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate();
	string sc = "";
	if(m_job == "payment")
	{
		sc = "SELECT id, name, short_name, trading_name, email, phone, trans_total, balance, access_level, discount, note FROM card ";
		sc += " ORDER BY balance DESC, name, register_date";	 
	}
	else
	{
		//if(Request.QueryString["t"] == "search")
		if(Request.Form["keyword"] != null && Request.Form["keyword"] != "")
		{
			//string kw = Request.QueryString["keyword"];
			string kw = Request.Form["keyword"].ToString();
			//DEBUG(" kw = ", kw);
			string s_card = "";
			//if(Request.QueryString["select_card"] != null && Request.QueryString["select_card"] != "")
			//	s_card = Request.QueryString["select_card"].ToString();
			if(Request.Form["select_card"] != null && Request.Form["select_card"] != "")
				s_card = Request.Form["select_card"].ToString();
			//DEBUG("sc ard= ", s_card);
			bool isNum = true;
			int ptr = 0;
			while (ptr < kw.Length)
			{
				if (!char.IsDigit(kw, ptr++))
				{
					isNum = false;
					break;
				}
			}
			//DEBUG("isnum = ", isNum.ToString());
			sc = "SELECT DISTINCT id, name, short_name, trading_name, email, phone, discount, balance, access_level, note ";
		
			if(m_sSite.ToLower() == "admin" && CheckAccountType(Session["card_id"].ToString()))
				sc += ", '<a href=ecard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Edit</a>' AS '<font >Action </font>'";
			//sc += ", '<a href=\"javascript:viewcard_window=window.open(''viewcard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=400, height=650, resizable=1''); viewcard_window.focus()\" >View</a>' AS ACTION ";
			sc += ", '<a href=\"javascript:viewcard_window=window.open(''ecard.aspx?id='+LTRIM(STR(id)) + '&v=view&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=800, height=650, resizable=1,scrollbars=1''); viewcard_window.focus()\"  >View</a>' AS '<font >ACTION </font>'";
				
			sc += " FROM card ";
			sc += " WHERE ( 1=1 ";
			if(kw != "")
			{
				kw = EncodeQuote(kw);
				if(s_card == "id")
				{
					if(isNum)
					{
						sc += " AND id = '" + kw + "' ";
						//sc += " OR phone LIKE '%"+ kw +"%' ";
					}
					else
						sc += " ";
				}
				if(s_card == "name")
					sc += " AND name LIKE '%" + kw + "%' ";
				if(s_card == "company")
					sc += " AND company LIKE '%" + kw + "%' ";
				if(s_card == "trading_name")
					sc += " AND trading_name LIKE '%" + kw + "%' ";
				if(s_card == "email")
					sc += " AND email LIKE '%" + kw + "%'";
				if(s_card == "phone")
					sc += " AND phone like '%"+ kw +"%' ";
				if(s_card == "all")
				{
					sc += "AND name LIKE '%" + kw + "%' OR company LIKE '%" + kw + "%' OR email LIKE '%" + kw + "%' OR phone like '%"+ kw +"%' OR trading_name LIKE '%" + kw + "%'";
					if(isNum)
					{
						sc += " OR id = '" + kw + "' ";
						sc += " OR phone LIKE '%"+ kw +"%' ";
					}
				}
				//sc += " AND REPLACE(phone, '-', '') LIKE '%"+ kw +"%' ";
			}
			sc += " ) AND type <> 0 ";
			if(m_bRestrict)
				sc += " AND type IN (1, 2) ";
			if(m_dealer_level != "")
			{
				if(TSIsDigit(m_dealer_level))
					sc += " AND dealer_level = "+ m_dealer_level;
			}
			sc += " ORDER BY name";
			if(m_cardType == "0")//personal
			{
				sc = "SELECT id AS '<a href=card.aspx?ob=id&type=" + m_cardType + "><font >ID</font></a>' ";
				sc += ", trading_name AS '<a href=card.aspx?ob=trading_name&type=" + m_cardType + "><font >COMPANY</font></a>' ";
				sc += ", name AS '<a href=card.aspx?ob=name&type=" + m_cardType + "><font >NAME</font></a>' ";
				sc += ", phone AS '<a href=card.aspx?ob=phone&type=" + m_cardType + "><font >PHONE</font></a>' ";
				sc += ", fax AS '<a href=card.aspx?ob=fax&type=" + m_cardType + "><font >FAX</font></a>' ";
				sc += ", address1 AS '<a href=card.aspx?ob=address1&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
				sc += ", address2 AS '<a href=card.aspx?ob=address2&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
				sc += ", address3 AS '<a href=card.aspx?ob=address3&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
				sc += ", dealer_level AS <font >DEALER_LEVEL </font>";
				if(m_sSite.ToLower() == "admin" && CheckAccountType(Session["card_id"].ToString()))
					sc += ", '<a href=ecard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Edit</a>' AS '<font >ACTION </font>'";
				//sc += ", '<a href=\"javascript:viewcard_window=window.open(''viewcard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=400, height=650, resizable=1''); viewcard_window.focus()\" >View</a>' AS ACTION ";
				sc += ", '<a href=\"javascript:viewcard_window=window.open(''ecard.aspx?id='+LTRIM(STR(id)) + '&v=view&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , '' resizable=1,scrollbars=1''); viewcard_window.focus()\"  >View</a>' AS '<font >ACTION1 </font>'";
				
				sc += " FROM card ";
				sc += " WHERE ( 1=1 ";
				if(kw != "")
				{
					kw = EncodeQuote(kw);
					if(s_card == "id")
					{
						if(isNum)
						{
							sc += " AND id = '" + kw + "' ";
							//sc += " OR phone LIKE '%"+ kw +"%' ";
						}
						else
							sc += " ";
					}
					if(s_card == "name")
						sc += " AND name LIKE '%" + kw + "%' ";
					if(s_card == "company")
						sc += " AND company LIKE '%" + kw + "%' ";
					if(s_card == "trading_name")
						sc += " AND trading_name LIKE '%" + kw + "%' ";
					if(s_card == "email")
						sc += " AND email LIKE '%" + kw + "%'";
					if(s_card == "phone")
						sc += " AND phone like '%"+ kw +"%' ";
					if(s_card == "all")
					{
						sc += "AND name LIKE '%" + kw + "%' OR company LIKE '%" + kw + "%' OR email LIKE '%" + kw + "%' OR phone like '%"+ kw +"%' OR trading_name LIKE '%" + kw + "%'";
						if(isNum)
						{
							sc += " OR id = '" + kw + "' ";
							sc += " OR phone LIKE '%"+ kw +"%' ";
						}
					}
					sc += ") AND type=0 AND personal_id = " + Session["card_id"].ToString(); //only display current users personal cards
					if(m_dealer_level != "")
					{
						if(TSIsDigit(m_dealer_level))
							sc += " AND dealer_level = "+ m_dealer_level;
					}
				}
			}
		}
		else
		{
			if(Request.QueryString["approved"] != null && Request.QueryString["approved"] == "0")
			{
				sc = "SELECT id, trading_name AS 'Legal Name', trading_name AS 'Trading Name', name AS 'Purchase Manager', ";
				sc += " email AS 'PM_Email', address1 AS 'Physical Addr', Phone, Fax, register_date AS 'Date', Approved, ";
				sc += " '<a href=ecard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Process</a>' AS '<font >Action </font>'";
				sc += " FROM card WHERE approved=0 AND type=2 ";
				if(m_dealer_level != "")
				{
					if(TSIsDigit(m_dealer_level))
						sc += " AND dealer_level = "+ m_dealer_level;
				}
				sc += " ORDER BY register_date DESC";	 
//				if(m_cardType != "")
//					sc += " AND type='" + m_cardType + "'";
			}
			else
			{
				string month = DateTime.UtcNow.AddHours(12).Month.ToString();
				string fname = "m" + month;
				sc = "SELECT id AS '<a href=card.aspx?ob=id&type=" + m_cardType + r + "><font >ACCOUNT</font></a>' ";
				sc += ", trading_name AS '<a href=card.aspx?ob=trading_name&type=" + m_cardType + r + "><font >Trade Name</font></a>' ";
				sc += ", name AS '<a href=card.aspx?ob=name&type=" + m_cardType + r + "><font >FIRST/LAST NAME</font></a>' ";
//				sc += ", short_name AS '<a href=card.aspx?ob=short_name" + r + "><font color=white>SHORT</font></a>' ";
//				sc += ", email AS '<a href=card.aspx?ob=email" + r + "><font color=white>EMAIL</font></a>' ";
//				sc += ", phone AS '<a href=card.aspx?ob=phone" + r + "><font color=white>PHONE</font></a>' ";
//				sc += ", trans_total AS '<a href=card.aspx?ob=trans_total" + r + "><font color=white>TRANS_TOTAL</font></a>' ";
				sc += ", ROUND(purchase_average, 2) AS '<a href=card.aspx?ob=purchase_average&type=" + m_cardType + r + "><font >PUR_AVE</font></a>' ";
				sc += ", ROUND(" + fname + ", 2) AS '<a href=card.aspx?ob=" + fname + "&type=" + m_cardType + r + "><font >THIS MONTH</font></a>' ";
				sc += ", ROUND(balance, 2) AS '<a href=card.aspx?ob=balance&type=" + m_cardType + r + "><font >BALANCE</font></a>' ";
				sc += ", credit_limit AS '<a href=card.aspx?ob=credit_limit&type=" + m_cardType + r + "><font >CREDIT_LIMIT</font></a>' ";
					sc += ", dealer_level As '<font >DEALER_LEVEL </font>'";
				if(m_sSite.ToLower() == "admin" && CheckAccountType(Session["card_id"].ToString())){
                    if(String.IsNullOrEmpty(Request.QueryString["type"])){
                        sc += ", '<a href=ecard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Edit</a>' AS '<font >ACTION </font>'";
                    }else{
                        sc += ", '<a href=ecard.aspx?type="+ Request.QueryString["type"] +"&id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Edit</a>' AS '<font >ACTION </font>'";
                    }
                    
                }
					
				//sc += ", '<a href=\"javascript:viewcard_window=window.open(''viewcard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=400, height=650, resizable=1''); viewcard_window.focus()\" >View</a>' AS ACTION ";
				//sc += ", '<a href=\"javascript:viewcard_window=window.open(''ecard.aspx?id='+LTRIM(STR(id)) + '&v=view&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , '' resizable=1,scrollbars=1''); viewcard_window.focus()\" >View</a>' AS '<font >ACTION1 </font>'";
				sc += ", '<a href=\"javascript:viewcard_window=window.open(''viewcard.aspx?id='+LTRIM(STR(id)) + '&v=view&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=350,height=400''); viewcard_window.focus()\" >View</a>' AS '<font >ACTION1 </font>'";
				
				sc += " FROM card WHERE 1=1 AND main_card_id IS NULL ";
				if(m_cardType != "")
				{
					sc += " AND type='" + m_cardType + "' ";
				}
				if(m_dealer_level != "")
				{
						if(TSIsDigit(m_dealer_level))
							sc += " AND dealer_level = "+ m_dealer_level;
				}
				sc += " ORDER BY " + m_sOrderBy;	 
				if(m_bDescent)
					sc += " DESC";
				if(m_cardType == "0")//personal
				{
					sc = "SELECT id AS '<a href=card.aspx?ob=id&type=" + m_cardType + "><font >ID</font></a>' ";
					sc += ", trading_name AS '<a href=card.aspx?ob=trading_name&type=" + m_cardType + "><font >COMPANY</font></a>' ";
					sc += ", name AS '<a href=card.aspx?ob=name&type=" + m_cardType + "><font >NAME</font></a>' ";
					sc += ", phone AS '<a href=card.aspx?ob=phone&type=" + m_cardType + "><font >PHONE</font></a>' ";
					sc += ", fax AS '<a href=card.aspx?ob=fax&type=" + m_cardType + "><font color=white>FAX</font></a>' ";
					sc += ", address1 AS '<a href=card.aspx?ob=address1&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
					sc += ", address2 AS '<a href=card.aspx?ob=address2&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
					sc += ", address3 AS '<a href=card.aspx?ob=address3&type=" + m_cardType + "><font >ADDRESS</font></a>' ";
					if(m_sSite.ToLower() == "admin" && CheckAccountType(Session["card_id"].ToString()))
						sc += ", '<a href=ecard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " >Edit</a>' AS '<font >ACTION</font>' ";
				
					//sc += ", '<a href=\"javascript:viewcard_window=window.open(''viewcard.aspx?id='+LTRIM(STR(id)) + '&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , ''width=400, height=650, resizable=1''); viewcard_window.focus()\" class=o>View</a>' AS ACTION ";
					sc += ", '<a href=\"javascript:viewcard_window=window.open(''ecard.aspx?id='+LTRIM(STR(id)) + '&v=view&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "'', '''' , '' resizable=1,scrollbars=1''); viewcard_window.focus()\" >View</a>' AS '<font >ACTION1 </font>'";

					sc += " FROM card WHERE 1=1 AND main_card_id IS NULL ";
					sc += " AND type=0 ";
					sc += " AND personal_id = " + Session["card_id"].ToString(); //only display current users personal cards
					if(m_dealer_level != "")
					{
						if(TSIsDigit(m_dealer_level))
							sc += " AND dealer_level = "+ m_dealer_level;
					}
					sc += " ORDER BY " + m_sOrderBy;	 
					if(m_bDescent)
						sc += " DESC";
				}
			}
		}
	}
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		m_members = myCommand.Fill(ds);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetExtraLogins()
{
	string sortDescent = m_bDescent?"&desc=0":"&desc=1";
	string r = sortDescent + "&type=0";
	string sc = "";

	string month = DateTime.UtcNow.AddHours(12).Month.ToString();
	string fname = "m" + month;
	sc = " SELECT c.id AS '<a href=card.aspx?ob=id" + r + "><font >ACCOUNT</font></a>' ";
	sc += ", c1.trading_name AS '<a href=card.aspx?ob=trading_name" + r + "><font >TradingName</font></a>' ";
	sc += ", c1.company AS '<a href=card.aspx?ob=company" + r + "><font >Company</font></a>' ";
	sc += ", c.name AS '<a href=card.aspx?ob=name" + r + "><font >Name</font></a>' ";
	sc += ", c.email AS '<a href=card.aspx?ob=email" + r + "><font >Email</font></a>' ";
	sc += ", c.is_branch AS '<a href=card.aspx?ob=is_branch" + r + "><font >Is Branch</font></a>' ";
	sc += ", '<a href=viewcard.aspx?id=' + LTRIM(STR(c.id)) + ' target=_blank >View</a>' AS '<font >ACTION </font>'";
	sc += " FROM card c JOIN card c1 ON c1.id = c.main_card_id ";
	sc += " WHERE c.main_card_id IS NOT NULL ";
	sc += " ORDER BY c1." + m_sOrderBy;	 
	if(m_bDescent)
		sc += " DESC";
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		m_members = myCommand.Fill(ds);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

/////////////////////////////////////////////////////////////////
void BindGrid()
{
	DataView source = new DataView(ds.Tables[0]);
	MyDataGrid.DataSource = source ;
	MyDataGrid.DataBind();
}

void MyDataGrid_Page(object sender, DataGridPageChangedEventArgs e) 
{
	MyDataGrid.CurrentPageIndex = e.NewPageIndex;
	BindGrid();
}

/////////////////////////////////////////////////////////////////
void BindGridPayment()
{
	DataView source = new DataView(ds.Tables[0]);
	MyDataGridPayment.DataSource = source ;
	MyDataGridPayment.DataBind();
}

void MyDataGridPayment_Page(object sender, DataGridPageChangedEventArgs e) 
{
	MyDataGridPayment.CurrentPageIndex = e.NewPageIndex;
	BindGridPayment();
}
</script>

<form runat=server>
<asp:DataGrid id=MyDataGrid 
	runat=server 
	AutoGenerateColumns=true
	BackColor=White 
	BorderWidth=0px 
	BorderStyle=Solid 
	BorderColor=#f2fdff
	CellPadding=1
	CellSpacing=0
	Font-Name=Verdana 
	Font-Size=8pt 
	width=100% 
	style=fixed
	HorizontalAlign=center
	AllowPaging=True
	PageSize=20
	PagerStyle-PageButtonCount=10
	PagerStyle-Mode=NumericPages
	PagerStyle-HorizontalAlign=Left
    
    
    OnPageIndexChanged=MyDataGrid_Page
	>

	<HeaderStyle CssClass=tableHeader/>
	<ItemStyle ForeColor=DarkSlateBlue/>
	<AlternatingItemstyle BackColor=#f2fdff/>
    
</asp:DataGrid>

<asp:DataGrid id=MyDataGridPayment
	runat=server 
	AutoGenerateColumns=true
	BackColor=White 
	BorderWidth=1px 
	BorderStyle=Solid 
	BorderColor=#f2fdff
	CellPadding=1
	CellSpacing=0
	Font-Name=Verdana 
	Font-Size=8pt 
	width=100% 
	style=fixed
	HorizontalAlign=center
	AllowPaging=True
	PageSize=20
	PagerStyle-PageButtonCount=10
	PagerStyle-Mode=NumericPages
	PagerStyle-HorizontalAlign=Left
    
    OnPageIndexChanged=MyDataGridPayment_Page
	>

	<HeaderStyle CssClass=tableHeader/>
	<ItemStyle ForeColor=DarkSlateBlue/>
	<AlternatingItemstyle BackColor=#f2fdff/>
    
	<Columns>
		<asp:HyperLinkColumn
			 HeaderText=PAYMENT
			 DataNavigateUrlField=id
			 DataNavigateUrlFormatString="payment.aspx?ci={0}"
			 Text=PAYMENT
			 Target=_blank/>
	</Columns>

</asp:DataGrid>

</form>

<asp:Label id=LFooter runat=server/>