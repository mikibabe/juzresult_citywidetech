<!-- #include file="card_access.cs" -->

<script runat=server>

const string m_sHeader = @"";
string m_sFooter = "";

string m_cat_access = "all";
string m_sTopCatString = "";
bool m_bAllowShowTopCat = false;

string ssid = ""; //sales session id

Boolean PrintHeaderAndMenu(String pageName)
{
	if(Session["show_popular_only"] == null)
	{
//		Session["show_popular_only"] = true;
//		if(m_sSite != "admin")
			Session["show_popular_only"] = MyBooleanParse(GetSiteSettings("show_popular_only", "0", true));
	}
	m_bAllowShowTopCat = MyBooleanParse(GetSiteSettings("allow_to_show_top_cat", "0", true));
	if(m_bAllowShowTopCat)
	{
		m_sTopCatString = GetSiteSettings("top_cat_string_name", "Product", false);
	}

	if(Session["cat_access"] == null)// && Session["cat_access"].ToString() != "all")
		Session["cat_access"] = "";

	string str = Session["cat_access"].ToString();
	string cat_block_to_all = GetSiteSettings("main_category_block_to_all", "");
	if(cat_block_to_all != "" && m_sSite != "admin")
		str += cat_block_to_all;
	m_cat_access = BuildCatAccess(str);
	Session["cat_access_sql"] = m_cat_access;

	string kw = "";
	if(Session["search_keyword"] != null)
		kw = Session["search_keyword"].ToString();

	m_sFooter = ReadSitePage("foot_menu").Replace("@@search_keyword", kw);

	string menu = "";
	string sMenuSubTables = "";
	if(!BuildMenuCache(ref menu, ref sMenuSubTables))
		return false;
	menu = BlockSysQuote(menu);

	if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
		ssid = "&ssid=" + Request.QueryString["ssid"];

	TSAddCache("item_categories", menu);

	string header = ReadSitePage("public_page_header");
	if(m_sRoot != "")
		header = ReadSitePage("dealer_page_header");
    //if logined show logout
    string _ssid = ssid.Replace("&ssid=", "");
    header = header.Replace("@@SSID@@", _ssid);
    if(Session["isLogined"] == null){
    
        header = header.Replace("@@show_URL_login_logout","#");
        header = header.Replace("@@show_class_login_logout","login-button");
        header = header.Replace("@@show_login_logout","Log in");
        header = header.Replace("@@show_URL_account","#");
        header = header.Replace("@@show_my_account","register-button");
        header = header.Replace("@@show_account_button", "Register");
    }else{
        header = header.Replace("@@show_URL_login_logout","login.aspx?logoff=true");
        header = header.Replace("@@show_login_logout","Log out");
        header = header.Replace("@@show_URL_account","sp.aspx?account");
        header = header.Replace("@@show_my_account","");
        header = header.Replace("@@show_account_button", "My Account");
    }

    //fill shopping cart
    header = fillShoppingCart(header);
    header = fillSpecialOne(header);
    
    //if(m_sRoot != "")
    //    header = ReadSitePage("dealer_page_header");

	header = ApplyCustomerAccessLevel(header);
	header = header.Replace("@@search_keyword", kw);
    //if(Request.QueryString["noCate"] == null){
    header = header.Replace("@@public_site_menu", menuLevel1());
    //}else{
     //   header = header.Replace("@@public_site_menu", "");
    //}
    
    string menuLevelNo = "";
    string level1MenuName = "";
    string level2MenuName = "";
    string level3MenuName = "";

    if(Request.QueryString["c"] != null){
        level1MenuName = Request.QueryString["c"].ToString();
    }
    if(Request.QueryString["s"] != null){
        level2MenuName = Request.QueryString["s"].ToString();
    }
    if(Request.QueryString["ss"] != null){
        level3MenuName = Request.QueryString["ss"].ToString();
    }
    if(Request.QueryString["L"] != null){
        menuLevelNo = Request.QueryString["L"].ToString();
    }

    header = header.Replace("@@navigation",navigationBar(level1MenuName,level2MenuName,level3MenuName,menuLevelNo,pageName));
    header = header.Replace("@@menu_level3",menuLevel3(level1MenuName,level2MenuName,menuLevelNo));

    header = header.Replace("@@PUBLIC_HEADER_TITLE",m_sCompanyTitle );

	header = header.Replace("@@HEADER_MENU_TOP_CAT", menu);
	header = header.Replace("@@date_now", DateTime.UtcNow.AddHours(12).ToString("D"));
	header = header.Replace("@@public_page_title", m_sCompanyTitle);
	header = header.Replace("@@companyTitle", m_sCompanyTitle);
	header = header.Replace("@@products", GetTotalProducts());
	header = header.Replace("@@rnd", "r=" + DateTime.UtcNow.AddHours(12).ToOADate());
	string login = "<a href=login.aspx?logoff=true class=d><font color=@@color_5><b>Log off</b></font></a>";
	if(!TS_UserLoggedIn())
		login = "<a href=login.aspx class=d><font color=@@color_5><b>Log on</b></font></a>";
	header = header.Replace("@@login", login);
	header = header.Replace("@@ssid_value", Request.QueryString["ssid"]);
	header = header.Replace("@@ssid", "&ssid=" + Request.QueryString["ssid"]);
	header = ApplyColor(header);
	
	if(Session["cart_total_no_gst"] == null)
		Session["cart_total_no_gst"] = 0;
	header = header.Replace("@@cart_total", (MyDoubleParse(Session["cart_total_no_gst"].ToString())).ToString("c"));
	if(Session["online_order_po_number"] == null)
		Session["online_order_po_number"] = "";
	header = header.Replace("@@cust_po_number", Session["online_order_po_number"].ToString());

	Response.Write(header);
	Response.Flush();
	return true;
}

Boolean BuildBrandsSubMenu()
{
//DEBUG("m_catablestring =", m_catTableString);
	DataSet dsCache = new DataSet();
	int rows = 0;
	string sc = "";
	//'"+ Request.QueryString["c"] +"'
	if(m_bAllowShowTopCat && Request.QueryString["c"] != null && Request.QueryString["c"] != "")
		sc += " SELECT DISTINCT cat AS s_cat, s_cat AS ss_cat FROM catalog";
	else
		sc += " SELECT s_cat, ss_cat FROM catalog";
	if(m_supplierString != "")
		sc += m_catTableString;
	if(m_bAllowShowTopCat && Request.QueryString["c"] != null && Request.QueryString["c"] != "")
		sc += " WHERE cat <> 'brands' ";//cat = '"+ Request.QueryString["c"].ToString() +"' ";
	else
		sc += " WHERE cat = 'Brands' ";
	if(m_sSite != "admin")
		sc += " AND s_cat <> 'ServiceItem' ";
	if(m_cat_access != null && m_cat_access != "" && m_cat_access != "all")
		sc += " AND s_cat " + m_cat_access + " ";
	if(m_bAllowShowTopCat && Request.QueryString["c"] != null && Request.QueryString["c"] != "")
		sc += " ORDER BY cat, ss_cat";
	else
		sc += " ORDER BY s_cat, ss_cat";
//DEBUG(" sc 1= ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsCache, "brands");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	string tpL = ReadSitePage("left_side_menu_sub_cat");
//DEBUG("tpl =", tpL);
	string srowTemplateL = GetRowTemplate(ref tpL, "menurow");
	string tpO = tpL;
	string srowL = srowTemplateL;
//DEBUG("srow s=", srowL);
	//apply view limit to left side sub menu
	string ssublimit = "";
	if(Session["cat_access_sql"] != null)
		ssublimit = Session["cat_access_sql"].ToString();
	StringBuilder sbSubSub = new StringBuilder();
	DataRow dr = null;

	string b = "-1";
	string c = "-1";
	string b_old = "-1";
	string c_old = "-1";
	int i = 0;
	for(;i<=rows;i++)
	{
		if(i<rows)
		{
			dr = dsCache.Tables["brands"].Rows[i];
			b = dr["s_cat"].ToString();
			c = dr["ss_cat"].ToString();
//		DEBUG("bran ="+b, "cat="+ c);
			Trim(ref b);
			Trim(ref c);
		}
		if(String.Compare(b, b_old, true) != 0 || i==rows)
		{
	//	DEBUG("compare =", String.Compare(b, b_old, true));
			if(sbSubSub.ToString() != "" && b_old != "-1") //end of subsub menu
			{
				sbSubSub.Append("</table>");
//				sbSubSub.Append("<!-- end of side menu -->\r\n\r\n");
				string sid = m_sCompanyName + m_sSite + "cache_leftmenu_brands_";
				sid += b_old;
				sid = sid.ToLower();
				tpL = tpL.Replace("@@template_menurow", "");
				TSAddCache(sid, tpL);
				tpL = tpO;

//				TSAddCache(sid, sbSubSub.ToString());
				sbSubSub.Remove(0, sbSubSub.Length);
				c_old = "-1";

				if(i == rows)
				{
//DEBUG("i==rows, end of leftmenu:", sid);
					break;
				}
			}

			b_old = b;

			//begin sub sub menu
//			sbSubSub.Append("<!-- begin side menu -->\r\n");
			sbSubSub.Append("<table class=n cellpadding=2 cellspacing=0 bgcolor='#EEEEEE' width=110>");
			sbSubSub.Append("<tr rowspan=3><td>&nbsp;</td></tr>");
			sbSubSub.Append("\r\n");
		}

		if(String.Compare(c, c_old, true) != 0)
		{
		//DEBUG("comparec =", String.Compare(c, c_old, true));
			string brandLink = b;
//			string ssLink = c;
			string ssName = c;
			if(b == "zzzOthers")
				brandLink = "";
			if(c == "zzzOthers")
			{
//				ssLink = "";
				ssName = "All Others";
			}

			string brand_link = "c.aspx?";
			if(m_bAllowShowTopCat && Request.QueryString["c"] != null && Request.QueryString["c"] != "")
				brand_link += "c=" + HttpUtility.UrlEncode(brandLink);
			else
				brand_link += "b=" + HttpUtility.UrlEncode(brandLink);
			
			brand_link += "&s=" + HttpUtility.UrlEncode(c);

			//	brand_link += "@@ssid";

			string sub_menu_link = brand_link;
			string sub_menu_name = ssName;
			//DEBUG("sumblimit =", ssublimit.IndexOf(sub_menu_name.ToLower()));
			if(ssublimit == "" || ssublimit.IndexOf(sub_menu_name.ToLower()) < 0)
			{			
				srowL = srowL.Replace("@@sub_menu_link", sub_menu_link);
				srowL = srowL.Replace("@@sub_menu_name", sub_menu_name);
				tpL = tpL.Replace("@@template_menurow", srowL + "@@template_menurow");
				srowL = srowTemplateL;
			}
			StringBuilder sbb = new StringBuilder();

			sbb.Append("<tr><td>&nbsp;<img src=/i/reddot.gif width=10></td><td>");
			if(m_bAllowShowTopCat && Request.QueryString["c"] != null && Request.QueryString["c"] != "")
				sbb.Append("<a href='c.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "@@ssid&c=");
			else
				sbb.Append("<a href='c.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "@@ssid&b=");
			sbb.Append(HttpUtility.UrlEncode(brandLink));
			sbb.Append("&s=");
			sbb.Append(HttpUtility.UrlEncode(c));
			sbb.Append("' class=d>");
			sbb.Append(ssName);
			sbb.Append("</a></td></tr><tr><td>&nbsp;</td></tr>");
			sbb.Append("\r\n");
			sbSubSub.Append(sbb.ToString()); 
			

			c_old = c;
		}
	}
	return true;
}

Boolean BuildMenuCache(ref string sMenu, ref string sMenuSubTables)
{
	if(!BuildBrandsSubMenu())
		return false;

	DataSet dsCache = new DataSet();
	int rows = 0;
	
	string sc = "SELECT * FROM catalog ";
	sc += " WHERE 1=1 ";
	if(m_sSite != "admin")
		sc += " AND cat <> 'ServiceItem' ";
	else if(m_supplierString != "")
		sc += " AND " + m_catTableString;
	if(m_cat_access != null && m_cat_access != "" && m_cat_access != "all")
	{
		sc += " AND s_cat " + m_cat_access + " ";
		sc += " AND cat " + m_cat_access + " "; //block main category as well
	}

	if(m_bAllowShowTopCat)
	{
		sc += " AND cat = 'brands' ";
		sc += " UNION ";
		sc += " SELECT '0' AS seq, '"+ m_sTopCatString +"' AS cat, cat as s_cat, '' as ss_cat ";
		sc += " FROM catalog ";
		sc += " WHERE cat <> 'brands' ";
		sc += " ORDER BY seq ";
	}
	else
		sc += " ORDER BY seq, LTRIM(RTRIM(cat)), LTRIM(RTRIM(s_cat)), LTRIM(RTRIM(ss_cat)) ";
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsCache, "catalog");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	string tpL = ReadSitePage("left_side_menu_sub_cat");
//DEBUG("tpl=", tpL);
	string srowTemplateL = GetRowTemplate(ref tpL, "menurow");
	string tpO = tpL;
	string srowL = srowTemplateL;

	string tp = ReadSitePage("public_header_menu_top_cat");
	if(m_sSite == "admin" || m_bDealerArea)
		tp = ReadSitePage("header_menu_top_cat");

	string tp_group = GetRowTemplate(ref tp, "menugroup");
	string sout = tp;
	string g = tp_group;
//DEBUG("tp_group=", tp_group);
	string srowTemplate = GetRowTemplate(ref g, "menurow");
	string srow = srowTemplate;
	string menu_id = "";
//DEBUG("osrow=", srow);

	//apply view limit to left side sub menu
	string ssublimit = "";
	if(Session["cat_access_sql"] != null)
		ssublimit = Session["cat_access_sql"].ToString();

	StringBuilder sbMain = new StringBuilder();
	StringBuilder sbSub = new StringBuilder();
	StringBuilder sbSubSub = new StringBuilder();

//	sbMain.Append("\r\n\r\n<!-- begin main menu -->\r\n");

	DataRow dr = null;

	string c = "-1";
	string s = "-1";
	string ss = "-1";
	string c_old = "-1";
	string s_old = "-1";
	string ss_old = "-1";
	string c_old_bak = "-1";
	string s_old_bak = "-1";
	int i = 0;
	bool bCatChanged = false;
	for(;i<=rows;i++)
	{
		bCatChanged = false;
		if(i<rows)
		{
			dr = dsCache.Tables["catalog"].Rows[i];
			c = dr["cat"].ToString();
			s = dr["s_cat"].ToString();
			ss = dr["ss_cat"].ToString();

			Trim(ref c);
			Trim(ref s);
			Trim(ref ss);

			if(String.Compare(c, c_old, true) != 0)
			{
				bCatChanged = true;
				c_old_bak = c_old;
				
				if(sbSub.ToString() != "") //end of this sub menu
				{
					if(c != null && c != "")
						menu_id = c_old;
					else
						menu_id = "_";
					g = g.Replace("@@menu_id", menu_id);
					g = g.Replace("@@template_menurow", ""); //delete the last tag
					sout = sout.Replace("@@template_menugroup", g + "@@template_menugroup");

					if(String.Compare(c_old, "brands", true) == 0)
					{
						sbSub.Append("<tr><td class=dl> <a href=m.aspx?m=brands&t=more class=d>More brands...</a></td></tr>");
					}
					sbSub.Append("</table>");
					s_old_bak = s_old;
					s_old = "-1"; 
				}

				g = tp_group;
				GetRowTemplate(ref g, "menurow"); //replace menurow with @@template_menurow
			
				srow = srowTemplate;
				sbMain.Append(MenuAddMain(c));
				c_old = c;
				
				//begin build sub menus
//				sbSub.Append("\r\n\r\n<!-- sub menu -->\r\n");
				sbSub.Append("<table border=0 class=m id='");
				if(c != null && c != "")
					sbSub.Append(c);
				else
					sbSub.Append("_");
				sbSub.Append("Menu' width=156 style='position:absolute;top:0;left:0;z-index:100;visibility:hidden' onmouseout='hideMenu()'>");
//				sbSub.Append("\r\n");
			}
		}
		if(String.Compare(s, s_old, true) != 0 || (i == rows && rows > 0) || bCatChanged)
		{
			if(sbSubSub.ToString() != "" && s != "" && c != "Brands") //end of subsub menu
			{
				if(c_old_bak == "-1")
					c_old_bak = c;
				if(s_old_bak == "-1")
					s_old_bak = s;
				sbSubSub.Append("</table>");
//				sbSubSub.Append("<!-- end of side menu -->\r\n\r\n");
				string sid = m_sCompanyName + m_sSite + "cache_leftmenu_";
				if(bCatChanged)
					sid += c_old_bak;
				else
					sid += c;
				sid += "_";
				if(bCatChanged)
					sid += s_old_bak;
				else
					sid += s_old;
				sid = sid.ToLower();
				tpL = tpL.Replace("@@template_menurow", "");
//DEBUG("sid=", sid);
//DEBUG("tpL=", tpL + "<br><br><br>");
				TSAddCache(sid, tpL);
				tpL = tpO;

//				TSAddCache(sid, sbSubSub.ToString());
				sbSubSub.Remove(0, sbSubSub.Length);
				ss_old = "-1";
				
				if(i == rows)
				{
					break;
				}
			}

			if(s != s_old)
			{
				sbSub.Append(MenuAddSub(c, s));
				s_old = s;

				bool bWriteMenu = true;
				if(String.Compare(c, "brands", true) == 0)
				{
					if(IsThisBrandShow(s) == false || s == "zzzOthers")
						bWriteMenu = false;
				}
				
				if(bWriteMenu)
				{
					string menu_link = "c.aspx?r=@@ssid&";
					if(c == "Brands")
					{
						menu_link += "b=";
						menu_link += HttpUtility.UrlEncode(s);
					}
					else if(c == m_sTopCatString)
					{	
						menu_link += "c=";
						menu_link += HttpUtility.UrlEncode(s);
					}
					else
					{
						menu_link += "c=";
						menu_link += HttpUtility.UrlEncode(c);
						menu_link += "&s=";
						menu_link += HttpUtility.UrlEncode(s);
					}
					string menu_name = s;
					if(s == "zzzOthers")
						menu_name = "All Others";

					srow = srow.Replace("@@menu_link", menu_link);
					srow = srow.Replace("@@menu_name", menu_name);
//DEBUG("fsrow=", srow);
					srow += "@@template_menurow";
					g = g.Replace("@@template_menurow", srow);
					srow = srowTemplate;
				}
			}

			//begin sub sub menu
			if(c != "Brands")
			{
				sbSubSub.Append("<table class=n cellpadding=2 cellspacing=0 bgcolor=#EEEEEE width=110>");
				sbSubSub.Append("<tr rowspan=3><td>&nbsp;</td></tr>");
				srowL = srowTemplateL;
			}
		}

		if(String.Compare(ss, ss_old, true) != 0)
		{
			if(c != "Brands")
			{
				sbSubSub.Append(MenuAddSubSub(c, s, ss)); 

				string sub_menu_link = "c.aspx?r=@@ssid&c=";
				sub_menu_link += HttpUtility.UrlEncode(c);
				sub_menu_link += "&s=";
				sub_menu_link += HttpUtility.UrlEncode(s);
				sub_menu_link += "&ss=";
				sub_menu_link += HttpUtility.UrlEncode(ss);
				string sub_menu_name = ss;
				if(ss == "zzzOthers")
					sub_menu_name = "All Others";

//if(Session["email"].ToString() == "tee@ezsoft.com")
//{DEBUG("ssublimit=", ssublimit);
//DEBUG("name=", sub_menu_name);}
				//DEBUG("infs =", ssublimit.IndexOf(sub_menu_name.ToLower()));
				if(ssublimit == "" || ssublimit.IndexOf(sub_menu_name.ToLower()) < 0)
				{
			//	DEBUG("sub_menu_name", sub_menu_name);
					srowL = srowL.Replace("@@sub_menu_link", sub_menu_link);
					srowL = srowL.Replace("@@sub_menu_name", sub_menu_name);
					tpL = tpL.Replace("@@template_menurow", srowL + "@@template_menurow");
					srowL = srowTemplateL;
				}
			}
			ss_old = ss;
		}
	}

	if(sbSub.ToString() != "")
	{
		sbSub.Append("</table>");
		sbSub.Append("\r\n\r\n");
	}

	sbSub.Append(AppendUsedCatalog());

//	sMenu = sbMain.ToString();// + sbSub.ToString();
//	sMenuSubTables = sbSub.ToString();

	menu_id = c;
	if(c != null && c != "")
		menu_id = c;
	else
		menu_id = "_";

//DEBUG("srow=", srow);
	g = g.Replace("@@menu_id", menu_id);
//	g = g.Replace("@@template_menurow", srow);
	g = g.Replace("@@template_menurow", ""); //delete the last tag
	sout = sout.Replace("@@template_menugroup", g);
//DEBUG("sout=", sout);	
	sMenu = sout;
	return true;
}

string AppendUsedCatalog()
{
	DataSet dsuc = new DataSet();
	string sc = "SELECT id, cat FROM used_catalog ORDER BY cat";
	try
	{
		//insert topic and get topic id first
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		myCommand1.Fill(dsuc, "cat");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	StringBuilder sb = new StringBuilder();
	sb.Append("<table border=0 class=m id='UsedParts");
	sb.Append("Menu' width=156 style='position:absolute;top:0;left:0;z-index:100;visibility:hidden' onmouseout='hideMenu()'>");
	for(int i=0; i<dsuc.Tables["cat"].Rows.Count; i++)
	{
		string cat = dsuc.Tables["cat"].Rows[i]["cat"].ToString();
		sb.Append("<tr><td> <a href=used.aspx?c=");
		sb.Append(HttpUtility.UrlEncode(cat));
		sb.Append(">");
		sb.Append(cat);
		sb.Append("</a></td></tr>");
	}
	sb.Append("</table>");
	return sb.ToString();
}

string MenuAddMain(string c)
{
	StringBuilder sb = new StringBuilder();

	string s = c;
	if(s == "zzzOthers")
		s = "All Others"; //display empty

//	sb.Append("<td bgcolor=#EEEEEE width=10 height=20></td>");
//	sb.Append("<td class=d bgcolor=#EEEEEE width=10 height=20></td>");
//	sb.Append("\r\n");
	sb.Append("<td nowrap id='");
	sb.Append(s);
	sb.Append("' onmouseover='setMenu(\"");
	sb.Append(s);
	sb.Append("\", \"");
	sb.Append(s);
	sb.Append("Menu\")'>");
	sb.Append("<a href=m.aspx?m=");
	sb.Append(HttpUtility.UrlEncode(c));
	sb.Append(">&nbsp;&nbsp;");
//	sb.Append(" class=d> &nbsp;");
	sb.Append(s);
	sb.Append("</a></td>");
//	sb.Append("\r\n");
	
	return sb.ToString();	
}

string MenuAddSub(string c, string s)
{
	if(String.Compare(c, "brands", true) == 0)
		if(IsThisBrandShow(s) == false || s == "zzzOthers")
			return "";
	
	StringBuilder sb = new StringBuilder();

	sb.Append("<tr><td> <a href=c.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "@@ssid&");
//	sb.Append("<tr><td nowrap class=d>&nbsp;&nbsp;<a href=c.aspx?");
	if(c == "Brands")
	{
		sb.Append("b=");
		sb.Append(HttpUtility.UrlEncode(s));
	}
	else if(c == m_sTopCatString)
	{
		sb.Append("c=");
		sb.Append(HttpUtility.UrlEncode(s));
	}
	else
	{
		sb.Append("c=");
		sb.Append(HttpUtility.UrlEncode(c));
		sb.Append("&s=");
		sb.Append(HttpUtility.UrlEncode(s));
	}
	sb.Append(">");
//	sb.Append(" class=d>");
	if(s == "zzzOthers")
		sb.Append("All Others");
	else
		sb.Append(s);
	sb.Append("</a></td></tr>");
//	sb.Append("\r\n");
	
	return sb.ToString();
}

string MenuAddSubSub(string c, string s, string ss)
{
	StringBuilder sb = new StringBuilder();

	sb.Append("<tr><td>&nbsp;<img src=rd.gif width=10></td><td>");
	sb.Append("<a href='c.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "@@ssid&c=");
	sb.Append(HttpUtility.UrlEncode(c));
	sb.Append("&s=");
	sb.Append(HttpUtility.UrlEncode(s));
	sb.Append("&ss=");
	sb.Append(HttpUtility.UrlEncode(ss));
//	sb.Append("' class=d>");
	sb.Append("'>");
	if(ss == "zzzOthers")
		sb.Append("All Others");
	else
		sb.Append(ss);
	sb.Append("</a></td></tr><tr><td>&nbsp;</td></tr>");
//	sb.Append("\r\n");

	return sb.ToString();
}

void PrintFooter()
{
	Response.Write(m_sFooter);
}

string GetTotalProducts()
{
	DataSet dscc = new DataSet();

	string sc = "SELECT count(*) AS count FROM product";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dscc, "sell");
	}
	catch(Exception e) 
	{
//		ShowExp(sc, e);
		return "";
	}
	string sell = dscc.Tables["sell"].Rows[0]["count"].ToString();

	sc = "SELECT count(*) AS count FROM product_skip";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dscc, "skip");
	}
	catch(Exception e) 
	{
//		ShowExp(sc, e);
		return "e";
	}
	string skip = dscc.Tables["skip"].Rows[0]["count"].ToString();

	int total = int.Parse(sell) + int.Parse(skip);
	return "<b>Total Items : " + total.ToString() + "</b>";
}

string GetRowTemplate(ref string tp, string sid)
{
	StringBuilder sb = new StringBuilder(); //for return
	StringBuilder sb1 = new StringBuilder();

	string begin = "<!-- BEGIN " + sid + " -->";
	string end = "<!-- END " + sid + " -->";
	int line = 0;
	string sline = "";
	bool bRead = ReadLine(tp, line, ref sline);
	bool bBegan = false;
	int protect = 999;
	while(bRead && protect-- > 0)
	{
		if(sline.IndexOf(begin) >= 0)
		{
			bBegan = true;
			sb1.Append("@@template_" + sid);

			//skip this line
			line++; 
			bRead = ReadLine(tp, line, ref sline);
		}
		if(sline.IndexOf(end) >= 0)
			bBegan = false;
		else if(bBegan)
			sb.Append(sline);
		else
			sb1.Append(sline + "\r\n");
		line++;
		bRead = ReadLine(tp, line, ref sline);
	}
	tp = sb1.ToString(); //replace template with @@template_[sid]
	return sb.ToString();
}

//return false means no more lines
bool ReadLine(string s, int n, ref string sline)
{
	StringBuilder sb = new StringBuilder();
	int lines = 0;
	int i = 0;
	for(i=0; i<s.Length && lines <= n; i++)
	{
		if(s[i] == '\r')
			lines++;
		else if(s[i] == '\n')
			continue;

		if(n == lines)
			sb.Append(s[i]);
		if(lines > n)
			break;
	}
	sline = sb.ToString();

	if(sb.ToString() == "" && i == s.Length)
		return false;
	return true;
}





//---get menu and return a string by html encode
string menuLevel1(){
    string menu = "<ul class='tree dhtml menuList1  jq-dropdown-menu'>"; 
    
    //menu body

    DataSet ds = getMenu("","",1);

    if(ds == null){
        //Response.Redirect("~/c.aspx");
        for(int i = 0; i < 8 ; i++){
            menu += "<li><a href=#\">#$#$#$#</a>";
            //call level 2 menu
            //menu += menuLevel2(dr["cat"].ToString());
            menu += "</li>";
        }
    }
    
    if(ds != null){
        DataRow dr = null;
        int rows = ds.Tables[0].Rows.Count;
        for(int i = 0; i < rows ; i++){
            dr = ds.Tables["menu"].Rows[i];
            string n = dr["cat"].ToString();
            if(n.Length > 11){
                //n = n.Substring(0, 10);
            }
            if(ShowMenu(dr["cat"].ToString())){
                menu += "<li class='menuList' data-id='c' data-value='"+dr["cat"].ToString()+"'><a href='c.aspx?L=1&c="+dr["cat"].ToString()+ssid+"' title='"+dr["cat"].ToString()+"'>"+n+"</a>";
                //call level 2 menu
                menu += menuLevel2(dr["cat"].ToString());
                menu += "</li>";
            }
        }
    }
        //menu += "<img style=\"float: left;\" alt=\"\" src=\"Images/public_site_menu_images/menu_right.png\" />";
    menu += "</ul>";   

    return menu;
}

string menuLevel2(string level1MenuName){
    string menuL2 = "";
    DataSet ds = getMenu(level1MenuName,"",2);
    if(ds == null){
        Response.Redirect("~/c.aspx");
    }
    if(ds != null){
        DataRow dr = null;
        int rows = ds.Tables[0].Rows.Count;
        dr = ds.Tables["menu"].Rows[0];
        string n = dr["s_cat"].ToString();
            if(n.Length > 11){
                //n = n.Substring(0, 10);
            }
        if(level1MenuName.ToLower() == "brands"){
             menuL2 += "<ul class='menuList2'>";
             for(int i = 0; i < rows ; i++){
                dr = ds.Tables["menu"].Rows[i];
                n = dr["s_cat"].ToString();
                if(n.Length > 11){
                    n = n.Substring(0, 10);
                }
                menuL2 += "<li class='last menuList' data-id='b' data-value='"+dr["s_cat"].ToString()+"'><a href=\"c.aspx?b="+dr["s_cat"].ToString()+ssid+"\" title='"+dr["s_cat"].ToString()+"'>"+n+"</a>";
                            //show menu 3
               // menuL2 += menuLevel3(level1MenuName, dr["s_cat"].ToString());
                menuL2 += "</li>";
                //if(i > 10){
                //    menuL2 += "<li><a href=\"c.aspx?L=1&c="+level1MenuName+"\"><b>Show More</b></a></li>";
                //    break;
                //}
                
            }
           menuL2 += "</ul>";
        }else{
        menuL2 += "<ul class='menuListHolder2'>";
            //menuL2 += "<li>";
            ////menuL2 += "<img class=\"corner_inset_left\" alt=\"\" src=\"Images/public_site_menu_images/corner_inset_left.png\" />";
            //menuL2 += "<a href=\"c.aspx?L=2&c="+level1MenuName+"&s="+dr["s_cat"].ToString()+ssid+"\" title='"+dr["s_cat"].ToString()+"'>"+n+"</a>";
            ////menuL2 += "<img class=\"corner_inset_right\" alt=\"\" src=\"Images/public_site_menu_images/corner_inset_right.png\" />";
            //menuL2 += "</li>";

            for(int i = 0; i < rows ; i++){
                dr = ds.Tables["menu"].Rows[i];
                n = dr["s_cat"].ToString();
                if(n.Length > 11){
                    //n = n.Substring(0, 10);
                }
                if(dr["s_cat"].ToString() == "zzzOthers") break;
                if(ShowMenu(level1MenuName, dr["s_cat"].ToString())){
                	String _c = Request.QueryString["c"];
                	if(_c == level1MenuName){
						menuL2 += "<li class='last menuList menuList2' data-id='c-s' data-value='"+level1MenuName+"-_-"+dr["s_cat"].ToString()+"'><a href=\"c.aspx?L=2&c="+level1MenuName+"&s="+dr["s_cat"].ToString()+ssid+"\" title='"+dr["s_cat"].ToString()+"'>"+n+"</a>";
	                            //show menu 3
	                    menuL2 +=  menuLevel3(level1MenuName, dr["s_cat"].ToString());
	                    menuL2 += "</li>";
	                    //if(i > 10){
	                    //    menuL2 += "<li><a href=\"c.aspx?L=1&c="+level1MenuName+"\"><b>Show More</b></a></li>";
	                    //    break;
	                    //}

                	}else{
                		menuL2 += "<li class='last menuList menuList2' style='display:none;' data-id='c-s' data-value='"+level1MenuName+"-_-"+dr["s_cat"].ToString()+"'><a href=\"c.aspx?L=2&c="+level1MenuName+"&s="+dr["s_cat"].ToString()+ssid+"\" title='"+dr["s_cat"].ToString()+"'>"+n+"</a>";
                            //show menu 3
	                    menuL2 +=  menuLevel3(level1MenuName, dr["s_cat"].ToString());
	                    menuL2 += "</li>";
	                    //if(i > 10){
	                    //    menuL2 += "<li><a href=\"c.aspx?L=1&c="+level1MenuName+"\"><b>Show More</b></a></li>";
	                    //    break;
	                    //}
                	}
                    
                }
                
                
            }
        menuL2 += "</ul>";

        }
    }
    return menuL2;

    
}

string menuLevel3(string level1MenuName, string level2MenuName){
    string menuL3 = "";
    
    if(level2MenuName == "zzzOthers") return "";
    level1MenuName = level1MenuName.Replace("%20"," ");
    level2MenuName = level2MenuName.Replace("%20"," ");
    DataSet ds = getMenu(level1MenuName,level2MenuName,3);
    if(ds == null){
        return "";
    }
    DataRow dr = null;
    int rows = ds.Tables["menu"].Rows.Count;
    dr = ds.Tables["menu"].Rows[0];
    if(rows > 0){
        menuL3 += "<ul  class='menuListHolder3'>";
        for(int i = 0; i < rows ; i++){
                dr = ds.Tables["menu"].Rows[i];
                string n = dr[0].ToString();
                if(n.Length > 11){
                    //n = n.Substring(0, 10);
                }
            if(dr[0].ToString() == "zzzOthers") break;
            if(ShowMenu(level1MenuName, level2MenuName, dr[0].ToString())){
                menuL3 += "<li class='last menuList3 menuList' style='display:none;' data-id='c-s-ss' data-value='"+level1MenuName+"-_-"+level2MenuName+"-_-"+ dr[0].ToString() +"'><a style='display: block;margin: 4px;' href=\"c.aspx?L=2&c="+level1MenuName+"&s="+level2MenuName+"&ss="+dr[0].ToString()+ssid+"\" title='"+dr[0].ToString()+"'>"+n+"</a></li>";
            }
            
        }
        menuL3 += "</ul>";
    }


    return menuL3;
}


string menuLevel3(string level1MenuName, string level2MenuName, string levelNo){
    string menuL3 = "";

    if(levelNo == "2"){

        DataSet ds = getMenu(level1MenuName,level2MenuName,3);
        if(ds == null){
            Response.Redirect("~/c.aspx");
        }

        DataRow dr = null;
        int rows = ds.Tables[0].Rows.Count;
        menuL3 += "       <div class='level3menuHolder' id='categories'>";
        menuL3 += "              <div class=\"container\">";
        menuL3 += "                  <div class=\"panel\">";
        menuL3 += "                     <div class=\"t-o b1\">";
        menuL3 += "                     </div>";
        menuL3 += "                     <div class=\"t-o b2\">";
        menuL3 += "                    </div>";
        menuL3 += "                   <div class=\"t-o b3\">";
        menuL3 += "                     </div>";
        menuL3 += "                      <div class=\"t-o b4\">";
        menuL3 += "                       </div>";
        menuL3 += "                      <div class=\"content\">";
        menuL3 += "<table>";
        int i = 0;
        for( int j = 0; j < rows ; j++){
            if(i == 0 ){
                menuL3 += "<tr>";
            }
            dr = ds.Tables["menu"].Rows[j];
            menuL3 += "<td><a href=\"c.aspx?L=3&c="+level1MenuName+"&s="+level2MenuName+"&ss="+dr["ss_cat"].ToString()+ssid+"\">"+dr["ss_cat"].ToString()+"</a></td>";
            if( i > 7 || (j + 1) == rows){
                menuL3 += "</tr>";
                i = 0;
            }else{
              i++;
            }
        }
        menuL3 += "</table>";

        menuL3 += "                    </div>";
        menuL3 += "                   <div class=\"b-o b4\">";
        menuL3 += "                   </div>";
        menuL3 += "                   <div class=\"b-o b3\">";
        menuL3 += "                    </div>";
        menuL3 += "                   <div class=\"b-o b2\">";
        menuL3 += "                   </div>";
        menuL3 += "                   <div class=\"b-o b1\">";
        menuL3 += "                   </div>";
        menuL3 += "                   <div class=\"break\">";
        menuL3 += "                   </div>";
        menuL3 += "               </div>";
        menuL3 += "          </div>";
        menuL3 += "      </div>";


    }else  if(levelNo == "1"){
        DataSet ds = getMenu(level1MenuName,level2MenuName,2);
        if(ds == null){
            Response.Redirect("~/c.aspx");
        }

        DataRow dr = null;
        int rows = ds.Tables[0].Rows.Count;


        menuL3 += "       <div class='level3menuHolder' id='categories'>";
        menuL3 += "              <div class=\"container\">";
        menuL3 += "                  <div class=\"panel\">";
        menuL3 += "                     <div class=\"t-o b1\">";
        menuL3 += "                     </div>";
        menuL3 += "                     <div class=\"t-o b2\">";
        menuL3 += "                    </div>";
        menuL3 += "                   <div class=\"t-o b3\">";
        menuL3 += "                     </div>";
        menuL3 += "                      <div class=\"t-o b4\">";
        menuL3 += "                       </div>";
        menuL3 += "                      <div class=\"content\">";
        menuL3 += "<table>";
        int i = 0;
        for( int j = 0; j < rows ; j++){
            if(i == 0 ){
                menuL3 += "<tr>";
            }
            dr = ds.Tables["menu"].Rows[j];
            menuL3 += "<td><a href=\"c.aspx?L=2&c="+level1MenuName+"&s="+dr["s_cat"].ToString()+ssid+"\">"+dr["s_cat"].ToString()+"</a></td>";
            if( i > 7 || (j + 1) == rows){
                menuL3 += "</tr>";
                i = 0;
            }else{
              i++;
            }
        }
        menuL3 += "</table>";
    }


    return menuL3;
}



DataSet getMenu(string level1MenuName,string level2MenuName, int level){
    DataSet menuSet = new DataSet();
    string sc = "";
    
    if(level == 1){
        sc = "SELECT DISTINCT cat , SEQ";
        sc += " FROM catalog";
        sc += " order by seq ASC";
    }else if(level == 2){
        sc = "SELECT DISTINCT s_cat, seq";
        sc += " FROM catalog";
        sc += " where cat='"+level1MenuName+"'";
        sc += " order by seq ASC";
    }else if(level == 3){
        sc = "SELECT DISTINCT ss_cat, seq";
        sc += " FROM catalog";
        sc += " where s_cat='"+level2MenuName+"' and cat='"+level1MenuName+"'";
        sc += " order by seq ASC";
    }

//DEBUG("menu query = ", sc);

    SqlDataAdapter myAdapter;
    int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(menuSet, "menu");

        if(rows == 0){
            return null;
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return null;
	}
    return menuSet;
}

string getMenuFatherName(string level2Name, string level3Name, int level){
    DataSet ds = new DataSet();

    string value = "";
    string sc = "";
    if(level == 2){//find menu level 1 
      sc += "      SELECT DISTINCT cat AS name";
      sc += "      FROM catalog";
      sc += "      where s_cat = '"+level2Name+"'";
      sc += "      order by seq";
    }else if(level == 3){//find menu level 2
      sc += "      SELECT DISTINCT s_cat AS name";
      sc += "      FROM catalog";
      sc += "      where ss_cat = '"+level3Name+"' and s_cat='"+level2Name+"'";
      sc += "      order by seq";
    }else if(level == 4){//find menu level 1 from menu level 3
      sc += "      SELECT DISTINCT cat AS name";
      sc += "      FROM catalog";
      sc += "      where s_cat = '"+level2Name+"' and ss_cat='"+level3Name+"'";
      sc += "      order by seq";
Response.Write(sc + "<br />");

    }else{
        return "";
    }


    SqlDataAdapter myAdapter;
    int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "fatherMenuName");

        if(rows == 0){
            return "";
        }
        DataRow dr =  null;
        int jj = 0;
        bool isLoop = true;
        while(isLoop && jj < rows){
            dr =  ds.Tables["fatherMenuName"].Rows[jj];
            value = dr["name"].ToString();
            if(value == "Brands"){
                jj++;
            }else{
                isLoop = false;
            }
        }
        
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}


    return value;
}

string navigationBar(string level1Name, string level2Name, string level3Name, string level, string pageName){
    string navigationS = "";

    //navigationS += "<a href='c.aspx'>Home</a>";
    if(level == "1"){
        navigationS += "<a href=\"c.aspx?L=1&c="+level1Name+"\">"+level1Name+"</a>";
    }else if(level == "2"){
        navigationS += "<a href=\"c.aspx?L=1&c="+level1Name+"\">"+level1Name+"</a> > <a href=\"c.aspx?L=2&c="+level1Name+"&s="+level2Name+"\">"+level2Name+"</a>";
    }else if(level == "3"){
        navigationS += "<a href=\"c.aspx?L=1&c="+level1Name+"\">"+level1Name+"</a> > <a href=\"c.aspx?L=2&c="+level1Name+"&s="+level2Name+"\">"+level2Name+"</a> > <a href=\"c.aspx?L=3&c="+level1Name+"&s="+level2Name+"&ss="+level3Name+"\">"+level3Name+"</a>";
    }else{
        navigationS += "<a href=\"#\">"+pageName+"</a>";
    }


    return navigationS;

}


string fillShoppingCart(string value){
    DataTable shoppingCart = new DataTable();

	string ssid = "";
	if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
		ssid = Request.QueryString["ssid"];

	if(Session["ShoppingCart" + ssid] == null) 
	{
		shoppingCart = new DataTable();
		shoppingCart.Columns.Add(new DataColumn("site", typeof(String)));	//site identifier, m_sCompanyName
//		dtCart.Columns.Add(new DataColumn("id", typeof(String)));	//class identifier, for sales, purchase etc.
		shoppingCart.Columns.Add(new DataColumn("kid", typeof(String)));	//purchase/sales order item kid
		shoppingCart.Columns.Add(new DataColumn("code", typeof(String)));	//product code
		shoppingCart.Columns.Add(new DataColumn("name", typeof(String)));	//product code
		shoppingCart.Columns.Add(new DataColumn("quantity", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("system", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("kit", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("used", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("supplierPrice", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("salesPrice", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("supplier", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("supplier_code", typeof(String)));
		shoppingCart.Columns.Add(new DataColumn("s_serialNo", typeof(String)));
		Session["ShoppingCart" + ssid] = shoppingCart;
	}else
	{
		shoppingCart = (DataTable)Session["ShoppingCart" + ssid];
	}

        double dSubTotal = 0;
        string eachItem = "";
        if(shoppingCart.Rows.Count<=0){
            eachItem = "";
        }   
        for(int i=0; i<shoppingCart.Rows.Count; i++)
		{
			DataRow drc = shoppingCart.Rows[i];

			string code = drc["code"].ToString();
			string supplier_code = drc["supplier_code"].ToString();
			string name = drc["name"].ToString();
            if(name.Length  > 10){
                name = name.Substring(0, 10);
            }
			int quantity = MyIntParse(drc["quantity"].ToString());
            double theGST = MyDoubleParse(GetSiteSettings("gst_rate_percent", "10.0")) / 100;
			double dPrice = Math.Round(MyDoubleParse(drc["salesPrice"].ToString()), 3);

            dPrice = dPrice ;//* (1 + theGST);
			double dRowTotal = Math.Round(dPrice * quantity, 3);
            dRowTotal = CheckPriceIf99(dRowTotal);
			dSubTotal += dRowTotal;
            if(i < 5){
                eachItem += "<dt id=\"cart_block_product_21\" class=\"first_item\">";
                eachItem += "<a class='cart_block_product_name' href='p.aspx?"+code+"' title='' >"+name+" </a>";
                eachItem += "<span class=\"quantity-formated\">";
                eachItem += "      &nbsp;&nbsp; X  <span  class=\"quantity\">"+quantity.ToString()+"</span> ";
                eachItem += "</span>";
                eachItem += "<span class=\"price\">$"+dRowTotal.ToString()+"</span> ";
                eachItem += "</dt>";
            }
         }
        value = value.Replace("@@product_count",shoppingCart.Rows.Count.ToString());
        value = value.Replace("@@shopping_cart_items", eachItem);  
        value = value.Replace("@@TotalPrice", dSubTotal.ToString());
        return value;
}

string fillSpecialOne(string value){
    //get all specials
    DataSet productDs = new DataSet();
    string sqlString = "select * from product where code in (select code from specials)";

    try
    {
        SqlDataAdapter myCommand = new SqlDataAdapter(sqlString, myConnection);
        myCommand.Fill(productDs, "product");

    //randmoize show one special
        System.Random r = new Random();
        int i = r.Next(0, productDs.Tables["product"].Rows.Count);
        DataRow dr = productDs.Tables["product"].Rows[i];
    
        string src = GetProductImgSrc(dr["code"].ToString());
        src = src.Replace("na.gif", "0.gif");
        string name = dr["name"].ToString();
        if(name.Length > 10){
            name = name.Substring(0,9);
        }
        value = value.Replace("@@special_one_code",dr["code"].ToString());
        value = value.Replace("@@special_one_name",name);
        value = value.Replace("@@specials_one_image",src);
    
        double dRRP = 0;
        double dDealerPrice = 0;
        DataRow drp = null;
        if (m_sRoot == "")
	    {
                if(GetProduct(dr["code"].ToString(), ref drp))
                {
                    dRRP = MyDoubleParse(drp["rrp"].ToString());
                    if(dRRP == 0)
	                    dRRP = MyDoubleParse(drp["manual_cost_nzd"].ToString()) * MyDoubleParse(drp["rate"].ToString()) * MyDoubleParse(drp["level_rate1"].ToString()) * 1.1;
               }
                value = value.Replace("@@specials_one_price",dRRP.ToString("n")); 
	    }else{
            int m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "dealer_level"].ToString());
            dDealerPrice = GetSalesPriceForDealer(dr["code"].ToString(),"1",m_nDealerLevel.ToString(),Session["card_id"].ToString());
            value = value.Replace("@@specials_one_price",dDealerPrice.ToString("n") + "  Inc GST"); 
        }
    }
    catch(Exception e) 
    {
        value = value.Replace("@@special_one_code","");
        value = value.Replace("@@special_one_name","");
        value = value.Replace("@@specials_one_image","");
        value = value.Replace("@@specials_one_price","");
        return value;
    }
    


    return value;
}
</script>

