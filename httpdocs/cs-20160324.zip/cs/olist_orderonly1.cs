<!-- #include file="card_function.cs" -->
<!-- #include file="page_index.cs" -->
<script runat="server">

int m_cols = 6;

string m_orderType = ""; //order
string m_action = "";
string m_id = "";
string m_kw = "";
bool m_bPIAList = false;
bool m_bSystem = false;
bool m_bListWaitingPayment = false;
DataSet ds = new DataSet();

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("sales"))
		return;

	if(Request.QueryString["wp"] == "1")
		m_bPIAList = true;

	if(Request.QueryString["ot"] != null && Request.QueryString["ot"] != "")
		m_orderType = Request.QueryString["ot"];

	if(Request.QueryString["system"] == "1")
	{
		m_bSystem = true;
	}
	else if(Request.QueryString["system"] == "0")
	{
		m_bSystem = false;
	}

	m_action = Request.QueryString["a"];
	m_id = Request.QueryString["id"];

	if(m_action == "process")
	{
		OrderOnlyDoProcessOrder();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=olist.aspx?t=");
		Response.Write(Request.QueryString["t"] + "\">");
		return;
	}
	else if(m_action == "delete")
	{
		OrderOnlyDoDeleteOrder();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=olist.aspx?t=");
		Response.Write(Request.QueryString["t"] + "\">");
		return;
	}
	else if(m_action == "u") //unlock
	{
		DoUnlock(m_id);
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=olist.aspx?t=");
		Response.Write(Request.QueryString["t"] + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
		return;
	}
	else if(Request.QueryString["kw"] != null && Request.QueryString["kw"] != "")
	{
		m_kw = Request.QueryString["kw"];
		Session["order_list_search_kw"] = m_kw;
	}

	PrintAdminHeader();
	PrintAdminMenu();

	if(Request.QueryString["id"] != null) //view perticular order
	{
		if(!GetOneOrder())
			return;
	}
	if(GetOrders())
		BindGrid();
	PrintAdminFooter();
}

bool DoUnlock(string id)
{
	string sc = " UPDATE orders SET locked_by=null, time_locked=null ";
	sc += " WHERE id=" + id;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

Boolean GetOrders()
{
	bool bWhereAdded = false;
	string sc = " SELECT * FROM (";
	sc += "SELECT o.*, i.paid AS ipaid, c.name, c.company, c.trading_name, c.email, c1.name AS lockedby ";
	sc += ", DATEDIFF(day, o.time_locked, GETDATE()) AS days_locked ";
	sc += ", c.credit_term, c.balance, d.name AS sales_name ";
	sc += ", (SELECT SUM(commit_price * quantity) FROM order_item WHERE id=o.id) AS amount ";
	sc += " FROM orders o LEFT OUTER JOIN card c ON c.id=o.card_id LEFT OUTER JOIN card d ON d.id=o.sales ";
	sc += " LEFT OUTER JOIN invoice i ON i.invoice_number = o.invoice_number ";
	sc += " LEFT OUTER JOIN card c1 ON c1.id=o.locked_by ";
	if(m_kw != "")
	{
		sc += " WHERE (o.po_number LIKE '%" + m_kw + "%' OR o.number LIKE '%" + m_kw + "%' OR o.invoice_number LIKE '%" + m_kw + "%' ";
		sc += " OR c.name LIKE '%" + m_kw + "%' OR c.trading_name LIKE '%" + m_kw + "%') ";
	}
	else if(Request.QueryString["t"] != null && Request.QueryString["t"] != "")
		sc += " WHERE o.status=" + Request.QueryString["t"];
	sc += " ) DERIVEDTBL ";
	if((m_kw == null || m_kw == "") && Request.QueryString["t"] == "1" && m_bListWaitingPayment)
	{
		if(!m_bPIAList)
			sc += " WHERE (credit_term NOT IN (1, 2) OR (credit_term IN (1, 2) AND amount + balance <= 0)) ";
		else
			sc += " WHERE ((credit_term IN (1, 2) AND amount + balance > 0 ) OR credit_term is null OR amount is null ) ";
		bWhereAdded = true;
	}
	if(m_bSystem)
	{
		if(bWhereAdded)
			sc += " AND ";
		else
			sc += " WHERE ";
		sc += " system = 1 ";
		if(m_orderType != "")
			sc += " AND type=" + m_orderType;
	}
	else if(m_kw == null || m_kw == "")
	{
		if(bWhereAdded)
			sc += " AND ";
		else
			sc += " WHERE ";
		sc += " type=2 "; //display Order only, ignore quote
	}
	sc += " ORDER BY number DESC, id DESC";
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(ds, "order");
		return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void BindGrid()
{
	Response.Write("<br><center><h3>");
	if(m_bSystem)
	{
		Response.Write("Quotation List - <font color=red>");
		if(m_orderType == "1")
			Response.Write("Quote");
		else if(m_orderType == "2")
			Response.Write("Order");
		else
			Response.Write("ALL");
	} 
	else
	{
		Response.Write("Order List - ");
		Response.Write("<font color=red>");
//		if(Request.QueryString["t"] == "7")
//			Response.Write("Deleted");
		if(Request.QueryString["t"] == "8")
			Response.Write("Done");
		else if(m_bPIAList)
			Response.Write("Waiting For Payment");
		else if(Request.QueryString["t"] != null && Request.QueryString["t"] != "")
			Response.Write(GetEnumValue("order_item_status", Request.QueryString["t"]));
		else
			Response.Write("ALL");
	}
	Response.Write("</font></h3>");
	Response.Write("<table width=100%>");
	
	Response.Write("<form name=f action=olist.aspx method=get>");
	Response.Write("<tr><td>");
	Response.Write("<input type=text size=10 name=kw autocomplete=off value='" + Session["order_list_search_kw"] + "'>");
	Response.Write("<input type=submit " + Session["button_style"] + " name=cmd value='Search Order'>");
	Response.Write("</td>");

	Response.Write("<script");
	Response.Write(">");
	Response.Write("document.f.kw.focus();");
	Response.Write("</script");
	Response.Write(">");

	Response.Write("<td align=right>");
	if(g_bEnableQuotation)
		Response.Write("<img src=r.gif> <a href=olist.aspx?system=1 class=o>SysQuote</a>&nbsp&nbsp&nbsp&nbsp;");
	if(m_bListWaitingPayment)
		Response.Write("<img src=r.gif> <a href=olist.aspx?t=1&wp=1 class=o>Waiting Payment</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=1 class=o>Being Processed</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=2 class=o>Invoiced</a>&nbsp&nbsp&nbsp&nbsp;");
/*	Response.Write("<img src=r.gif> <a href=olist.aspx?t=3 class=o>Shipped</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=4 class=o>BackOrder</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=5 class=o>OnHold</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=6 class=o>Credit</a>&nbsp&nbsp&nbsp&nbsp;");
*/
	Response.Write("<img src=r.gif> <a href=olist.aspx?t=0 class=o>Deleted</a>&nbsp&nbsp&nbsp&nbsp;");
	Response.Write("<img src=r.gif> <a href=olist.aspx? class=o>All</a> ");

	Response.Write("</td></tr>");
	Response.Write("</form>");

	Response.Write("<tr><td colspan=2>");
	Response.Write("<table width=100% align=center cellspacing=1 cellpadding=1 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>");
	Response.Write("<th>Sales</th>");
	Response.Write("<th>Date</th>");
	Response.Write("<th>Customer</th>");
	Response.Write("<th>Term</th>");
	Response.Write("<th>Customer#</th>");
//	Response.Write("<th>Invoice#</th>");
	Response.Write("<th>Shipping</th>");
	Response.Write("<th>Our#</th>");
//	Response.Write("<th>Locked By</th>");
	Response.Write("<th>Action</th>");
	Response.Write("</tr>");

	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
	int rows = ds.Tables["order"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?";
	m_cPI.PageSize = 20;
	if(Request.QueryString["t"] != null && Request.QueryString["t"] != "")
		m_cPI.URI += "t=" + Request.QueryString["t"];
	if(Request.QueryString["wp"] != null)
		m_cPI.URI += "&wp=" + Request.QueryString["wp"];
	if(m_bSystem)
		m_cPI.URI += "&system=1";
	int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	if(rows <= 0)
	{
		Response.Write("</table>");
		return;
	}

	bool bAlterColor = false;
	string bgc = GetSiteSettings("table_row_bgcolor", "#EEEEEE");
	string sbgc = GetSiteSettings("sys_quote_bgcolor", "#AAFFFF");
	string sbgcl = GetSiteSettings("sys_quote_bgcolor_light", "#DDFFFF");
	for(; i < rows && i < end; i++)
	{
		DataRow dr = ds.Tables["order"].Rows[i];
		string id = dr["id"].ToString();
		bool bPaid = false;
//		string paid = dr["paid"].ToString();
//		if(paid != "")
//			bPaid = bool.Parse(paid);
		bool biPaid = false;
		string ipaid = dr["ipaid"].ToString();
		if(ipaid != "")
			biPaid = bool.Parse(ipaid);
		string email = dr["email"].ToString();
//		string purchase_id = dr["purchase_id"].ToString();
		string card_id = dr["card_id"].ToString();
		string sales = dr["sales_name"].ToString();
		string invoice_number = dr["invoice_number"].ToString();
		string order_number = dr["number"].ToString();
		string po_number = dr["po_number"].ToString();
		string part = dr["part"].ToString();
		string credit_term = dr["credit_term"].ToString();
		if(credit_term != "")
			credit_term = GetEnumValue("credit_terms", dr["credit_term"].ToString());
		if(credit_term == "cash only")
			credit_term = "<font color=red><b>Cash Only</b></font>";
		else if(credit_term == "pay in advance")
			credit_term = "<b>P.I.A.</b>";
		else if(credit_term.IndexOf("20th") >= 0)
			credit_term = "20th";
		else 
			credit_term = credit_term.ToUpper();
//		string payment_type = dr["payment_type"].ToString();
//		if(payment_type != "")
//			payment_type = GetEnumValue("payment_method", payment_type);

//		bool bSystem = bool.Parse(dr["system"].ToString());

		string company = dr["trading_name"].ToString();
		if(company == "")
			company = dr["trading_name"].ToString();
		if(company == "")
			company = dr["name"].ToString();

		string date = DateTime.Parse(dr["record_date"].ToString()).ToString("dd-MM HH:mm");
		string shipping_method = GetEnumValue("shipping_method", dr["shipping_method"].ToString());
		shipping_method = shipping_method.ToUpper();
		string p_time = dr["pick_up_time"].ToString();
		string sm_title = shipping_method; //shipping_method title
		if(shipping_method == "PICK UP")
		{
			shipping_method = "<font color=green>Pick Up ";
			string p_stime = p_time;
			shipping_method += p_stime + "</font>";
			sm_title = "Pick Up : " + p_time;
		}
		else if(shipping_method == "SUB60")
			shipping_method = "<font color=red>" + shipping_method + "</font>";
		else if(shipping_method == "2 DAYS COURIER")
			shipping_method = "<font color=blule>2 Days Courier</font>";
		else if(shipping_method == "OVERNIGHT COURIER")
			shipping_method = "<font color=purple>Overnight Courier</font>";
		else if(shipping_method == "LOCAL(AKL) COURIER")
			shipping_method = "Local(AKL) Courier";

		string status = GetEnumValue("order_item_status", dr["status"].ToString());
		string statusPlus = status;
		if(status == "Shipped")
			statusPlus += " " + DateTime.Parse(dr["date_shipped"].ToString()).ToString("dd-MM-yyyy HH:mm");
		
		string locker_id = dr["locked_by"].ToString();
		string lockedby = dr["lockedby"].ToString();
		int days_locked = 0;
		int auto_unlock = MyIntParse(GetSiteSettings("auto_unlock_order_after_days", "2"));
		if(lockedby != "")	
		{
			string time_locked = dr["time_locked"].ToString();
			if(time_locked != "")
				time_locked = DateTime.Parse(time_locked).ToString("HH:mm");
			lockedby = "<font color=red><b>" + lockedby + "</b></font> " + time_locked;
			days_locked = MyIntParse(dr["days_locked"].ToString());
			if(days_locked >= auto_unlock)
				lockedby += " (" + days_locked.ToString() + " days)";
		}
		if(days_locked >= auto_unlock)
		{
			DoUnlock(id);
		}

		Response.Write("<tr");
/*		if(bSystem)
		{
			if(m_bSystem)
			{
				if(bAlterColor)
					Response.Write(" bgcolor=" + sbgc);
				else 
					Response.Write(" bgcolor=" + sbgcl);
			}
			else 
			{
				Response.Write(" bgcolor=" + sbgc);
			}
		}
		else
*/
		{
			if(bAlterColor)
				Response.Write(" bgcolor=" + bgc);
		}
		bAlterColor = !bAlterColor;

		Response.Write(">");
		Response.Write("<td>" + sales + "</td>");
		Response.Write("<td align=center>" + date + "</td>");
		Response.Write("<td>" + company + "</td>");
		Response.Write("<td>" + credit_term + "</td>");
		Response.Write("<td>" + po_number + "</td>");
/*		Response.Write("<td>");
		if(invoice_number != "")
		{
			Response.Write("<a href=invoice.aspx?" + invoice_number + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
			Response.Write(" class=o target=_blank title='click to view invoice'>" + invoice_number + "</a>");
			Response.Write(" <a href=invoice.aspx?n=" + invoice_number + "&confirm=1&email=" + HttpUtility.UrlEncode(email));
			Response.Write(" class=o target=_blank title='Email Invoice to customer'>M</a>");

			Response.Write(" <a href=pack.aspx?i=" + invoice_number + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
			Response.Write(" target=_blank title='click to view packing slip' class=o>PKS</a>");
			Response.Write(" <a href=pack.aspx?i=" + invoice_number + "&confirm=1&email=" + HttpUtility.UrlEncode(email));
			Response.Write(" target=_blank title='Email Packing Slip to customer' class=o>M</a>");
		}
		Response.Write("</td>");
*/
		Response.Write("<td align=center title=\"" + sm_title + "\">" + shipping_method + "</td>");
		Response.Write("<td><a href=olist.aspx?");
		if(Request.QueryString["id"] == id)
			Response.Write("r=" + DateTime.UtcNow.AddHours(12).ToOADate());
		else
			Response.Write("id=" + id);
		if(m_bPIAList)
			Response.Write("&wp=1");
		if(Request.QueryString["t"] != null)
			Response.Write("&t=" + Request.QueryString["t"]);
		if(Request.QueryString["ot"] != null)
			Response.Write("&ot=" + Request.QueryString["ot"]);
		if(Request.QueryString["p"] != null)
			Response.Write("&p=" + Request.QueryString["p"]);
		if(Request.QueryString["spb"] != null)
			Response.Write("&spb=" + Request.QueryString["spb"]);
		if(m_kw != "")
			Response.Write("&kw=" + HttpUtility.UrlEncode(m_kw));
		Response.Write("&system=" + Request.QueryString["system"]);
		Response.Write(" class=o>" + order_number);
		if(part != "0")
			Response.Write("." + part);
		Response.Write("</a>");
		Response.Write(" <a href=invoice.aspx?t=order&id=" + id + " class=o title='Print Order' target=_blank>V</a>");
		Response.Write("</td>");

		bool bLocked = false;
		if(locker_id != "" && locker_id != Session["card_id"].ToString())
			bLocked = true;

		//locked by
//		Response.Write("<td>" + lockedby + "</td>");
		string sAction = "";
/*
		if(status == "Invoiced")
		{
			sAction += "<a href=esales.aspx?i=" + invoice_number + " class=o title=Process>Process</a> ";
		}
		else if(status == "Shipped" || status.IndexOf("Returned") >= 0)
		{
		}
		else if(!bLocked)
		{
			if(!m_bPIAList && Request.QueryString["t"] != null && Request.QueryString["t"] != "")
			{
				sAction += "<a href=eorder.aspx?id=" + id + "&part=" + part + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o title=Process>Process</a> ";
			}
			else
			{
			}
		}

		if(locker_id != "")
		{
			if(locker_id == Session["card_id"].ToString())
			{
				sAction += "<a href=olist.aspx?a=u&id=" + id + "&t=" + Request.QueryString["t"];
				sAction += "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o title=Unlock>Unlock</a> ";
			}
		}
		if(SecurityCheck("manager", false) 
			&& (status == "Being Processed" || status == "Back Ordered" || status == "On Hold")
			&& Session["access_level"] != GetEnumID("access_level", "stockman")
			&& !bLocked)
		{
			string uri = "pos.aspx?id=" + id;
			sAction += "<a href=" + uri + " class=o title=Edit><font color=black>E</font></a> ";
		}
*/
		if(Request.QueryString["t"] == "1")
			sAction = "<input type=button onclick=window.location='olist.aspx?a=process&id=" + id + "&t=" + Request.QueryString["t"] + "' value='Process' " + Session["button_style"] + ">";
		if(Request.QueryString["t"] != "1" && Request.QueryString["t"] != "0")
			sAction += "<input type=button onclick=window.location='olist.aspx?a=delete&id=" + id + "&t=" + Request.QueryString["t"] + "' value='Delete' " + Session["button_style"] + ">";
		Response.Write("<td nowrap>" + sAction + "</td>");
		Response.Write("</tr>");

		if(Request.QueryString["id"] != null && id == Request.QueryString["id"])
		{
			Response.Write("<tr><td colspan=9 align=center>");
			PrintOneOrderStatus();
			Response.Write("<br>&nbsp;</td></tr>");
		}
	}
	Response.Write("<tr><td colspan=6>" + sPageIndex + "</td></tr>");
//	Response.Write(PrintPageIndex());
	Response.Write("</table>");

	Response.Write("</td></tr></table>");
}

bool GetOneOrder()
{
	string sc = "SELECT o.number, o.part, o.contact, o.po_number, o.status, o.freight ";
	sc += ", o.invoice_number, o.date_shipped, o.sales_note, c.gst_rate, i.* ";
	sc += " FROM orders o JOIN order_item i ON i.id=o.id ";
	sc += " LEFT OUTER JOIN card c ON c.id = o.card_id ";
	sc += " WHERE o.id=" + Request.QueryString["id"];
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(ds, "one");
		return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void PrintOneOrderStatus()
{
//	Response.Write("<br><center><h3>Order Information</h3>");
	Response.Write("<table width=90% valign=center cellspacing=1 cellpadding=1 border=1 bordercolor=#000000 bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr style=\"color:white;background-color:#444444;font-weight:bold;\">");
	Response.Write("<th>Code</th>");
	Response.Write("<th>M_PN</th>");
	Response.Write("<th>Description</th>");
	Response.Write("<th>Quantity</th>");
	Response.Write("<th>Status</th>");
	Response.Write("<th>Amount</th>");
	Response.Write("</tr>");
/*
	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
	int rows = ds.Tables["one"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?r=" + DateTime.UtcNow.AddHours(12).ToOADate();
	int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();
*/
	int rows = ds.Tables["one"].Rows.Count;
	if(rows <= 0)
	{
		Response.Write("</table>");
		return;
	}

	double dGstRate = 0.15;
	string gst_rate = ds.Tables["one"].Rows[0]["gst_rate"].ToString();
	if(gst_rate != "")
		dGstRate = MyDoubleParse(gst_rate);
	double dTotal = 0;
	double dTax = 0;
	bool bAlterColor = false;
//	for(; i < rows && i < end; i++)
	DataRow dr = null;
	for(int i=0; i < rows; i++)
	{
		dr = ds.Tables["one"].Rows[i];
		string code = dr["code"].ToString();
		string m_pn = dr["supplier_code"].ToString();
		string name = dr["item_name"].ToString();
		string quantity = dr["quantity"].ToString();
		string price = dr["commit_price"].ToString();
		double dAmount = MyDoubleParse(price) * MyIntParse(quantity);
//		string  = dr[""].ToString();
//		string invoice_number = dr["invoice_number"].ToString();
//		string order_number = dr["number"].ToString();
//		string po_number = dr["po_number"].ToString();
//		string part = dr["part"].ToString();
//		string contact = dr["contact"].ToString();
//		string date = DateTime.Parse(dr["record_date"].ToString()).ToString("dd-MM-yyyy HH:mm");
		string status = GetEnumValue("order_item_status", dr["status"].ToString());
		if(status == "Shipped")
			status += " " + DateTime.Parse(dr["date_shipped"].ToString()).ToString("dd-MM-yyyy HH:mm");
		
		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=#EEEEEE");
		bAlterColor = !bAlterColor;

		Response.Write(">");
		Response.Write("<td>" + code + "</td>");
		Response.Write("<td>" + m_pn + "</td>");
		Response.Write("<td nowrap><a href=p.aspx?" + code + " target=_blank>" + name + "</a></td>");
		Response.Write("<td>" + quantity + "</td>");
		Response.Write("<td nowrap>" + status + "</td>");
		Response.Write("<td nowrap align=right>" + dAmount.ToString("c") + "</td>");
		Response.Write("</tr>");
		dTotal += dAmount;
	}
	double dFreight = 0;
	if(dr["freight"].ToString() != "")
	{
		dFreight = MyDoubleParse(dr["freight"].ToString());
		dTotal += dFreight;
	}
	dTax = dTotal * dGstRate;

	Response.Write("<tr><td colspan=6 align=right>");

	Response.Write("<table cellspacing=1 cellpadding=1 border=0 bordercolor=#000000 bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
//	Response.Write("<tr><td align=right><b>Sub Total : </b></td><td align=right>" + dTotal.ToString("c") + "</td></tr>");
//	Response.Write("<tr><td align=right><b>Tax : </b></td><td align=right>" + dTax.ToString("c") + "</td></tr>");
	Response.Write("<tr><td align=right><b>Total Amount : </b></td><td align=right>" + (dTotal + dTax).ToString("c") + "</td></tr>");
	Response.Write("</table>");

	Response.Write("</td></tr>");

	string note = dr["sales_note"].ToString();
	if(note != "")
	{
		note = note.Replace("\r\n", "\r\n<br>");
		Response.Write("<tr><td colspan=6><table cellspacing=0 cellpadding=0>");
		Response.Write("<tr><td valign=top><b>Comment : &nbsp&nbsp;</b></td>");
		Response.Write("<td colspan=5><font color=red>" + note + "</font></td></tr>");
		Response.Write("</table></td></tr>");
	}
	Response.Write("</table>");
}

bool OrderOnlyDoProcessOrder()
{
	string sc = " UPDATE orders SET status = 2 WHERE id = " + m_id;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool OrderOnlyDoDeleteOrder()
{
	string sc = " UPDATE orders SET status = 0 WHERE id = " + m_id;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
</script>
