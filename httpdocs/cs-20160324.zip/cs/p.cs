<!-- #include file="chart.cs" -->
<!-- #include file="s_item.cs" -->
<!-- #include file="wholemenu.cs" -->

<script runat=server>

bool m_bAdminMenu = false;
bool m_bIncludeGST = true;
string m_sAdminFooter1 = "";
string code = "";
string m_left_side_menu = "";
bool bEnable_Allocated_Stock = false;

DataSet ds = new DataSet();

protected void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
//	TS_Init();
	InitializeData(); //init functions

	if(m_sSite == "admin" && Request.QueryString["t"] == "getdata")
	{
		if(DoGetItemDetails())
		{
			Response.Redirect("p.aspx?" + Request.QueryString[0]);
			return;
		}
	}
    if(Session["display_include_gst"] != null){
        if(Session["display_include_gst"].ToString() == "false")
		        m_bIncludeGST = false;
    }
	

	if(Request.QueryString["t"] == "b") //buy
	{
		DoBuy();
		return;
	}

	RememberLastPage();
	PrintHeaderAndMenu("Product Detail");
  	//insert product review
	if(!String.IsNullOrEmpty(Request.Form["ProductReview"])){
		AddProductReivew();
	}

	PrintBody();
	if(m_bAdminMenu)
		Response.Write(m_sAdminFooter1);
	else
		PrintFooter();
}

void AddProductReivew(){
	if(!GetProductWithDetails())
		return;

	if(Session["CheckCode"] != null && !String.IsNullOrEmpty(Request.Form["validationTxt"]) && Request.Form["validationTxt"].ToLower() != Session["CheckCode"].ToString().ToLower()){
		Response.Write("<script");
		Response.Write(">alert('Verification code does not match the image!');</");
		Response.Write("script>");
		return;
	}
	//DEBUG("USERID=", Session["login_card_id"].ToString());
	string sc = " insert into [product_review] (UserId, ProductId, Review, ReviewDate, Rating, IsActive)";
	sc += " VALUES ";
	DateTime dt = DateTime.Now;
	string review = HttpUtility.HtmlEncode(Request.Form["ProductReview"]);
	review = review.Replace("+", "&nbsp;");
	review = review.Replace("'", "&apos;");
	sc += "   ("+ Session["login_card_id"].ToString() +", "+ code +", '"+ review +"', '"+ dt.ToString("dd/MM/yyyy") +"', "+ Request.Form["ProductReviewRatingValue"] +", 0)";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();

		Response.Write("<script");
		Response.Write(">alert('Thanks for your review.');</");
		Response.Write("script>");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}



}

bool GetProductWithDetails()
{
	if(Request.QueryString.Count <= 0)
	{
		Response.Write("<h3>ERROR, NO PRODUCT CODE</h3>");
		return false;
	}
	code = Request.QueryString[0];

	if(!CheckSQLAttack(code))
		return false;

	if(!IsInteger(code))
	{
		Response.Write("<h3>ERROR, INVALID PRODUCT CODE</h3>");
		return false;
	}
/*	string sc = "SELECT p.name, p.supplier, p.supplier_code, p.price, p.supplier_price, d.highlight, ";
	sc += "d.manufacture, d.spec, d.pic, d.rev, d.warranty, c.clearance ";
	sc += ", c.level_rate1, c.level_rate2, c.qty_break1, c.qty_break2, c.qty_break3, c.qty_break4 ";
	sc += "FROM product p JOIN code_relations c on c.id=p.supplier+p.supplier_code ";
	sc += " LEFT JOIN product_details d On d.code = p.code ";
*/

    if(MyBooleanParse(GetSiteSettings("allocated_stock_public_enabled", "1", true)))
			bEnable_Allocated_Stock = true;

	string sc = " SELECT c.*, d.* ";
	sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";

    if(g_bRetailVersion)
	{
		sc += ", ISNULL((select sum(qty";
		if(bEnable_Allocated_Stock){
            sc += "-allocated_stock";
        }
		sc += ") FROM stock_qty WHERE code = c.code), 0) AS  stock ";
	}
	else{
        sc += ", p.stock AS stock ";
    }
			
	sc += " FROM code_relations c LEFT OUTER JOIN product_details d On d.code = c.code left outer join product p On c.id=p.supplier+p.supplier_code ";
	sc += " WHERE [skip] <> 1 and c.code=" + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		ds = new DataSet();
		if(myAdapter.Fill(ds) <= 0)
		{
//do kit
            sc = " SELECT *, '' AS highlight , details AS spec, '' AS manufacture, '' AS cast_member, '' AS discs , '' AS director, 'Package' AS title_zone , '' AS rev, 1 AS level_rate1, 1 AS level_rate2, 1 AS level_rate3, 1 AS level_rate4, 1 AS level_rate5, 1 AS level_rate6, 1 AS level_rate7, 1 AS level_rate8, 1 AS level_rate9, 'false' AS clearance, price AS rrp, price AS manual_cost_nzd , 0 AS nzd_freight, '0' AS brand , 2 AS stock ";
	        //sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
	        sc += " FROM kit ";
	        sc += " WHERE id=" + code;
		    myAdapter = new SqlDataAdapter(sc, myConnection);
		    ds = new DataSet();
		    if(myAdapter.Fill(ds) <= 0){
                Response.Write("<h3>Product Not Found  </h3>");
			    return false;
            }
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
string doGetSubSubCatMenu(ref string scode)
{
	string smenu = "";
	string sc = " SELECT cl.ss_cat, cl.s_cat, cl.cat ";
	sc += " FROM code_relations c JOIN catalog cl On cl.cat = c.cat AND cl.s_cat = c.s_cat";
	sc += " WHERE c.code=" + scode;
	int rows = 0;
//DEBUG("sc =", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "sscat");
		
	}
	catch(Exception e) 
	{
		ShowExp("", e);
		return "";
	}
	if(rows >0)
	{
		for(int i=0; i<rows; i++)
		{
			DataRow dr = ds.Tables["sscat"].Rows[i];
			string cat = dr["cat"].ToString();
			string s_cat = dr["s_cat"].ToString();
			string ss_cat = dr["ss_cat"].ToString();
			smenu += "<a title='go to this catalog' href='c.aspx?c="+ HttpUtility.UrlEncode(cat) +"&s="+ HttpUtility.UrlEncode(s_cat) +"&ss="+ HttpUtility.UrlEncode(ss_cat) +"";
			if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
				smenu += "&ssid="+ Request.QueryString["ssid"].ToString();
			if(Request.QueryString["r"] != null && Request.QueryString["r"] != "")
				smenu += "&r="+ Request.QueryString["r"].ToString();
			smenu += "'>"+ ss_cat +"</a><br>";
		}
	}
//DEBUG("smenu =", smenu);
	return smenu;
}

void PrintBody()
{
	if(!GetProductWithDetails())
		return;

	DataRow dr = ds.Tables[0].Rows[0];

	//administrator menu
	if(m_bAdminMenu)
	{
		Response.Write("<table width=100% bgcolor=#EEEEEE22>");
		Response.Write("<tr><td><img src=r.gif> ");
		Response.Write("<a href=addpic.aspx?code=");
		Response.Write(code);
		Response.Write("&name=");
		Response.Write(HttpUtility.UrlEncode(dr["name"].ToString()));
		Response.Write(" target=_blank>Upload Photo</a> ");
		
		Response.Write("<img src=r.gif> ");
		Response.Write("<a href=addpdf.aspx?code=");
		Response.Write(code);
		Response.Write("&name=");
		Response.Write(HttpUtility.UrlEncode(dr["name"].ToString()));
		Response.Write(" target=_blank>Upload PDF File</a> ");

		Response.Write("<img src=r.gif> <a href=ep.aspx?code=");
		Response.Write(code);
		Response.Write(" target=_blank>Edit Specifications</a> ");

		Response.Write("<img src=r.gif> <a href=liveedit.aspx?code=");
		Response.Write(code);
		Response.Write(" target=_blank>Edit Product Details</a> ");

		Response.Write("<img src=r.gif> <a href=p.aspx?code=" + code + "&t=getdata>Get Spec From Supplier</a>");
		Response.Write("</td></tr></table>\r\n");
	}
	//end of administrator menu

	
	string sPDFFile = GetProductPDFSrc(code);
	string sHighLight = ListText(dr["highlight"].ToString());
	string spec = ListText(dr["spec"].ToString());
	string manufacture = HashLink(dr["manufacture"].ToString());	
    string stockQtyString = dr["stock"].ToString();
    bool inStock = false;
    int  stockQty = 0;
    int.TryParse(stockQtyString, out stockQty);
    if(stockQty > 0){
        inStock = true;
    }

	string castmember = ListText(dr["cast_member"].ToString());
	string director = ListText(dr["director"].ToString());
	string discs = HashLink(dr["discs"].ToString());	
	string title_zone = HashLink(dr["title_zone"].ToString());	

	string review = HashLink(dr["rev"].ToString());
	string warranty = HashLink(dr["warranty"].ToString());
	if(warranty == "")
		warranty = "12 months return to base";
	m_left_side_menu = doGetSubSubCatMenu(ref code);
	string dealer_level = "1";
	if(Session[m_sCompanyName + "dealer_level"] != null)
		dealer_level = Session[m_sCompanyName + "dealer_level"].ToString();
	double dlevel_rate = MyDoubleParse(dr["level_rate" + dealer_level].ToString());
	bool bClearance = bool.Parse(dr["clearance"].ToString());

	double dRRP = MyDoubleParse(dr["rrp"].ToString());
	double dBottomPrice = MyDoubleParse(dr["manual_cost_nzd"].ToString()) * MyDoubleParse(dr["rate"].ToString()) + MyDoubleParse(dr["nzd_freight"].ToString());

	double dPriceYours = dBottomPrice;
	if(!bClearance)
		dPriceYours *= dlevel_rate;
	if(dRRP <= 0)
		dRRP = dPriceYours * MyDoubleParse(dr["level_rate1"].ToString());
	double dMargin = 0;
	if(dRRP > 0)
		dMargin = (dRRP - dPriceYours) / dPriceYours;

	//get level_one price (highest price level) for price history check, regardless clearance or not
	double dPrice = Math.Round(dBottomPrice * MyDoubleParse(dr["level_rate1"].ToString()), 2); 
	string p_h_s = CheckPriceHistoryChart(code, dPrice); //store bottom price
	string sgst = GetSiteSettings("gst_rate_percent", "12.5");
	if(MyDoubleParse(sgst) < 1)
		sgst = (MyDoubleParse(sgst) + 1).ToString();
	else if(MyDoubleParse(sgst) >= 2)
		sgst = (1 +(MyDoubleParse(sgst) / 100 )).ToString();

	string s = ReadSitePage("product_detail_page");
	if(m_sSite == "www")
		s = ReadSitePage("product_detail_page_public");

    string itemname1 = dr["name"].ToString();
    if(itemname1.Length > 100){
        itemname1 = itemname1.Substring(0,80);
    }
    if(inStock){
        s = s.Replace("@@product_detail_instock_color", "red");
        s = s.Replace("@@product_detail_instock_status", "YES");
    }else{
        s = s.Replace("@@product_detail_instock_color", "green");
        s = s.Replace("@@product_detail_instock_status", "NO");
    }
    
    
//show navigation
    string catString = "";
    string link = "";
    try{
        catString = dr["cat"].ToString();
        link = " ->  <a href='c.aspx?L=1&c="+catString+"' >"+catString+"</a>";
        link += " -> <a href='c.aspx?L=2&c="+catString+"&s="+dr["s_cat"].ToString()+"' >"+dr["s_cat"].ToString()+"</a>";
        link += " -> <a href='c.aspx?L=2&c="+catString+"&s="+dr["s_cat"].ToString()+"&ss="+dr["ss_cat"].ToString()+"' >"+dr["ss_cat"].ToString()+"</a>";
    }catch(Exception ex){
        catString = GetSiteSettings("package_bundle_kit_name", "Kit", true);
        link = " ->  <a href='c.aspx?L=1&c="+catString+"' >"+catString+"</a>";
        link += " -> <a href='c.aspx?L=2&c="+catString+"&s="+dr["s_cat"].ToString()+"' >"+dr["s_cat"].ToString()+"</a>";
    }
    
    s = s.Replace("@@public_site_menu", menuLevel1());
    s = s.Replace("@@product_detail_navigation", link);    

    s = s.Replace("@@product_codr", code);
    s = s.Replace("@@title_item_name", itemname1);
	s = s.Replace("@@item_name", dr["name"].ToString());
    string m_sKitTerm = "Package";
    string cat = dr["title_zone"].ToString();
    bool isKit = false;
    if(m_sKitTerm == cat){
        s = s.Replace("@@item_code", "id=" + code);
        isKit = true;
    }else{
        s = s.Replace("@@item_code", "c=" + code);
    }
	System.Collections.Generic.List<string> imageSrcList = GetProductImgSrcList(code, isKit);
    string imageSrcListString = "";
    string imageSrcListShow = "";
    if(imageSrcList != null){
        if(imageSrcList.Count > 0){
            int imageCount = 0;
            foreach(string ims in imageSrcList){
                imageSrcListShow += "<li><img src='"+ims+"'  /></li>";
            }
        }
    }

    string sImageLink = GetProductImgSrc(code, isKit);

    s = s.Replace("@@product_image_list_show@@", imageSrcListShow);
    s = s.Replace("@@product_image_list", imageSrcListString);
	s = s.Replace("@@image_link", sImageLink);
	s = s.Replace("@@price_history_image_link", p_h_s);
	s = s.Replace("@@item_highlight", sHighLight);
	s = s.Replace("@@manufacture_link", manufacture);
	s = s.Replace("@@item_spec", spec);
	s = s.Replace("@@item_review", review);
	s = s.Replace("@@item_warranty", warranty);
	s = s.Replace("@@pdf_link", sPDFFile);
	s = s.Replace("@@ProductPageUri@@", Request.Url.AbsoluteUri);
    double show_price = 0;
     try{
        string showPriceString = dr["show_price"].ToString();
        double.TryParse(showPriceString, out show_price);
    }catch(Exception ex){
        show_price = 0;
    }
    if(show_price == 0){
        s = s.Replace("@@CSS_SHOW_SPECIAL_IMAGE", "home-product-list-show-special-image-none");
        s = s.Replace("@@show_price", "");
        s = s.Replace("@@item_rrp", "RRP: <span>" +  dRRP.ToString("c") + "</span>");
    }else{
         s = s.Replace("@@CSS_SHOW_SPECIAL_IMAGE", "home-product-list-show-special-image");
         s = s.Replace("@@show_price", "RRP: <span style='  text-decoration: line-through;'><strike>" + show_price.ToString("c") + "</strike></span>");
         s = s.Replace("@@item_rrp", "Special price: <span>" +  dRRP.ToString("c") + "</span>");
    }

    s = s.Replace("@@itemCodeString@@",  code);

	
	s = s.Replace("@@item_gst_rrp",(dRRP * MyDoubleParse(sgst)).ToString("c"));
	s = s.Replace("@@your_buy_price", dPriceYours.ToString("c"));
	s = s.Replace("@@your_buy_price_gst",(dPriceYours * MyDoubleParse(sgst)).ToString("c"));
	s = s.Replace("@@item_margin", dMargin.ToString("p"));
	s = s.Replace("@@manufacture", dr["manufacture"].ToString());
	s = s.Replace("@@mpic", ""+ dr["brand"].ToString()+".gif");
	s = s.Replace("@@LEFT_SIDE_MENU", m_left_side_menu);
//	if(g_bRentalVersion)
	{
		s = s.Replace("@@item_zone", title_zone);
		s = s.Replace("@@item_discs", discs);
		s = s.Replace("@@item_director", director);
		s = s.Replace("@@item_cast_member", castmember);
	
	}
	string stock_details = "";
	if(Session["branch_support"] != null)
		stock_details = GetStockDetails(code);
	
	s = s.Replace("@@item_stock", ApplyColor(stock_details));

	if(Session["login_card_id"] == null)
		s = s.Replace("@@ShowProductReview@@", "hide");
	else
		s = s.Replace("@@ShowProductReview@@", "");

	s = s.Replace("@@ProductReview@@", GetProductReview(code));
	s = s.Replace("@@ProductAvgReview@@", GetProductAvgReview(code));
	s = s.Replace("@@ReviewCount@@", reviewCount.ToString());

	Response.Write(s);
/*
	Response.Write("<table width=100% align=center bgcolor=white>");
	Response.Write("<tr><td><table width=80% align=center>");
		Response.Write("<tr><td>&nbsp;</td></tr>");
		Response.Write("<tr><td>");
		Response.Write("<table>");
			Response.Write("<tr><td width=30% valign=top>");

			//print pic
			Response.Write("<table height=100% width=10%>");
				Response.Write("<tr><td>");
				string sPicFile = GetProductImgSrc(code);
		//DEBUG("sPicFile=", sPicFile);
				Response.Write("<table cellpadding=0 cellspacing=0><tr><td align=center>");
				//Response.Write("<a href=");
				Response.Write("<a title='view Larger Image' href=\"javascript:image_window=window.open('");
				Response.Write(sPicFile);
				Response.Write("', 'image_window', 'width=450, height=500, scrollbars=no,resizable=yes '); image_window.focus()\" ");
				//Response.Write(sPicFile);
				Response.Write("><img src=");
				Response.Write(sPicFile);
			//	Response.Write(" title='Click For Large Image' border=0 ");
				string rp = Server.MapPath(sPicFile);
				int iWidth = 0;
				System.Drawing.Image im = null;
				if(File.Exists(rp))
				{
					try
					{
						im = System.Drawing.Image.FromFile(rp);
					}
					catch(Exception e)
					{
//						ShowExp("file : " + rp, e);
					}
				}
				if(im != null)
				{
					iWidth = im.Width;
					if(im.Width > 200)
						Response.Write(" width=200 title='Click For Large Image'");
					im.Dispose();
				}
				else
					Response.Write(" width=150");
				
				Response.Write(" border=0></a></td></tr><tr><td align=center>");
				//Response.Write("<a href=");
				Response.Write("<a title='view Larger Image' href=\"javascript:image_window=window.open('");
				Response.Write(sPicFile);
				Response.Write("', 'image_window', 'width=450, height=500, scrollbars=no,resizable=yes '); image_window.focus()\" ");
				//Response.Write(sPicFile);
				if(sPicFile.Length > 2)
				{
					if(sPicFile.Substring(0, 2) == "/i")
						Response.Write("><font size=+1 color=red><b>We are sorry, Image temporarily unavailable</b></font>");
					else
					{
						Response.Write(">");
						if(iWidth > 200)
							Response.Write("<font size=1 color=blue>Click For Large Image</font>");
					}
				}
				Response.Write("</a></td></tr>");
				Response.Write("</table>");
				Response.Write("</td></tr><tr valign=bottom><td height=200 valign=bottom>");
				//Response.Write("<a href=" + p_h_s + " class=d><img width=200 src=" + p_h_s + "><br>Price History</a></td></tr>");
				Response.Write("<a title='view Larger Image' href=\"javascript:image_window=window.open('");
				Response.Write(p_h_s);
				Response.Write("', 'image_window', 'width=450, height=500, scrollbars=no,resizable=yes '); image_window.focus()\" class=d>");
				Response.Write("<img width=200 src=" + p_h_s + "><br>Price History</a></td></tr>");
			Response.Write("</table>");

			
			//price
			Response.Write("</td><td>&nbsp;&nbsp;&nbsp;</td><td valign=top>");
			PrintPrice(dr, code);
			Response.Write("</td></tr>");
		Response.Write("</table>");

	Response.Write("</td></tr>");
	Response.Write("<tr><td><hr></td></tr>");

	//display pdf file
			string sPDFFile = GetProductPDFSrc(code);
		//DEBUG("sPdfFile=", sPDFFile);
				
			//	Response.Write(" title='Click For Large Image' border=0 ");
				string rpdf = Server.MapPath(sPDFFile);
				if(File.Exists(rpdf))
				{
					Response.Write("<tr><td colspan=2 valign=top>");
					Response.Write("<table cellpadding=0 cellspacing=0><tr><td align=center>");
					Response.Write("<tr><td><a title='download Acrobat Reader from Adobe' href='http://www.adobe.com/productindex/acrobat' ");
					Response.Write(" target=new class=o><img border=0 src='/i/pdf.gif'></a> View The product specification in PDF format.</td></tr>");
					Response.Write("<tr></tr><tr></tr>");
					Response.Write("<tr><td> <a title='Click to View by PDF Format' href=");
					Response.Write(sPDFFile);
					Response.Write("><img src='/i/download.gif' ");
					//Response.Write(sPDFFile);	
					Response.Write(" border=0></a></td></tr>");
					
					//Response.Write("<a href=");
					//Response.Write(sPicFile);
					Response.Write("</table>");
					Response.Write("</td></tr>");
					//Response.Write("</td></tr><tr valign=bottom><td height=200 valign=bottom>");
					//Response.Write("<a href=" + p_h_s + " class=d><img width=200 src=" + p_h_s + "><br>Price History</a></td></tr>");
				}

			//--------------end here
	//manufacture
	Response.Write("<tr><td>");
	string sManufacture = HashLink(dr["manufacture"].ToString());
	if(sManufacture != "")
	{
		Response.Write("<b>Manufacturer:</b><br>");
		Response.Write(sManufacture);
	}
	Response.Write("</td></tr>");
	//Response.Write("<tr><td>&nbsp;</td></tr>");

	//review
	Response.Write("<tr><td>");
	string sRev = HashLink(dr["rev"].ToString());
	if(sRev != "")
	{
		Response.Write("<b>Reviews:</b><br>");
		Response.Write(sRev);
	}
	Response.Write("</td></tr>");

	Response.Write("<tr><td>&nbsp;</td></tr>");

	//spec
	Response.Write("<tr><td>");
	string sSpec = ListText(dr["spec"].ToString());
	if(sSpec != "")
	{
		Response.Write("<b>Specifications:</b><br>");
		Response.Write(sSpec);
	}
	Response.Write("</td></tr>");

	Response.Write("<tr><td>&nbsp;</td></tr>");

	//warranty
	Response.Write("<tr><td>");
	string sWarranty = HashLink(dr["warranty"].ToString());
	if(sWarranty != "")
	{
		Response.Write("<b>Warranty:</b><br>");
		Response.Write(sWarranty);
	}
	else
	{
		Response.Write("<b>Warranty:</b><br>");
		Response.Write("<ul><li>12 months return to base</ul>");
	}
	Response.Write("</td></tr>");
	
	Response.Write("<tr><td><br><b>Notice : </b><ul>");
	Response.Write("<li>Errors and omissions excepted.");
	Response.Write("<li>Photographs, pictures or graphics are indicative only.");
	Response.Write("<li>Specifications subject to change without notice.");
	Response.Write("<li>All prices exclude freight & GST and are subject to change without notice.");
	Response.Write("<li>Availabilty subject to change without notice.");
	Response.Write("</ul></td></tr>");

	Response.Write("</td></tr></table>");
	Response.Write("</table>");
*/
}

int reviewCount = 0;
string GetProductReview(string code){
	string review = "";
	string sc = "SELECT pv.* , c.name  FROM product_review pv left join [card] c on c.id = pv.UserId ";
	sc += " WHERE ProductId = '"+ code +"' AND pv.IsActive = 1";
	sc += " ORDER BY ReviewDate DESC";

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		ds = new DataSet();
		int rows = myAdapter.Fill(ds, "ProductReview");
		reviewCount = 0;
		if(rows <= 0)
			review = "There are no reviews for this product.";
		else{
			review = "";
			reviewCount = rows;
			for(int i = 0; i < rows; i++){
				review += "<li><div class='firstLine'><span>"+ ds.Tables["ProductReview"].Rows[i]["name"] +"</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>"+ ds.Tables["ProductReview"].Rows[i]["ReviewDate"] +"</span></div><div class='secondLine'><span>"+  GetProductRatingString(ds.Tables["ProductReview"].Rows[i]["Rating"].ToString()) +"</span></div><div class='thirdLine'>"+ ds.Tables["ProductReview"].Rows[i]["Review"] +"</div></li>";
			}
		}

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		review = "There are no reviews for this product.";
	}
	return review;
}

string GetProductAvgReview(string code){
	string review = "";
	string sc = "SELECT AVG(pv.Rating) AS avgRating  FROM product_review pv ";
	sc += " WHERE ProductId = '"+ code +"' AND pv.IsActive = 1";
	

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		ds = new DataSet();
		int rows = myAdapter.Fill(ds, "ProductAvgReview");
		
		if(rows <= 0)
			review = GetProductRatingString("0");
		else{
			review = GetProductRatingString(ds.Tables["ProductAvgReview"].Rows[0]["avgRating"].ToString());
		}

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		review = GetProductRatingString("0");
	}
	return review;
}

string GetProductRatingString(string rating){
	String r = "";
	int value = 0;
	if(!int.TryParse(rating, out value)){
		value = 0;
	}

	if(value == 0){
	   r = "<img alt='1' src='themes/raty/images/star-off.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-off.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-off.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-off.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-off.png' title='gorgeous'>";
    }else if(value == 1){
    	r = "<img alt='1' src='themes/raty/images/star-on.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-off.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-off.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-off.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-off.png' title='gorgeous'>";
	}else if(value == 2){
	   r = "<img alt='1' src='themes/raty/images/star-on.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-on.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-off.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-off.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-off.png' title='gorgeous'>";
	}else if(value == 3){
		r = "<img alt='1' src='themes/raty/images/star-on.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-on.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-on.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-off.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-off.png' title='gorgeous'>";
	}else if(value == 4){
		r = "<img alt='1' src='themes/raty/images/star-on.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-on.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-on.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-on.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-off.png' title='gorgeous'>";
	}else if(value == 5){
		r = "<img alt='1' src='themes/raty/images/star-on.png' title='bad'>";
	   r += "<img alt='2' src='themes/raty/images/star-on.png' title='poor'>";
	   r += "<img alt='3' src='themes/raty/images/star-on.png' title='regular'>";
	   r += "<img alt='4' src='themes/raty/images/star-on.png' title='good'>";
	   r += "<img alt='5' src='themes/raty/images/star-on.png' title='gorgeous'>";
	}


	return r;
}

void PrintPrice(DataRow dr, string code)
{
	string dealer_level = Session[m_sCompanyName + "dealer_level"].ToString();
	double dlevel_rate = MyDoubleParse(dr["level_rate" + dealer_level].ToString());
	bool bClearance = bool.Parse(dr["clearance"].ToString());

	double dRRP = MyDoubleParse(dr["rrp"].ToString());
	double dBottomPrice = MyDoubleParse(dr["manual_cost_nzd"].ToString()) * MyDoubleParse(dr["rate"].ToString());

	double dPriceYours = dBottomPrice;
	if(!bClearance)
		dPriceYours *= dlevel_rate;

	double dMargin = 0;
	if(dRRP > 0)
		dMargin = (dRRP - dPriceYours)/dPriceYours;

	Response.Write("<table><tr><td colspan=2><font color=red><h3>");
	Response.Write(dr["name"].ToString());
	Response.Write("</h3></font></td></tr>\r\n<tr><td>&nbsp;</td></tr>\r\n<tr><td colspan=2>");
	Response.Write(ListText(dr["highlight"].ToString()));
	Response.Write("</td></tr>");
	
	Response.Write("<tr rowspan=3>");

	Response.Write("<td colspan=2>&nbsp;</td></tr>");
	
	Response.Write("<tr><td align=right><b>Item Code:</b></td><td><b>" + code + "</b>");
	Response.Write("</td></tr>");

	if(TS_UserLoggedIn())
	{
		Response.Write("<tr><td align=right><b>RRP:</b></td><td><b>");
		Response.Write(dRRP.ToString("c"));
		Response.Write("</b></td></tr>");

		Response.Write("<tr><td align=right><b>Your Buy Price</b></td><td><b>");
		Response.Write(dPriceYours.ToString("c"));
		if(bClearance)
			Response.Write("</b> <font color=red><b>(*Clearance*)</b></font>");
		Response.Write("</td></tr>");
		
//		Response.Write("<tr><td></td><td><br><b>Your Single Buy Price:&nbsp;<font color=blue>");
//		Response.Write(((dPriceYours*margin)).ToString("c")+ "</font></b></td></tr>");
		Response.Write("<tr><td align=right><b>Margin:&nbsp;<font color=blue></td><td><b>");
		Response.Write(dMargin.ToString("p"));
		Response.Write("</b></td></tr>");
//		Response.Write("<tr><td></td><td><font color=blue><i>(Further discount applies for quantity)</i></font></td></tr>");
	}
				
	Response.Write("<tr><td colspan=2 align=center>");

	//forum
	if(Session["loggedin"] != null)
	{
		Response.Write("<table>");
		Response.Write("<tr><td><font size=+1 color=red><b>&nbsp&nbsp;Any Question?&nbsp;&nbsp;</b></font></td><td>");
		Response.Write("<input type=button " + Session["button_style"] + " onclick=window.location=('bb.aspx?t=nt&fi=1&q=1&dp="+ HttpUtility.UrlEncode(dr["name"].ToString())+"&cd="+ code +"') value='&nbsp&nbsp; Ask Us &nbsp;'>");
		Response.Write("</td></tr>");
		Response.Write("</table>");
	}

//	if(m_sSite == "admin")
//		Response.Write("<br><input type=button value='Get Details From Supplier Site' onclick=window.location=('p.aspx?code=" + code + "&t=getdata') " + Session["button_style"] + ">");

	Response.Write("</td></tr>");
//	}
//	Response.Write("</table>\r\n");
//	Response.Write("<button onclick=window.location=('watch.aspx?t=price&code=" + code + "')>Stock and Price Watch</button>");
}

string HashLink(string s)
{
	int len = s.Length;

	StringBuilder sb = new StringBuilder();
	StringBuilder sl = new StringBuilder();
	
	Boolean bLink = false;
	bool bAddHttp = false;
	int i = 0;
	for(i=0; i<len; i++)
	{
		if(s[i] == 'h' || s[i] == 'H')
			if(i+6 < len)
				if(s[i+1] == 't' || s[i+1] == 'T')
					if(s[i+2] == 't' || s[i+2] == 'T')
						if(s[i+3] == 'p' || s[i+3] == 'P')
							if(s[i+4] == ':' && s[i+5] == '/' && s[i+6] == '/')
								bLink = true;
		
		if(!bLink)
		{
			if(s[i] == 'w' || s[i] == 'W')
				if(i+3 < len)
					if(s[i+1] == 'w' || s[i+1] == 'W')
						if(s[i+2] == 'w' || s[i+2] == 'W')
							if(s[i+3] == '.')
							{
								bLink = true;
								bAddHttp = true;
							}
		}

//		bLink = false;
		if(!bLink)
		{
			sb.Append(s[i]);
		}
		else
		{
			if(i+1 == len || s[i] == ' ')
			{
				if(i+1 == len) //the last character
					sl.Append(s[i]);

				sb.Append("<a href=");
				if(bAddHttp)
				{
					sb.Append("http://");
					bAddHttp = false;
				}
				sb.Append(sl.ToString());
				sb.Append(" class=o target=_blank>");
				sb.Append(sl.ToString());
				sb.Append("</a>");
				bLink = false;
				sl.Remove(0, sl.Length);
			}
			else
				sl.Append(s[i]);
		}
	}
	return sb.ToString();
}

string ListText(string s)
{
	CompareInfo ci = CompareInfo.GetCompareInfo(1);
	bool bHasTable = (ci.IndexOf(s, "<table", CompareOptions.IgnoreCase) >= 0);
	if(!bHasTable)
		bHasTable = (ci.IndexOf(s, "<td>", CompareOptions.IgnoreCase) >= 0);

	if(bHasTable)
		return s;

	//string sRet = "<ul><li>";
	string sRet = "";
	for(int i=0; i<s.Length; i++)
	{
		if(i<s.Length-4 && s[i] == '\r' && s[i+1] == '\n')
		{
			if(i>2 && (s[i-2] == '\r' && s[i-1] == '\n') || (s[i+2] == '\r' && s[i+3] == '\n'))
				sRet += "<br>";
			else
				sRet += "";
			//sRet += "<li>";
		}
		else
			sRet += s[i];
	}
	//sRet += "</ul>"; 
	sRet += ""; 

	return sRet; 
}

string CheckPriceHistoryChart(string code, double level_one_price)
{
	DateTime dNow = DateTime.UtcNow.AddHours(12);
	DataSet ds;
	int rows = 0;

	string filename = code + ".jpg";
	filename = RemoveSlash(filename);
	string vpath = GetRootPath() + "/ph/";
	string fn = "";
	try
	{
		fn = Server.MapPath(vpath);
	}
	catch(Exception e)
	{
		return "";
	}
	fn += filename; 

	double dPrice = level_one_price;
	string sc = "IF NOT EXISTS (SELECT price FROM price_history WHERE code=" + code + ") ";
	sc += " INSERT INTO price_history (code, price, price_date) VALUES(" + code;
	sc += ", " + dPrice + ", GETDATE() )";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return vpath + filename;
	}
	
	sc = "SELECT h.price * c.level_rate1 AS price, h.price_date ";
	sc += " FROM price_history h JOIN code_relations c ON c.code=h.code ";
	sc += " WHERE h.code='";
	sc += code + "' AND h.price_date>";
	sc += "DATEADD(Year, -1, GETDATE())"; //dNow.AddYears(-1);
	sc += " ORDER BY h.price_date DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		ds = new DataSet();
		rows = myAdapter.Fill(ds);
		if(rows <= 0)
			return vpath + filename;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	DateTime dDate = DateTime.Parse(ds.Tables[0].Rows[rows-1]["price_date"].ToString());
	// build the new chart
	dPrice = 0;
	double dPriceL = 99999999; //lowest price
	double dPriceH = -1; //highest price
	DataRow dr = null;

	//get price margin first
	for(int i=0; i<ds.Tables[0].Rows.Count; i++)
	{
		dr = ds.Tables[0].Rows[i];
		dPrice = double.Parse(dr["price"].ToString());
		if(dPrice < dPriceL)
			dPriceL = dPrice;
		if(dPrice > dPriceH)
			dPriceH = dPrice;
	}
//DEBUG("dPriceL=", (int)dPriceL);
//DEBUG("dPriceH=", (int)dPriceH);

	//build chart
	int nYear = dNow.Year - dDate.Year;

	LineChart c = new LineChart(500, 300, Page);
	c.Title="Price History - Last 12 Months";
	c.SetBgColor(0xFFCCCC);
//	c.SetBgColor(0xFFFFFF);
	c.ScaleX=400; 
	c.Xdivs=12;
	DateTime dOrigin = dNow.AddYears(-1);	//backward one year
	dOrigin = dOrigin.AddDays(0 - dNow.Day);			//back to the beginning of the month
//	c.Xorigin = d.DayOfYear;				
	c.Xorigin = 0;

	int nStep = (int)((dPriceH - dPriceL) / 10);
	if(nStep < 1)
		nStep = 1;
	c.Yorigin = (int)(dPriceL / nStep) * nStep - nStep;
	c.ScaleY = (int)(dPriceH / nStep) * nStep + nStep - c.Yorigin;
	c.Ydivs = c.ScaleY / nStep;
//DEBUG("Yorigin=", (int)c.Yorigin);
//DEBUG("ScaleY=", (int)c.ScaleY);
//DEBUG("nStep=", nStep);
//DEBUG("Ydivs=", (int)c.Ydivs);
	DateTime dDatePrev = DateTime.Parse("01/01/1900");
	double dPricePrev = -1;
//	DataRow[] drsbp = ds.Tables[0].Select("", "price"); //sort by price
	DataRow[] drsbp = ds.Tables[0].Select("", "price_date"); //sort by price_date
	for(int i=0; i<ds.Tables[0].Rows.Count; i++)
	{
		dr = drsbp[i];
		dDate = DateTime.Parse(dr["price_date"].ToString());
		if((dDate - dDatePrev).Days <= 1)
			continue; //skip rapid changes
		dDatePrev = dDate;
		dPrice = double.Parse(dr["price"].ToString());
//DEBUG("price=", dPrice.ToString());
		if(dPrice == dPricePrev)
			continue;
//DEBUG("price=", dPrice.ToString());
		dPricePrev = dPrice;
		nYear = dNow.Year - dDate.Year;
		c.AddValue((dDate - dOrigin).Days, (int)(dPrice));
//DEBUG("days=", (dDate-dOrigin).Days);
//DEBUG("y=", (int)dPrice);
	}
	c.AddValue((dNow - dOrigin).Days, (int)(dPrice));
	c.Draw();
//DEBUG("filename=", fn);
	c.Save(fn);
	return vpath + filename;
}

void DoBuy()
{
	if(!GetProductWithDetails())
		return;

	string sDiscount = "0";
	double dDiscount = 0;
	if(Session["loggedin"] != null)
	{
		if(Session[m_sCompanyName + "discount"] != null)
		{
			sDiscount = Session[m_sCompanyName + "discount"].ToString();
			dDiscount = double.Parse(sDiscount);
			sDiscount = ((int)dDiscount).ToString();
		}
	}

	DataRow dr = ds.Tables[0].Rows[0];
	string price = dr["price"].ToString(); 
	double dPrice = double.Parse(price);
	string supplier_price = dr["supplier_price"].ToString(); 
	double dsupplier_price = double.Parse(supplier_price);
	double cost = dsupplier_price * 0.04; //Bank charge 2.5 and DPS charg 1;
	double dProfit = dPrice - dsupplier_price - cost;
	double dPriceYours = dPrice - dProfit * dDiscount / 100;
	double dPriceCreditCard = 0;

	bool bDealer = false;
	if(Session["loggedin"] != null)
	{
		if(Session["card_type"].ToString() == GetEnumID("card_type", "dealer"))
		{
			bDealer = true;
			dPriceCreditCard = dPriceYours;
			dProfit = dPrice - dsupplier_price;
			dPriceYours = dPrice - dProfit * dDiscount / 100;
		}
	}
	
	bool bCreditCard = false;
	double dFinalPrice = dPriceCreditCard;
	if(Request.QueryString["card"] != "1")
	{
		dFinalPrice = dPriceYours;
		Session[m_sCompanyName + "no_credit_card"] = true;
	}
	
	Session["bargain_price_" + code] = dFinalPrice;
	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=cart.aspx?t=b&c=" + code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
}

double GetBottomLevelDiscount()
{
	DataSet dsld = new DataSet();

	double dd = 2;
	int rows = 0;
	string sc = "SELECT MAX(data1) AS rate FROM discount WHERE factor='level'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsld, "ld") == 1)
			dd = MyDoubleParse(dsld.Tables["ld"].Rows[0]["rate"].ToString());
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	return dd;
}

bool DoGetItemDetails()
{
//	return false;

	bool bRet = true;

	if(!GetProductWithDetails())
		return false;

	DataRow dr = ds.Tables[0].Rows[0];
	string supplier = dr["supplier"].ToString();
	string supplier_code = dr["supplier_code"].ToString();

	string serviceUrl = "";
	if(supplier.ToLower() == "dw")
		serviceUrl = "http://www.datawellonline.co.nz/service/item.asmx";
	else if(supplier.ToLower() == "tm")
		serviceUrl = "http://www.timesonline.co.nz/service/item.asmx";
	else if(supplier.ToLower() == "iw")
		serviceUrl = "http://210.55.223.208/service/item.asmx";
	else if(supplier.ToLower() == "edit")
		serviceUrl = "http://www.ed-it.co.nz/service/item.asmx";

	if(serviceUrl == "")
		return true;
	csItem ItemService = new csItem(serviceUrl);

	DataSet ds1 = ItemService.GetItemDetail(supplier_code);
	if(ds1 != null)
	{
		dr = ds1.Tables[0].Rows[0];
		string sc = "";
		sc = " IF NOT EXISTS (SELECT code FROM product_details WHERE code = " + code + ") "; 
		sc += " BEGIN ";
		sc += " INSERT INTO product_details (code, highlight, spec, manufacture, rev, warranty) ";
		sc += " VALUES( " + code;
		sc += ", '" + EncodeQuote(dr["highlight"].ToString()) + "' ";
		sc += ", '" +  EncodeQuote(dr["spec"].ToString()) + "' ";
		sc += ", '" + EncodeQuote(dr["manufacture"].ToString()) + "' ";
		sc += ", '" + EncodeQuote(dr["rev"].ToString()) + "' ";
		sc += ", '" + EncodeQuote(dr["warranty"].ToString()) + "' ";
		sc += ") ";
		sc += " END ";
		sc += " ELSE ";
		sc += " BEGIN ";
		sc += " UPDATE product_details SET ";
		sc += " highlight = '" + EncodeQuote(dr["highlight"].ToString()) + "' ";
		sc += ", spec = '" + EncodeQuote(dr["spec"].ToString()) + "' ";
		sc += ", manufacture = '" + EncodeQuote(dr["manufacture"].ToString()) + "' ";
		sc += ", rev = '" + EncodeQuote(dr["rev"].ToString()) + "' ";
		sc += ", warranty = '" + EncodeQuote(dr["warranty"].ToString()) + "' ";
		sc += " WHERE code = " + code;
		sc += " END ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	else
	{
		Response.Write("<br><center><h3>Error getting product details from " + supplier + ", " + serviceUrl + ", MPN: " + supplier_code + "</h3>");	
		bRet = false;
	}

	string fileType = ItemService.GetItemPhotoType(supplier_code);
	if(fileType == null || fileType == "")
		return false;
	byte[] buffer = ItemService.GetItemPhotoData(supplier_code + "." + fileType);
	if(buffer == null)
		return false;

	string strPath = "";
	try
	{
		strPath = Server.MapPath("/pi/" + code + "." + fileType);
	}
	catch(Exception e)
	{
		return false;
	}
	FileStream newFile = new FileStream(strPath, FileMode.Create);
	newFile.Write(buffer, 0, buffer.Length);
	newFile.Close();
	return bRet;


}

string GetStockDetails(string code)
{
	DataSet dssd = new DataSet();
	string sc = " SELECT ISNULL(q.qty,0) AS qty, ISNULL(q.allocated_stock,0) AS allocated_stock, b.name ";
	sc += " FROM stock_qty q JOIN branch b ON b.id = q.branch_id ";
	sc += " WHERE q.code=" + code;
//DEBUG("sc = ",sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dssd, "stock") <= 0)
		{
		//	return "Error getting stock details";
			return "** Stock Un-Available in Showroom **";
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	StringBuilder sb = new StringBuilder();
	sb.Append("<table class=\"dealerStockTable\">");
	sb.Append("<tr><th>Stock On Hand</th>"+
                                "<th>Commited</th>"+
                                "<th>Available</th></tr>");
	for(int i=0; i<dssd.Tables["stock"].Rows.Count; i++)
	{
		DataRow dr = dssd.Tables["stock"].Rows[i];
		string branch_name = dr["name"].ToString();
		string qty = dr["qty"].ToString();
		string allocated = dr["allocated_stock"].ToString();
		int nQty = MyIntParse(qty);
		int nAllocated = MyIntParse(allocated);

		sb.Append("<tr>");
		sb.Append("<td><b>" + qty + "(" + branch_name + ")</b></td>");
		sb.Append("<td><b>" + allocated + "(" + branch_name + ")</b></td>");
		sb.Append("<td><b>" + (nQty-nAllocated).ToString() + "(" + branch_name + ")</b></td>");
		sb.Append("</tr>");
	}
    sb.Append("</table>");
	return sb.ToString();
}

</script>
