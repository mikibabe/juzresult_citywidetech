<script runat=server>

string r = "r=";
string m_sAdminFooter = "</td></tr></table></td></tr><tr><td><a href=default.aspx?";
string m_sMenuTables = "";
bool m_bShowProgress = false;

DataSet dsAdminMenu = new DataSet();

void PrintAdminMenu()
{
	//PrintMenuTables();
//	if(!m_bShowProgress)
//		Response.Write("<table cellpadding=0 cellspacing=0 align=center bgcolor=#FFFFFF width=96% height=95%><tr><td valign=top><table width=100% height=100%><tr><td valign=top>");

//print user name
Response.Write("<table class=showUserName>");
Response.Write("<tr>");
Response.Write("<td>");
Response.Write("<font>Hi, </font>" + Session["name"] + "<font>!</font>");
Response.Write("</td>");
Response.Write("</tr>");
Response.Write("</table>");
Response.Write("<hr>");

}

void PrintAdminHeader()
{
	r += DateTime.UtcNow.AddHours(12).ToOADate().ToString(); //random seeds to force IE no cache
//	m_sAdminFooter += r;
//	m_sAdminFooter += ">Main Page</a></td></tr></table><div align=right>&#169; EZ Soft CORP. 2001-2002 All Right Reserved</body></html>";

	m_sAdminFooter = ApplyColor(ReadSitePage("admin_footer"));
	string header = ReadSitePage("admin_page_header");
	header = header.Replace("@@companyTitle", m_sCompanyTitle);
	Response.Write(ApplyColor(header));
}

void PrintAdminFooter()
{
	Response.Write(m_sAdminFooter);
}

void PrintSearchForm()
{
	string kw = "";
	if(Session["search_keyword"] != null)
		kw = Session["search_keyword"].ToString();
	string frmSearch = ReadSitePage("admin_search");
	frmSearch = frmSearch.Replace("@@search_keyword", kw);
	Response.Write(frmSearch);
}

void PrintMenuTables()
{
/*	string smenu = ReadSitePage("admin_menu");
	string uri = Request.ServerVariables["URL"];
	uri = uri.Substring(0, uri.IndexOf(".aspx"));
	int i = uri.Length-1;
	for(; i>=0; i--)
	{
		if(uri[i] == '/')
			break;
	}
	uri = uri.Substring(i+1, uri.Length - i - 1);

	smenu = smenu.Replace("@@help_page", uri);
	smenu = smenu.Replace("@@rnd", r);
	smenu = smenu.Replace("@@card_id", Session["card_id"].ToString());
	Response.Write(smenu);
*/
	//get current page name for dynamic parameters
	string uri = Request.ServerVariables["URL"];
	uri = uri.Substring(0, uri.IndexOf(".aspx"));
	int i = uri.Length-1;
	for(; i>=0; i--)
	{
		if(uri[i] == '/')
			break;
	}
	uri = uri.Substring(i+1, uri.Length - i - 1);

	string sc = "SELECT * FROM menu_admin_catalog ";
	if(g_bDemo && g_bOrderOnlyVersion)
		sc += " WHERE orderonly=1 ";
	sc += " ORDER BY seq";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dsAdminMenu, "cat") <= 0)
			return;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return;
	}

	string class_administrator = GetAccessClassID("Administrator");

	string s = ""; //catalog table
	string ss = ""; //sub menu table
	string u = ""; //uri
	string menu_name = "";
	string name = "";
	string cat = "";
	string m_class = Session[m_sCompanyName + "AccessLevel"].ToString();
	DataRow dr = null;

	string bgcolor = "@@color_8";//GetSiteSettings("main_menu_bg_color", "#666696");
	s += "<table cellpadding=2 cellspacing=0 BORDER=0 BGCOLOR=" + bgcolor + "";
	if(GetSiteSettings("background_admin_menu_picture", "true", true).ToLower() == "true")
		s += " background='/i/clbg.gif' ";
	s += ">";
//	s += "<tr style='color:black;background-color:" + bgcolor + ";font-weight:bold;'>";
	s += "<tr>";

	for(i=0; i<dsAdminMenu.Tables["cat"].Rows.Count; i++)
	{
		dr = dsAdminMenu.Tables["cat"].Rows[i];
		name = dr["name"].ToString();
		cat = dr["id"].ToString();

		Trim(ref name);
		if(name == "") //seperator
			s += "\r\n<td width=30>&nbsp;</td>";

		sc = "SELECT i.uri, i.name ";
		sc += " FROM menu_admin_id i JOIN menu_admin_sub s ON i.id=s.menu ";
		if(m_class != class_administrator) //administrator has all access
			sc += " JOIN menu_admin_access a ON i.id=a.menu ";
		sc += " WHERE s.cat=" + cat;
		if(m_class != class_administrator)
			sc += " AND a.class=" + m_class;
		if(g_bDemo && g_bOrderOnlyVersion)
			sc += " AND s.orderonly=1 ";
		sc += " ORDER BY s.seq";
		
		if(dsAdminMenu.Tables["sub"] != null)
			dsAdminMenu.Tables["sub"].Clear();
		try
		{
			SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
			if(myCommand.Fill(dsAdminMenu, "sub") <= 0)
				continue;
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
		}

		//sub menu table
		ss += "\r\n<table border=0 class=m id=" + name + "Menu width=156 style='position:absolute;top:0;left:0;z-index:100;visibility:hidden' onmouseout='hideMenu()'>";
		for(int j=0; j<dsAdminMenu.Tables["sub"].Rows.Count; j++)
		{
			u = dsAdminMenu.Tables["sub"].Rows[j]["uri"].ToString();
			if(u.IndexOf("help.aspx") >= 0)
			{
				if(u.IndexOf("@@help_page") >= 0)
				{
					u = u.Replace("@@help_page", uri + "&name=" + HttpUtility.UrlEncode(Session["name"].ToString()) + "&email=" + HttpUtility.UrlEncode(Session["email"].ToString()) );
				}
				else
				{
					u = u.Replace("help.aspx", "help.aspx?name=" + HttpUtility.UrlEncode(Session["name"].ToString()) + "&email=" + HttpUtility.UrlEncode(Session["email"].ToString()) );
				}
			}

			menu_name = dsAdminMenu.Tables["sub"].Rows[j]["name"].ToString();
			ss += "\r\n<tr><td>&nbsp&nbsp;<a href=" + u;
			if(u.IndexOf("?") >= 0)
				ss += "&r=";
			else
				ss += "?r=";
			ss += DateTime.UtcNow.AddHours(12).ToOADate() + " class=d>" + menu_name + "</a></td></tr>";
		}
		ss += "</table>\r\n";

		//catalog table
		s += "\r\n<td id=m" + name + " onmouseover='setMenu(\"m" + name + "\", \"" + name + "Menu\")'>";
		s += "<a href=default.aspx?ms="+ HttpUtility.UrlEncode(name) +" class=w><b>" + name + "&nbsp&nbsp&nbsp&nbsp;</b></td>";
		s += "\r\n<td width=15>&nbsp&nbsp&nbsp;</td>";
	}

	string sVersion = "Wholesale";
	if(g_bRetailVersion)
		sVersion = "Retail";
	if(g_bOrderOnlyVersion)
		sVersion = "OrderOnly";
sVersion = "";
	if(g_bDemo)
		s += "<td width=100% nowrap align=right><font color=@@color_1><b>" + sVersion + " - " + Session["name"] + "</b></font></td>";
	else
		s += "<td width=100% nowrap align=right><font color=@@color_1><b>" + Session["name"] + "</b></font></td>";
	s += "</tr></table>";
//	smenu = smenu.Replace("@@help_page", uri);
//	smenu = smenu.Replace("@@rnd", r);
//	smenu = smenu.Replace("@@card_id", Session["card_id"].ToString());
	
	Response.Write(ApplyColor(s));
	Response.Write(ss);

}
</script>


