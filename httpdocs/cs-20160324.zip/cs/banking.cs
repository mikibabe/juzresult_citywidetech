<!-- #include file="page_index.cs" -->
<script runat=server>

DataSet ds = new DataSet();	//for creating Temp talbes templated on an existing sql table

string m_accountID = "";
string m_action = "";
string m_tranID = "";
string m_date = "";
string m_ref = "";
double m_dTotal = 0;
bool m_bPrint = false;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("administrator"))
		return;

	m_action = Request.QueryString["t"];

	if(Request.QueryString["id"] != null)
	{
		m_tranID = Request.QueryString["id"];
		if(m_action == "p")
			m_bPrint = true;
		PrintBankingSlip();
		return;
	}
	if(Request.QueryString["roll"] == "done")
	{
			PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<center><h3>Roll Back Done!</h3>");
		Response.Write("<br><br><a title='go to banking' href="+ Request.ServerVariables["URL"] +"?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +" class=blueFont2>Back to Banking</a>");
		PrintAdminFooter();
		return;
	}
	if(Request.QueryString["rid"] != null)
	{
		if(DoRollBackDeposit())
		{
			Response.Write("<br><center><h4>Please Wait for 1 Second to finish the Roll Back Transaction...</center>");
			Response.Write("<meta http-equiv=\"refresh\" content=\"1; URL="+ Request.ServerVariables["URL"] +"?roll=done\">");
			return;
		}
		
	}

	if(Request.Form["cmd"] == "Deposit")
	{
		if(!DoDeposit())
		{
			return;
		}
		return;
	}
	
	if(!IsPostBack)
	{
		string startDate = "";
		if(Session["banking_start_date"] == null || Session["banking_start_date"] == "")
		{
			
//			Calendar1.VisibleDate = DateTime.UtcNow.AddHours(12);
			startDate = DateTime.UtcNow.AddHours(12).ToString();
		
			Session["banking_start_date"] = startDate;

			DateTime dstart = DateTime.Parse(startDate);
			Session["banking_day"] = dstart.Day;
			Session["banking_month"] = dstart.Month;
			Session["banking_year"] = dstart.Year;
		}
		else
			startDate = Session["banking_start_date"].ToString();

		if(!DoSearch())
			return;
		BindGrid();
	}	

	bool bPrint = false;
	if(Request.Form["cmd"] == "Deposit")
		bPrint = true;

	if(m_action != "p")
		LFooter.Text = m_sAdminFooter;
//	PrintAdminFooter();
}

Boolean DoSearch()
{
	string startDate = DateTime.UtcNow.AddHours(12).ToString();
	if(Session["banking_start_date"] != null)
		startDate = Session["banking_start_date"].ToString();

	string endDate = DateTime.Parse(startDate).AddDays(1).ToString("dd-MM-yyyy");
	startDate = DateTime.Parse(startDate).ToString("dd-MM-yyyy");

	ds.Clear();

	string sc = "SET DATEFORMAT dmy ";
	sc += " SELECT t.id, d.trans_date, c.trading_name, d.payment_method, d.payment_ref, d.note, t.amount ";
	sc += ", c.id AS card_id, c.company, c.name, d.invoice_number ";
	sc += " FROM tran_detail d JOIN trans t ON t.id=d.id LEFT OUTER JOIN card c ON c.id=d.card_id ";
	sc += " WHERE t.dest = 1116 AND t.banked = 0 "; //unbanked trans in undeposite
	sc += " ORDER BY d.trans_date DESC, d.payment_method ";
//DEBUG("bankging2 =", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(ds, "banking");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}

void PrintJavaFunctions()
{
	Response.Write("<script language=JavaScript");
	Response.Write(">");
	
	const string s = @"
	function CheckAll()
	{
		for (var i=0;i<document.f.elements.length;i++) 
		{
			var e = document.f.elements[i];
			if((e.name != 'check') && (e.type=='checkbox'))
				e.checked = document.f.allbox.checked;
		}
	}
	";
	Response.Write(s);

	Response.Write("</script");
	Response.Write(">");
}

/////////////////////////////////////////////////////////////////
void BindGrid()
{
	PrintAdminHeader();
	PrintAdminMenu();

	int i = 0;
	//Response.Write("<br><center><font size=+2>Sales Report &nbsp; </font> <b>");
	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	m_cPI.PageSize = 50;
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);

	int rows = 0;
	if(ds.Tables["banking"] != null)
		rows = ds.Tables["banking"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?r=" + DateTime.UtcNow.AddHours(12).ToOADate();
	i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	string cols = "6";

		//call checkbox java function
	PrintJavaFunctions();

	StringBuilder sb = new StringBuilder();

	sb.Append("<form name=f action=banking.aspx method=post>");

	sb.Append("<br><table align=center valign=center cellspacing=0 cellpadding=1 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");

	//title
	sb.Append("<tr><td colspan=" + cols + " align=center><font size=+1><b>Bank Deposit</b></font></td></tr>");
	
	sb.Append("<tr>");
	sb.Append("<th width=120 align=left>Payment Method</th>");
	sb.Append("<th width=70 align=left>Date</th>");
	sb.Append("<th align=left>Customer</th>");
	sb.Append("<th align=left>Invoice#</th>");
	sb.Append("<th width=150 align=right>Amount</th>");
//	sb.Append("<th align=right>&nbsp;</th>");
	sb.Append("<th align=right>CHECK ALL<input type=checkbox name=allbox onclick='CheckAll(); CalcTotal();'></th>");
	sb.Append("</tr>");

	sb.Append("<tr><td colspan=" + cols + "><hr></td></tr>");

	if(rows <= 0)
	{
		sb.Append("</table>");
		LTable.Text = sb.ToString();
		return;
	}
	double dSubTotal = 0;
	double dGrandTotal = 0;
	string payment_method_old = "-1";

	sb.Append("<input type=hidden name=rows value=" + rows + ">");

	bool bAlterColor = true;
//	for(; i < rows && i < end; i++)
	string pm = "";
	for(i=0; i < rows; i++)
	{
		DataRow dr = ds.Tables["banking"].Rows[i];
		string id = dr["id"].ToString();
		string date = dr["trans_date"].ToString();
		pm = dr["payment_method"].ToString();
		string note = dr["note"].ToString();
		string reference = dr["payment_ref"].ToString();
//		string invoice_number = dr["invoice_number"].ToString();
		string customer = dr["trading_name"].ToString();
		string company = dr["company"].ToString();
		string name = dr["name"].ToString();
		string invoice = dr["invoice_number"].ToString();
		if(customer == "")
			customer = company;
		if(customer == "")
			customer = name;
		if(customer == "")
			customer = dr["card_id"].ToString();
//DEBUG("customer=", customer);
		string total = dr["amount"].ToString();

		DateTime dd = DateTime.Parse(date);
		double dTotal = MyMoneyParse(total);

		string payment = GetEnumValue("payment_method", pm);
		if(pm != payment_method_old)
		{
			if(dSubTotal != 0)
			{
				sb.Append("<tr><td colspan=" + (MyIntParse(cols) - 1).ToString() + " align=right><b>UnDeposit Total : </b></td>");
				sb.Append("<td align=right>" + dSubTotal.ToString("c") + "</td></tr>");
				sb.Append("<tr><td colspan=" + (MyIntParse(cols) - 1).ToString() + " align=right><font color=red><b>Deposit Total : </font></b></td>");
				sb.Append("<td align=right><input type=text style=border:0;font-size:12;font-face:verdana;text-align:right readonly=true name=total" + payment_method_old + " value=$0></td></tr>");
				dSubTotal = 0;
			}
            try{
                sb.Append("<tr><td><font size=+1><b>" + payment[0].ToString().ToUpper() + payment.Substring(1, payment.Length-1) + "</b></font></td></tr>");
            }catch(Exception ex){
                sb.Append("<tr><td><font size=+1><b></b></font></td></tr>");
            }
			
			bAlterColor = true;
		}
		payment_method_old = pm;

		sb.Append("<tr");
		if(bAlterColor)
			sb.Append(" class=rowColor");
		bAlterColor = !bAlterColor;
		sb.Append(">");

		sb.Append("<input type=hidden name=id" + i.ToString() + " value=" + id + ">");
		sb.Append("<input type=hidden name=amount" + i.ToString() + " value=" + dTotal + ">");
		sb.Append("<input type=hidden name=type" + i.ToString() + " value=" + pm + ">");

		if(payment.ToLower() == "cheque")
			sb.Append("<td>" + dr["payment_ref"].ToString());
		else
			sb.Append("<td>&nbsp;");
		
		sb.Append(" " + note + " &nbsp&nbsp;");
		sb.Append("</td>");

		sb.Append("<td>" + dd.ToString("dd-MM-yy") + "</td>");
//		sb.Append("<td><a href=invoice.aspx?" + invoice_number + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o>" + dr["trading_name"].ToString() + "</a></td>");
		sb.Append("<td>" + customer + "</td>");
		int nINCREASED = 12;
		string sinvoice = "";
		int nFound = 0;
		for(int k=0; k<invoice.Length; k++)
		{
			sinvoice += invoice[k].ToString();
	//		DEBUG("sinvoice = ", sinvoice);
			if(invoice[k].ToString() == ",")
				nFound++ ;
			
			if(nFound == nINCREASED)
			{
				nINCREASED += 12;
				sinvoice += "<br>";
			}
			
		}
		invoice = sinvoice;
		sb.Append("<td>" + invoice + "</td>");
		sb.Append("<td align=right>" + dTotal.ToString("c") + "</td>");
		sb.Append("<td align=right><input type=checkbox name=check" + i.ToString() + " onclick=CalcTotal();></td>");
		sb.Append("</tr>");

		dSubTotal += dTotal;
		dGrandTotal += dTotal;
	}

	string cols1 = (MyIntParse(cols) - 1).ToString();
	if(dSubTotal != 0)
	{
		sb.Append("<tr><td colspan=" + cols1 + " align=right><b>UnDeposit Total:</b></td>");
		sb.Append("<td align=right>" + dSubTotal.ToString("c") + "</td></tr>");
		sb.Append("<tr><td colspan=" + cols1 + " align=right><font color=red><b>Deposit Total:</b></font></td>");
		sb.Append("<td align=right><input type=text style=border:0;font-size:12;font-face:verdana;text-align:right readonly=true name=total" + pm + " value=$0></td></tr>");
	}

	sb.Append("<tr><td>&nbsp;</td></tr>");
	sb.Append("<tr><td colspan=" + cols1 + " align=right><b>Grant UnDeposit Total:</b></td>");
	sb.Append("<td align=right><b>" + dGrandTotal.ToString("c") + "</b></td>");
	sb.Append("</tr>");
	sb.Append("<tr><td colspan=" + cols1 + " align=right><b><font class=blueFont2>Grant Deposit Total:</b></font></td>");
	sb.Append("<td align=right><input type=text style=border:0;font-size:12;font-face:verdana;text-align:right readonly=true name=gtotal value=$0 class=blueFont2></td></tr>");

	sb.Append("</tr>");


	sb.Append("<tr><td colspan=" + cols + " align=right><br>");

	sb.Append("<b>To : </b>" + PrintToAccountList());

	sb.Append("<b>Date : </b><input type=text size=10 name=date value=" + DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy") + ">&nbsp&nbsp;");
	sb.Append("<b>Ref# : </b><input type=text size=10 name=ref>");
	sb.Append("<input type=submit name=cmd value=Deposit class=depositButton title='Deposit' ");
	sb.Append(" onclick=\"if(!confirm('Processing Transaction!!!')){return false;}\" ");
	sb.Append(">");
	sb.Append("</td></tr>");
	sb.Append("</table>");

	sb.Append("</form>");

	sb.Append("\r\n<script language=JavaScript");
	sb.Append(">\r\n");
	sb.Append("function CalcTotal()\r\n");
	sb.Append("{	var total = 0;\r\n");
	sb.Append("		var gtotal = 0;\r\n");
	sb.Append("		var type = document.f.type0.value;\r\n");
	sb.Append("		var type_old = type;\r\n");
    sb.Append("try{ ");
	sb.Append("for(var i=0; i<" + rows + "; i++)\r\n");
	sb.Append("{		");
	sb.Append(" type = eval(\"document.f.type\" + i + \".value\");\r\n");
	sb.Append(" if(type != type_old)\r\n");
	sb.Append("	{			");
	sb.Append("		eval(\"document.f.total\" + type_old + \".value = '$' + total\");");
	sb.Append("		type_old = type; gtotal += total; total = 0; \r\n");
	sb.Append("	}			");
	sb.Append("	if(eval(\"document.f.check\" + i + \".checked\"))\r\n");
	sb.Append("		total += Number(eval(\"document.f.amount\" + i + \".value\"));\r\n");
	sb.Append(" total = Math.round(total * 100) / 100; \r\n");
	sb.Append("}			");
	sb.Append("	eval(\"document.f.total\" + type_old + \".value = '$' + total\");");
	sb.Append(" gtotal += total; ");
	sb.Append(" gtotal = Math.round(gtotal * 100) / 100;");
	sb.Append(" document.f.gtotal.value = '$' + gtotal;\r\n");
    sb.Append("}catch(err){console.log(err)}");
	sb.Append("}\r\n</script");
	sb.Append(">");


	LTable.Text = sb.ToString();
}

bool DoRollBackDeposit()
{
	string roll_id = Request.QueryString["rid"];
if(roll_id != "" && roll_id != null)
{
	if(TSIsDigit(roll_id))
	{
	string sc = "";
	sc += " SELECT * FROM tran_deposit_id WHERE id = "+ roll_id +" ";
	int rows =0;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(ds, "roll_id");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	sc = " IF EXISTS (SELECT id FROM tran_deposit WHERE id = "+ roll_id +") ";
	sc += " UPDATE account SET balance = balance - (SELECT total FROM tran_deposit WHERE id = " + roll_id +") ";
	sc += " WHERE id = (SELECT account_id FROM tran_deposit WHERE id = "+ roll_id +") ";
	sc += " DELETE FROM tran_deposit WHERE id = "+ roll_id +" ";
	
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	for(int i=0; i<rows; i++)
	{
		DataRow dr = ds.Tables["roll_id"].Rows[i];
		string tran_id = dr["tran_id"].ToString();
		string id = dr["id"].ToString();
		string kid = dr["kid"].ToString();
		
		sc = " UPDATE account SET balance = balance + (SELECT amount FROM trans WHERE id = " + tran_id +" ) ";
		sc += " WHERE CONVERT(varchar(5), class1) + CONVERT(varchar(5), class2) + CONVERT(varchar(5), class3) + CONVERT(varchar(5), class4) ";
		sc += " = 1116 "; //(SELECT dest FROM trans WHERE id = "+ tran_id +") ";
		sc += " UPDATE trans SET banked = 0 , trans_bank_id = '', dest = '1116' WHERE id = "+ tran_id +"";
		sc += " DELETE FROM tran_deposit_id WHERE tran_id = "+ tran_id +" AND kid = "+ kid +"";
//	DEBUG("sc1 = ", sc );
			try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	

	}
	}
}
	return true;
}

bool DoDeposit()
{
	m_date = Request.Form["date"];
	m_ref = Request.Form["ref"];

	string sc = "BEGIN TRANSACTION ";
	sc += " SET DATEFORMAT dmy ";
	sc += " INSERT INTO tran_deposit (total, deposit_date, ref, staff, account_id) ";
	sc += " VALUES(" + Request.Form["gtotal"] + ", '" + m_date + "', '" + EncodeQuote(m_ref) + "', " + Session["card_id"] + "";
	sc += " , "+ Request.Form["account_id"];
	sc += " ) ";
	sc += " SELECT IDENT_CURRENT('tran_deposit') AS id ";
	sc += " COMMIT ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(ds, "tranid") != 1)
		{
			Response.Write("<br><br><center><h3>Error getting IDENT");
			return false;
		}
		m_tranID = ds.Tables["tranid"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	sc = "";

	string account_class = GetAccountClass(Request.Form["account_id"]);
//DEBUG("account clas = ", account_class);
	int rows = MyIntParse(Request.Form["rows"]);
	for(int i=0; i<rows; i++)
	{
		if(Request.Form["check" + i] != "on")
			continue;
		string id = Request.Form["id" + i];
		sc += " INSERT INTO tran_deposit_id (id, tran_id) VALUES(" + m_tranID + ", " + id + ") ";	
		sc += " UPDATE trans SET banked = 1, trans_bank_id = " + m_tranID;
		sc += " WHERE id = " + id + " ";
	}

	//update account balance
	sc += " UPDATE account SET balance = balance - " + Request.Form["gtotal"];
	sc += " WHERE class1=1 AND class2=1 AND class3=1 AND class4=6 ";
	sc += " UPDATE account SET balance = balance + " + Request.Form["gtotal"];
	sc += " WHERE id=" + Request.Form["account_id"];

	if(sc == "")
		return false;

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=banking.aspx?id=" + m_tranID + "\">");
//	PrintBankingSlip();
	return true;
}

bool GetTransaction(string id)
{
	string sc = "SET DATEFORMAT dmy ";
	sc += " SELECT t.id, d.trans_date, c.trading_name, d.payment_method, d.payment_ref, d.note, t.amount ";
	sc += ", c.company, c.name, d.bank, d.branch, d.paid_by ";
	sc += " FROM tran_detail d JOIN trans t ON t.id=d.id LEFT OUTER JOIN card c ON c.id=d.card_id ";
	sc += " WHERE t.id = " + id;// + " AND t.dest = 1116 "; //unbanked trans in undeposite
	sc += " ORDER BY d.payment_method ";
//DEBUG("banking = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(ds, "banking");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool PrintBankingSlip()
{
	int i = 0;
	int rows = 0;
	string sc = "SELECT i.tran_id, d.deposit_date ";
	sc += " FROM tran_deposit_id i JOIN tran_deposit d ON d.id=i.id ";
	sc += " WHERE i.id = " + m_tranID;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(ds, "ids");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	rows = ds.Tables["ids"].Rows.Count;
	if(rows <= 0)
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><center><h3>Deposit Record Not Found</h3>");
		return false;
	}

	string deposit_date = DateTime.Parse(ds.Tables["ids"].Rows[0]["deposit_date"].ToString()).ToString("dd-MM-yyyy");

	for(i=0; i<rows; i++)
	{
		string id = ds.Tables["ids"].Rows[i]["tran_id"].ToString();
		if(!GetTransaction(id))
			return false;
	}

	if(ds.Tables["banking"] != null)
		rows = ds.Tables["banking"].Rows.Count;

	string cols = "5";

	StringBuilder sb = new StringBuilder();

	sb.Append("<tr>");
	sb.Append("<th width=300 align=left><font color=#888888>Cheque issued by</font></th>");
	sb.Append("<th width=70 align=left><font color=#888888>Bank</font></th>");
	sb.Append("<th align=left><font color=#888888>Branch</font></th>");
	sb.Append("<th width=90 align=right><font color=#888888>Ref/Chk#</font></th>");
	sb.Append("<th width=90 align=right><font color=#888888>Amount</font></th>");
	sb.Append("</tr>");

	sb.Append("<tr><td colspan=" + cols + "><hr></td></tr>");

	double dSubTotal = 0;
	double dCashTotal = 0;
	double dChequeTotal = 0;
	double dGrandTotal = 0;
	
	string payment_method_old = "-1";

	string pm = "";
	for(i=0; i < rows; i++)
	{
		DataRow dr = ds.Tables["banking"].Rows[i];
		string id = dr["id"].ToString();
		string company = dr["company"].ToString();
		string paid_by = dr["paid_by"].ToString();
		if(paid_by != "")
			company = paid_by; //cheque paid by different company or title
		else if(company == "")
			company = dr["name"].ToString(); //use personal name

		string bank = dr["bank"].ToString();
		string branch = dr["branch"].ToString();
		string date = dr["trans_date"].ToString();
		pm = dr["payment_method"].ToString();
		string note = dr["note"].ToString();
		string reference = dr["payment_ref"].ToString();
		string customer = dr["trading_name"].ToString();
		string total = dr["amount"].ToString();

		double dTotal = MyMoneyParse(total);
//DEBUG("total=", total);
		string payment = GetEnumValue("payment_method", pm);
		if(pm != payment_method_old)
		{
			if(dSubTotal != 0)
			{
				if(payment_method_old == "1")
					dCashTotal = dSubTotal;
				else if(payment_method_old == "2")
					dChequeTotal = dSubTotal;
				dSubTotal = 0;
			}
		}
		payment_method_old = pm;

		dSubTotal += dTotal;
		dGrandTotal += dTotal;

		if(payment.ToLower() != "cheque")
			continue;

		sb.Append("<tr>");
		sb.Append("<td>" + company + "</td>");
		sb.Append("<td>" + bank + "</td>");
		sb.Append("<td>" + branch + "</td>");
		sb.Append("<td align=right>" + reference + "</td>");
		sb.Append("<td align=right>" + dTotal.ToString("c") + "</td>");
		sb.Append("</tr>");

	}
	if(dSubTotal != 0)
	{
		if(payment_method_old == "1")
			dCashTotal = dSubTotal;
		else if(payment_method_old == "2")
			dChequeTotal = dSubTotal;
		dSubTotal = 0;
	}

	sb.Append("<tr><td colspan=" + cols + "><hr></td></tr>");

	int cols1 = MyIntParse(cols) - 1;

	sb.Append("<tr><td colspan=" + cols1 + " align=right><b>Total : &nbsp; </b></td>");
	sb.Append("<td align=right>" + dChequeTotal.ToString("c") + "</td></tr>");

	sb.Append("<tr><td>&nbsp;</td></tr>");
	sb.Append("<tr><td>&nbsp;</td></tr>");

	sb.Append("<tr><td colspan=" + cols1 + " align=right><font size=+1><b>Deposit Total : &nbsp; </b></font></td>");
	sb.Append("<td align=right><font size=+1><b>" + dGrandTotal.ToString("c") + "</b></font></td></tr>");


	//begin write out
	string header = ReadSitePage("deposit_header");

	StringBuilder sbb = new StringBuilder();

	sbb.Append("<table align=center valign=center cellspacing=0 cellpadding=0 border=0 bordercolor=#EEEEEE bgcolor=white");
	sbb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	sbb.Append("<tr><td colspan=" + cols + ">");
	sbb.Append(header);
	sbb.Append("</td></tr>");

	sbb.Append("<tr><td colspan=" + cols1 + " align=right><b>Date : &nbsp; </b></td>");
//	sbb.Append("<td align=right>" + DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy") + "</td></tr>");
	sbb.Append("<td align=right>" + deposit_date + "</td></tr>");

	sbb.Append("<tr><td colspan=" + cols1 + " align=right><b>Notes : &nbsp; </b></td>");
	sbb.Append("<td align=right>" + dCashTotal.ToString("c") + "</td></tr>");

	sbb.Append("<tr><td colspan=" + cols1 + " align=right><b>Cheques : &nbsp; </b></td>");
	sbb.Append("<td align=right>" + dChequeTotal.ToString("c") + "</td></tr>");

	sbb.Append("<tr><td colspan=" + cols1 + " align=right><b>Total : &nbsp; </b></td>");
	sbb.Append("<td align=right>" + dGrandTotal.ToString("c") + "</td></tr>");

	sbb.Append("<tr><td>&nbsp; <br> &nbsp;</td></tr>");

	if(dChequeTotal > 0)
	{
		sbb.Append("<tr><td colspan=" + cols + "><h4>Particulars of cheques</h4></td></tr>");
		sbb.Append(sb.ToString());
	}
	if(m_bPrint)
	{
		Response.Write("<html>");
		Response.Write("<head>");

		Response.Write("<style type=text/css>");
		Response.Write("td{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:vardana;}");
		Response.Write("body{background:#FFFFFF;font:10px Verdana;}");
		Response.Write("</style></head>");

		Response.Write("<body onload='window.print()'>");
		Response.Write(sbb.ToString());
		Response.Write("</table>");
		Response.Write("</body>");
		Response.Write("</html>");
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=banking.aspx?id=" + m_tranID + "\">");
	}
	else
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write(sbb.ToString());
		Response.Write("<tr><td colspan=" + cols + " align=right><br>");
		Response.Write("<input type=button class=linkButton title='Roll Back Trans' value='Roll Back Trans' ");
		Response.Write(" onclick=\"if(!confirm('Confirm Roll Back!!!!')){return false;}else{ window.location=('"+ Request.ServerVariables["URL"] +"?rid="+ m_tranID +"' );} \"> ");
		Response.Write("<input type=button class=linkButton title='Print' " );
		Response.Write(" onclick=window.location=('banking.aspx?id=" + m_tranID + "&t=p') value='Print'>");
		Response.Write("</td></tr>");
		Response.Write("</table>");
		PrintAdminFooter();
	}
	return true;
}

string PrintToAccountList()
{
	int rows = 0;
	string sc = "SELECT * FROM account ORDER BY class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "account");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	
	StringBuilder sb = new StringBuilder();

	sb.Append("<select name=account_id>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = ds.Tables["account"].Rows[i];
		string id = dr["id"].ToString();
//		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		sb.Append("<option value=" + id);
		if(id == m_accountID)
			sb.Append(" selected");
		sb.Append(">" + disnumber + " " + dr["name4"].ToString() + " " +dr["name1"].ToString()+ " $" +dr["balance"].ToString());		
	}
	sb.Append("</select>");
	return sb.ToString();
}

</script>

<table width=100%>
<tr><td><asp:Label id=LTable runat=server/></td></tr>

<tr><td>

</td></tr>

<tr><td>
<asp:Label id=LFooter runat=server/>
</td></tr>

</table>