<!-- #include file="kit_fun.cs" -->
<!-- #include file="sales_function.cs" -->
<!-- #include file="card_function.cs" -->
<!-- #include file="fifo_f.cs" -->

<script runat=server>

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
const int m_cols = 7;	//how many columns main table has, used to write colspan=
string m_tableTitle = "";
string m_invoiceNumber = "";
string m_comment = "";	//Sales Comment in Invoice Table;
string m_custpo = "";
string m_salesNote = "";
string m_branchID = "1";
string m_branchName = "";
string m_sSalesType = ""; //as string, m_quoteType is receipt_type ID
string m_nShippingMethod = "1";
string m_specialShipto = "0";
string m_specialShiptoAddr = ""; //special
string m_pickupTime = "";

string m_orderStatus = "1"; //Being Processed
string m_url = "";

double m_dFreight = 0;
double m_dInvoiceTotal = 0;
string m_discount = "0";
int m_nSearchReturn = 0;

bool b_create = false;
bool m_bCreditReturn = false;
bool m_bOrderCreated = false;
bool m_bFixedPrices = false;

string m_jdic = ""; //JScript Dictionary object
string m_sProductCache = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("editor"))
		return;

	if(MyBooleanParse(GetSiteSettings("use_fixed_level_prices", "0", true)))
		m_bFixedPrices = true;

	if(Session["branch_id"] != null)
		m_branchID = Session["branch_id"].ToString();

	m_branchName = GetBranchName(m_branchID);

	if(Request.QueryString["t"] == "new")
		EmptyCart();
	else if(Request.QueryString["t"] == "p")
	{
		PrintPaymentForm();
		return;
	}
	else if(Request.QueryString["t"] == "end")
	{
		DoReceivePayment();
		return;
	}

	bool bMassInterface = false;
	if(Request.Form["rows"] == null)
		bMassInterface = true;

	if(bMassInterface)
	{
		if(!BuildProductCache())
			return;
		PrintMassInterface();
		return;
	}

	if(Request.Form["confirm_checkout"] == "0") //force going back on unknow error
	{
//		Response.Write("Error");
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=qpos.aspx\">");
		return;
	}

	if(BuildShoppingCart())
	{
		if(!DoCreateOrder(false, m_custpo, m_salesNote)) // false means not system quotation
		{
			Response.Write("<h3>ERROR CREATING QUOTE</h3>");
			return;
		}
		EmptyCart();
		m_bOrderCreated = true;
		Session["order_created"] = true;

		if(!CreateInvoice(m_orderID))
		{
			Response.Write("<h3>Error Create Invoice</h3>");
			return;
		}

		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=qpos.aspx?t=p&i=" + m_invoiceNumber + "&total=" + m_dInvoiceTotal + "\">");
		return;

		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>" + m_sSalesType.ToUpper() + " Created</h3>");
		Response.Write("<h5>Number : </h5><h1><font color=red>" + m_orderID + "</h1><br>");
		Response.Write("<input type=button " + Session["button_style"]);
		Response.Write("onclick=window.location=('invoice.aspx?n=" + m_invoiceNumber + "') ");
		Response.Write(" value='Print Invoice'>");
		Response.Write("<br><br><br><br><br>");
		LFooter.Text = m_sAdminFooter;

	}
}

bool CreateOrder(string branch_id, string card_id, string po_number, string special_shipto, string shipto, 
				 string shipping_method, string pickup_time, string contact, string sales_id, string sales_note, 
				 ref string order_number)
{
	string reason = "";
	bool bStopOrdering = false;//IsStopOrdering(card_id, ref reason);
	if(bStopOrdering)
	{
		if(reason == "")
			reason = "No reason given.";
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>This account has been disabled to place order</h3><br>");
		Response.Write("<h4><font color=red>" + reason + "<font color=red></h4><br>");
		Response.Write("<h4><a href=ecard.aspx?id=" + card_id + " class=o>Edit Account</a></h4>");
		Response.Write("<br><br><br><br><br><br><br>");
		LFooter.Text = m_sFooter;
		return false;
	}

//	if(!CheckBottomPrice())
//		return false;

	DataSet dsco = new DataSet();
	string sc = "BEGIN TRANSACTION ";
	sc += " INSERT INTO orders (number, card_id, po_number, freight) VALUES(0, " + card_id + ", '";
	sc += po_number + "', 0 ";
	sc += ") SELECT IDENT_CURRENT('orders') AS id";
	sc += " COMMIT ";
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dsco, "id") == 1)
		{
			m_orderID = dsco.Tables["id"].Rows[0]["id"].ToString();
			m_orderNumber = m_orderID; //new order, same
			//assign ordernumber same as id
			sc = "UPDATE orders SET number=" + m_orderNumber + ", branch=" + branch_id + ", sales_note='" + sales_note + "' ";
			if(special_shipto == "1")
				sc += ", special_shipto=1, shipto='" + shipto + "' ";
			sc += ", contact='" + contact + "' ";
			if(sales_id != "")
				sc += ", sales=" + sales_id;
			sc += ", shipping_method=1";// + shipping_method;
			sc += ", pick_up_time='" + EncodeQuote(pickup_time) + "' ";
			sc += " WHERE id=" + order_number;
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
		}
		else
		{
			Response.Write("<br><br><center><h3>Create Order failed, error getting new order number</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(!WriteOrderItems(m_orderID))
		return false;
	return true;
}

bool CreateInvoice(string id)
{
	DataRow dr = null;
	double dPrice = 0;
	double dFreight = 0;
	double dTax = 0;
	double dTotal = 0;
	int rows = 0;
	string sc = "SELECT * FROM orders WHERE id=" + id;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		rows = myCommand1.Fill(dst, "invoice");
		if(rows != 1)
		{
			Response.Write("<br><br><center><h3>Error creating invoice, id=" + id + ", rows return:" + rows + "</h3>");
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	dr = dst.Tables["invoice"].Rows[0];
	string card_id = dr["card_id"].ToString();
	string po_number = dr["po_number"].ToString();
	string m_shippingMethod = dr["shipping_method"].ToString();
	string m_pickupTime = dr["pick_up_time"].ToString();
	string sales = dr["sales"].ToString();
	if(sales != "")
		sales = TSGetUserNameByID(sales);

	dFreight = Math.Round(MyDoubleParse(dst.Tables["invoice"].Rows[0]["freight"].ToString()), 2);

	sc = "SELECT * FROM order_item WHERE id=" + id;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		rows = myCommand1.Fill(dst, "item");
		if(rows <= 0)
		{
			Response.Write("<br><br><center><h3>Error getting order items, id=" + id + ", rows return:" + rows + "</h3>");
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	for(int i=0; i<dst.Tables["item"].Rows.Count; i++)
	{
		dr = dst.Tables["item"].Rows[i];
		double dp = MyDoubleParse(dr["commit_price"].ToString());
		dp = Math.Round(dp, 2);
		double qty = MyDoubleParse(dr["quantity"].ToString());
		dPrice += dp * qty;
		dPrice = Math.Round(dPrice, 2);
	}
	dTax = (dPrice + dFreight) * GetGstRate(card_id);
	dTax = Math.Round(dTax, 2);
	dTotal = (dPrice + dFreight) * (1 + GetGstRate(card_id));
	dTotal = Math.Round(dTotal, 2);

	m_dInvoiceTotal = dTotal;
	
	dr = dst.Tables["invoice"].Rows[0];
	string special_shipto = "0";
	if(bool.Parse(dr["special_shipto"].ToString()))
		special_shipto = "1";
	
	string receipt_type = GetEnumID("receipt_type", "invoice");
	if(m_bCreditReturn)
		receipt_type = "6";//GetEnumID("receipt_type", "credit note");

	string sbSystem = "0";
	if(MyBooleanParse(dr["system"].ToString()))
		sbSystem = "1";

	sc = "BEGIN TRANSACTION ";
	sc += " SET DATEFORMAT dmy ";
	sc += "INSERT INTO invoice (type, card_id, price, tax, total, commit_date, special_shipto, shipto ";
	sc += ", freight, cust_ponumber, shipping_method, pick_up_time, sales, sales_note)";
	sc += " VALUES(" + receipt_type + ", " + dr["card_id"].ToString() + ", " + dPrice;
	sc += ", " + dTax + ", " + dTotal + ", GETDATE(), ";
	sc += special_shipto + ", '" + EncodeQuote(dr["shipto"].ToString()) + "', " + dFreight + ", '" + po_number + "', ";
	sc += m_shippingMethod + ", '" + EncodeQuote(m_pickupTime) + "', '" + EncodeQuote(sales) + "', '";
	sc += EncodeQuote(dr["sales_note"].ToString()) + "' ";
	sc += " )";
	sc += " SELECT IDENT_CURRENT('invoice') AS id";
	sc += " COMMIT ";
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dst, "invoice_id") == 1)
		{
			m_invoiceNumber = dst.Tables["invoice_id"].Rows[0]["id"].ToString();
		}
		else
		{
			Response.Write("<br><br><center><h3>Error get new invoice number</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	//update order to record invoice number
	sc = "UPDATE orders SET invoice_number=" + m_invoiceNumber + ", status=3 WHERE id=" + id; //status 3 = shipped
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	bool bHasKit = false;

	//write price history
	for(int i=0; i<dst.Tables["item"].Rows.Count; i++)
	{
		dr = dst.Tables["item"].Rows[i];
		string commit_price = dr["commit_price"].ToString();
		string quantity = dr["quantity"].ToString();
		string code = dr["code"].ToString();
		string name = dr["item_name"].ToString();
		string kit = dr["kit"].ToString();
		string krid = dr["krid"].ToString();
		string supplier = dr["supplier"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		string supplier_price = dr["supplier_price"].ToString();
		sbSystem = "0";
		if(bool.Parse(dr["system"].ToString()))
			sbSystem = "1";

		string sKit = "0";
		if(MyBooleanParse(kit))
		{
			sKit = "1";
			bHasKit = true;
		}
		if(krid == "")
			krid = "null";

		sc = "INSERT INTO sales (invoice_number, code, name, quantity, commit_price, supplier, supplier_code, supplier_price, system, kit, krid)";
		sc += " VALUES(" + m_invoiceNumber + ", " + code + ", '" + name + "', " + quantity + ", " + commit_price + ", ";
		sc += "'" + supplier + "', '" + supplier_code + "', " + supplier_price + ", " + sbSystem + ", " + sKit + ", " + krid + ")";

		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
		
		double dQty = MyDoubleParse(quantity);
		fifo_sales_update_cost(m_invoiceNumber, code, commit_price, m_branchID, dQty);
		//update stock qty
		UpdateStockQty(dQty, code, m_branchID);
//		fifo_checkAC200Item(m_invoiceNumber, code, supplier_code, commit_price); //for unknow item
	}

	if(bHasKit)
	{
		if(!RecordKitToInvoice(id, m_invoiceNumber))
			return true;
	}

	UpdateCardAverage(card_id, dPrice, MyIntParse(DateTime.UtcNow.AddHours(12).ToString("MM")));
	UpdateCardBalance(card_id, dTotal);
	return true;
}

bool UpdateStockQty(double qty, string id, string branch_id)
{
	string sc = "";
	sc = " IF NOT EXISTS (SELECT code FROM stock_qty WHERE code=" + id;
	sc += " AND branch_id = " + branch_id;
	sc += ")";
	sc += " INSERT INTO stock_qty (code, branch_id, qty, supplier_price) ";
	sc += " VALUES (" + id + ", " + branch_id + ", " + (0 - qty).ToString() + ", " + GetSupPrice(id) + ")"; 
	sc += " ELSE Update stock_qty SET ";
	sc += "qty = qty - " + qty + ", allocated_stock = allocated_stock - " + qty;
	sc += " WHERE code=" + id + " AND branch_id = " + branch_id;

	if(!g_bRetailVersion)
	{
		sc += " UPDATE product SET stock = stock - " + qty + ", allocated_stock = allocated_stock - " + qty;
		sc += " WHERE code=" + id;
	}
	else //retail version only update allocated stock in product table
	{
		sc += " UPDATE product SET allocated_stock = allocated_stock - " + qty;
		sc += " WHERE code=" + id;
	}
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
/*
string GetSupPrice(string id)
{
	string s_price ="0";
	int nRows = 0;
	string sc = " SELECT supplier_price FROM code_relations WHERE code=" + id;	
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		nRows = myAdapter.Fill(dst, "sup_price");
		if(nRows != 1)
		{
			return s_price;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return s_price;
	}
	s_price = dst.Tables["sup_price"].Rows[0]["supplier_price"].ToString();
	return s_price;
}
*/
bool DoCreateOrder(bool bSystem, string sCustPONumber, string sSalesNote)
{
	string branch = "1";
	string contact = "";
	return CreateOrder(branch, m_customerID, sCustPONumber, m_specialShipto, m_specialShiptoAddr, m_nShippingMethod, 
		m_pickupTime, contact, m_sales,  EncodeQuote(sSalesNote), ref m_orderID);
}

bool DoDeleteOrder()
{
	DeleteOrderItems(m_orderID);
	string sc = " DELETE FROM orders WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DoUpdateOrder()
{
	if(Request.Form["order_id"] == null || Request.Form["order_id"] == "")
		return true;

//	if(!CheckBottomPrice())
//		return false;

	m_orderID = Request.Form["order_id"];

	string sc = "UPDATE orders SET ";
	sc += " branch=" + m_branchID;
	sc += ", card_id=" + m_customerID;
	sc += ", po_number='" + EncodeQuote(m_custpo) + "' ";
	sc += ", sales_note='" + EncodeQuote(m_salesNote) + "' ";
	sc += ", shipping_method=" + m_nShippingMethod;
	sc += ", special_shipto=" + m_specialShipto;
	sc += ", shipto='" + EncodeQuote(m_specialShiptoAddr) + "' ";
	sc += ", pick_up_time='" + EncodeQuote(m_pickupTime) + "' ";
	sc += ", locked_by=null, time_locked=null "; //unlock
	sc += " WHERE id=" + m_orderID;

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	DeleteOrderItems(m_orderID);
	WriteOrderItems(m_orderID);
	return true;
}

bool DeleteOrderKits(string m_orderID)
{
	string sc = " DELETE FROM order_kit WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DeleteOrderItems(string m_orderID)
{
	if(!DeleteOrderKits(m_orderID))
		return false;

	int items = 0;
	string sc = " SELECT code, quantity FROM order_item WHERE id=" + m_orderID;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		items = myCommand1.Fill(dst, "delete_items");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	sc = "";
	for(int i=0; i<items; i++)
	{
		DataRow dr = dst.Tables["delete_items"].Rows[i];
		string code = dr["code"].ToString();
		string sqty = dr["quantity"].ToString();
		int nqty = MyIntParse(sqty);
		sc += " Update stock_qty SET ";
		sc += " allocated_stock = allocated_stock - " + sqty;
		sc += " WHERE code=" + code + " AND branch_id = " + m_branchID;
		sc += " UPDATE product SET allocated_stock = allocated_stock - " + sqty + " WHERE code=" + code;
	}
	sc += " DELETE FROM order_item WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool WriteOrderItems(string order_id)
{
	CheckShoppingCart();

	for(int i=0; i<dtCart.Rows.Count; i++)
	{
		DataRow dr = dtCart.Rows[i];
		if(dr["site"].ToString() != m_sCompanyName)
			continue;

		string kit = dr["kit"].ToString();
		double dPrice = Math.Round(MyDoubleParse(dr["salesPrice"].ToString()), 2);
		string name = EncodeQuote(dr["name"].ToString());
		if(name.Length > 255)
			name = name.Substring(0, 255);

		if(kit == "1")
		{
			RecordKitToOrder(order_id, dr["code"].ToString(), name, dr["quantity"].ToString(), dPrice, m_branchID);
			continue;
		}
		
		string sc = "INSERT INTO order_item (id, code, quantity, item_name, supplier, supplier_code, supplier_price ";
		sc += ", commit_price) VALUES(" + order_id + ", " + dr["code"].ToString() + ", ";
		sc += dr["quantity"].ToString() + ", '" + name + "', '" + dr["supplier"].ToString();
		sc += "', '" + dr["supplier_code"].ToString() + "', " + Math.Round(MyDoubleParse(dr["supplierPrice"].ToString()), 2);
		sc += ", " + Math.Round(MyDoubleParse(dr["salesPrice"].ToString()), 2) + ") ";
		
		sc += " UPDATE stock_qty SET allocated_stock = allocated_stock + " + dr["quantity"].ToString();
		sc += " WHERE code = " + dr["code"].ToString();
		sc += " AND branch_id = " + m_branchID;
		
		sc += " UPDATE product SET allocated_stock=allocated_stock+" + dr["quantity"].ToString();
		sc += " WHERE code=" + dr["code"].ToString() + " ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

void PrintJavaFunction()
{
	Response.Write("<script TYPE=text/javascript");
	Response.Write(">");
	Response.Write("function OnShippingMethodChange()");
	Response.Write("{		");
	Response.Write("	var m = Number(document.form1.shipping_method.value);\r\n");
	Response.Write("	if(m == 1){document.all('tShipTo').style.visibility='hidden';document.all('tPT').style.visibility='visible';}\r\n");
	Response.Write("	else{document.all('tShipTo').style.visibility='visible';document.all('tPT').style.visibility='hidden';}\r\n");
	Response.Write("}\r\n");

	Response.Write("function OnSpecialShiptoChange()								");
	Response.Write("{																");
	Response.Write("	var v = document.all('ssta').style.visibility;				");
	Response.Write("	if(v != 'hidden')											");
	Response.Write("	{															");
	Response.Write("		document.all('ssta').style.visibility='hidden';			");
	Response.Write("		document.all('tshiptoaddr').style.visibility='visible';	");
	Response.Write("		document.all('tshiptoaddr').style.top = 10;			");
	Response.Write("	}															");
	Response.Write("	else														");
	Response.Write("	{															");
	Response.Write("		document.all('ssta').style.visibility='visible';		");
	Response.Write("		document.all('tshiptoaddr').style.visibility='hidden';	");
	Response.Write("	}															");
	Response.Write("}																");

	Response.Write("</script");
	Response.Write(">");
}

bool PrintMassInterface()
{
	PrintAdminHeader();

	StringBuilder sb = new StringBuilder();

	sb.Append("<form name=f action=? method=post>");
	sb.Append("<input type=hidden name=confirm_checkout value=0>");

//sb.Append("<input type=text name=debug>");
	sb.Append("<font color=#444444><b>P.O.S. - " + m_sCompanyTitle + "</b></font>");
//	sb.Append(" &nbsp&nbsp&nbsp&nbsp;<b><font color=#888888>Sales : " + Session["name"] + "</b>");
	sb.Append("<div align=right><font color=#888888>");
	sb.Append(m_branchName + " - ");
	sb.Append(Session["name"] + "</div>");

	sb.Append("<table width=100% border=1 cellspacing=0 cellpadding=0 bordercolor=#eeeeee bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr><td width=110 valign=top>");
	
	//left side table
	sb.Append("<table width=100% border=0 cellspacing=0 cellpadding=0 bordercolor=#eeeeee bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr><td><input type=text name=code class=f style='font-weight:bold'></td></tr>");
	sb.Append("<tr><td><textarea name=desc rows=5 cols=15 class=f style=overflow:hidden></textarea></td></tr>");
	sb.Append("<tr><td align=right><input type=text name=price class=f style='font-weight:bold;text-align:right'></td></tr>");
	sb.Append("<tr><td><textarea name=sspace rows=15 cols=10 class=f style=overflow:hidden></textarea></td></tr>");
//	sb.Append("<tr rowspan=30><td> &nbsp; <br><br><br> &nbsp; </td></tr>");
	sb.Append("<tr><td align=right><b>Total : </b><input type=text name=total size=5 value=0 class=f style='font-weight:bold;text-align:right'></td></tr>");
	sb.Append("</table>");

	sb.Append("</td><td width=100%>");

	sb.Append("<table width=100% border=1 cellspacing=0 cellpadding=0 bordercolor=#eeeeee bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
//	sb.Append("<table width=80% border=0 cellspacing=0 cellpadding=0>");
	sb.Append("<tr><td colspan=4>");
	sb.Append("<input type=text name=s>");
	sb.Append("<script");
	sb.Append(">document.f.s.focus();</script");
	sb.Append(">");
//	sb.Append("<input type=submit value=Enter class=b onclick=\"if(document.f.s.value == ''){return true;} onscan();return false;\">");
	sb.Append("<input type=submit value=GO class=b onclick=\"if(onscan()){return false;}\">");
//	sb.Append(" <input type=submit value='Remove Last One' class=b onclick='removelastone(); return false;'>");
	sb.Append("</td></tr>");

//	sb.Append("<tr><td colspan=4 align=right><b>Grand Total : </b><input type=text name=total size=10 value=0 class=f></td></tr>");
	for(int i=0; i<300; i++)
	{
		sb.Append("<tr><td><input type=text name=c" + i + " size=3 class=f></td>");
		sb.Append("<td><input type=text size=30 name=d" + i + " class=f></td>");
		sb.Append("<td><input type=text size=3 name=q" + i + " class=f onchange=\"CalcTotal();\"></td>");
		sb.Append("<td align=right><input type=text size=10 name=p" + i + " class=f onchange=\"CalcTotal();\"></td>");
//		sb.Append("<input type=hidden name=op" + i + " value=></td>");
		sb.Append("<input type=hidden name=o" + i + ">");
		sb.Append("</tr>");
	}

	sb.Append("</table>");

	sb.Append("</td></tr></table>");

	sb.Append(m_sProductCache);
	//jave memory
	sb.Append("<input type=hidden name=rows value=0>");
	sb.Append("<input type=hidden name=last_code>");

	sb.Append("</form>");

	Response.Write(sb.ToString());
	PrintMJava();
	return true;
}

bool BuildProductCache()
{
	if(Session["pos_product_cache"] != null)
	{
		m_sProductCache = Session["pos_product_cache"].ToString();
		return true;
	}

	int rows = 0;
	DataSet dspc = new DataSet();
	string sc = " SELECT top 3000 code, name, barcode ";
	if(m_bFixedPrices)
		sc += ", price2 AS price "; //GST exclusive price
	else
		sc += ", supplier_price * rate * level_rate1 AS price ";
	sc += " FROM code_relations ";
//	sc += " where code != 1461 ";
	sc += " ORDER BY code ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dspc);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	StringBuilder sb = new StringBuilder();

	for(int i=0; i<rows; i++)
	{
		DataRow dr = dspc.Tables[0].Rows[i];
		string code = dr["code"].ToString();
		string barcode = dr["barcode"].ToString();
		string name = dr["name"].ToString();
		string price = Math.Round(MyDoubleParse(dr["price"].ToString()), 2).ToString();

		if(name.Length > 24)
			name = name.Substring(0, 24);

//		if(barcode != "")
//		{
//			m_jdic += "	d.Add('" + barcode + "', ['" + code + "', '" + name + "', " + price + "]);\r\n";
//		}
//		else
		{
			sb.Append("\r\n<input type=hidden name=b" + barcode + " value=" + code + ">");
			sb.Append("\r\n<input type=hidden name=d" + code + " value='" + name + "'>");
			sb.Append("\r\n<input type=hidden name=p" + code + " value=" + price + ">");
		}
	}

	m_sProductCache = sb.ToString();
	Session["pos_product_cache"] = m_sProductCache;
	return true;
}

void PrintMJava()
{
	string s = "<script";
	s += ">\r\n";

//	s += " var d = new ActiveXObject(\"Scripting.Dictionary\"); \r\n";
//	s += m_jdic;
	s += @"

	self.moveTo(-4,-4);
	self.resizeTo((screen.availWidth+8),(screen.availHeight+8));

//	y.add ('a', ['code', 'name', 'price'] );
//	if (y.Exists('a'))
//		document.f.total.value=y.Item('a')[2];

	function onscan()
	{
		if(document.f.s.value == '')
		{
			if(document.f.confirm_checkout.value == '1')
				return true; //no double invoicing, already confirmed, checking out
			var bconfirm = window.confirm('Confirm to checkout?');
			document.f.s.focus();
			if(bconfirm)
				document.f.confirm_checkout.value = 1;
			return !bconfirm;
		}
		var i = Number(document.f.rows.value);
//		for(i=0; i<300; i++)
//		{
	";
	
//	s += "		var sexists = eval(\"document.f.c\" + i + \".value\"); ";
//	s += @"
//			if(sexists != '')
//				continue;
	s += @"
		var sin = document.f.s.value;
		var sinb = document.f.s.value;
		var nqty = 1;
		if(sin.substring(0, 1) == '*')
		{
			nqty = Number(sin.substring(1));
			if(i > 0)
				i -= 1;
		";
	s += "	eval(\"document.f.q\" + i + \".value = nqty\"); \r\n";
	s += @"
			CalcTotal();
			document.f.s.value='';
			document.f.s.focus();
			return true;
		}
		else if(sin.substring(0, 1) == '.' || sin.substring(0, 1) == '/')
		{
			removelastone();
			return true;
		}
		";

	s += "	var qty = eval(\"document.f.q\" + i + \".value\"); \r\n";
	s += "	if(qty == ''){qty = '1'}; \r\n";
/*
	s += " if(d.Exists(sin)){ \r\n ";
	s += "	var da = d.Item(sin); \r\n ";
	s += "	var code = d.Item(sin)[0]; \r\n ";
*/
//	s += "	if(i>0 && code == document.f.last_code.value) \r\n";
	s += "	if(i>0 && sin == document.f.last_code.value) \r\n";
	s += "	{		\r\n";
	s += "		i--; \r\n";
	s += "		qty = eval(\"Number(document.f.q\" + i + \".value) + 1\") \r\n";
	s += "		eval(\"document.f.q\" + i + \".value = qty\"); \r\n";
	s += "		CalcTotal(); \r\n";
	s += "		document.f.s.value=''; \r\n";
	s += "		document.f.s.focus(); \r\n";
	s += "		return true; \r\n";
	s += "	}		\r\n"; 
/*	
	s += "	var sdesc = d.Item(sin)[1]; \r\n ";
	s += "	var sprice = d.Item(sin)[2]; \r\n ";
	s += "	var sgprice = Math.round(sprice*1.125 * 100) / 100; \r\n";
	s += "	eval(\"document.f.c\" + i + \".value = da[0]\"); \r\n";
	s += "	eval(\"document.f.d\" + i + \".value = da[1]\"); \r\n";
	s += "	eval(\"document.f.o\" + i + \".value = sprice\"); \r\n";
	s += "	eval(\"document.f.p\" + i + \".value = sgprice\"); \r\n";
	s += "	eval(\"document.f.q\" + i + \".value = qty\"); \r\n";
	s += "	document.f.code.value = sin; \r\n";
	s += "	document.f.desc.value = sdesc; \r\n";
	s += "	document.f.price.value = sprice; \r\n";
	s += "	document.f.last_code.value = da[0]; \r\n";
	s += "	}else{ \r\n";
	s += "	eval(\"document.f.c\" + i + \".value = sin\"); \r\n";
	s += "	eval(\"document.f.d\" + i + \".value = 'NOT FOUND'\"); \r\n";
	s += "	eval(\"document.f.p\" + i + \".value = 0\"); \r\n";
	s += "	eval(\"document.f.o\" + i + \".value = 0\"); \r\n";
	s += "	eval(\"document.f.q\" + i + \".value = qty\"); \r\n";
	s += "	document.f.code.value = sin; \r\n";
	s += "	document.f.desc.value = 'NOT FOUND'; \r\n";
	s += "	document.f.price.value = 0; \r\n";
	s += "	document.f.last_code.value = ''; \r\n";
	s += " } \r\n";
*/
	

	s += "	if(eval(\"document.f.b\" + sin) != null){sin = eval(\"document.f.b\" + sin + \".value\");} ";

	s += "	if(eval(\"document.f.d\" + sin) == null){ \r\n";
	s += "	eval(\"document.f.c\" + i + \".value = sin\"); \r\n";
	s += "	eval(\"document.f.d\" + i + \".value = 'NOT FOUND'\"); \r\n";
	s += "	eval(\"document.f.p\" + i + \".value = 0\"); \r\n";
	s += "	eval(\"document.f.o\" + i + \".value = 0\"); \r\n";
	s += "	eval(\"document.f.q\" + i + \".value = qty\"); \r\n";
	s += "	document.f.code.value = sin; \r\n";
	s += "	document.f.desc.value = 'NOT FOUND'; \r\n";
	s += "	document.f.price.value = 0; \r\n";
	s += "	document.f.last_code.value = sinb; \r\n";
	s += "	} else { \r\n";
//	s += "  eval(if(\"document.f.d\" + sin + \".value == ''){return true;}\"); ";
	s += "	var sdesc = eval(\"document.f.d\" + sin + \".value\"); \r\n";
	s += "	var sprice = eval(\"document.f.p\" + sin + \".value\"); \r\n";
	s += "	var sgprice = eval(\"Math.round(Number(document.f.p\" + sin + \".value)*1.125 * 100) / 100\"); \r\n";
	s += "	eval(\"document.f.c\" + i + \".value = sin\"); \r\n";
	s += "	eval(\"document.f.d\" + i + \".value = sdesc\"); \r\n";
	s += "	eval(\"document.f.o\" + i + \".value = sprice\"); \r\n";  //GST exclusive price
	s += "	eval(\"document.f.p\" + i + \".value = sgprice\"); \r\n"; //GST Inclusive price
	s += "	eval(\"document.f.q\" + i + \".value = qty\"); \r\n";
	s += "	document.f.code.value = sin; \r\n";
	s += "	document.f.desc.value = sdesc; \r\n";
	s += "	document.f.price.value = sgprice; \r\n";
	s += "	document.f.last_code.value = sinb; \r\n";
	s += " } ";

//			document.f.c0.value=document.f.s.value;
//			document.f.d0.value=document.f.s.value + document.f.s.value + document.f.s.value;
	s += @"

		document.f.rows.value = i + 1;
//document.f.debug.value = i + 1;
		CalcTotal();
		document.f.s.value='';
		document.f.s.focus();
		return true;
	}
	";

	s += @"

	function removelastone()
	{
		document.f.code.value = '';
		document.f.desc.value = '';
		document.f.price.value = '';

		var i = Number(document.f.rows.value) - 1;
		if(i < 0)
		{
			document.f.s.value='';
			document.f.s.focus();
	//		document.f.rows.value = 0;
			return;
		}
	";
	s += "	eval(\"document.f.c\" + i + \".value = ''\"); ";
	s += "	eval(\"document.f.d\" + i + \".value = ''\"); ";
	s += "	eval(\"document.f.o\" + i + \".value = ''\"); ";
	s += "	eval(\"document.f.p\" + i + \".value = ''\"); ";
	s += "	eval(\"document.f.q\" + i + \".value = ''\"); ";
	s += @"
		document.f.rows.value = i;
//document.f.debug.value = document.f.rows.value;
		CalcTotal();
		document.f.s.value='';
		document.f.s.focus();

		";

	s += " if(i > 0)\r\n{document.f.last_code.value = eval(\"document.f.c\" + (i-1) + \".value\");} \r\n";

	s += @"
	}

	function CalcTotal()
	{
		var dtotal = 0;
		var rows = Number(document.f.rows.value);
		for(var j=0; j<rows; j++)
		{
	";
	s += " if(eval(\"document.f.c\" + j + \".value\") == ''){break;} \r\n";
	s += " dtotal += Number(eval(\"document.f.p\" + j + \".value\")) * Number(eval(\"document.f.q\" + j + \".value\")) / 1.125; \r\n";
	s += @"
		}
		dtotal *= 1.125;
		document.f.total.value = Math.round(dtotal * 100) / 100;

	}
	";

	s += "</script";
	s += ">";

	Response.Write(s);
}

bool BuildShoppingCart()
{
	if(Request.Form["rows"] == null)
		return false;

	int rows = MyIntParse(Request.Form["rows"]);
	for(int i=0; i<rows; i++)
	{
		string code = Request.Form["c" + i];
		string qty = Request.Form["q" + i];
//		string price = Request.Form["o" + i];
		string price = Request.Form["p" + i];
		double dPrice = MyMoneyParse(price);
		dPrice /= 1.125;
		dPrice = Math.Round(dPrice, 2);
		AddToCart(code, qty, dPrice.ToString());
	}
	return true;
}

bool PrintPaymentForm()
{
	m_invoiceNumber = Request.QueryString["i"];
	m_dInvoiceTotal = MyDoubleParse(Request.QueryString["total"].ToString());

	PrintAdminHeader();

	Response.Write("<br><br><br>");
	Response.Write("<form name=f action=qpos.aspx?t=end method=post>");
	Response.Write("<input type=hidden name=invoice_number value=" + m_invoiceNumber + ">");
	Response.Write("<input type=hidden name=pm value=cash>");

	Response.Write("<input type=hidden name=payment_total value=0>");
	Response.Write("<input type=hidden name=payment_cash value=>");
	Response.Write("<input type=hidden name=payment_eftpos value=>");
	Response.Write("<input type=hidden name=payment_cheque value=>");
	Response.Write("<input type=hidden name=payment_visa value=>");
	Response.Write("<input type=hidden name=payment_master value=>");
	Response.Write("<input type=hidden name=payment_dinners value=>");
	Response.Write("<input type=hidden name=payment_amex value=>");
	Response.Write("<input type=hidden name=payment_jcb value=>");
	Response.Write("<input type=hidden name=payment_bankcard value=>");

	Response.Write("<table width=50% height=50% align=center valign=center border=1 cellspacing=0 cellpadding=0 bordercolor=#eeeeee bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr><td colspan=2 align=center><h2>Payment</h3></td></tr>");

	Response.Write("<tr><td colspan=2>");
//	Response.Write("<input type=text name=tptype value='Type' class=f style='font-size:30'>");
	Response.Write("<input type=text name=pmt value=Cash class=f style='font-weight:bold;font-size:30;'>");
//	Response.Write("<i>(press ENTER for EFTPOS)</i>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td><input type=text name=ttotal value='Total' class=f style='font-size:30'></td>");
	Response.Write("<td align=right>");
	Response.Write("<input type=text name=total size=3 value=" + m_dInvoiceTotal + " class=f style='text-align:right;font-weight:bold;font-size:30;'>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td><input type=text name=tcashin value='Cash In' class=f style='font-size:30'></td>");
	Response.Write("<td align=right><input type=text name=cashin size=3 class=f style='text-align:right;font-weight:bold;font-size:30'>");
//	Response.Write("<input type=submit value=GO class=b onclick=\"oncashin();return false;\"></td></tr>");

	Response.Write("<tr><td><input type=text name=tcashchange value='Changes' class=f style='font-size:30'></td>");
	Response.Write("<td align=right><input type=text name=cashchange size=3 class=f style='text-align:right;font-weight:bold;font-size:30;'></td></tr>");
	Response.Write("<tr><td colspan=2 align=right><input type=submit name=cmd value=OK class=b onclick=\"if(!paymentok()){return false;}\">");
	Response.Write("</table>");
	Response.Write("</form>");

	PrintPaymentJava();

	return true;
}

void PrintPaymentJava()
{
	string s = "<script";
	s += ">\r\n";
	s += @"

	document.f.cashin.focus();

	function CalcPaymentTotal()
	{
		var total = 0;
		total += Number(document.f.payment_cash.value);
		total += Number(document.f.payment_eftpos.value);
		total += Number(document.f.payment_cheque.value);
		total += Number(document.f.payment_visa.value);
		total += Number(document.f.payment_master.value);
		total += Number(document.f.payment_dinners.value);
		total += Number(document.f.payment_amex.value);
		total += Number(document.f.payment_bankcard.value);
		total += Number(document.f.payment_jcb.value);
		document.f.payment_total.value = Math.round(total * 100) / 100;
		var invoice_total = Number(document.f.total.value);
		var res = invoice_total - total;
		return res;
	}

	function MsgNotEnough(cashin)
	{
		var payment_total = Number(document.f.payment_total.value);
		var invoice_total = Number(document.f.total.value);
		var res = Math.round( (invoice_total - payment_total) * 100) / 100;
		var p_cash = Number(document.f.payment_cash.value);
		var p_eftpos = Number(document.f.payment_eftpos.value);
		var p_cheque = Number(document.f.payment_cheque.value);
		var p_visa = Number(document.f.payment_visa.value);
		var p_master = Number(document.f.payment_master.value);
		var p_dinners = Number(document.f.payment_dinners.value);
		var p_amex = Number(document.f.payment_amex.value);
		var p_bankcard = Number(document.f.payment_bankcard.value);
		var p_jcb = Number(document.f.payment_jcb.value);
		
		var msg = 'Payment Shortage.\r\n\r\n';
		msg += 'Invoice Total : $' + invoice_total + '\r\n';
		msg += 'Paid Total : $' + payment_total + '\r\n';
		msg += '------------------------------------\r\n';
		if(p_cash != 0)
			msg += 'Cash : $' + p_cash + '\r\n';
		if(p_eftpos != 0)
			msg += 'EFTPOS : $' + p_eftpos + '\r\n';
		if(p_cheque != 0)
			msg += 'Cheque : $' + p_cheque + '\r\n';
		if(p_visa != 0)
			msg += 'VISA Card : $' + p_visa + '\r\n';
		if(p_master != 0)
			msg += 'MASTER Card : $' + p_master + '\r\n';
		if(p_dinners != 0)
			msg += 'Dinners Card : $' + p_dinners + '\r\n';
		if(p_amex != 0)
			msg += 'AMEX Card : $' + p_amex + '\r\n';
		if(p_jcb != 0)
			msg += 'CJB Card : $' + p_jcb + '\r\n';
		msg += '------------------------------------\r\n';
		msg += 'Shortage : $' + res + '\r\n';
		window.alert(msg);
		shownextform();
	}

	function MsgConfirmCheckout()
	{
		var bconfirm = window.confirm('Confirm Payment OK?');
		if(!bconfirm)
		{
			document.f.cashin.value = '';
			document.f.cashchange.value = '';
			document.f.cashin.focus();
		}
		return bconfirm;
	}

	function shownextform()
	{
		if(document.f.pm.value == 'cash')
			showeftposform();
		else if(document.f.pm.value == 'eftpos')
			showvisaform();
		else if(document.f.pm.value == 'visa')
			showmasterform();
		else if(document.f.pm.value == 'master')
			showamexform();
		else if(document.f.pm.value == 'amex')
			showdinnersform();
		else if(document.f.pm.value == 'dinners')
			showbankcardform();
		else if(document.f.pm.value == 'bank card')
			showjcbform();
		else if(document.f.pm.value == 'jcb')
			showchequeform();
		else
			showcashform();
	}

	function FullyPaid()
	{
		if(CalcPaymentTotal() > 0)
			MsgNotEnough();
		else
			return MsgConfirmCheckout();
		return false;
	}

	function paymentok()
	{
		if(document.f.cashin.value == '.')// && document.f.pm.value != 'cash')
		{
			if(document.f.pm.value == 'cash')
				showchequeform();
			else if(document.f.pm.value == 'cheque')
				showjcbform();
			else if(document.f.pm.value == 'master')
				showvisaform();
			else if(document.f.pm.value == 'visa')
				showeftposform();
			else if(document.f.pm.value == 'amex')
				showmasterform();
			else if(document.f.pm.value == 'dinners')
				showamexform();
			else if(document.f.pm.value == 'bank card')
				showdinnersform();
			else if(document.f.pm.value == 'jcb')
				showbankcardform();
			else
				showcashform();
			return false;
		}
		else if(document.f.cashin.value == '')
		{
			shownextform();
			return false;
		}

		if(document.f.pm.value == 'cash')
		{
			document.f.payment_cash.value = document.f.cashin.value;
			CalcPaymentTotal();
			if(document.f.cashchange.value != '') //ENTER after cashed in
			{
				if(Number(document.f.cashchange.value) >= 0) //ok, we got enough money
					return MsgConfirmCheckout();
				else
				{
					document.f.cashchange.value = '';
					MsgNotEnough();
				}
				return false;
			}
			var cg = Number(document.f.payment_total.value) - Number(document.f.total.value);
			document.f.cashchange.value = Math.round(cg * 100) / 100;
			return false;
		}
		else if(document.f.pm.value == 'eftpos')
		{
			document.f.payment_eftpos.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'visa')
		{
			document.f.payment_visa.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'master')
		{
			document.f.payment_master.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'amex')
		{
			document.f.payment_amex.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'dinners')
		{
			document.f.payment_dinners.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'bank card')
		{
			document.f.payment_bankcard.value = document.f.cashin.value;
			return FullyPaid();
		}

		if(document.f.pm.value == 'jcb')
		{
			document.f.payment_jcb.value = document.f.cashin.value;
			return FullyPaid();
		}
		else if(document.f.pm.value == 'cheque')
		{
			document.f.payment_cheque.value = document.f.cashin.value;
			return FullyPaid();
		}
		return false;
	}
//***** added new 4 forms ********
	function showamexform()
	{
		document.f.pm.value = 'amex';
		document.f.pmt.value='AMERICAN EXPRESS';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_amex.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showdinnersform()
	{
		document.f.pm.value = 'dinners';
		document.f.pmt.value='DINNERS CLUB';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_dinners.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showbankcardform()
	{
		document.f.pm.value = 'bank card';
		document.f.pmt.value='BANK CARD';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_bankcard.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showjcbform()
	{
		document.f.pm.value = 'jcb';
		document.f.pmt.value='JCB';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_jcb.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
//******** end new 4 forms *******************
	function showeftposform()
	{
		document.f.pm.value = 'eftpos';
		document.f.pmt.value='EFTPOS';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_eftpos.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showvisaform()
	{
		document.f.pm.value = 'visa';
		document.f.pmt.value='VISA CARD';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_visa.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showmasterform()
	{
		document.f.pm.value = 'master';
		document.f.pmt.value='MASTER CARD';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_master.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	function showchequeform()
	{
		document.f.pm.value = 'cheque';
		document.f.pmt.value='CHEQUE';
		document.f.tcashin.value = '';
		document.f.tcashchange.value = '';
		document.f.cashin.value = document.f.payment_cheque.value;
		document.f.cashin.focus();
		document.f.cashin.select();
	}

	function showcashform()
	{
		document.f.pm.value = 'cash';
		document.f.pmt.value='CASH';
		document.f.tcashin.value = 'Cash In';
		document.f.tcashchange.value = 'Changes';
		document.f.cashin.value = document.f.payment_cash.value;
		document.f.cashchange.value = '';
		document.f.cashin.focus();
		document.f.cashin.select();
	}
	";

	s += "</script";
	s += ">";

	Response.Write(s);
}

string BuildReceiptBody()
{
	int rows = 0;
	string sc = " SELECT i.total, s.code, s.name, s.quantity, s.commit_price * 1.125 AS price ";
	sc += " FROM invoice i JOIN sales s ON s.invoice_number=i.invoice_number ";
	sc += " WHERE i.invoice_number = " + m_invoiceNumber;
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "receipt");
		if(rows <= 0)
		{
//			Response.Write("<br><br><center><h3>ERROR, Order Not Found</h3>");
			return "Error, Invoice #" + m_invoiceNumber + " Not Found or no item found.";
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "SQL Error";
	}

	int n = 0;
	int len = 0;
	m_dInvoiceTotal = Math.Round(MyDoubleParse(dst.Tables["receipt"].Rows[0]["total"].ToString()), 2);
	string stotal = m_dInvoiceTotal.ToString("c");
	string s = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["receipt"].Rows[i];
		string code = dr["code"].ToString();
		string name = dr["name"].ToString();
		string qty = dr["quantity"].ToString();
		string price = Math.Round(MyDoubleParse(dr["price"].ToString()), 2).ToString("c");

		s += name + "\r\n";

		string slcode = "       " + code;
		s += slcode;
		len = 20 - slcode.Length;
		for(n=0; n<len; n++)
			s += ' ';
		len = qty.Length + 1 + price.Length;
		len = 22 - len;
		s += "x" + qty;
		for(n=0; n<len; n++)
			s += ' ';
		s += price + "\r\n";

//		s += "      " + code + "          x" + qty + "      " + price + "\r\n";
	}

	string pm = Request.Form["pm"].ToString().ToUpper(); //payment method
//DEBUG("pm = ", pm);	
	string si = rows + " Items        TOTAL";
	s += si;
	si += stotal;
	len = 42 - si.Length;
	for(n=0; n<len; n++)
		s += ' ';
	s += stotal + "\r\n";

//	s += rows + " Items       Total " + "           " + stotal + "\r\n";
	len = 20 - pm.Length;
	for(n=0; n<len; n++)
		s += ' ';
	s += pm;
	if(pm == "CASH")
	{
		string cashin = MyDoubleParse(Request.Form["cashin"].ToString()).ToString("c"); 
		string cashchange = MyDoubleParse(Request.Form["cashchange"].ToString()).ToString("c");
		len = 22 - cashin.Length;
		for(n=0; n<len; n++)
			s += ' ';
		s += cashin + "\r\n";
		for(n=0; n<14; n++)
			s += ' ';
		s += "CHANGE";
		len = 22 - cashchange.Length;
		for(n=0; n<len; n++)
			s += ' ';
		s += cashchange + "\r\n";
	}
	else
	{
		len = 22 - stotal.Length;
		for(n=0; n<len; n++)
			s += ' ';
		s += stotal + "\r\n";
	}

	s += "\r\n";
	return s;
}

bool DoReceiveOnePayment(string pm, double dAmount)
{
	if(dAmount <= 0)
		return true;

	string payment_method = GetEnumID("payment_method", pm);
	string sAmount = dAmount.ToString();

	//do transaction
	SqlCommand myCommand = new SqlCommand("ezsoft_payment", myConnection);
	myCommand.CommandType = CommandType.StoredProcedure;

	myCommand.Parameters.Add("@Amount", SqlDbType.Money).Value = sAmount;
	myCommand.Parameters.Add("@paid_by", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@bank", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@branch", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@nDest", SqlDbType.Int).Value = "1116";
	myCommand.Parameters.Add("@amount_for_card_balance", SqlDbType.Money).Value = 0;
	myCommand.Parameters.Add("@staff_id", SqlDbType.Int).Value = Session["card_id"].ToString();
	myCommand.Parameters.Add("@card_id", SqlDbType.Int).Value = "0"; //cash sales
	myCommand.Parameters.Add("@payment_method", SqlDbType.Int).Value = payment_method;
	myCommand.Parameters.Add("@invoice_number", SqlDbType.VarChar).Value = m_invoiceNumber;
	myCommand.Parameters.Add("@payment_ref", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@note", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@finance", SqlDbType.Money).Value = "0";
	myCommand.Parameters.Add("@credit", SqlDbType.Money).Value = "0";
	myCommand.Parameters.Add("@bRefund", SqlDbType.Bit).Value = 0;
	myCommand.Parameters.Add("@amountList", SqlDbType.VarChar).Value = sAmount;
	myCommand.Parameters.Add("@return_tran_id", SqlDbType.Int).Direction = ParameterDirection.Output;

	try
	{
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp("DoCustomerPayment", e);
		return false;
	}
//	string m_tranid = myCommand.Parameters["@return_tran_id"].Value.ToString();
	return true;
}

bool DoReceivePayment()
{
	m_invoiceNumber = Request.Form["invoice_number"];
	string sReceiptBody = BuildReceiptBody(); //get m_dInvoiceTotal first before record payment

	bool bMultiPayments = false;
	double dCash = MyMoneyParse(Request.Form["payment_cash"]);
	double dEftpos = MyMoneyParse(Request.Form["payment_eftpos"]);
	double dVisa = MyMoneyParse(Request.Form["payment_visa"]);
	double dMaster = MyMoneyParse(Request.Form["payment_master"]);
	double dAmex = MyMoneyParse(Request.Form["payment_amex"]);
	double dDinners = MyMoneyParse(Request.Form["payment_dinners"]);
	double dBankcard = MyMoneyParse(Request.Form["payment_bankcard"]);
	double dJcb = MyMoneyParse(Request.Form["payment_jcb"]);
	double dCheque = MyMoneyParse(Request.Form["payment_cheque"]);

	double dCreditCard = dVisa + dMaster + dAmex + dDinners + dJcb;

	if(!DoReceiveOnePayment("cash", dCash))
		return false;
	if(!DoReceiveOnePayment("eftpos", dEftpos))
		return false;
	if(!DoReceiveOnePayment("bank card", dBankcard))
		return false;
	if(!DoReceiveOnePayment("cheque", dCheque))
		return false;
	if(!DoReceiveOnePayment("credit card", dCreditCard))
		return false;

	//print receipt
	byte[] bf = {0x1b, 0x21, 0x20, 0x0};//new char[4];
	byte[] sf = {0x1b, 0x21, 0x02, 0x0};//new char[4];
	byte[] cut = {0x1d, 0x56, 0x01, 0x00};//new char[4];
	byte[] kick = {0x1b, 0x70, 0x30, 0x7f};//, 0x0a, 0x0};//new char[6];

	ASCIIEncoding encoding = new ASCIIEncoding( );
    string bigfont = encoding.GetString(bf);	
    string smallfont = encoding.GetString(sf);
    string scut = encoding.GetString(cut);
    string kickout = encoding.GetString(kick);
	
	string header = ReadSitePage("pos_receipt_header");
	string footer = ReadSitePage("pos_receipt_footer");
	string sbody = sReceiptBody;
	string sdate = DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy");
	string stime = DateTime.UtcNow.AddHours(12).ToString("HH:mm");

	string sprint = header + sbody + footer + scut;
	if(dCash > 0)
		sprint += "\\r\\n" + kickout;
	sprint = sprint.Replace("\r\n", "\\r\\n");
	sprint = sprint.Replace("[/b]", smallfont);
	sprint = sprint.Replace("[b]", bigfont);
	sprint = sprint.Replace("[cut]", scut.ToString());
	sprint = sprint.Replace("[date]", sdate);
	sprint = sprint.Replace("[time]", stime);
	sprint = sprint.Replace("[inv_num]", m_invoiceNumber);

	PrintAdminHeader();

	//AsPrint ActiveX Control
	Response.Write("\r\n<object classid=\"clsid:B816E029-CCCB-11D2-B6ED-444553540000\" ");
	Response.Write(" CODEBASE=\"..\\cs\\asprint.ocx\" ");
	Response.Write(" id=\"AsPrint1\">\r\n");
	Response.Write("<param name=\"_Version\" value=\"65536\">\r\n");
	Response.Write("<param name=\"_ExtentX\" value=\"2646\">\r\n");
	Response.Write("<param name=\"_ExtentY\" value=\"1323\">\r\n");
	Response.Write("<param name=\"_StockProps\" value=\"0\">\r\n");
	Response.Write("<param name=\"HideWinErrorMsg\" value=\"1\">\r\n");
	Response.Write("</object>\r\n");

	string s = "<script";
	s += ">\r\n";

	s += "	document.AsPrint1.Open('LPT1')\r\n";
	s += "	document.AsPrint1.PrintString('" + sprint + "');\r\n";
	s += "	document.AsPrint1.Close();\r\n";

	s += "</script";
	s += ">";

	Response.Write(s);

	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=qpos.aspx?t=new\">");
	return true;
}

string GetBranchName(string id)
{
	if(dst.Tables["branch_name"] != null)
		dst.Tables["branch_name"].Clear();

	string sc = " SELECT name FROM branch WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "branch_name") == 1)
			return dst.Tables["branch_name"].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	return "";
}

/*
		var bigfont = '';
		bigfont += '\x1b';
		bigfont += '\x21';
		bigfont += '\x20';
		bigfont += '\0x00';

		var smallfont = '';
		bigfont += '\x1b';
		bigfont += '\x21';
		bigfont += '\x02';
		bigfont += '\0x00';

		var scut = '\x1d';
		scut += '\x56';
		scut += '\x01';
		scut += '\x00';

		var kickout = '';
		kickout += '\x1b';
		kickout += '\x70';
		kickout += '\x30';
		kickout += '\x7f';
		kickout += '\x0a';
*/

</script>

<asp:Label id=LFooter runat=server/>

