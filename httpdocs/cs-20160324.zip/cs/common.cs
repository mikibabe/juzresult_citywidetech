<!-- #include file="sqlstring.cs" -->

<%@Language=C# Debug="true" %>
<%@Import Namespace="System" %>
<%@Import Namespace="System.Web.Caching" %>
<%@Import Namespace="System.Web" %>
<%@Import Namespace="System.Web.Configuration" %>
<%@Import Namespace="System.Data" %>
<%@Import Namespace="System.Data.SqlClient" %>
<%@Import Namespace="System.IO" %>
<%@Import Namespace="System.Globalization" %>
<%@Import Namespace="System.Web.Mail" %>
<%@Import Namespace="System.Threading" %>
<%@Import Namespace="System.Security.Cryptography" %>
<%@Import Namespace="System.Xml" %>
<%@Import Namespace="System.IO" %>


<%@ Import Namespace="System.Drawing" %>
<%@ Import Namespace="System.Drawing.Imaging" %>
<%@ Import Namespace="System.Drawing.Text" %>



<script runat=server>
//////////////////////////////////////////////////////////////////////////////////////
//common functions for all sites

string m_sHeaderCacheName = "header"; //will append current virtual path later
string m_sSalesEmail = "";
string m_sAdminEmail = "sales@ezsoft.com";
string m_supplierString = "";
string m_catTableString = "";

const int const_sleeps = 1;					//for throat CPU usage
int	monitorCount = 0;						//for remote process monitoring

SqlConnection myConnection;// = new SqlConnection("Initial Catalog=" + m_sCompanyName + m_sDataSource + m_sSecurityString);
SqlDataAdapter myAdapter;
SqlCommand myCommand;

DataTable dtUser = new DataTable();
DataSet dstcom = new DataSet();

int	m_pMonitor = 0;
string m_sMonitor = @".......";

string GetMd5Hash(string input)
        {
using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes 
            // and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data  
            // and format each one as a hexadecimal string. 
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string. 
            return sBuilder.ToString();

            }
            
        }

void Trim(ref string s)
{
	if(s == null)
		return;
	s = s.TrimStart(null);
	s = s.TrimEnd(null);
}

void DEBUG(string msg, string value)
{
	string sd = "";
	sd += "<font color=red>";
	sd += msg;
	sd += "</font>";
	sd += value;
	sd += "<br>\r\n";
	Response.Write(sd);
	Response.Flush();
}

void DEBUG(string msg, int value)
{
	string sd = "";
	sd += "<font color=red>";
	sd += msg;
	sd += "</font>";
	sd += value.ToString();
	sd += "<br>\r\n";
	Response.Write(sd);
	Response.Flush();
}

void DEBUG(string msg, double value)
{
	string sd = "";
	sd += "<font color=red>";
	sd += msg;
	sd += "</font>";
	sd += value.ToString();
	sd += "<br>\r\n";
	Response.Write(sd);
	Response.Flush();
}
void DEBUG(string msg, float value)
{
	string sd = "";
	sd += "<font color=red>";
	sd += msg;
	sd += "</font>";
	sd += value.ToString();
	sd += "<br>\r\n";
	Response.Write(sd);
	Response.Flush();
}
void DEBUG(string msg, bool value)
{
	string sd = "";
	sd += "<font color=red>";
	sd += msg;
	sd += "</font>";
	sd += value.ToString();
	sd += "<br>\r\n";
	Response.Write(sd);
	Response.Flush();
}

void ShowExp(string query, Exception e)
{
	Response.Write("Execute SQL Query Error.<br>\r\nQuery = ");
	Response.Write(query);
	Response.Write("<br>\r\n Error: ");
	Response.Write(e);
	Response.Write("<br>\r\n");
	string msg = "\r\n<font color=red><b>EXP</b></font><br>\r\n";
	msg += e.ToString();
	msg += "<br><br><font color=red><b>QUERY</b></font><br>\r\n";
	msg += query;
	msg += "<br><br>\r\n\r\n";
	msg += "ip : " + Session["ip"] + "<br>\r\n";
	msg += "login : " + Session["name"] + "<br>\r\n";
	msg += "email : " + Session["email"] + "<br>\r\n";
	msg += "url : " + Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"] + "<br>\r\n";
	AlertAdmin(msg);
}

void MonitorProcess(int step)
{
	monitorCount++;
	if(monitorCount > step)
	{
		monitorCount = 0;
//		Response.Write(".");
		Response.Write(m_sMonitor[m_pMonitor++]);
		if(m_pMonitor >= m_sMonitor.Length)
			m_pMonitor = 0;
		Response.Flush();
	}
//	Thread.Sleep(const_sleeps);
}

void AlertAdmin(string msg)
{
	
	
	string mTo = m_emailAlertTo;
	string mFrom = GetSiteSettings("postmaster_email", "postmaster@ezsoft.com");
	string mSubject = m_sCompanyName + " site " + Request.ServerVariables["SERVER_NAME"] + " err: " + Request.ServerVariables["LOCAL_ADDR"].ToString();
	

	
    SendEmail(mFrom, mFrom, mTo, mSubject,msg);
    Response.Write(mSubject);
}

void AlertAdmin(string subject, string msg)
{
	
	
	string mTo = m_emailAlertTo;
	string mFrom = GetSiteSettings("postmaster_email", "postmaster@ezsoft.com");
	string mSubject= Request.ServerVariables["SERVER_NAME"] + " @ " + Request.ServerVariables["LOCAL_ADDR"].ToString();
	mSubject += subject;

	
    SendEmail(mFrom, mFrom, mTo, mSubject,msg);
}

string GetSiteSettings(string name)
{
	return GetSiteSettings(name, "");
}

string GetSiteSettings(string name, string sDefault)
{
	return GetSiteSettings(name, sDefault, false);
}
	
string GetSiteSettings(string name, string sDefault, bool bHide)
{
	string s = "";
	string sc = "SELECT value FROM settings WHERE name='";
	sc += name;
	sc += "'"; 
	int rows = 0;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		DataSet ds = new DataSet();
		rows = myCommand.Fill(ds);
		if(rows > 0)
			s = ds.Tables[0].Rows[0].ItemArray[0].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return sDefault;
	}
	if(rows == 0)
	{
		string sHide = "0";
		if(bHide)
			sHide = "1";
		if(name == "next_cheque_number")
			s = "100000";
		else
			s = sDefault;
		s = EncodeQuote(s);
		sc = " INSERT INTO settings (name, value, hidden) VALUES('" + name + "', '" + s + "', " + sHide + ") ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
		}
	}
	return s;
}

bool SetSiteSettings(string name, string value)
{
	string sc = "UPDATE settings SET value='";
	sc += EncodeQuote(value);
	sc += "' WHERE name='"; 
	sc += name;
	sc += "'";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string ReadSitePage(string name)
{
	string id = "";
	return ReadSitePage(name, ref id);
}

string GetSitePageText(string name, ref string id)
{
	string cat = "";
	return GetSitePageText(name, ref id, ref cat);
}

string GetSitePageText(string name, ref string id, ref string cat)
{
    //string s = "";
    //string sc = "SELECT id, text, cat FROM site_pages WHERE name='";
    //sc += name;
    //sc += "'"; 
    //int rows = 0;
    //try
    //{
    //    SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
    //    DataSet ds = new DataSet();
    //    rows = myCommand.Fill(ds);
    //    if(rows > 0)
    //    {
    //        s = ds.Tables[0].Rows[0]["text"].ToString();
    //        id = ds.Tables[0].Rows[0]["id"].ToString();
    //        cat = ds.Tables[0].Rows[0]["cat"].ToString();
    //    }
    //}
    //catch(Exception e) 
    //{
    //    ShowExp(sc, e);
    //}
    //if(rows == 0 && name != "new_page")
    //{
    //    sc = "BEGIN TRANSACTION ";
    //    sc += " INSERT INTO site_pages (name, text) VALUES('" + name + "', '') ";
    //    sc += " SELECT IDENT_CURRENT('site_pages') AS id";
    //    sc += " COMMIT ";
    //    try
    //    {
    //        SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
    //        DataSet ds = new DataSet();
    //        rows = myCommand.Fill(ds);
    //        if(rows > 0)
    //            id = ds.Tables[0].Rows[0]["id"].ToString();
    //    }
    //    catch(Exception e) 
    //    {
    //        ShowExp(sc, e);
    //    }
    //}
	return getThemes(name);
}
int GetNextRepairID()
{
	int rNumber = int.Parse(GetSiteSettings("repair_id").ToString());
	
	if(dstcom.Tables["insertrma"] != null)
		dstcom.Tables["insertrma"].Clear();

	//DEBUG("rnumber = ", rNumber);
	string sc = "SELECT TOP 1 ra_number FROM repair ORDER BY id DESC";
//DEBUG("sc ++", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "insertrma") == 1)
		{
			if(dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString() != null && dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString() != "")
				rNumber = int.Parse(dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString()) + 1;
			else
				rNumber = rNumber + 1;
		}
		
		return rNumber;
		//Session["ra_id"] = rNumber;
		//DEBUG("raid =", Session["ra_id"].ToString());

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		//return false;
		return 0;
	}

	return rNumber;
}


string ExtractRA(string ra_number)
{
	string sDigitRA = "";
	string sStartValue = "";
	for(int i=0; i<ra_number.Length; i++)
	{
		if(TSIsDigit(ra_number[i].ToString()))
			sDigitRA += ra_number[i].ToString();
		else
			sStartValue += ra_number[i].ToString();
	}
	if(Session["start_value"] != null && Session["start_value"] != "")
	{
		if(Session["start_value"].ToString() != sStartValue)
			Session["start_value"] = Session["start_value"].ToString();//sStartValue;
	}
	else
		Session["start_value"] = sStartValue;	

	return sDigitRA;
}

string GetNextRA_ID()
{
	string sNumber_End = "";
	string sNumber = "";  
	sNumber = GetSiteSettings("repair_id").ToString();

	sNumber_End = ExtractRA(sNumber);
	if(dstcom.Tables["insertrma"] != null)
		dstcom.Tables["insertrma"].Clear();
//DEBUG("fistr start =", Session["start_value"].ToString());	
//	string sc = "SELECT TOP 1 ra_number FROM repair WHERE ra_number <> null AND ra_number <> '' ORDER BY id DESC";
	string sc = "SELECT TOP 1 ra_number FROM repair WHERE ra_number IS NOT null ORDER BY ra_number DESC";
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "insertrma") == 1)
		{
			
			if(dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString() != null && dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString() != "")
			{
				sNumber = dstcom.Tables["insertrma"].Rows[0]["ra_number"].ToString();
				if(!TSIsDigit(sNumber))
					sNumber = ExtractRA(sNumber);
//			DEBUG("secnod start =", Session["start_value"].ToString());		
				if(int.Parse(sNumber_End) > int.Parse(sNumber))
					sNumber = (int.Parse(sNumber_End) + 1).ToString();
				else
					sNumber = (int.Parse(sNumber) + 1).ToString();
								
			}
			else
			{
				sNumber = ExtractRA(sNumber);
				sNumber = (int.Parse(sNumber) + 1).ToString();
			}
		
		}
		else
			sNumber = (int.Parse(sNumber_End) + 1).ToString();
		
		
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	return Session["start_value"].ToString() + sNumber;
}

int GetNextSupplierRA_ID()
{
	int rNumber = 1000;
	
	if(dstcom.Tables["insertrma"] != null)
		dstcom.Tables["insertrma"].Clear();

//DEBUG("rnumber = ", rNumber);
	string sc = "SELECT TOP 1 ra_id FROM rma ORDER BY ra_id DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "insertrma") == 1)
		{
			if(dstcom.Tables["insertrma"].Rows[0]["ra_id"].ToString() != null && dstcom.Tables["insertrma"].Rows[0]["ra_id"].ToString() != "")
				rNumber = int.Parse(dstcom.Tables["insertrma"].Rows[0]["ra_id"].ToString()) + 1;
			else
				rNumber = rNumber + 1;
		}
		return rNumber;
		//Session["rma_id"] = rNumber;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
//		return false;
	}

	return rNumber;
	//return true;
}


string ReadRATemplate(string supplier_id)
{
	string s = "";
	string sc = "SELECT id, text_template FROM template_ra_form WHERE supplier_id='";
	sc += supplier_id;
	sc += "'"; 
	int rows = 0;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		DataSet ds = new DataSet();
		rows = myCommand.Fill(ds);
		if(rows > 0)
		{
			s = ds.Tables[0].Rows[0]["text_template"].ToString();
			//id = ds.Tables[0].Rows[0]["id"].ToString();
			s = s.Replace("&&", "&");
			return s;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return s;
}

string ReadSitePage(string name, ref string id)
{
	string s = GetSitePageText(name, ref id);
	int p = s.IndexOf("[[");
	int protect = 99;
	while(p >=0 && protect-->0)
	{
		string tag = "";
		for(int i=p+2; i<s.Length-1; i++)
		{
			if(s[i] == ']' && s[i+1] == ']')
				break;
			tag += s[i];
		}
		string sid = ""; //dummy
//DEBUG("tag=", tag);
		s = s.Replace("[[" + tag + "]]", GetSitePageText(tag, ref sid));
		p = s.IndexOf("[[");
	}
	return s;
}

Boolean CheckUserTable()
{
	if(Session["RebuildUserTable"] == "true") 
	{
		Session["RebuildUserTable"] = null;
		if(Session["dtUser"] != null)
		{
			dtUser.Dispose();
			dtUser = new DataTable();
			Session["dtUser"] = null;
		}
	}

	if(Session["dtUser"] == null)
	{
		//compatible with retail version
		dtUser.Columns.Add(new DataColumn("City", typeof(String)));
		dtUser.Columns.Add(new DataColumn("Country", typeof(String)));
		dtUser.Columns.Add(new DataColumn("NameB", typeof(String)));
		dtUser.Columns.Add(new DataColumn("CompanyB", typeof(String)));
		dtUser.Columns.Add(new DataColumn("Address1B", typeof(String)));
		dtUser.Columns.Add(new DataColumn("Address2B", typeof(String)));
		dtUser.Columns.Add(new DataColumn("CityB", typeof(String)));
		dtUser.Columns.Add(new DataColumn("CountryB", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ads", typeof(Boolean)));
		dtUser.Columns.Add(new DataColumn("shipping_fee", typeof(String)));
		//compatible with retail version

		dtUser.Columns.Add(new DataColumn("our_branch", typeof(String)));
		dtUser.Columns.Add(new DataColumn("id", typeof(String)));
		dtUser.Columns.Add(new DataColumn("type", typeof(String)));
		dtUser.Columns.Add(new DataColumn("name", typeof(String)));
		dtUser.Columns.Add(new DataColumn("short_name", typeof(String)));
		dtUser.Columns.Add(new DataColumn("company", typeof(String)));
		dtUser.Columns.Add(new DataColumn("branch", typeof(String)));
		dtUser.Columns.Add(new DataColumn("trading_name", typeof(String)));
		dtUser.Columns.Add(new DataColumn("corp_number", typeof(String)));
		dtUser.Columns.Add(new DataColumn("directory", typeof(String)));
		dtUser.Columns.Add(new DataColumn("gst_rate", typeof(String)));
		dtUser.Columns.Add(new DataColumn("currency_for_purchase", typeof(String)));
		dtUser.Columns.Add(new DataColumn("address1", typeof(String)));
		dtUser.Columns.Add(new DataColumn("address2", typeof(String)));
		dtUser.Columns.Add(new DataColumn("address3", typeof(String)));
		dtUser.Columns.Add(new DataColumn("postal1", typeof(String)));
		dtUser.Columns.Add(new DataColumn("postal2", typeof(String)));
		dtUser.Columns.Add(new DataColumn("postal3", typeof(String)));
		dtUser.Columns.Add(new DataColumn("phone", typeof(String)));
		dtUser.Columns.Add(new DataColumn("fax", typeof(String)));
		dtUser.Columns.Add(new DataColumn("email", typeof(String)));
		dtUser.Columns.Add(new DataColumn("note", typeof(String)));

		dtUser.Columns.Add(new DataColumn("CardType", typeof(String)));
		dtUser.Columns.Add(new DataColumn("NameOnCard", typeof(String)));
		dtUser.Columns.Add(new DataColumn("CardNumber", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ExpireMonth", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ExpireYear", typeof(String)));
		
		dtUser.Columns.Add(new DataColumn("pm_email", typeof(String)));
		dtUser.Columns.Add(new DataColumn("pm_ddi", typeof(String)));
		dtUser.Columns.Add(new DataColumn("pm_mobile", typeof(String)));
		dtUser.Columns.Add(new DataColumn("sm_name", typeof(String)));
		dtUser.Columns.Add(new DataColumn("sm_email", typeof(String)));
		dtUser.Columns.Add(new DataColumn("sm_ddi", typeof(String)));
		dtUser.Columns.Add(new DataColumn("sm_mobile", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ap_name", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ap_email", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ap_ddi", typeof(String)));
		dtUser.Columns.Add(new DataColumn("ap_mobile", typeof(String)));

		dtUser.Columns.Add(new DataColumn("access_level", typeof(String)));
		dtUser.Columns.Add(new DataColumn("dealer_level", typeof(String)));
		dtUser.Columns.Add(new DataColumn("credit_limit", typeof(String)));
		dtUser.Columns.Add(new DataColumn("credit_term", typeof(String)));
		dtUser.Columns.Add(new DataColumn("approved", typeof(Boolean)));
		dtUser.Columns.Add(new DataColumn("purchase_average", typeof(String)));
		dtUser.Columns.Add(new DataColumn("purchase_nza", typeof(String)));
		dtUser.Columns.Add(new DataColumn("cat_access", typeof(String)));
		dtUser.Columns.Add(new DataColumn("cat_access_group", typeof(String)));
		dtUser.Columns.Add(new DataColumn("stop_order", typeof(String)));
		dtUser.Columns.Add(new DataColumn("stop_order_reason", typeof(String)));
		dtUser.Columns.Add(new DataColumn("sales", typeof(String)));
		dtUser.Columns.Add(new DataColumn("no_sys_quote", typeof(String)));
		
		DataRow dr = dtUser.NewRow();
		dr["Name"] = "";
		dr["Company"] = "";
		dr["Address1"] = "";
		dr["Address2"] = "";
		dr["Address3"] = "";
		dr["Email"] = "";
		dr["CardType"] = GetEnumID("card_type", "dealer");
		dr["NameOnCard"] = "";
		dr["CardNumber"] = "";
		dr["ExpireMonth"] = "";
		dr["ExpireYear"] = "";
		dr["stop_order"] = "false";
//		dr["shipping_fee"] = "0";

		dr["approved"] = false;
		//dr["gst_rate"] = "0.15";
        dr["gst_rate"] = (MyDoubleParse(GetSiteSettings("gst_rate_percent", "10.0")) / 100).ToString();
		dr["directory"] = "1";
		dr["sales"] = "";
		dr["no_sys_quote"] = "false";
		dtUser.Rows.Add(dr);
		Session["dtUser"] = dtUser;
		return false;
	}
	else
	{
		dtUser = (DataTable)Session["dtUser"];
	}
	return true;
}

//is it show in "Brands", if not then only show it in "More Brands..."
Boolean IsThisBrandShow(string brand)
{
	DataSet dstt = new DataSet();
	string show = "true";
	int rows = 0;

	string sc = "SELECT TOP 1 show FROM brand_settings WHERE brand='";
	sc += EncodeQuote(brand);
	sc += "'";

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstt, "1");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return true;
	}
	
	if(rows == 0)
	{
		sc = "INSERT INTO brand_settings (brand, show) VALUES('";
		sc += EncodeQuote(brand);
		sc += "', 'true')";
		
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return true;
		}
		return true;
	}
	else
	{	
		show = dstt.Tables[0].Rows[0]["show"].ToString();
	}
	
	return (show == "true");
}

//mark it for return, especailly after login
void RememberLastPage()
{
	string sl = "http";
	
    if(String.Compare(Request.ServerVariables["HTTPS"].ToString(), "on", true) == 0)
        sl += "s";
	
    sl += "://";
    sl += Request.ServerVariables["HTTP_HOST"];
    sl += Request.ServerVariables["URL"].ToString();
    sl += "?";
	sl += Request.ServerVariables["QUERY_STRING"];
	Session["LastPage"] = sl;
}

void BackToLastPage()
{
//	Response.Write("lastpage = "+Session["LastPage"]);
	string url;

	if(Session["LastPage"] != null)
	{
//DEBUG("last page = ", Session["LastPage"].ToString());
		url = Session["LastPage"].ToString();
		int p = 0;
		if(url.IndexOf("checkout.aspx") >= 0)
		{
			if(Session[m_sCompanyName + "sales"] != null && (bool)Session[m_sCompanyName + "sales"])
			{
				url = "/sales/pos.aspx";
			}
		}
/*		else if(url.IndexOf("/p.aspx") >= 0 && url.IndexOf("admin") < 0)
		{
			if(SecurityCheck("editor", false))
			{
				p = url.IndexOf("/p.aspx");
				string u = url.Substring(0, p);
				u += "/admin";
				u += url.Substring(p, url.Length -  p);
				url = u;
			}
		}
*/		if(Session["card_type"] != null && Session["card_type"] != "")
		{
			if(Session["card_type"].ToString() == "2")
			{
				if(url.IndexOf("/dealer") <= 0 )
				{
					//url = "dealer/";
				}
			}
		}
	}
	else
	{
		url = "";
	
		if(Session["card_type"] != null && Session["card_type"] != "")
		{
		
			if(Session["card_type"].ToString() == "2"){}
				//url = "dealer/";
		}
		

        url += "default.aspx";
	}
//DEBUG("url=", url);

    if(url.Contains("?")){
        url += "&isLogin=y";
    }else{
        url += "?isLogin=y";
    }

    Response.Redirect(url);
}

string RemoveSlash(string s)
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] != '\\' && s[i] != '/')
			ss += s[i];
	}
	return ss;
}

//remove single quote for sql statements, most used for brands and catalogs
//we don't encode and decode this for them to gain performance and smiplify code
string RemoveQuote(string s) 
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] != '\'')
			ss += s[i];
	}
	return ss;
}

string EncodeQuote(string s) //double single quote for sql statements
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == '\'')
			ss += '\''; //double it for SQL query
		ss += s[i];
	}
	return ss;
}

string DecodeQuote(string s) //reverse of EncodeQuote
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == '\'')
			if(i<s.Length-1)
				if(s[i+1] == '\'')
					continue; //skip one	
	}
	return ss;
}

string TSGetPath() //get virtual path exclusive of page name and slashes, ie: /eden/cart.aspx return eden
{
	string s = Request.ServerVariables["URL"];
	int i = s.Length - 1;
	for(; i>=0; i--)
	{
		if(s[i] == '/')
			break;
	}
	
	if(i > 1)
		return s.Substring(1, i - 1);
	return Request.ServerVariables["SERVER_NAME"];
}

string TSGetUserNameByID(string id) //get user name from account table according to user id
{
	DataSet dsu = new DataSet();
	string sc = "SELECT name FROM card WHERE id='" + id + "'";
	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft;" + m_sDataSource + m_sSecurityString);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(dsu);
		if(rows > 0)
			return dsu.Tables[0].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "error";
	}
	return "user not found";
}

string TSGetUserCompanyByID(string id) //get user name from account table according to user id
{
	DataSet dsu = new DataSet();
	string sc = "SELECT company, trading_name FROM card WHERE id='" + id + "'";
	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft;" + m_sDataSource + m_sSecurityString);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(dsu);
		if(rows > 0)
			return dsu.Tables[0].Rows[0]["trading_name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "error";
	}
	return "user not found";
}

string TSGetUserEmailByID(string id) //get user email from account table according to user id
{
	DataSet dsu = new DataSet();
	string sc = "SELECT email FROM card WHERE id='" + id + "'";
	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft;" + m_sDataSource + m_sSecurityString);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(dsu);
		if(rows > 0)
			return dsu.Tables[0].Rows[0]["email"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "error";
	}
	return "user not found";
}

Boolean TSIsDigit(string s) //is this string valid for int.parse
{
	if(s == null || s == "")
		return false;
	Boolean bRet = true;
	for(int i=0; i<s.Length; i++)
	{
		if(Char.IsDigit(s[i]) == false)
		{
			if(s[i] != '.' && s[i] != '-' && s[i] != '$')
			{
				bRet = false; 
				break;
			}
		}		
	}
	return bRet;
}

bool IsInteger(string s) //is this string valid for int.parse
{
	if(!TSIsDigit(s))
		return false;

	bool bRet = true;
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == '.')
		{
			bRet = false; 
			break;
		}
	}
	return bRet;
}

private static CacheItemRemovedCallback onCacheRemove = null;
public void CacheRemovedCallback(String k, Object v, CacheItemRemovedReason r)
{
//	AlertAdmin("Cache Rmoved Notice", "Cache Rmoved from site: " + TSGetPath() + "\r\nk=" + k + ", objectName=" + v.ToString() + ", reason=" + r.ToString());
}

void TSAddCache(string sKey, object oValue)
{
	onCacheRemove = new CacheItemRemovedCallback(this.CacheRemovedCallback);
//	Cache.Insert(sKey, oValue, null, DateTime.MaxValue, TimeSpan.Zero);
	Cache.Insert(sKey, oValue, null, DateTime.UtcNow.AddHours(12).AddMinutes(60), TimeSpan.Zero, CacheItemPriority.Default, onCacheRemove);
}

void TSRemoveCache(string cn) //remove(refresh) cache 
{
//DEBUG("removing cache, m_sCompanyName=" + m_sCompanyName + " cn=", cn);
	Cache.Remove(cn); //remove catalog cache
	
	//remove all catalog contents cache
	IDictionaryEnumerator ide = Cache.GetEnumerator();
	if(ide == null)
		return;
	for(int i=Cache.Count-1; i>=0; i--)
	{
		ide.MoveNext();
		string s = ide.Key.ToString();
		if(s.Length > 7)
		{
			if(String.Compare(s.Substring(0, 7), "System.", true) != 0 && String.Compare(s.Substring(0, 5), "ISAPI", true) != 0)
			{
				if(s.Length > m_sCompanyName.Length)
				{
					if(String.Compare(s.Substring(0, m_sCompanyName.Length), m_sCompanyName, true) == 0)
					{
//						if(Cache[s] != null)
//						{
							Cache.Remove(s);
//							DEBUG(s, " removed");
//						}
					}
//					else
//					{
//					DEBUG("sub=", s.Substring(0, 4));
//					}
				}
			}
		}
	}
}

void TSRemoveCache() //remove(refresh) cache 
{
	IDictionaryEnumerator ide = Cache.GetEnumerator();
	for(int i=Cache.Count-1; i>=0; i--)
	{
		ide.MoveNext();
		string s = ide.Key.ToString();
		if(s.Length > 7)
		{
			if(String.Compare(s.Substring(0, 7), "System.", true) != 0 && String.Compare(s.Substring(0, 5), "ISAPI", true) != 0)
			{
				if(s.Length > m_sCompanyName.Length)
				{
					if(String.Compare(s.Substring(0, m_sCompanyName.Length), m_sCompanyName, true) == 0)
					{
						Cache.Remove(s);
					}
				}
			}
		}
	}
}

void doDeleteAllPicFiles()
{
	//string strPath = "C:\\html\\ezsoft\\nz\\shops\\eden\\admin\\ri\\";
	//string file = strPath;
	
	string path = Server.MapPath("./ri/");
//DEBUG(" path =", path);
	string[] files = Directory.GetFiles(path,"*.jpg");
	int count = files.Length;
	
	for(int i=0; i<count; i++)
	{
		File.Delete(files[i]);
	}

}

//xml decoding
string XMLDecoding(string stext)
{
	stext = stext.Replace("</b>", "");
	stext = stext.Replace("<b>", "");
	stext = stext.Replace("<font", "");
	stext = stext.Replace("</font>", "");
	stext = stext.Replace("color=", "");
	stext = stext.Replace(">", "");
	stext = stext.Replace("<", "");
	
	return stext;
}


/////////date changer ////////////////////////////////////////////////////////
string datePicker()
{
	Response.Write("<SCRIPT LANGUAGE=javascript>");
	string s = @"

	function tg_mm_daysinmonth(lnMonth,lnYear) {
	var dt1, cmn1, cmn2, dtt, lflag, dycnt, lmn
	lmn = lnMonth-1
	dt1 = new Date(lnYear,lmn,1)
	cmn1 = dt1.getMonth()
	dtt=dt1.getTime()+2332800000
	lflag = true
	dycnt=28
	while (lflag) {
	   dtt = dtt + 86400000
	   dt1.setTime(dtt)
	   cmn2 = dt1.getMonth()
	   if (cmn1!=cmn2) {
		  lflag = false }
	   else {dycnt = dycnt + 1}}
	if (dycnt > 31) {dycnt = 31}
		return dycnt
	}
	function tg_mm_setdays(sobjname, datemode){
	var dobj = eval(sobjname + '_day')
	var mobj = eval(sobjname + '_month')
	var yobj = eval(sobjname + '_year')
	var hobj = eval(sobjname)
	var hobjconv = eval(sobjname + '_conv')
	var monthdays = tg_mm_daysinmonth(mobj.options[mobj.selectedIndex].value,yobj.options[yobj.selectedIndex].value)
	var selectdays = dobj.length
	var curdy = dobj.options[dobj.selectedIndex].value
	if (curdy.length==1) {curdy = '0'+curdy}
	var curmn = mobj.options[mobj.selectedIndex].value
	if (curmn.length==1) {curmn = '0'+curmn}
	var curyr = yobj.options[yobj.selectedIndex].value
	if (selectdays > monthdays) {
	   for (var dlp=selectdays; dlp > monthdays; dlp--) {
		   dobj.options[dlp-1] = null }}
	else if (monthdays > selectdays) {
	   for (var dlp=selectdays; dlp < monthdays; dlp++) {
		   dobj.options[dlp] = new Option(dlp+1,dlp+1) }}
	if (curdy > monthdays) {
	   dobj.options[monthdays-1].selected = true
	   curdy = monthdays }
	var curdateconv = curmn+'/'+curdy+'/'+curyr
	if (datemode==1) {
	   var curdate = curmn+'/'+curdy+'/'+curyr }
	else if (datemode==2) {
	   var curdate = curdy+'/'+curmn+'/'+curyr }
	else if (datemode==3) {
	   var curdate = curyr+curmn+curdy }
	else if (datemode==4) {
	   var cdate = new Date(curyr,curmn-1,curdy)
	   var curdate = cdate.toGMTString() }
	hobj.value = curdate
	hobjconv.value = curdateconv
	}
	";
	Response.Write(s);
	Response.Write("</SCRIPT");
	Response.Write(">");
	return s;

}
//// END date changer -------


bool LogVisit()
{
	string site = TSGetPath();
	if(Session["site"].ToString() != site)
	{
		Session["site"] = site;
		if(!UpdateSessionLog())
			return false;
	}
	string sc = "INSERT INTO web_log (id, ip, name, email, browser, url, query, visit) VALUES('"
		+ Session.SessionID + "', '" 
		+ Session["ip"].ToString() + "', '" 
		+ Session["name"].ToString() + "', '" 
		+ Session["email"].ToString() + "', '" 
		+ Request.ServerVariables["HTTP_USER_AGENT"] + "', '"
		+ Request.ServerVariables["URL"] + "', '"
		+ Request.ServerVariables["QUERY_STRING"] + "', '"
		+ DateTime.UtcNow.AddHours(12) + "')";
	try
	{
		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft;" + m_sDataSource + m_sSecurityString);
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		AlertAdmin("Error LogVisit", e.ToString() + "\r\n\r\nQuery = \r\n" + sc);
		return false;
	}
	return true;
}

bool UpdateSessionLog()
{
	if(Session["session_log_id"] == null || Session["session_log_id"].ToString() == "")
		return true;

	string sc = "UPDATE web_session SET card_id='" + Session["card_id"].ToString() + "' ";
	sc += " WHERE id=" + Session["session_log_id"].ToString();
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		AlertAdmin("Error LogVisit", e.ToString() + "\r\n\r\nQuery = \r\n" + sc);
		return false;
	}
	return true;
}

bool BackupProduct(DataRow dr)
{
	string sc;
	sc = "INSERT INTO product_bak (code, name, brand, cat, s_cat, ss_cat, hot, price, stock, supplier, supplier_code, supplier_price, price_age)";
	sc += "VALUES('";
	sc += dr["code"].ToString();
	sc += "', '";
	sc += dr["name"].ToString();
	sc += "', '";
	sc += dr["brand"].ToString();
	sc += "', '";
	sc += dr["cat"].ToString(); 
	sc += "', '";
	sc += dr["s_cat"].ToString(); 
	sc += "', '";
	sc += dr["ss_cat"].ToString();
	sc += "', ";
	sc += "0";
	sc += ", ";
	sc += dr["price"].ToString();
	sc += ", ";
	if(dr["stock"].ToString() == "")
		sc += "null";
	else
		sc += dr["stock"].ToString();
	sc += ", '";
	sc += dr["supplier"].ToString();
	sc += "', '";
	sc += dr["supplier_code"].ToString();
	sc += "', ";
	sc += dr["supplier_price"].ToString();
	sc += ", '";
	sc += dr["price_age"].ToString();
	sc += "')";

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string GetProductDesc(string code)
{
//DEBUG("code=", code);
	DataRow dr = null;
	if(!GetProduct(code, ref dr))
		return "";
	return clearDangeronsRequest(dr["name"].ToString());
}
string clearDangeronsRequest(string hRequest){
     StringBuilder sb = new StringBuilder(HttpUtility.HtmlEncode(hRequest));
     sb.Replace("&lt;b&gt;", "<b>");
     sb.Replace("&lt;/b&gt;", "");
     sb.Replace("&lt;i&gt;", "<i>");
     sb.Replace("&lt;/i&gt;", "");
     return sb.ToString();
}
string GetProductStock(string code)
{
//DEBUG("code=", code);
	DataRow dr = null;
	if(!GetProduct(code, ref dr))
		return "0";
//	double stock = MyDoubleParse(dr["stock"].ToString());
	double stock = MyDoubleParse(dr["stock_qty"].ToString());
	string allocated = dr["allocated_stock"].ToString();
	double dAllocated = 0;
	if(allocated != "")
		dAllocated = MyDoubleParse(allocated);
/*	if(g_bRetailVersion)
		return (stock).ToString();
	else
		return (stock - dAllocated).ToString();
		*/
	return (stock).ToString();
}
string GetProductAllocated_Stock(string code)
{
	DataRow dr = null;
	if(!GetProduct(code, ref dr))
		return "0";
	string allocated = dr["allocated_stock"].ToString();
	double dAllocated = 0;
	if(allocated != "")
		dAllocated = MyDoubleParse(allocated);
	
	return dAllocated.ToString();
	
}

//get kit
Boolean GetKit(string code, ref DataRow dr)
{
	if(!TSIsDigit(code))
	{
		Response.Write("<h3>Error, item code must be digits</h3>");
		return false;
	}

	if(dstcom.Tables["product"] != null)
		dstcom.Tables["product"].Clear();
	Boolean bRet = false;

	string sc = "SELECT k.show_level,  k.price AS last_cost, 1 AS currency, 0.00 AS foreign_supplier_price ";
	sc += ", price AS manual_cost_nzd, rate, 1 AS level_rate1, price AS rrp";
	sc += ", '' AS highlight,  k.details AS spec, ' ' AS manufacture , ' ' AS pic, ' ' AS rev, k.warranty AS warranty,  null AS director , null AS cast_member, 1 AS discs, 4 AS title_zone, 1 AS classification, 3 AS rating ";
	sc += " , 2 AS stock_qty  ";
	sc += " FROM kit AS k ";

	sc += " WHERE k.id=" + code;

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "product") > 0)
		{
			dr = dstcom.Tables["product"].Rows[0];
			bRet = true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return bRet;
}

//end get kit


Boolean GetProduct(string code, ref DataRow dr)
{
	if(!TSIsDigit(code))
	{
		Response.Write("<h3>Error, item code must be digits</h3>");
		return false;
	}

	if(dstcom.Tables["product"] != null)
		dstcom.Tables["product"].Clear();
	Boolean bRet = false;

	string sc = "SELECT p.*, c.supplier_price AS last_cost, c.currency, c.foreign_supplier_price ";
	sc += ", c.manual_cost_nzd, c.rate, c.level_rate1, c.rrp, c.show_price, c.show_level, c.rrp ";
	sc += ", pd.* ";
	sc += " , ISNULL((SELECT sum(qty) FROM stock_qty sq WHERE sq.code = p.code AND sq.code = c.code ";
//	if(Session["branch_support"] != null)
//		sc += " AND branch_id = "+ Session["branch_id"].ToString() +"";
	sc += " ),0) AS stock_qty  ";
	sc += " FROM product p JOIN code_relations c ON c.code=p.code ";
	sc += " LEFT OUTER JOIN product_details pd ON pd.code=p.code ";

	sc += " WHERE c.code=" + code;

//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "product") > 0)
		{
			dr = dstcom.Tables["product"].Rows[0];
			bRet = true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
/*	if(!bRet)
	{
		sc = "SELECT k.* FROM product_skip k JOIN code_relations c ON k.id=c.id WHERE c.code=" + code;
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			if(myAdapter.Fill(dstcom, "product") > 0)
			{
				dr = dstcom.Tables["product"].Rows[0];
				bRet = true;
			}
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
*/
	return bRet;
}

bool GetRawProduct(string supplier, string supplier_code, ref DataRow dr)
{
	string sc = "SELECT code, supplier, supplier_code, ISNULL(supplier_price, 0) AS supplier_price, name ";
	sc += " FROM code_relations WHERE supplier='" + supplier + "' AND supplier_code='" + supplier_code + "'";

	if(dstcom.Tables["product"] != null)
		dstcom.Tables["product"].Clear();

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "product") > 0)
			dr = dstcom.Tables["product"].Rows[0];
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetProduct(string supplier, string supplier_code, ref DataRow dr)
{
	Boolean bRet = false;

	string sc = "SELECT * FROM product WHERE supplier='" + supplier + "' AND supplier_code='" + supplier_code + "'";

	if(dstcom.Tables["product"] != null)
		dstcom.Tables["product"].Clear();

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "product") > 0)
		{
			dr = dstcom.Tables["product"].Rows[0];
			bRet = true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return bRet;
}

Boolean GetProductWithSpecialPrice(string code, ref DataRow dr)
{
	Boolean bRet = true;

	string sc = "SELECT p.code, p.name, p.price, p.supplier, p.supplier_code ";
	sc += ", p.supplier_price, ISNULL(p.price, 0) AS special, c.level_rate1 ";
	sc += " FROM product p JOIN code_relations c ON c.code=p.code ";
	sc += " LEFT OUTER JOIN specials s ON p.code=s.code ";
	sc += " WHERE p.code=" + code;

	if(dstcom.Tables["product"] != null)
		dstcom.Tables["product"].Clear();

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "product") > 0)
		{
			dr = dstcom.Tables["product"].Rows[0];
		}
		else
		{
			sc = "SELECT c.name, k.price, c.supplier, c.supplier_code, k.supplier_price, ISNULL(s.price, 0) AS special ";
			sc += "FROM code_relations c JOIN product_skip k ON c.id=k.id LEFT OUTER JOIN specials s ON c.code=s.code WHERE c.code='";
			sc += code;
			sc += "'";
			try
			{
				myAdapter = new SqlDataAdapter(sc, myConnection);
				if(myAdapter.Fill(dstcom, "product") > 0)
					dr = dstcom.Tables["product"].Rows[0];
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return bRet;
}

//if this product for current user return true;
// if not return false.
void ProductFilter(ref System.Data.DataSet ds){
    if(ds.Tables["product"] == null || ds.Tables["product"].Rows.Count <= 0) return;
//code 

    System.Data.DataRow dr;
    for(int i = 0; i < ds.Tables["product"].Rows.Count; i++){
        dr = ds.Tables["product"].Rows[i];
        string code = dr["code"].ToString();
        if(!ShowProduct(code)){
            ds.Tables["product"].Rows[i].Delete();
        }
    }
    ds.Tables["product"].AcceptChanges();
}

bool ShowProduct(string code){
    bool returnValue = true;
    // int userLevel = 0;
    // int show_level = 1;
    // DataRow dr = null;
    // GetProduct(code, ref dr);
    // if(dr != null){
    //    if(!int.TryParse(dr["show_level"].ToString(), out show_level)){
    //             show_level = 4;
    //     }
    // }else{
    //     GetKit(code, ref dr);
    //     if(dr != null){
    //       if(!  int.TryParse(dr["show_level"].ToString(), out show_level)){
    //             show_level = 4;
    //       }
    //     }
    // }
    // if(Session["card_type"] != null){
    //     //if logined
    //     int.TryParse(Session["card_type"].ToString(), out userLevel);

    //     if(userLevel == 0){ //person.
    //         if(show_level == 1 || show_level == 3){
    //             returnValue = true;
    //         }
    //     }else if(userLevel == 1){ //customer
    //         if(show_level == 1 || show_level == 3){
    //             returnValue = true;
    //         }
    //     }else if(userLevel == 2){ //dealer
    //         if(show_level == 2 || show_level == 3){
    //             returnValue = true;
    //         }
    //     }else{// if other type of user show all like admin.
    //         returnValue = true;
    //     }
    // }else{ //if nobody login
    //      if(show_level == 1 || show_level == 3){
    //          returnValue = true;
    //      }
    // }
    return returnValue;
}

string GetProductPDFSrc(string code)
{
	bool bHasLocal = false;
	string sPDFFile = "";
	string vpath = GetRootPath();
	if(vpath == "")
		vpath = "/pdf/";
	else
		vpath += "/pdf/";
	string path = vpath;
//	sPDFFile = "/" + m_sCompanyName + "/pi/" + code + ".gif";
//	if(m_sSite != "www")
//		path = "../pi/";
	sPDFFile = path + code + ".pdf";
//if(Session["email"] != null && Session["email"].ToString() == "darcy@ezsoft.com")
//{
//DEBUG("sPDFFile=", sPDFFile);
//DEBUG("path=", Server.MapPath(sPDFFile));
//}
	bHasLocal = File.Exists(Server.MapPath(sPDFFile));
	if(!bHasLocal)
	{
		sPDFFile = path + code + ".pdf";
		bHasLocal = File.Exists(Server.MapPath(sPDFFile));
	}
	if(!bHasLocal)
		sPDFFile = "#";//GetRandomNAImage();

	return sPDFFile;	
}



System.Collections.Generic.List<string> GetProductImgSrcList(string code){
            System.Collections.Generic.List<string> imageList = new System.Collections.Generic.List<string>();
            
	        string vpath = GetRootPath();
	        if(vpath == "")
		        vpath = "/pi/";
	        else
		        vpath += "/pi/";
	        string path = vpath;
	        
            try
            {
                //get path
                path = Server.MapPath(path + code + "/");
                // 1
                // Get array of all file names.
                string[] a = Directory.GetFiles(path, "*.*");
                string imageSrc = "";
                // 2
                // Calculate total bytes of all files in a loop.
                foreach (string name in a)
                {
                    string n = name.Replace(path, "");
                    //DEBUG("filename = " , vpath + code + "/" + n);
                    n = vpath + code + "/" + n;
                    imageList.Add(n);
                }
            }
            catch (System.Exception)
            {
            }
            // 4
            // Return total size
            return imageList;
}

System.Collections.Generic.List<string> GetProductImgSrcList(string code, bool isKit){
            System.Collections.Generic.List<string> imageList = new System.Collections.Generic.List<string>();
            
	        string vpath = GetRootPath();
	        if(isKit){
	        	if(vpath == "")
		        	vpath = "/pk/";
		        else
			        vpath += "/pk/";
	        }else{
	        	if(vpath == "")
		        	vpath = "/pi/";
		        else
			        vpath += "/pi/";
	        }


	        string path = vpath;
	        
            try
            {
                //get path
                path = Server.MapPath(path + code + "/");
                // 1
                // Get array of all file names.
                string[] a = Directory.GetFiles(path, "*.*");
                string imageSrc = "";
                // 2
                // Calculate total bytes of all files in a loop.
                foreach (string name in a)
                {
                    string n = name.Replace(path, "");
                    //DEBUG("filename = " , vpath + code + "/" + n);
                    n = vpath + code + "/" + n;
                    imageList.Add(n);
                }
            }
            catch (System.Exception)
            {
            }
            // 4
            // Return total size
            return imageList;
}

string GetProductImgSrc(string code)
{
	bool bHasLocal = false;
	string sPicFile = "";
	string vpath = GetRootPath();
	if(vpath == "")
		vpath = "/pi/";
	else
		vpath += "/pi/";
	string path = vpath;
//	sPicFile = "/" + m_sCompanyName + "/pi/" + code + ".gif";
//	if(m_sSite != "www")
//		path = "../pi/";
	sPicFile = path + code + ".gif";
//if(Session["email"] != null && Session["email"].ToString() == "darcy@ezsoft.com")
//{
//DEBUG("sPicFile=", sPicFile);

//}
	try
	{
		bHasLocal = File.Exists(Server.MapPath(sPicFile));
		if(!bHasLocal){
				sPicFile = path + code + ".jpg";
				bHasLocal = File.Exists(Server.MapPath(sPicFile));
				if(!bHasLocal){
					sPicFile = path + code + ".png";
					bHasLocal = File.Exists(Server.MapPath(sPicFile));
					if(!bHasLocal){
						sPicFile = path + code + ".bmp";
						bHasLocal = File.Exists(Server.MapPath(sPicFile));
					}
				}
		}
	}
	catch(Exception e)
	{
	}
	if(!bHasLocal)
	{
		sPicFile = path + code + ".jpg";
		try
		{
			bHasLocal = File.Exists(Server.MapPath(sPicFile));			
		}
		catch(Exception e)
		{
		}
	}
	if(!bHasLocal)
		sPicFile = "/i/na.gif";//GetRandomNAImage();

/*	if(!bHasLocal)
	{
		string sc = "SELECT pic FROM product_details WHERE code=";
		sc += code;

		DataSet ds;
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			ds = new DataSet();
			if(myAdapter.Fill(ds) > 0)
			{
				DataRow dr = ds.Tables[0].Rows[0];
				if(dr["pic"] != null && dr["pic"] != "")
					sPicFile = dr["pic"].ToString().TrimEnd();
			}
			else
				sPicFile = GetRandomNAImage();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return "/i/na.jpg";
		}
	}
*/
	return sPicFile;	
}

string GetProductImgSrc(string code, bool isKit)
{
	bool bHasLocal = false;
	string sPicFile = "";
	string vpath = GetRootPath();
	if(isKit){
	   	if(vpath == "")
		    vpath = "/pk/";
		else
			vpath += "/pk/";
	}else{
	    if(vpath == "")
		   vpath = "/pi/";
		else
		   vpath += "/pi/";
	}
	string path = vpath;

	sPicFile = path + code + ".gif";

	try
	{
		bHasLocal = File.Exists(Server.MapPath(sPicFile));
		if(!bHasLocal){
			sPicFile = path + code + ".jpg";
			bHasLocal = File.Exists(Server.MapPath(sPicFile));
			if(!bHasLocal){
				sPicFile = path + code + ".png";
				bHasLocal = File.Exists(Server.MapPath(sPicFile));
				if(!bHasLocal){
					sPicFile = path + code + ".bmp";
					bHasLocal = File.Exists(Server.MapPath(sPicFile));
				}
			}
		}
	}
	catch(Exception e)
	{
	}

	//if(!bHasLocal)
	//	sPicFile = "/i/na.gif";//GetRandomNAImage();

	return sPicFile;	
}


string GetRandomNAImage()
{
	Random rnd = new Random();
	int i = rnd.Next(1, 15);
	string s = "i/na";
	s += i.ToString();
	string f = s + ".gif";
	if(!File.Exists(Server.MapPath(f)))
	{
		f = s + ".jpg";
		if(!File.Exists(Server.MapPath(f)))
			f = "i/na.jpg";
	}
	return f;
}

DataSet dsAEV = new DataSet();	//for GetAllExistsValues
//search exists target fields to build selectable box for edit
bool ECATGetAllExistsValues(string sFieldName, string sCondition)
{
	if(sFieldName == "" || sCondition == "")
	{
		Response.Write("<h3>Error, fieldName or Condition can't be blank</h3>");
		return false;
	}
	
	if(dsAEV.Tables[sFieldName] != null)
		dsAEV.Tables[sFieldName].Clear();
	//string sc = "SELECT DISTINCT (" + sFieldName + ")) FROM product WHERE " + sCondition;
	string sc = "SELECT DISTINCT RTRIM(LTRIM(" + sFieldName + ")) AS "+ sFieldName +" FROM product WHERE " + sCondition;
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsAEV, sFieldName);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool ECATGetAllExistsValues(string sFieldName, string sCondition, bool bNewTableAlso)
{
	if(!ECATGetAllExistsValues(sFieldName, sCondition))
		return false;
	if(!bNewTableAlso)
		return true;

	string sc = "SELECT DISTINCT LTRIM(RTRIM(" + sFieldName + ")) AS "+ sFieldName +" FROM code_relations_new" + m_catTableString + " WHERE " + sCondition;
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsAEV, sFieldName);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

//check phased out item  1-10-03 tee
bool UpdatePhasedOutItem(string code, int nQty, int nPoID)
{
	if(code == "" && code == null)
		return false;
	nQty = 0;
	string sc = "";

//sc = " IF (SELECT COUNT(*) FROM product_skip WHERE id = (select top 1 id FROM code_relations WHERE code = "+ code +") > 0";
	sc += " IF NOT EXISTS (SELECT code FROM product WHERE code = "+ code +" ) ";
	sc += " INSERT INTO product (code ,name  ,brand ,cat  ,s_cat ,ss_cat ,hot ,price  ,stock ,eta  ,supplier  ,supplier_code  ,supplier_price ,price_dropped ,price_age ,allocated_stock ,popular ,real_stock) ";
	sc += " SELECT c.code, c.name, c.brand, c.cat, c.s_cat, c.ss_cat, 0 AS hot ";
	sc += " , ps.price, ps.stock - "+ nQty +", ps.eta, c.supplier, c.supplier_code, ps.supplier_price, 0 AS price_drop "; 
	sc += " , GETDATE() AS price_age, 0 AS allocated_stock, 0 AS popular, c.real_stock ";
	sc += " FROM code_relations c JOIN product_skip ps ON c.id = ps.id ";
	sc += " AND c.skip = 1 ";
	sc += " WHERE c.code = "+ code;
//sc += " END ";
	
	//update not phased out item
	sc += " UPDATE code_relations SET skip=0 WHERE code = "+ code;
	//delete from skip table
	sc += " DELETE FROM product_skip WHERE id = (select DISTINCT c.id FROM code_relations c JOIN purchase_item pi ON pi.code = c.code ";
	sc += " AND pi.supplier_code = c.supplier_code AND pi.id = "+ nPoID +" WHERE c.code = "+ code +")";

//DEBUG("s c = ", sc );
	try	
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
		
	return true;

}


//two or more same code items, we choose one by comparing stock and price
bool SingleOut(string code)
{
	DataSet dsSingle = new DataSet();

	int rows = 0;
	StringBuilder sb = new StringBuilder();
	sb.Append("SELECT * FROM product WHERE code=" + code + " ORDER BY price, stock");
	try
	{
		myAdapter = new SqlDataAdapter(sb.ToString(), myConnection);
		rows = myAdapter.Fill(dsSingle, "singleout");
//DEBUG("rows=", rows);
		if(rows <= 1)
			return true; //no duplicate code
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}

	DataRow dr;
	
	int nStock;
	int nTheOne = 0; //default the first row (cheapest)
	for(int i=0; i<dsSingle.Tables["singleout"].Rows.Count; i++)
	{
		dr = dsSingle.Tables["singleout"].Rows[i];
		if(dr["stock"] == null || dr["stock"].ToString() == "")
			nStock = 9999;
		else
			nStock = int.Parse(dr["stock"].ToString());
		if(nStock > 0)
		{
			nTheOne = i;//if the cheapest one has stock, then this is the one we after
			break;
		}
	}
	//if all out of stock, we still choose the cheapest one
//DEBUG("theone=", nTheOne);
	//keep theone, delete all others
	for(int i=0; i<dsSingle.Tables["singleout"].Rows.Count; i++)
	{
//DEBUG("i=", i);
		if(i != nTheOne)
		{
			dr = dsSingle.Tables["singleout"].Rows[i];
			if(!BackupProduct(dr))
				return false;
			sb.Remove(0, sb.Length);
			sb.Append("DELETE FROM product WHERE supplier='");
			sb.Append(dr["supplier"].ToString());
			sb.Append("' AND supplier_code='");
			sb.Append(dr["supplier_code"].ToString());
			sb.Append("'");
//DEBUG("sc=", sb.ToString());
			try
			{
				myCommand = new SqlCommand(sb.ToString());
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sb.ToString(), e);
				return false;
			}
		}
	}
	return true;
}

int GetNextID(string sTable, string sColumn)
{
	int id = 1;

	DataSet ds = new DataSet();
	int rows = 0;
	string sc = "SELECT TOP 1 " + sColumn + " FROM " + sTable + " ORDER BY " + sColumn + " DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "id");
		if(rows == 1)
			id = int.Parse(ds.Tables["id"].Rows[0][sColumn].ToString()) + 1;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return -1;
	}
	return id;
}

int GetNextInvoiceNumber()
{
	int newNumber = 100000;

	DataSet ds = new DataSet();
	int rows = 0;
	string sc = "SELECT TOP 1 invoice_number FROM invoice ORDER BY invoice_number DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "invoice");
		if(rows == 1)
			newNumber = int.Parse(ds.Tables["invoice"].Rows[0]["invoice_number"].ToString()) + 1;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return -1;
	}
	return newNumber;
}

int GetNextTempInvoiceNumber() //use minus number to keep real invoices in sequence
{
	int newNumber = 100000;

	DataSet ds = new DataSet();
	int rows = 0;
	string sc = "SELECT TOP 1 invoice_number FROM invoice ORDER BY invoice_number";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds, "invoice");
		if(rows == 1)
			newNumber = int.Parse(ds.Tables["invoice"].Rows[0]["invoice_number"].ToString()) - 1;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return -1;
	}
	if(newNumber > -10000)
		newNumber = -10001;
	return newNumber;
}

void AlertMissProduct(string code, string refer, string email)
{
	
	
	string ser = Request.ServerVariables["SERVER_NAME"];
	string tspath = TSGetPath().ToLower();
	if(tspath == m_sCompanyName || tspath == m_sCompanyName + "admin" || tspath == m_sCompanyName + "/admin" || tspath == m_sCompanyName + "/sales")
		ser += "/" + m_sCompanyName;
	
	string url = "http://" + Request.ServerVariables["SERVER_NAME"] + Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"];
	string mTo = email;
	string mFrom = GetSiteSettings("postmaster_email", "postmaster@ezsoft.com");
	string mSubject = "Error Recommened System";
	string mBody = "Product code : " + code + " (" + refer + ") didn't find.\r\n\r\n<br><br>";
	mBody += "User : " + Session["name"].ToString() + "\r\n<br>";
	mBody += "URL : <a href=" + url + ">" + url + "</a>\r\n<br>";
	mBody += "ip : " + Session["ip"].ToString() + "\r\n<br>";

	
    SendEmail(mFrom, mFrom, mTo, mSubject,mBody);
    SendEmail(mFrom, mFrom, m_emailAlertTo, mSubject,mBody);
	

}

bool UpdateDiscount(string id, double discount)
{
	string sc = "UPDATE card SET discount=" + discount + " WHERE id=" + id;
//DEBUG("sc=", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void PrintPaymentType(string current)
{

	//payment type
	Response.Write("<select name=payment_type>");

	Response.Write(GetEnumOptions("payment_method", current));

	Response.Write("&nbsp;");
	Response.Write("</select>");	

}

bool PrintBranchNameOptions()
{
	int nBranchID = 1;
	if(Request.Form["branch"] != null && Request.Form["branch"] != "")
	{
		nBranchID = int.Parse(Request.Form["branch"]);
		Session["branch_id"] = nBranchID;
	}
	else if(Session["branch_id"] != null && Session["branch_id"].ToString() != "")
	{
		nBranchID = MyIntParse(Session["branch_id"].ToString());
	}

	return PrintBranchNameOptions(nBranchID.ToString());
}

bool PrintBranchNameOptions(string current_branch)
{
	return PrintBranchNameOptions(current_branch, "");
}
bool PrintBranchNameOptions(string current_branch, string onchange_url)
{
	return PrintBranchNameOptions(current_branch, onchange_url, false);
}
bool PrintBranchNameOptions(string current_branch, string onchange_url, bool bAllBranchOn)
{
	DataSet dsBranch = new DataSet();
	int rows = 0;

	//do search
	string sc = "SELECT id, name FROM branch ORDER BY id";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dsBranch, "dc_branch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=branch");
    if(onchange_url != "")
    {
        Response.Write(" onchange=\"window.location=('");
        Response.Write(onchange_url + "&_b='+ this.options[this.selectedIndex].value ) \" ");
    }
	Response.Write(">");
	if(bAllBranchOn)
		Response.Write("<option value=all>All Branch</option>");
	for(int i=0; i<rows; i++)
	{
		string bname = dsBranch.Tables["dc_branch"].Rows[i]["name"].ToString();
		string bid = dsBranch.Tables["dc_branch"].Rows[i]["id"].ToString();
		Response.Write("<option value="+ bid);
		if(bid == current_branch)
			Response.Write(" selected=\"selected\" ");
		Response.Write(">" + bname + "</option>");
	}
	if(rows == 0){
        Response.Write("<option value=\"1\">No Branch</option>");
    }else{
        //Response.Write("<option value=\"0\">All</option>");  
    }  
	Response.Write("</select>");
	return true;
}

string GetEnumValue(string sClass, string id)
{
	if(id == "")
	{
		//Response.Write("Empty ID, class=" + sClass);
		return "";
	}
	if(!TSIsDigit(id))
	{
		//Response.Write("Empty ID, class=" + sClass);
		return "";
	}

	DataSet dsEnum = new DataSet();
	string sValue = "";
	//string sc = "SELECT name FROM enum WHERE class='" + sClass + "' AND id=" + id;
	string sc = "SELECT name FROM enum WHERE class='" + sClass + "' AND id=" + id +" AND name is not null AND name <> ''";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsEnum, "enum") == 1)
			sValue = dsEnum.Tables["enum"].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return sValue;
}

string GetEnumID(string sClass, string sValue)
{
	DataSet dsEnum = new DataSet();
	string sID = "";
	string sc = "SELECT id FROM enum WHERE class='" + sClass + "' AND name='" + sValue + "'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsEnum, "enum") == 1)
			sID = dsEnum.Tables["enum"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return sID;
}

string GetEnumOptions(string sClass, string current_id)
{
	return GetEnumOptions(sClass, current_id, false);
}
string GetEnumOptions(string sClass, string current_id, bool bNoBeforeOptions)
{
	return GetEnumOptions(sClass, current_id, bNoBeforeOptions, true);
}
//string GetEnumOptions(string sClass, string current_id)
string GetEnumOptions(string sClass, string current_id, bool bNoBeforeOptions, bool bShowEnumID)
{
	string sOut = "";
	DataSet dsEnum = new DataSet();
	string sc = "SELECT id, name FROM enum WHERE class='" + sClass + "'";
	if(!bShowEnumID)
		sc += " AND name <> 'deleted' ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsEnum, "enum");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	for(int i=0; i<dsEnum.Tables["enum"].Rows.Count; i++)
	{
		string id = dsEnum.Tables["enum"].Rows[i]["id"].ToString();
		string name = dsEnum.Tables["enum"].Rows[i]["name"].ToString();
		if(sClass == "access_level")
		{
			if(name == "administrator" || name == "dev") //no one can give out administrator access_level except ezsoft staff
			{
				if(Session["email"].ToString().IndexOf("@ezsoft.com") < 0)
					continue;
			}
		}
		if(bNoBeforeOptions)
			if(int.Parse(id) < int.Parse(current_id))
				continue;
		sOut += "<option value=";
		if(bShowEnumID)
			sOut += id;
		else
			sOut += name;
		if(id == current_id)
			sOut += " selected";
		sOut += ">" + Capital(name) + "</option>";
	}
	return sOut;
}

//code from : http://www.asp.net/Forums/ShowPost.aspx?tabindex=1&PostID=4377
string GenRandomString() 
{ 
	string password = ""; 
//	string passchar = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"; 
	string passchar = "abcdefghijklmnpqrstuvwxyz123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 

	int runs = 0;
	int digits = 0;
	while(digits < 2)
	{
		digits = 0;
		password = "";
		Byte[] ranbuff = new Byte[50]; 
		
		// gen a password 
		System.Security.Cryptography.RandomNumberGenerator rng = System.Security.Cryptography.RandomNumberGenerator.Create(); 
		rng.GetBytes(ranbuff); 
		int iLen = (ranbuff[0] % 4) + 8; // random length 8 to 12 chars 
		iLen = 8; //8 is enough, DW

		for (int iIndex = 1; iIndex <= iLen; iIndex++) 
		{ 
			int bNum = (int) ranbuff[iIndex+1]; 
			bNum %= passchar.Length; 
			char c = passchar[bNum];
			if(Char.IsDigit(c))
				digits++;
			password += passchar.Substring(bNum,1); 
		} 
		runs++;
		if(runs > 1000)
			break;
	}

//DEBUG("runs=", runs);

	return password; 
}

string GetRootPath()
{
//	return m_sRoot;

	string tspath = TSGetPath().ToLower();
	if(tspath.IndexOf(m_sCompanyName) == 0)
	{
		if(tspath.IndexOf(".") < 0)
			return "/" + m_sCompanyName;
	}
	return "";
}

bool GetCardID(string email, ref string id)
{
	DataSet dsu = new DataSet();
	string sc = "SELECT id FROM card WHERE email='" + email + "'";
	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft;" + m_sDataSource + m_sSecurityString);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(dsu);
		if(rows == 1)
			id = dsu.Tables[0].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string GetShipName(string id)
{
	DataSet dssn = new DataSet();
	string sc = "SELECT name FROM ship WHERE id=" + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dssn, "shipname") == 1)
			return dssn.Tables["shipname"].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	return "";
}

string GetCpusMBNeeds(string code)
{
	DataSet dscpus = new DataSet();
	string sc = "SELECT cpus FROM q_mb_cpus WHERE code=" + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dscpus) > 0)
			return dscpus.Tables[0].Rows[0]["cpus"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "1";
	}
	return "1"; //default 1 cpu
}

long MyLongParse(string s)
{
	Trim(ref s);
	if(s == null || s == "")
		return 0;

	long n = 0;
	try
	{
		n = long.Parse(s);
	}
	catch(Exception e)
	{
		ShowParseException(s);
	}
	return n;
}

int MyIntParse(string s)
{
	Trim(ref s);
	if(s == null || s == "")
		return 0;

	int n = 0;
	try
	{
		n = int.Parse(s);
	}
	catch(Exception e)
	{
		ShowParseException(s);
	}
	return n;
}

double MyDoubleParse(string s)
{
	Trim(ref s);
	if(s == null || s == "")
		return 0;

        Char[] c = s.ToCharArray();
        bool isCurrency = false;
        foreach (Char cc in c){
            if (cc == '$') {
                s = s.Replace("$" , "");
                isCurrency = true;
            }

            if(cc == '('){
                 s = s.Replace("(" , "-");
                 s = s.Replace(")" , "");
            }
        }


    
	double d = 0;
	try
	{
		//d = double.Parse(s);
        if (isCurrency)
        {
            d = double.Parse(s, NumberStyles.Currency, null);
        }
        else { 
            d = double.Parse(s);
        }
	}
	catch(Exception e)
	{
		ShowParseException(s);
	}
	return d;
}

bool MyBooleanParse(string s)
{
	Trim(ref s);
	if(s == null || s == "" || s == "0")
		return false;
	else if(s == "1")
		return true;
	else if(s == "on")
		return true;
	else if(s == "off")
		return false;

	bool b = false;
	try
	{
		b = Boolean.Parse(s);
	}
	catch(Exception e)
	{
		ShowParseException(s);
	}
	return b;
}

double MyMoneyParse(string s)
{
	Trim(ref s);
	if(s == null || s == "")
		return 0;

	double d = 0;
	try
	{
		d = double.Parse(s, NumberStyles.Currency, null);
	}
	catch(Exception e)
	{
		//ShowParseException(s);
        d = 0;
	}
	return d;
}

void ShowParseException(string s)
{
	string s1 = "<br><br><center><h3>Error, input string \"<font color=red>" + s + "</font>\" was not in a correct format</h3></center>";
	s1 += Environment.StackTrace;
	Response.Write(s1);
	s1 += Environment.StackTrace;
//	AlertAdmin(s1);
	Response.End();
}

string PrintCustomerOptions()
{
	return PrintCustomerOptions("", "");
}

string PrintCustomerOptions(string current_id, string uri)
{
	DataSet dssup = new DataSet();
	//string type_customer = GetEnumID("card_type", "supplier");
	int rows = 0;
	string sc = "SELECT id, short_name, name, email, company ";
	sc += " FROM card ";
	//sc += " WHERE type = 1 OR type = 2 ";
	sc += " ORDER BY company";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dssup, "customer");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string s = "\r\n<select name=customer";
	if(uri != "")
		s += " onchange=\"window.location=('" + uri + "'+this.options[this.selectedIndex].value)\"";
	s += "><option value=''>All Customer</option>";
	for(int i=0; i<rows; i++)
	{
		string id = dssup.Tables["customer"].Rows[i]["id"].ToString();
		string name = dssup.Tables["customer"].Rows[i]["name"].ToString();
		if(name == "")
			name = dssup.Tables["customer"].Rows[i]["company"].ToString();
		if(name == "")
			name = dssup.Tables["customer"].Rows[i]["short_name"].ToString();
		s += "<option value=" + dssup.Tables["customer"].Rows[i]["id"].ToString();
		if(current_id == id)
			s += " selected";
		s += ">" + name + "</option>\r\n";
	}
	s += "\r\n</select>";
	return s;
}

string PrintSupplierOptions()
{
	return PrintSupplierOptions("", "");
}

string PrintSupplierOptions(string current_id, string uri)
{
	return PrintSupplierOptions(current_id, uri, "supplier");
}

string PrintSupplierOptions(string current_id, string uri, string supplier_type)
{
	DataSet dssup = new DataSet();
	//string type_supplier = GetEnumID("card_type", "supplier");
	string type_supplier = GetEnumID("card_type", supplier_type);
	int rows = 0;
	string sc = "SELECT id, short_name, name, email, company ";
    if(supplier_type == ""){
        sc += " FROM card   ORDER BY company";
    }else{
        sc += " FROM card WHERE type=3 or type=" + type_supplier + " ORDER BY company";
    }
	
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dssup, "suppliers");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string s = "\r\n<select name=supplier";
	if(uri != ""){
        //s += " onchange=\"window.location=('" + uri + "'+this.options[this.selectedIndex].value)\"";
        s += " onclick='window.location=(\""+uri+"&search=1\")'";
    }
		
	s += "><option value=''>Please Select</option>";
	for(int i=0; i<rows; i++)
	{
		string id = dssup.Tables["suppliers"].Rows[i]["id"].ToString();
		string name = dssup.Tables["suppliers"].Rows[i]["company"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["name"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["short_name"].ToString();
		s += "<option value=" + dssup.Tables["suppliers"].Rows[i]["id"].ToString();
		if(current_id == id)
			s += " selected";
		s += ">" + name + "</option>\r\n";
	}
	s += "\r\n</select>";
	return s;
}


string PrintSupplierOptions(string current_id, string uri, bool type )
{
	DataSet dssup = new DataSet();
    string supplier_type = "supplier";
	//string type_supplier = GetEnumID("card_type", "supplier");
	string type_supplier = GetEnumID("card_type", supplier_type);
	int rows = 0;
	string sc = "SELECT id, short_name, name, email, company ";
    if(supplier_type == ""){
        sc += " FROM card   ORDER BY company";
    }else{
        sc += " FROM card WHERE type=3 or type=" + type_supplier + " ORDER BY company";
    }
	
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dssup, "suppliers");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string s = "\r\n<select name=supplier";
	if(uri != ""){
        s += " onchange=\"window.location=('" + uri + "'+this.options[this.selectedIndex].value)\"";
        //s += " onclick='window.location=(\""+uri+"&search=1\")'";
    }
		
	s += "><option value=''>Please Select</option>";
	for(int i=0; i<rows; i++)
	{
		string id = dssup.Tables["suppliers"].Rows[i]["id"].ToString();
		string name = dssup.Tables["suppliers"].Rows[i]["company"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["name"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["short_name"].ToString();
		s += "<option value=" + dssup.Tables["suppliers"].Rows[i]["id"].ToString();
		if(current_id == id)
			s += " selected";
		s += ">" + name + "</option>\r\n";
	}
	s += "\r\n</select>";
	return s;
}

string PrintSupplierOptionsWithShortName()
{
	DataSet dssup = new DataSet();
	string type_supplier = GetEnumID("card_type", "supplier");
	int rows = 0;
	string sc = "SELECT id, short_name, name, email, company ";
	sc += " FROM card WHERE type=" + type_supplier + " ORDER BY company ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dssup, "suppliers");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string s = "\r\n<select name=supplier>";
	for(int i=0; i<rows; i++)
	{
		string name = dssup.Tables["suppliers"].Rows[i]["company"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["name"].ToString();
		if(name == "")
			name = dssup.Tables["suppliers"].Rows[i]["short_name"].ToString();
		s += "<option value=" + dssup.Tables["suppliers"].Rows[i]["short_name"].ToString() + ">";
		s += name + "</option>\r\n";
	}
	s += "\r\n</select>";
	return s;
}

void MsgDie(string msg) //out put error msg and terminate script
{
	Response.Write("<br /><br /><center><h3>" + msg + "</h3></center></body></html>");
	Response.End();
}

void MsgDie(string msg, string extrScript) //out put error msg and terminate script
{
	Response.Write("<br /><br /><center><h3>" + msg + "</h3>");
    Response.Write(extrScript);
    Response.Write("</center></body></html>");
	Response.End();
}

//Get Next Available Product Code;
int GetNextCode()
{
	DataSet dst = new DataSet();
	int next_code = -1;
	//delete all data
	if(dst.Tables["code_relations"] != null)
		dst.Tables["code_relations"].Clear();

	int rows;
	string sc = "SELECT TOP 1 code FROM code_relations ORDER BY code DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "code_relations");
		if(rows > 0)
			next_code = int.Parse(dst.Tables["code_relations"].Rows[0]["code"].ToString()) + 1;
		else
			next_code = m_nFirstCode;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return next_code;
}

double GetFixedPriceForDealer(string code, string qty, string dealer_level, string card_id)
{
	if(code == null || code == "")
		return 99999999;

	DataSet dsgspfd = new DataSet();
	string sc = "SELECT c.* FROM product p JOIN code_relations c ON p.code=c.code WHERE c.code=" + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsgspfd, "price") <= 0)
		{
			sc = " SELECT name FROM code_relations WHERE code=" + code;
			try
			{
				myAdapter = new SqlDataAdapter(sc, myConnection);
				if(myAdapter.Fill(dsgspfd, "name") <= 0)
				{
					Response.Write("<br><br><h3>Error, product not found, code=" + code + "</h3>");
					return 9999991;
				}
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
			}
	
			Response.Write("<br><br><h3>Error, product discontinued, code=" + code + " : " + dsgspfd.Tables["name"].Rows[0]["name"].ToString() + "</h3>");
			return 9999992;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	
	DataRow dr = dsgspfd.Tables["price"].Rows[0];
	string price = dr["price" + dealer_level].ToString();
	return MyDoubleParse(price);
}

double GetSalesKitPriceForDealer(string kitCode, string qty, string dealer_level, string card_id){
   double dealerKitPrice = 0;
   double dealerKitPrice2 = 0;
   string kitItemCode = "";
   int kitItemQty = 0;
   
   //get kit item
   string sc = "SELECT * FROM [kit_item] where [id] = "+kitCode+"";
   DataSet dsgspfd = new DataSet();
   myAdapter = new SqlDataAdapter(sc, myConnection);
   int rows = myAdapter.Fill(dsgspfd, "kitItem");
   if( rows <= 0){
       dealerKitPrice = 0;
   }else{
      for(int i=0; i<rows; i++){
        DataRow dr = dsgspfd.Tables["kitItem"].Rows[i];
        kitItemQty = int.Parse(dr["qty"].ToString());
        for(int ii = 0; ii < kitItemQty; ii++){
            dealerKitPrice += GetSalesPriceForDealer(dr["code"].ToString(), "1", dealer_level, card_id);
        }
      }
   }


   sc = "SELECT * FROM kit where id = "+kitCode+"";
   dsgspfd = new DataSet();
   myAdapter = new SqlDataAdapter(sc, myConnection);
   rows = myAdapter.Fill(dsgspfd, "kitItem");
   if( rows <= 0){
      dealerKitPrice = 0;
   }else{
      for(int i=0; i<rows; i++){
        DataRow dr = dsgspfd.Tables["kitItem"].Rows[i];
        try{
            dealerKitPrice2 = double.Parse(dr["price"].ToString());
            break;
        }catch(Exception ex){

        }
      }
   }

    if(dealerKitPrice > dealerKitPrice2){
        dealerKitPrice = dealerKitPrice2;
    }

   return dealerKitPrice;
}


int GetDealerLevel(){
    int m_nDealerLevel = 1;
    string m_ssid = Request.QueryString["ssid"];
    if(!String.IsNullOrEmpty(m_ssid)){
        if(Session[m_sCompanyName + "dealer_level"] == null)
		    Session[m_sCompanyName + "dealer_level"] = "1";
	    if(TS_UserLoggedIn())
		    m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "dealer_level"].ToString());
        if(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid] != null)
	        m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString());
    }
    return m_nDealerLevel;
}


double GetSalesPriceForDealer(string code, string qty, string dealer_level, string card_id)
{
	bool bFixedPrices = false;
	if(MyBooleanParse(GetSiteSettings("use_fixed_level_prices", "0", true)))
		bFixedPrices = true;

	if(bFixedPrices)
		return GetFixedPriceForDealer(code, qty, dealer_level, card_id);

	bool bRoundPrice = false;
	if(Session["round_price_no_cent"] == null)
	{
		bRoundPrice = MyBooleanParse(GetSiteSettings("round_price_no_cent", "0", true));
		Session["round_price_no_cent"] = bRoundPrice;
	}
	else
		bRoundPrice = (bool)Session["round_price_no_cent"];

	if(code == null || code == "")
		return 99999999;

	DataSet dsgspfd = new DataSet();
	string sc = "SELECT p.price, c.*, c.manual_cost_nzd * c.rate + nzd_freight AS bottom_price FROM product p JOIN code_relations c ON p.code=c.code WHERE c.code=" + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsgspfd, "price") <= 0)
		{
			sc = " SELECT name FROM code_relations WHERE code=" + code;
			try
			{
				myAdapter = new SqlDataAdapter(sc, myConnection);
				if(myAdapter.Fill(dsgspfd, "name") <= 0)
				{
					//Response.Write("<br><br><h3>Error, product not found, code=" + code + "</h3>");
                    return GetSalesKitPriceForDealer(code, qty, dealer_level, card_id);
				}
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
			}
	
			Response.Write("<br><br><h3>Error, product discontinued, code=" + code + " : " + dsgspfd.Tables["name"].Rows[0]["name"].ToString() + "</h3>");
			return 9999994;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	
	DataRow dr = dsgspfd.Tables["price"].Rows[0];

	string brand = dr["brand"].ToString();
	string slcat = dr["cat"].ToString() + " - " + dr["s_cat"].ToString();
	dealer_level = GetDealerLevelForCat(card_id, brand, slcat, MyIntParse(dealer_level)).ToString();
//DEBUG("card=", card_id);
//DEBUG("level=", dealer_level);
	bool bClearance = bool.Parse(dr["clearance"].ToString());	

	int i = 0;
	string si = "";
	int[] qb = new int[9]; //qty breaks;
	double[] qbd = new double[9];
	double[] lr = new double[9];
	for(i=0; i<9; i++)
	{
		string ii = (i+1).ToString();
		si = dr["qty_break" + ii].ToString();
		if(si == "")
			qb[i] = 1000;
		else
			qb[i] = MyIntParse(si);
		
		si = dr["qty_break_discount" + ii].ToString();
		if(si == "")
			qbd[i] = 0;
		else
			qbd[i] = MyDoubleParse(si);

		si = dr["level_rate" + ii].ToString();
		if(si == "")
			lr[i] = 1.2;
		else
			lr[i] = MyDoubleParse(si);
	}
	
	double level_rate = lr[MyIntParse(dealer_level)-1];

//	double dPrice = double.Parse(dr["price"].ToString());
	double dPrice = MyDoubleParse(dr["bottom_price"].ToString());
	if(!bClearance)
		dPrice *= level_rate;

	double dPriceOnePiece = dPrice; //price without qty discount

	double dQtyDiscount = 1;
	double dDiscount = 0;

	bool bFixLevel6 = MyBooleanParse(GetSiteSettings("level_6_no_qty_discount", "0"));
	if(bFixLevel6 && dealer_level == "6")
	{
		if(bRoundPrice)
			dPrice = Math.Round(dPrice, 0);
		return dPrice;
	}
	int dqty = MyIntParse(qty);

	if(dqty > 1)
	{
		//get qty discount
		dQtyDiscount = GetQtyDiscount(dqty, qb, qbd);
		if(!bClearance)
		{
			dPrice *= (1 - dQtyDiscount);
			dDiscount = 1 - dQtyDiscount;
		}
	}
	if(bRoundPrice)
		dPrice = Math.Round(dPrice, 0);
	return dPrice;
}

double GetQtyDiscount(int qty, int[] qb, double[] qbd)
{
	int qbs = MyIntParse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
	if(qbs > 9)
		qbs = 9;
	for(int i=qbs-1; i>=0; i--)
	{
		if(qb[i] != 0 && qty >= qb[i])
			return qbd[i] / 100;
	}
	return 0;
}

double GetQuantityDiscount(int qty, int[] qb, double level_rate)
{
	double dd = 1;
	for(int i=3; i>=0; i--)
	{
		double margin = 0;
		int breaks = qb[i];
		if(qty >= breaks)
		{
			dd = 1 - (i+1) * (1 - 1/level_rate) / 4;
			break;
		}
	}
	return dd;
}

double GetLevelDiscount(string level)
{
	DataSet dsld = new DataSet();
	if(level == "")
		return 2;

	double dd = 2;
	int rows = 0;
	string sc = "SELECT * FROM discount WHERE factor='level' AND factor_id=" + level;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsld, "ld") == 1)
			dd = MyDoubleParse(dsld.Tables["ld"].Rows[0]["data1"].ToString());
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	return dd;
}

string GetDisplayQuoteNumber(string sNumber, string sType)
{
	int number = MyIntParse(sNumber);
	string absnumber = Math.Abs(number).ToString();
	string typestring = GetEnumValue("receipt_type", sType);
	if(typestring == "")
		return sNumber;

	string prefix = typestring[0].ToString().ToUpper();
	return prefix + absnumber;
}

string Capital(string s)
{
	if(s == "")
		return s;

	string sc = "";
	bool bCap = true; //cap the first one
	for(int i=0; i<s.Length; i++)
	{
		if(bCap)
		{
			sc += s[i].ToString().ToUpper();
			bCap = false;
		}
		else
			sc += s[i];

		if(s[i] == ' ')
			bCap = true;
	}
	return sc;
//	return s[0].ToString().ToUpper() + s.Substring(1, s.Length-1);
}

DataRow GetCardData(string id)
{
	Trim(ref id);
	if(id == null || id == "")
		return null;

	DataSet dsa = new DataSet();
	int rows = 0;
	string sc = "SELECT * FROM card WHERE id=" + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsa, "card") == 1)
			return dsa.Tables["card"].Rows[0];
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return null;
	}
	return null;
}

string GetAccessClassName(string id)
{
	if(dstcom.Tables["getclassname"] != null)
		dstcom.Tables["getclassname"].Clear();

	string sc = " SELECT name FROM menu_access_class WHERE id=" + id;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dstcom, "getclassname") == 1)
			return dstcom.Tables["getclassname"].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return id;
}

string GetAccessClassID(string name)
{
	if(dstcom.Tables["getclassid"] != null)
		dstcom.Tables["getclassid"].Clear();

	string sc = " SELECT id FROM menu_access_class WHERE name='" + name + "'";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dstcom, "getclassid") == 1)
			return dstcom.Tables["getclassid"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return name;
}

bool CheckAccess(string class_id, string uri)
{
	if(class_id == GetAccessClassID("Administrator"))
		return true;

	if(dstcom.Tables["checkaccess"] != null)
		dstcom.Tables["checkaccess"].Clear();

	string sc = "SELECT id ";
	sc += " FROM menu_admin_id ";
	sc += " WHERE uri LIKE '" + uri + "%' OR sisters LIKE '%" + uri + "%' ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dstcom, "checkaccess") <= 0) //if there's no record on available menus, then allow it
		{
			if(m_sSite == "www")
				return true;
			else if(m_sSite == "admin")
			{
				if(Session[m_sCompanyName + "AccessLevel"].ToString() != GetAccessClassID("no access"))
					return true;
			}
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}

	if(dstcom.Tables["checkaccess"] != null)
		dstcom.Tables["checkaccess"].Clear();

	sc = "SELECT a.id ";
	sc += " FROM menu_admin_access a JOIN menu_admin_id i ON i.id=a.menu ";
	sc += " WHERE (i.uri LIKE '" + uri + "%' OR sisters LIKE '%" + uri + "%') "; 
	sc += " AND a.class=" + class_id;
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dstcom, "checkaccess") >= 1)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	return false;
}

bool CheckAccess(string class_id)
{
	if(class_id == GetAccessClassID("Administrator"))
		return true;

	string uri = Request.ServerVariables["URL"];
	uri = uri.Substring(0, uri.IndexOf(".aspx") + 5); //strip off parameters
	int i = uri.Length-1;
	for(; i>=0; i--)
	{
		if(uri[i] == '/')
			break;
	}
	uri = uri.Substring(i+1, uri.Length - i - 1);
	return CheckAccess(class_id, uri);
}

bool SecurityCheck(string sLevel)
{
	if(sLevel == "normal")
	{
		if(!TS_UserLoggedIn())
		{
			RememberLastPage();
			Response.Redirect("login.aspx");
			return false;
		}
		else
		{
			return true;
		}
	}
	return SecurityCheck(sLevel, true);
}

bool SecurityCheck(string sLevel, bool bSayNo)
{
	if(!TS_UserLoggedIn())
	{
		if(!bSayNo)
			return false;
		RememberLastPage();
		Response.Redirect("login.aspx");
		return false;
	}

	if(CheckAccess(Session[m_sCompanyName + "AccessLevel"].ToString()))
	{
		return true;
	}
	else if(bSayNo)
	{
		Response.Write("<h3>ACCESS DENIED</h3>");
		Response.End();
	}
	return false;
/*
//	else if(Session["email"] != null && Session["email"].ToString() == "darcy@ezsoft.co.nz")
//	{
//		return true; // owner
//	}
	else //check site and rights
	{
		string key = m_sCompanyName + "AccessLevel";
		int nLevel = 1;
		if(Session[key] != null)
			nLevel = int.Parse(Session[key].ToString());
		
		string sRequired = GetEnumID("access_level", sLevel);
		int nRequired = int.Parse(sRequired);
//DEBUG("nReq=", nRequired);
//DEBUG("nLevel=", nLevel);
		if(nLevel >= nRequired)
			return true;
	}
	//for corportate
	if(m_supplierString != "")
	{
		if(Session["email"].ToString() == m_sSalesEmail)
			return true;
	}
	if(bSayNo)
	{
		Response.Write("<h3>ACCESS DENIED</h3>");
		Response.End();
	}
	return false;	
*/
}

string GetAccessClassOptions(string current_class)
{
	if(dstcom.Tables["getaccessclass"] != null)
		dstcom.Tables["getaccessclass"].Clear();
	string s = "";
	string sc = " SELECT * FROM menu_access_class ";
//	sc += " WHERE name NOT LIKE '%no access%' AND name NOT LIKE '%administrator%' ";
	sc += " ORDER BY id";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dstcom, "getaccessclass");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	
	for(int i=0; i<dstcom.Tables["getaccessclass"].Rows.Count; i++)
	{
		string id = dstcom.Tables["getaccessclass"].Rows[i]["id"].ToString();
		string name = dstcom.Tables["getaccessclass"].Rows[i]["name"].ToString();
//		if(name == "administrator" || name == "dev") //no one can give out administrator access_level except ezsoft staff
//		{
//			if(Session["email"].ToString().IndexOf("@ezsoft.com") < 0)
//				continue;
//		}
		s += "<option value=" + id;
		if(id == current_class)
			s += " selected";
		s += ">" + name + "</option>";
	}
	return s;
}

string GetCatAccessGroupString(string card_id)
{
	if(dstcom.Tables["cagroup"] != null)
		dstcom.Tables["cagroup"].Clear();

	string sc = " SELECT limit FROM view_limit v JOIN card c ON v.id=c.cat_access_group WHERE c.id=" + card_id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "cagroup") <= 0)
			return "";//no limit
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	return dstcom.Tables["cagroup"].Rows[0]["limit"].ToString();
}

string BuildCatAccess(string str)
{
	str = str.ToLower();
	Trim(ref str);
	if(str == "all" || str == "" || str == null)
		return null;

	string sRet = "";
	string word = "";
	string[] sa = new String[64];
	int j = 0;
	int i = 0;
	//get all key words
	for(; i<str.Length; i++)
	{
		if(i > 1024 || j > 63)
			break;

		if(str[i] != ',' && str[i] != ';')
		{
			word += str[i];
		}
		else
		{
			Trim(ref word);
			if(word != "" && word != "all")
			{
				sa[j++] = word;
				word = "";
			}
		}
	}
	if(word != "" && word != "all") //don't forget the last one
		sa[j++] = word;

	if(j <= 0)
		return null;
	//build search key

	if(sa[0] == "not")
	{
		sRet = " IN(";
		i = 1;
	}
	else
	{
		sRet = " NOT IN(";
		i = 0;
	}

	i = 0;
	for(; i<j; i++)
	{
		Trim(ref sa[i]);
		sRet += "'" + sa[i] + "'";
		if(i<j-1)
			sRet += ", ";
	}
	sRet += ") ";
//DEBUG("sRet=", sRet);
	return sRet;
}

string EncodeDoubleQuote(string s)
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == '\"')
			ss += '\"'; //double it
		if(s[i] == 8220 || s[i] == 8221) //chinese double quote
		{
//DEBUG("s=", (int)s[i]);
			ss += "\"\""; //add double quote
			continue; //skip this
		}

		ss += s[i];
	}
	return ss;
}

string AddRepairLogString(string action_desc, string invoice_number, string product_code, string repair_id, string sn, string rma_id)
{
	string sc = " INSERT INTO repair_log ";
	sc += " (log_time, staff, action_desc, code, invoice_number, repair_id, sn, rma_id) ";
	sc += " VALUES( ";
	sc += " GETDATE() ";
	sc += ", " + Session["card_id"].ToString();
	sc += ", '" + EncodeQuote(action_desc) + "' ";
	sc += ", '" + product_code + "', '" + invoice_number + "', '"+ repair_id +"' ";
	sc += " ,'" + EncodeQuote(sn) + "' ";
	sc += " ,'" + rma_id + "' ";
	sc += ") ";
	return sc;
}

string AddSerialLogString(string sn, string desc, string po_id, string invoice_number, 
			   string dealer_rma_id, string supplier_rma_id)
{
	string sc = " INSERT INTO serial_trace ";
	sc += " (sn, logtime, staff, action_desc, po_id, invoice_number, dealer_rma_id, supplier_rma_id) ";
	sc += " VALUES( ";
	sc += " '" + EncodeQuote(sn) + "' ";
	sc += ", GETDATE() ";
	sc += ", " + Session["card_id"].ToString();
	sc += ", '" + EncodeQuote(desc) + "' ";
	sc += ", '" + po_id + "', '" + invoice_number + "', '" + dealer_rma_id + "', '" + supplier_rma_id + "' ";
	sc += ") ";
	return sc;
}

string GetPoNumber(string po_id)
{
	if(dstcom.Tables["ponumber"] != null)
		dstcom.Tables["ponumber"].Clear();
	string sc = " SELECT po_number, inv_number FROM purchase WHERE id = " + po_id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "ponumber") == 1)
		{
			string pon = dstcom.Tables["ponumber"].Rows[0]["po_number"].ToString();
			string inv = dstcom.Tables["ponumber"].Rows[0]["inv_number"].ToString();
			pon = "<font color=blue>" + pon + "</font>";
			if(inv != "")
				pon += "<font color=red>(" + inv + ")</font>";
			return pon;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
	}
	return "Error";
}

string EncodeUserName()
{
	if(Session["name"] == null)
		return "";
	string uname = Session["name"].ToString();
	uname = uname.Replace(" ", "_");
	uname = uname.Replace("/", "_");
	uname = uname.Replace("\\", "_");
	return uname;
}

string GetCardValue(string sType, string sid)
{

	DataSet dsEnum = new DataSet();
	string sValue = "";
	string sc = "SELECT DISTINCT id, CONVERT(varchar(15),company) AS company FROM card WHERE type = "+ sType +" ";
	sc += " ORDER BY company ASC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsEnum, "supplier");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	for(int i=0; i<dsEnum.Tables["supplier"].Rows.Count; i++)
	{
		string id = dsEnum.Tables["supplier"].Rows[i]["id"].ToString();
		sType = dsEnum.Tables["supplier"].Rows[i]["company"].ToString();
		sValue += "<option value=" + id;
		if(id == sid)
			sValue += " selected ";
		sValue += ">" + sType + "</option>";
	}

	return sValue;
}


bool PrintPatentInfomation(string name)
{
	DataSet ds1 = new DataSet();
	string sc = " SELECT * FROM patent WHERE name = '" + name + "' ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(ds1, "patent") <= 0)
		{
			return true;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}

	DataRow dr = ds1.Tables["patent"].Rows[0];
	double dPrice = MyDoubleParse(dr["price"].ToString());

	Response.Write("<table align=center border=3 bgcolor=yellow>");
	Response.Write("<tr><td align=center>");
	Response.Write("<h3><font color=black size=+1><b>Patented Feature (" + dPrice.ToString("c") + ")</b></font>");
//	Response.Write("<h5>Cost : " + dPrice.ToString("c") + " + GST</h5>");
//	Response.Write("<h5><a href=patent.aspx class=o target=_blank><font color=blue><u>View Other Patented Features</u></font></a></h5>");
	Response.Write("</td></tr></table>");
	return true;
}

bool CheckSQLAttack(string str)
{
	if(str == null || str == "")
		return true;

	string s = str.ToLower();
	Trim(ref s);
	bool bUpdate = (s.IndexOf("update") >= 0);
	bool bDelete = (s.IndexOf("delete") >= 0);
	bool bDrop = (s.IndexOf("drop") >= 0);
	bool bCreate = (s.IndexOf("create") >= 0);
	bool bSelect = (s.IndexOf("select") >= 0);
	bool bQuote = (s.IndexOf("'") >= 0);
//	bool bSpace = (s.IndexOf(" ") >= 0);

	if(bUpdate || bDelete || bDrop || bCreate || bSelect || bQuote)
	{
		string manager_email = GetSiteSettings("manager_email", "alert@ezsoft.com");
		string ip = Request.ServerVariables["REMOTE_ADDR"]; //cache ip
		string rip = ""; //real ip
		if(Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
			rip = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
		else
			rip = ip;

		string sbody = "SQL Injection Attack detected and blocked. <br>";
		sbody += "ip : " + rip + "<br>";
		sbody += "user : " + Session["name"] + "<br>";
		sbody += "email : " + Session["email"] + "<br>";
		sbody += "Account# : " + Session["login_card_id"] + "<br>";
		sbody += "URI : " + Request.ServerVariables["URL"] + "<br>";
		sbody += "Parameter : " + str + "<br><br>";

/*		sbody += "This attack is potential, the attacker was trying take control of you database useing<br>";
		sbody += "a technic called 'SQL Injection Attack', which could issentially destory your database if succeeded.<br>";
		sbody += "<br>We strongly suggest that you investigate this accoun/person if account# or user name is showing.<br>";
		sbody += " Detailed log is available in database if evidence is needed to take legal action.<br>";

		sbody += "<br>ezsoft Team";
*/
		
		
//		msgMail.To = manager_email;
		string mTo = "alert@ezsoft.com";
		string mFrom = manager_email;
		string mSubject = "Warning, SQL Injection Attack !";

		
        SendEmail(mFrom, mFrom, mTo, mSubject,sbody);
		return false;
	}
	return true;
}

string ApplyColor(string s)
{
	if(dstcom.Tables["colorset"] != null)
		dstcom.Clear();

	string set_id = GetSiteSettings("color_set_in_use", "1");
//	if(Session["color_set"] != null)
//		set_id = Session["color_set"].ToString();

	string sc = " SELECT * FROM color_set WHERE id=" + set_id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "cs") <= 0)
			return s;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return s;
	}
	DataRow dr = dstcom.Tables["cs"].Rows[0];
//	m_name = dr["name"].ToString();
//	m_note = dr["note"].ToString();
	for(int i=20; i>=0; i--)
	{
		string sid = "@@color_" + i.ToString();
		string color = dr["c" + i.ToString()].ToString();
		if(color == "")
			continue;
		s = s.Replace(sid, color);
	}
	return s;
}


string StripHTMLtags(string s)
{
/******************************
provided by michael cox 13/11/03
********************************/
	string ss = "";
	bool remove = false;
	for(int i=0; i<s.Length; i++)
	{
		if(i >0)
			if(s[i-1] == '>')
				remove = false;
		if(s[i] == '<')
			remove = true;
		
		if(remove == false)
			ss += s[i];
		}
	return ss;
}

bool CreateBarcode(string sValue, string spath)
{

	//----------user private font to generate code39 barcode-------------------
	string sFontPath = Server.MapPath("./bar/BARCODE39.TTF");
//DEBUG("sfontpath =", sFontPath);
	// Create a private font collection
	PrivateFontCollection pfc = new PrivateFontCollection();

	// Load in the temporary barcode font
	pfc.AddFontFile(""+ sFontPath +"");

	// Select the font family to use
	FontFamily usefont = new FontFamily("code 39",pfc);

	//-------------end of using private font---------------------

	int n_ImgWidth = int.Parse(GetSiteSettings("barcode_width", "350"));
	int n_ImgHeight = int.Parse(GetSiteSettings("barcode_height", "160"));
		
	Bitmap b = new Bitmap(n_ImgWidth,n_ImgHeight,PixelFormat.Format32bppRgb);
	Graphics g = Graphics.FromImage(b);
	SolidBrush sb = new SolidBrush(Color.Black);
	SolidBrush sb2 = new SolidBrush(Color.Orange);
	//Font f = new Font(bfCode39,30);
	//Font myCode39 = new Font(""+ sFontPath +"", 30);
	Font myCode39 = new Font(usefont, 30);
	Font f2 = new Font("Verdana",10);
	Font f3 = new Font("Verdana", 12,FontStyle.Bold);
	Font f4 = new Font("Verdana", 12);
	//g.FillRectangle(new SolidBrush(Color.White),0,0,n_ImgWidth,n_ImgHeight);
	g.FillRectangle(new SolidBrush(Color.White),0,0,n_ImgWidth,n_ImgHeight);
	//g.DrawString(""+ name +"",f3,sb,5,3);
	g.DrawString("*"+ sValue +"*",myCode39,sb,(n_ImgWidth/2)-(n_ImgWidth/3),(n_ImgHeight/2)-30);
//	g.DrawString(""+ "",f2,sb,(n_ImgWidth/2)-(n_ImgWidth/4),(n_ImgHeight/2));
//	g.DrawString(""+ dPrice.ToString("c") +"(exc GST)",f4,sb,5,(n_ImgHeight/2)+30);
//	g.DrawString(""+ dPriceWithGST.ToString("c") +"(inc GST)",f4,sb,(n_ImgWidth/2)+10,(n_ImgHeight/2)+30);
	//Response.ContentType = "image/jpeg";
	//b.Save(Response.OutputStream, ImageFormat.Jpeg);
	//b.Save(Server.MapPath("./bar") +"\\"+ sValue +".bmp",ImageFormat.Bmp);
	b.Save(Server.MapPath(spath) +"\\"+ sValue +".gif",ImageFormat.Gif);
	//b.Save(Server.MapPath(spath) +"\\"+ sValue +".jpg",ImageFormat.Jpeg);
	g.Dispose();
	
	return true;

}

bool PrintBarcode(string sValue, string spath)
{
//	DEBUG("mcosl =", m_cols);
	string swidth = GetSiteSettings("barcode_width_percent", "25%");
	string sheight = GetSiteSettings("barcode_height_percent", "18%");
	string dest_path = Server.MapPath(spath);
	DirectoryInfo di = new DirectoryInfo(dest_path);
//DEBUG("sfile = ", dest_path);
//DEBUG(" scol  = ", scol);
//DEBUG(" fcol  = ", fcol);
	foreach (FileInfo f in di.GetFiles("*.gif")) 
	{
		string sfile = f.Name.ToString();
		sfile = sfile.Replace(".gif", "");
//DEBUG("sfile = ", sfile);
		int nSpace = int.Parse(GetSiteSettings("barcode_bt_space", "6"));
		
		if(sValue == sfile)
		{
			//string dest_file = dest_path + "\\" + f.Name;
			string dest_file = "./bar/" + f.Name;

			for(int j=0; j<nSpace; j++)
				Response.Write("&nbsp;");
			Response.Write("<img width="+ swidth +" height="+ sheight +" src='"+ dest_file +"'>");
	
		}
	}

	return true;
}

bool TS_UserLoggedIn()
{
	if(Session[m_sCompanyName + "loggedin"] != null)
		return true;
	return false;
}

void TS_LogUserIn()
{
	Session[m_sCompanyName + "loggedin"] = true;
}

int GetDealerLevelForCat(string card_id, string brand, string cat, int default_level)
{
	int nLevel = default_level;
	if(MyIntParse(card_id) <= 0)
		return nLevel;

	DataSet dsdl = new DataSet();
	string sc = "";
	if(brand != null && brand != "")
	{
		//brand levels overwrite categories
		sc = " SELECT level FROM dealer_levels WHERE card_id = " + card_id + " AND cat = '" + EncodeQuote("Brands - " + brand) + "' ";
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			if(myAdapter.Fill(dsdl) > 0)
			{
				nLevel = MyIntParse(dsdl.Tables[0].Rows[0]["level"].ToString());
			}
			else
			{
				sc = " SELECT level FROM dealer_levels WHERE card_id = " + card_id + " AND cat='" + EncodeQuote(cat) + "' ";
				try
				{
					myAdapter = new SqlDataAdapter(sc, myConnection);
					if(myAdapter.Fill(dsdl) > 0)
						nLevel = MyIntParse(dsdl.Tables[0].Rows[0]["level"].ToString());
				}
				catch(Exception e1) 
				{
					ShowExp(sc, e1);
				}
			}
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
		}
	}
	else
	{
		sc = " SELECT level FROM dealer_levels WHERE card_id = " + card_id + " AND cat='" + EncodeQuote(cat) + "' ";
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			if(myAdapter.Fill(dsdl) > 0)
				nLevel = MyIntParse(dsdl.Tables[0].Rows[0]["level"].ToString());
		}
		catch(Exception e1) 
		{
			ShowExp(sc, e1);
		}
	}
	return nLevel;
}

string PrintBranchOptions(string current_id)
{
	if(dstcom.Tables["branch"] != null)
		dstcom.Tables["branch"].Clear();

	int rows = 0;
	string s = "";
	string sc = " SELECT id, name FROM branch ORDER BY id ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstcom, "branch");
	}
	catch(Exception e1) 
	{
		ShowExp(sc, e1);
		return "";
	}

	s += "<select name=branch>";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dstcom.Tables["branch"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		s += "<option value=" + id;
		if(id == current_id)
			s += " selected";
		s += ">" + name + "</option>";
	}
	s += "</select>";
	return s;	
}

string PrintBranchOptionsOnly(string current_id)
{
	if(dstcom.Tables["branch"] != null)
		dstcom.Tables["branch"].Clear();

	int rows = 0;
	string s = "";
	string sc = " SELECT id, name FROM branch ORDER BY id ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstcom, "branch");
	}
	catch(Exception e1) 
	{
		ShowExp(sc, e1);
		return "";
	}

	s += "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dstcom.Tables["branch"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		s += "<option value=" + id;
		if(id == current_id)
			s += " selected";
		s += ">" + name + "</option>";
	}
	return s;	
}

string GetAccountClass(string id)
{
	DataSet dsname = new DataSet();
	string sc = " SELECT class1, class2, class3, class4 ";
	sc += " FROM account ";
	sc += " WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsname, "acc") == 1)
		{
			DataRow dr = dsname.Tables["acc"].Rows[0];
			return dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		}
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return "";
	}
	return "";
}

string GetAccountIDByClass(string sclass)
{
	if(sclass.Length < 4)
		return "0";

	string class1 = sclass.Substring(0, 1);
	string class2 = sclass.Substring(1, 1);
	string class3 = sclass.Substring(2, 1);
	string class4 = sclass.Substring(3, sclass.Length - 3);

	DataSet dsname = new DataSet();
	string sc = " SELECT id ";
	sc += " FROM account ";
	sc += " WHERE class1 = " + class1 + " AND class2 = " + class2 + " AND class3 = " + class3 + " AND class4 = " + class4;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsname, "acc") == 1)
		{
			DataRow dr = dsname.Tables["acc"].Rows[0];
			return dr["id"].ToString();
		}
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return "0";
	}
	return "0";
}

bool DoGetCountry(string country)
{
	DataSet dsname = new DataSet();
	string sc = " SELECT * FROM country_name ";
	sc += " WHERE country = '"+ country +"' ";
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsname, "nz");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows > 0)
	{
		for(int i=0; i<rows; i++)
		{
			Response.Write("<option value='"+ dsname.Tables["nz"].Rows[i]["city"] +"'");
			if(dsname.Tables["nz"].Rows[i]["city"].ToString() == "Auckland")
				Response.Write(" selected ");
			Response.Write(">"+ dsname.Tables["nz"].Rows[i]["city"] +"</option>");
		}
	}
	
	return true;
}
bool bSecurityAccess(string card_id)
{
	bool bAccessGranted = false;
	string sc = " SELECT * FROM card ";
	sc += " WHERE id = "+ Session["card_id"] +" ";
//DEBUG("sc=", sc);
	int rows = 0;
	int allow_level = int.Parse(GetSiteSettings("branch_access_level_allow", "6", true));
	int access_level = 1;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstcom, "access_level");
		
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows == 1)
	{
		access_level = int.Parse(dstcom.Tables["access_level"].Rows[0]["access_level"].ToString());
//		DEBUG("accesleve =", access_level);
//DEBUG("allow =", allow_level);
		if(access_level >= allow_level)
			bAccessGranted = true;
	}

	return bAccessGranted;
}

string doReturnAccountIDFromCodeRelations(string code, string accType)
{
	if(dstcom.Tables["accountID"] != null)
		dstcom.Tables["accountID"].Clear();
	string accID = "";
	string sc = " SELECT "+ accType +" FROM code_relations WHERE code = "+ code +"";
	int rows = 1;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstcom, "accountID");
		
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return accID;
	}
	if(rows == 1)
	{
		accID = dstcom.Tables["accountID"].Rows[0][accType].ToString();
	}
	return accID;
}



//read themes file and xml file
   string getFilePath(String name)
    {
        String filePath = "";
        XmlDocument xmlDoc = new XmlDocument();
        String path = Server.MapPath("~/themes/ThemeXML.xml");
        xmlDoc.Load(path);

        XmlNode xn = xmlDoc.SelectSingleNode("themesNo");

        XmlNodeList xnl = xn.ChildNodes;

        foreach (XmlNode xnf in xnl)
        {
            XmlElement xe = (XmlElement)xnf;
            if (xe.GetAttribute("name") == name)
            {
                XmlNodeList xnf1 = xe.ChildNodes;
                string common = "";
                string file = "";
                string cat = "";
                int i = 0;
                foreach (XmlNode xn2 in xnf1)
                {
                    if (i == 0)
                    {
                        common = xn2.InnerText;
                    }
                    else if (i == 1)
                    {
                        file = xn2.InnerText;
                        file = Server.MapPath("~/themes/" + file);
                    }
                    else if (i == 2)
                    {
                        cat = xn2.InnerText;
                    }
                    i++;
                }
                filePath = file;
                break;
            }
        }
        return filePath;
    }


    string readFile(String path)
    {
        FileStream aFile = new FileStream(path, FileMode.OpenOrCreate);
        byte[] bytes = new byte[aFile.Length];
        int numBytesToRead = (int)aFile.Length;
        int numBytesRead = 0;
        while (numBytesToRead > 0)
        {
            // Read may return anything from 0 to numBytesToRead.
            int n = aFile.Read(bytes, numBytesRead, numBytesToRead);

            // Break when the end of the file is reached.
            if (n == 0)
                break;
            numBytesRead += n;
            numBytesToRead -= n;
        }
        aFile.Close();
        return System.Text.Encoding.UTF8.GetString(bytes);
    }

    string getThemes(String name) {
        string themePath = getFilePath(name);
        if (themePath == "") {
            themePath = Server.MapPath("~/themes/" + name);
        }
        return readFile(themePath);
    }

public void SendEmail(String from, String fromTitle, String to, String subject, String body)
{
    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
    try
    {
        if(!IsEmail(to)){
            to = "sale@cyetek.co.nz";
            subject = "Email adress error"; 
        }
        if(!IsEmail(from)){
            to = "sale@cyetek.co.nz";
            subject = "Email adress error"; 
        }

        msg.To.Add(to);

        msg.From = new System.Net.Mail.MailAddress(from, fromTitle, System.Text.Encoding.UTF8);

        msg.Subject = subject;
        msg.SubjectEncoding = System.Text.Encoding.UTF8;
        msg.Body = body;
        msg.BodyEncoding = System.Text.Encoding.UTF8;
        msg.IsBodyHtml = true;
        msg.Priority = System.Net.Mail.MailPriority.High;

        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();

        object userState = msg;
    
        client.Send(msg);
    }
    catch (Exception ex)
    {
        Response.Write(ex.Message);
    }
}


public void SendEmail(String from, String fromTitle, String to, String subject, String body, System.Net.Mail.Attachment attach)
{
    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
    try
    {
        if(!IsEmail(to)){
            to = "sale@cyetek.co.nz";
            subject = "Email adress error"; 
        }
        if(!IsEmail(from)){
            to = "sale@cyetek.co.nz";
            subject = "Email adress error"; 
        }

        msg.To.Add(to);

        msg.From = new System.Net.Mail.MailAddress(from, fromTitle, System.Text.Encoding.UTF8);

        msg.Subject = subject;
        msg.SubjectEncoding = System.Text.Encoding.UTF8;
        msg.Body = body;
        msg.BodyEncoding = System.Text.Encoding.UTF8;
        msg.IsBodyHtml = true;
        msg.Priority = System.Net.Mail.MailPriority.High;
        if(attach != null){
             msg.Attachments.Add(attach);
        }
       
        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();

        object userState = msg;
    
        client.Send(msg);
    }
    catch (Exception ex)
    {
        Response.Write(ex.Message);
    }
}

public void markInvoiceEmailSend(string invoiceNo){
    string sc = "UPDATE invoice SET emailSend=1 where invoice_number="+invoiceNo;
//DEBUG("sc" , sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
}

public static bool IsEmail(string str_Email)  
    {  
        return System.Text.RegularExpressions.Regex.IsMatch(str_Email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");  
    }  

double CheckPriceIf99 (double tem){
    double returnValue = tem;
    //try{
    //    int indexx = tem.ToString().IndexOf(".");
    //    if(indexx > 0){
    //        string value = tem.ToString().Substring(indexx + 1, 2);
    //        string intValueString = tem.ToString().Substring(0, indexx);
    //        int intValue = int.Parse(intValueString);
    //        int t = int.Parse(value);
    //        int pointValue = 0;
    //        if(t > 97){
    //            pointValue = 0;
    //            intValue++;
    //        }else if(t > 98){
    //            pointValue = 0;
    //            intValue++;
    //        }else if(t == 1){
    //            pointValue = 0;
    //        }else{
    //            pointValue = t;
    //        }

    //        string newValueString = intValue.ToString() + "." + pointValue.ToString();
    //        double newValue = double.Parse(newValueString);
    //        returnValue = newValue;
    //    }
    //}catch(Exception){
    //    returnValue = tem;
    //}

    return returnValue;
}

int GetCatagoryShowLevel(string c, string s, string ss){
    int showLevel = 4;
    string sc = "select show_level from main_catalog where ";
    sc += " cat = '"+c+"'";
    if(s != ""){
        sc += " and s_cat = '"+s+"'";
    }else{
        sc += " and s_cat = 'zzzOthers'";
    }
    if(ss != ""){
         sc += " and ss_cat = '"+ss+"'";
    }else{
        sc += " and ss_cat = 'zzzOthers'";
    }
    DataSet ddss = new DataSet();

    try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(ddss, "ddss");

        if(rows > 0)
	    {
		    string show_level_string = ddss.Tables["ddss"].Rows[0]["show_level"].ToString();
            showLevel = int.Parse(show_level_string);
	    }
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
        showLevel = 4;
	}

    return showLevel;
}

bool ShowMenu(string c){
    //if(c == "ServiceItem"){
    //    return false;
    //}
    return ShowMenu(c, "", "");
}

bool ShowMenu(string c, string s){
    return ShowMenu(c, s, "");
}

bool ShowMenu(string c, string s, string ss){
    bool returnValue = false;
    if(s == ""){
        s = "zzzOthers";
    }
    if(ss == ""){
        ss = "zzzOthers";
    }
    int show_level = GetCatagoryShowLevel(c, s, ss);
    int userLevel = 0;
    if(Session["card_type"] != null){
        //if logined
        int.TryParse(Session["card_type"].ToString(), out userLevel);

        if(userLevel == 0){ //person.
            if(show_level == 1 || show_level == 3){
                returnValue = true;
            }
        }else if(userLevel == 1){ //customer
            if(show_level == 1 || show_level == 3){
                returnValue = true;
            }
        }else if(userLevel == 2){ //dealer
            if(show_level == 2 || show_level == 3){
                returnValue = true;
            }
        }else{// if other type of user show all like admin.
            returnValue = true;
        }
    }else{ //if nobody login
         if(show_level == 1 || show_level == 3){
             returnValue = true;
         }
    }
    return returnValue;
}

public string ShowShipingOption(string selectValue){
    string sc = "SELECT * FROM ship ORDER BY name";
    string value = "";
    DataSet dst = new DataSet();
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "shipcom");
        for(int i=0; i<dst.Tables["shipcom"].Rows.Count;i++)
	    {
		    DataRow dr = dst.Tables["shipcom"].Rows[i];
            if(selectValue == dr["id"].ToString()){
                value += "<option value='"+ dr["id"].ToString() +"' selected=selected>" + dr["name"].ToString() + "(" + dr["description"].ToString() + ")</option>";
            }else{
                value += "<option value='"+ dr["id"].ToString() +"'>" + dr["name"].ToString() + "(" + dr["description"].ToString() + ")</option>";
            }
		    
	    }

	}
	catch(Exception e) 
	{
		
	}
    return value;
}

public string ShowShipingOption(){
    string sc = "SELECT * FROM ship ORDER BY name";
    string value = "";
    DataSet dst = new DataSet();
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "shipcom");
        for(int i=0; i<dst.Tables["shipcom"].Rows.Count;i++)
	    {
		    DataRow dr = dst.Tables["shipcom"].Rows[i];
            value += "<option value='"+ dr["id"].ToString() +"'>" + dr["name"].ToString() + "(" + dr["description"].ToString() + ")</option>";
	    }

	}
	catch(Exception e) 
	{
		
	}
    return value;
}

public string GetShipCompany(string id){
    string sc = "SELECT * FROM ship where id="+id+" ORDER BY name";
    string value = "";
    DataSet dst = new DataSet();
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "shipcom");
        for(int i=0; i<dst.Tables["shipcom"].Rows.Count;i++)
	    {
		    DataRow dr = dst.Tables["shipcom"].Rows[i];
		    value += dr["name"].ToString() + "(" + dr["description"].ToString() + ")";
            break;
	    }

	}
	catch(Exception e) 
	{
		
	}
    return value;
}

    public DateTime DateTimeConvert(string value, char splitString)
    {
        DateTime dt = DateTime.Now;

        try
        {
            string[] v = value.Split(splitString);
            int day = int.Parse(v[0]);
            int month = int.Parse(v[1]);
            int year = int.Parse(v[2]);
            dt = new DateTime(year,month,day);
        }catch(Exception ex){

        }

        return dt;
    }


int GetStock(String code)
{

	if(dstcom.Tables["_stock"] != null)
		dstcom.Tables["_stock"].Clear();

    int rNumber = 0;
	
	string sc = "SELECT SUM(qty) stock FROM stock_qty ";
    sc += " where code = " + code;
//DEBUG("sc ++", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "_stock") == 1)
		{
			rNumber = int.Parse(dstcom.Tables["_stock"].Rows[0]["stock"].ToString()) ;
		}
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}

	return rNumber;
}

int GetStock(String code, String branchId)
{

	if(dstcom.Tables["_stock"] != null)
		dstcom.Tables["_stock"].Clear();

    int rNumber = 0;
	
	string sc = "SELECT SUM(qty) stock FROM stock_qty ";
    sc += " where code = " + code + " and branch_id = " + branchId;
//DEBUG("sc ++", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "_stock") == 1)
		{
			rNumber = int.Parse(dstcom.Tables["_stock"].Rows[0]["stock"].ToString()) ;
		}
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}

	return rNumber;
}


int GetAllocatedStock(String code)
{

	if(dstcom.Tables["_stock"] != null)
		dstcom.Tables["_stock"].Clear();

    int rNumber = 0;
	
	string sc = "SELECT SUM(allocated_stock) stock FROM stock_qty ";
    sc += " where code = " + code;
//DEBUG("sc ++", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "_stock") == 1)
		{
			rNumber = int.Parse(dstcom.Tables["_stock"].Rows[0]["stock"].ToString()) ;
		}
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}

	return rNumber;
}

int GetAllocatedStock(String code, String branchId)
{

	if(dstcom.Tables["_stock"] != null)
		dstcom.Tables["_stock"].Clear();

    int rNumber = 0;
	
	string sc = "SELECT SUM(allocated_stock) stock FROM stock_qty ";
    sc += " where code = " + code + " and branch_id = " + branchId;
//DEBUG("sc ++", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dstcom, "_stock") == 1)
		{
			rNumber = int.Parse(dstcom.Tables["_stock"].Rows[0]["stock"].ToString()) ;
		}
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}

	return rNumber;
}


</script>
