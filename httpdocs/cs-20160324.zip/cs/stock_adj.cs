<!-- #include file="fifo_f.cs" -->

<script runat=server>
DataSet dst = new DataSet();	//for creating Temp tables templated on an existing sql table

//
int m_page = 1;
int m_nPageSize = 30;
int m_nQtyReturn = 0;
int m_nIndexCount = 10;

bool b_Allbranches = false;

string cat = "";
string s_cat = "";
string ss_cat = "";
string m_branchid = "1";		//branch id, 21/03/03 herman
string m_id = "";
string m_qty = "";  //1=bigger than 0, 2=less than 0 and 0=0

bool m_bBarcode = false;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("sales"))
		return;

	if(Request.QueryString["t"] == "transfer")
	{
		if(Request.Form["cmd"] == "Transfer")
		{
			if(DoStockTransfer())
			{
				PrintAdminHeader();
				Response.Write("<br><center><h4>Stock transfered, please wait a second</h4>");
				Response.Write("<meta http-equiv=\"refresh\" content=\"1; URL=stock_adj.aspx?t=transfer&code=" + Request.QueryString["code"] + "\">");
				return;
			}
		}
		PrintTransferForm();
		return;
	}

	if(Session["branch_support"] != null)
	{
		if(Request.QueryString["b"] != null && Request.QueryString["b"] !="")
		{
			m_branchid = Request.QueryString["b"];
			if(m_branchid == "all")
				b_Allbranches = true;
		}
		else if(Session["branch_id"] != null)
		{
			m_branchid = Session["branch_id"].ToString();
		}
	}
	string bar = GetSiteSettings("use_barcode", "false", true);
	
	if(bar.ToLower() != "true" && bar.ToLower() != "false")
		m_bBarcode = false;
	else
		m_bBarcode = bool.Parse(bar);

	if(Request.QueryString["page"] != null)
	{
		if(IsInteger(Request.QueryString["page"]))
			m_page = int.Parse(Request.QueryString["page"]);
	}

	if(Request.QueryString["cat"] != null && Request.QueryString["cat"] != "")
		cat = Request.QueryString["cat"];
	if(Request.QueryString["scat"] != null && Request.QueryString["scat"] != "")
		s_cat = Request.QueryString["scat"];
	if(Request.QueryString["sscat"] != null && Request.QueryString["sscat"] != "")
		ss_cat = Request.QueryString["sscat"];

	if(Request.QueryString["qty"] != null && Request.QueryString["qty"] != "")
		m_qty = Request.QueryString["qty"];
	
	Trim(ref cat);
	Trim(ref s_cat);
	Trim(ref ss_cat);

	if(Request.QueryString["allocode"] != null && Request.QueryString["allocode"] != "")
	{
		string code = Request.QueryString["allocode"].ToString();
		if(!doCleanAlloCode(code))
			return;
//		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=stock_adj.aspx");
//		Response.Write("?cat=" + HttpUtility.UrlEncode(cat));
//		Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
//		Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
//		Response.Write("&page=" + m_page + " \">");
//		return;
	}

	if(Request.Form["cmd"] == "Update Adjustment" || Request.Form["txtQty"] != null)
	{
		if(DoUpdate())
		{
            Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=stock_adj.aspx");
            Response.Write("?cat=" + HttpUtility.UrlEncode(cat));
            Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
            Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
            if(m_qty != "")
                Response.Write("&qty="+ m_qty);
            Response.Write("&page=" + m_page + " \">");
			
			return;
		}
	}
	
	PrintAdminHeader();
	PrintAdminMenu();

	if(!GetStockQty())
		return;
		
	BindStockQty();	
	LFooter.Text = m_sAdminFooter;
}

// clean allocated stock in product table by set to 0 : tee?8-4-3
// need recalculate each branch's allocated (in stock_qty table). darcy 08-03-2004
bool doCleanAlloCode(string code)
{
	double allocated = 0;
	string sc = "";

	//update allocated total
	//branches
	int nBranch = 1;
	sc = " SELECT id FROM branch ORDER BY id ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		nBranch = myCommand.Fill(dst, "nbranch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	double dTotalAllocated = 0;
	for(int i=0; i<nBranch; i++)
	{
		string branchid = dst.Tables["nbranch"].Rows[i]["id"].ToString();

		allocated = 0;
		if(dst.Tables["get_allocated"] != null)
			dst.Tables["get_allocated"].Clear();

		string s = " SELECT SUM(i.quantity) AS allocated ";
		s += " FROM order_item i JOIN orders o ON o.id = i.id ";
		s += " WHERE i.code = " + code;
		s += " AND o.status IN(1, 4, 5) "; 
		s += " AND o.branch = " + m_branchid;
		try
		{
			SqlDataAdapter myCommand = new SqlDataAdapter(s, myConnection);
			myCommand.Fill(dst, "get_allocated");
			string ret = dst.Tables["get_allocated"].Rows[0]["allocated"].ToString();
			if(ret != "")
				allocated = MyDoubleParse(ret);
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}

		dTotalAllocated += allocated;
		
		//stock_qty for each branch's allocated and real stock
		sc += " UPDATE stock_qty ";
		sc += " SET allocated_stock = " + allocated;
		sc += " WHERE code = " + code + " AND branch_id = " + m_branchid + " ";
	}

	//allocated total in product table
	sc += " UPDATE product ";
	sc += " SET allocated_stock = " + dTotalAllocated;
	sc += " WHERE code = "+ code +" ";

	if(sc != "")
	{
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

bool DoUpdate()
{
	int i = (m_page-1) * m_nPageSize;
	string code = Request.Form["code"+i];
	while(code != null)
	{
		if(!UpdateOneRow(i.ToString()))
			return false;
		i++;
		code = Request.Form["code"+i];
	}
	return true;
}

Boolean UpdateOneRow(string sRow)
{
	Boolean bRet = true;

	string code		= Request.Form["code"+sRow];
	string qty_new = Request.Form["txtQty"+sRow];
	string qty_old = Request.Form["qty_old"+sRow];
	string allocated = Request.Form["allocated" + sRow];
	string allocated_old = Request.Form["allocated_old" + sRow];
	string branch = Request.Form["branch_id"+sRow];
	if(branch == null || branch == "")
		branch = "1";

	if(qty_new == qty_old && allocated == allocated_old)
		return true;

	string note = Request.Form["note"];

	int adj = MyIntParse(qty_new) - MyIntParse(qty_old);
	if(m_branchid == null || m_branchid == "" || m_branchid == "all")
		m_branchid = "1";
	string sc = "BEGIN TRANSACTION ";
	if(qty_new != qty_old)
	{
		sc += " INSERT INTO stock_adj_log (staff, code, qty, branch_id, note) VALUES(" + Session["card_id"].ToString();
		sc += ", " + code + ", " + adj + ", " + branch + ", '" + EncodeQuote(note) + "') "; 
//		if(g_bRetailVersion)
		{
			sc += " IF EXISTS(SELECT * FROM stock_qty WHERE code=" + code + ") ";
			sc += " UPDATE stock_qty SET qty=" + qty_new + " WHERE code=" + code + " AND branch_id = " + branch;
			sc += " ELSE ";
			sc += " INSERT INTO stock_qty (code, qty, branch_id) VALUES(" + code + ", " + qty_new + ", " + branch + ") ";
		}
//		else
//		{
//			sc += " UPDATE product SET stock=" + qty_new + " WHERE code=" + code;
//		}
	}
	if(allocated != allocated_old)
	{
		sc += " UPDATE product SET allocated_stock = " + allocated + " , stock = "+qty_new+" WHERE code=" + code; //all branch's alocated
		sc += " UPDATE stock_qty SET allocated_stock = " + allocated + " WHERE code=" + code; //this branch's allocated
		sc += " AND branch_id = " + branch;
	}

	sc += " SELECT IDENT_CURRENT('stock_adj_log') AS id ";
	sc += " COMMIT ";

	if(sc == "")
		return true;
	DataSet dsid = new DataSet();
	string new_id = "";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dsid, "id") != 1)
		{
			Response.Write("<br><center><h3>Error getting new record ID");
			return false;
		}
		new_id = dsid.Tables["id"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	fifo_RecordStockLoss(code, m_branchid, (0 - adj), new_id);
	return true;
}

bool GetStockQty()
{
	string kw = "";
	if(Request.Form["kw"] != null)
	{
		kw = Request.Form["kw"];
		Session["stock_adj_search"] = kw;
	}
	kw = EncodeQuote(kw);

	bool bWhereAdded = false;
	string sc = "SELECT DISTINCT p.code, p.supplier, p.supplier_code, p.name ";
//	if(g_bRetailVersion)
		sc += ", sq.qty AS stock, sq.allocated_stock, sq.branch_id ";
//	else
//		sc += ", p.stock, p.allocated_stock, '1' AS branch_id ";
	sc += ", l.code AS adjusted";
	if(Session["branch_support"] != null)
		sc += ", b.name AS branch_name ";
	sc += " FROM product p LEFT OUTER JOIN stock_adj_log l ON l.code=p.code ";
//	if(g_bRetailVersion)
		sc += " LEFT OUTER JOIN stock_qty sq ON p.code=sq.code";
	if(Session["branch_support"] != null)
		sc += " LEFT OUTER JOIN branch b ON b.id = sq.branch_id ";
	sc += " WHERE 1=1 ";
	if(cat != "" && cat != "all")
		sc += " AND p.cat = '"+ cat +"' ";
	if(s_cat != "" && s_cat != "all")
		sc += " AND p.s_cat = '"+ s_cat +"' ";
	if(ss_cat != "" && ss_cat != "all")
		sc += " AND p.ss_cat = '"+ ss_cat +"' ";
	if(kw != "")
	{
		if(IsInteger(kw))
			sc += " AND p.code = " + kw;
		else
			sc += " AND (p.supplier_code LIKE '%" + kw + "%' OR p.name LIKE '%" + kw + "%') ";
	}

	if(Session["branch_support"] != null)
	{
		if(!b_Allbranches)// && g_bRetailVersion)
		{
			/*if(bWhereAdded)
				sc += " AND ";
			else 
				sc += " WHERE ";
			sc += " sq.branch_id=" + m_branchid;
			*/
			sc += " AND sq.branch_id=" + m_branchid;
		}
	}
	if(m_qty != "")
	{		
		if(TSIsDigit(m_qty))
		{
			sc += " AND ";
//			if(g_bRetailVersion)
			{
				if(m_qty == "0")
					sc += " sq.qty = 0 ";
				if(m_qty == "1")
					sc += " sq.qty > 0 ";
				if(m_qty == "2")
					sc += " sq.qty < 0 ";				
			}
/*			else
			{
				if(m_qty == "0")
					sc += " p.stock = 0 ";
				if(m_qty == "1")
					sc += " p.stock > 0 ";
				if(m_qty == "2")
					sc += " p.stock < 0 ";				
			}
			*/
		}
	}
	sc += " ORDER BY p.name ";	
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_nQtyReturn = myAdapter.Fill(dst, "stock_qty");

	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;

}

void BindStockQty()
{
	Response.Write("<script Language=javascript");
	Response.Write(">");
	Response.Write("<!-- hide from older browser");
	const string jav = @"
	function checkform() 
	{	
		if(document.frmQtyAdjust.txtQty.value==''){
			window.alert('Please enter Invoice Number');
			document.frmQtyAdjust.txtQty.focus();
			return false;
		}
		
		if (!IsNumberic(document.frmQtyAdjust.txtQty.value)) { 
			  window.alert('Please enter only numbers in the invoice number field'); 
			  document.frmQtyAdjust.txtQty.focus();
			  return false; 
		}

	}	
	
	function IsNumberic(sText)
	{
	   var ValidChars = '0123456789-';
	   var IsNumber=true;
	   var Char;
 	   for (i = 0; i < sText.length && IsNumber == true; i++) 
	   { 
		  Char = sText.charAt(i); 
		  if (ValidChars.indexOf(Char) == -1) 
		  {
			 IsNumber = false;
		  }
	   }
		   return IsNumber;
	}

	";
	Response.Write("--> "); 
	Response.Write(jav);
	Response.Write("</script");
	Response.Write("> ");
	Response.Write("<form name=frmQtyAdjust method=post action=stock_adj.aspx?update=success&b=all");
	if(cat != "")
		Response.Write("&cat=" + HttpUtility.UrlEncode(cat));
	if(s_cat != "")
		Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
	if(ss_cat != "")
		Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
	if(m_qty != "")
		Response.Write("&qty="+ m_qty +"");
	Response.Write("&page=" + m_page);
	Response.Write(">");
	
	Response.Write("<center><h3>Stock Taking and Adjustment</h3>");
	Response.Write("<table width=98% cellspacing=0 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	
	Response.Write("<tr><td colspan=10><table border=0 cellpadding=0 width=95%><tr><td>");
	Response.Write("<b>Quick Search : </b></td><td><input type=text name=kw value='" + Session["stock_adj_search"] + "'>");
	Response.Write("<input type=submit name=cmd value=Search class=searchButton2>");
	Response.Write("</td></tr>");
	
	
	//branch option
//	if(!(Request.QueryString["update"] != null && Request.QueryString["update"] != ""))
	Response.Write("<tr>");
	if(Session["branch_support"] != null)
	{
		Response.Write("<td><b>Branch :</b></td><td align=left>");
		PrintBranchNameOptionsWithOnChange();
		Response.Write("</td>");
	}
	else
		Response.Write("<td colspan=2>&nbsp;</td>");

	Response.Write("<td align=right colspan=3>");
	string suri = Request.ServerVariables["URL"] +"?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
	if(cat != "")
		suri += "&cat=" + HttpUtility.UrlEncode(cat) +"";
	if(s_cat != "")
		suri += "&scat=" + HttpUtility.UrlEncode(s_cat) +"";
	if(ss_cat != "")
		suri += "&sscat=" + HttpUtility.UrlEncode(ss_cat) +"";
	Response.Write("Filter With: <input type=button title=' Filter with QTY Greater than 0 ' value=' > ' class=stokrButton onclick=\"window.location=('"+ suri +"&qty=1");
	if(m_branchid != "")
		Response.Write("&b="+ m_branchid +"");
	Response.Write("');\" >");
	Response.Write("<input type=button title=' Filter with QTY = 0 ' value=' 0 ' class=zeroButton onclick=\"window.location=('"+ suri +"&qty=0");
	if(m_branchid != "")
		Response.Write("&b="+ m_branchid +"");
	Response.Write("');\" >");
	Response.Write("<input type=button title=' Filter with QTY Less than 0 ' value=' < ' class=stoklButton onclick=\"window.location=('"+ suri +"&qty=2");
	if(m_branchid != "")
		Response.Write("&b="+ m_branchid +"");
	Response.Write("');\" >");
	Response.Write("<input type=button title=' Show ALL QTY ' value=' All ' class=allButton onclick=\"window.location=('"+ suri +"");
	if(m_branchid != "")
		Response.Write("&b="+ m_branchid +"");
	Response.Write("');\" >");
	Response.Write("&nbsp;&nbsp;|&nbsp;&nbsp;");

	if(!DoItemOption())
		return;
	Response.Write("</tr>");

	Response.Write("</table></td></tr>");

	Response.Write("<tr class=tableHeader>");
	Response.Write("<th align=center>CODE#</th>");
	Response.Write("<th align=center nowrap>M_PN/STOCK TRACE</th>");
	Response.Write("<th>ITEM DESC</th>");
	if(Session["branch_support"] != null)
	{
//		if(Request.QueryString["update"] != null && Request.QueryString["update"] != "")
			Response.Write("<th align=left width=80px>BRANCH</th>");
	}
	else
		Response.Write("<th>&nbsp;</th>");
	Response.Write("<th colspan=2 align=center width=150px>QTY</th>");
	Response.Write("<th>ALLOCATED</th>");
	Response.Write("<th align=right>NEW QTY</th> "); //<td align=center>Adjustment</td></tr>");
	Response.Write("<th align=right>CORRECT ALLOCATED STOCK</th>");
	if(m_bBarcode)
		Response.Write("<th>PRINT BARCODE</th>");
	Response.Write("</tr>");

	bool bAlt = true;
	string s = "";
	DataRow dr;
	Boolean alterColor = true;
	int startPage = (m_page-1) * m_nPageSize;
//DEBUG("p=", startPage);
	for(int i=startPage; i<dst.Tables["stock_qty"].Rows.Count; i++)
	{
		
		//Response.Write("<form name=frmQtyAdjust method=post action='stock_adj.aspx?update=success'>");
		if(i-startPage >= m_nPageSize)
			break;
		dr = dst.Tables["stock_qty"].Rows[i];
		alterColor = !alterColor;
		if(!DrawRow(dr, i, alterColor))
			break;
	}
		
	PrintPageIndex();
	
	Response.Write("</table>");
	Response.Write("</form></center>");


}

bool PrintBranchNameOptionsWithOnChange()	//Herman: 21/03/03
{
	DataSet dsBranch = new DataSet();
	string sBranchID = "1";
	int rows = 0;
	if(Request.QueryString["b"] != null && Request.QueryString["b"] != "")
	{
		sBranchID = Request.QueryString["b"];
		if(sBranchID != "all")
			Session["branch_id"] = MyIntParse(sBranchID); //Session["branch_id"] is integer
	}
	else if(Session["branch_id"] != null)
	{
		sBranchID = Session["branch_id"].ToString();
	}

	//do search
	string sc = "SELECT id, name FROM branch ORDER BY id";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dsBranch, "branch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=branch");
	Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"]);
	Response.Write("?b=' + this.options[this.selectedIndex].value)\"");
	Response.Write(">");
	for(int i=0; i<rows; i++)
	{
		string bname = dsBranch.Tables["branch"].Rows[i]["name"].ToString();
		int bid = int.Parse(dsBranch.Tables["branch"].Rows[i]["id"].ToString());
		Response.Write("<option value='" + bid + "' ");
		if(IsInteger(sBranchID))
		{
			if(bid == int.Parse(sBranchID))
				Response.Write("selected");
		}
		Response.Write(">" + bname + "</option>");
	}
//	int iNumBranches = dsBranch.Tables["branch"].Rows.Count + 1;
	Response.Write("<option value='all'");
	if(!IsInteger(m_branchid))
	{
		Response.Write("selected");
		b_Allbranches = true;	
	}
	Response.Write("> All Branches</option>");

	if(rows == 0)
		Response.Write("<option value=1>Branch 1</option>");
	Response.Write("</select>");
	return true;
}

bool DoItemOption()
{
	int rows = 0;
	string sc = "SELECT DISTINCT cat FROM product ";
	sc += " ORDER BY cat";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "cat");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows <= 0)
		return true;
	Response.Write("Catalog Select: <select name=s ");
	Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"]);
	Response.Write("?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"");
	if(m_qty != "")
		Response.Write("&qty="+ m_qty +"");
	Response.Write("&cat=' + this.options[this.selectedIndex].value)\"");
	
	Response.Write(">");
	Response.Write("<option value='all'>Show All</option>");
	if(Request.QueryString["cat"] != null)
		cat = Request.QueryString["cat"].ToString();
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["cat"].Rows[i];
		string s = dr["cat"].ToString();
		Trim(ref s);
		if(cat == s)
			Response.Write("<option value='"+s+"' selected>" +s+ "");
		else
			Response.Write("<option value='"+s+"'>" +s+ "");

	}

	Response.Write("</select>");
	
	if(cat != "")
	{
		cat = Request.QueryString["cat"].ToString();
	
		sc = "SELECT DISTINCT s_cat FROM product ";
		sc += " WHERE cat = '"+ cat +"' ";
		sc += " ORDER BY s_cat";
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			rows = myAdapter.Fill(dst, "s_cat");
	//DEBUG("rows=", rows);
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
		
		if(rows <= 0)
			return true;
		Response.Write("<select name=s ");
		Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"]);
		Response.Write("?cat=" + HttpUtility.UrlEncode(cat));
		if(m_qty != "")
		Response.Write("&qty="+ m_qty +"");
		Response.Write("&scat=' + this.options[this.selectedIndex].value)\"");
		Response.Write(">");
		Response.Write("<option value='all'>Show All</option>");
		for(int i=0; i<rows; i++)
		{
			DataRow dr = dst.Tables["s_cat"].Rows[i];
			string s = dr["s_cat"].ToString();
			Trim(ref s);
			if(s_cat == s)
				Response.Write("<option value='"+s+"' selected>" +s+ "");
			else
				Response.Write("<option value='"+s+"'>" +s+ "");
			
		}

		Response.Write("</select>");
	}

	
	if(s_cat != "")
	{
		cat = Request.QueryString["cat"].ToString();
		sc = "SELECT DISTINCT ss_cat FROM product ";
		sc += " WHERE cat = '"+ cat +"' ";
		sc += " AND s_cat = '"+ s_cat +"' ";
		sc += " ORDER BY ss_cat";
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			rows = myAdapter.Fill(dst, "ss_cat");
	//DEBUG("rows=", rows);
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
		
		if(rows <= 0)
			return true;
		Response.Write("<select name=s ");
		Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"]);
		Response.Write("?cat=" + HttpUtility.UrlEncode(cat));
		if(m_qty != "")
		Response.Write("&qty="+ m_qty +"");
		Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
		Response.Write("&sscat=' + this.options[this.selectedIndex].value)\"");
		
		Response.Write(">");
		Response.Write("<option value='all'>Show All</option>");
		for(int i=0; i<rows; i++)
		{
			DataRow dr = dst.Tables["ss_cat"].Rows[i];
			string s = dr["ss_cat"].ToString();
			Trim(ref s);
			if(ss_cat == s)
				Response.Write("<option value='"+s+"' selected>"+s+"");
			else
				Response.Write("<option value='"+s+"'>"+s+"");
		}

		Response.Write("</select>");
	}

	return true;
}

bool DrawRow(DataRow dr, int i, bool alterColor)
{
	string adjusted = dr["adjusted"].ToString(); //if not blank then this product has been adjusted stock
	
	string s_qty = dr["stock"].ToString();
	string code = dr["code"].ToString();
	string supplier = dr["supplier"].ToString();
	string supplier_code = dr["supplier_code"].ToString();
	string s_productdesc = dr["name"].ToString();
	string swap = "";
	if(s_productdesc.Length >=60)
	{
		for(int j=0; j<60; j++)
			swap += s_productdesc[j].ToString();
	}
	else
		swap = s_productdesc;

	s_productdesc = swap;

	Response.Write("<tr");
	if(alterColor)
		Response.Write(" class=rowColor");
	Response.Write(">");

	Response.Write("<td align= nowrap>");
	Response.Write("<table border=0><tr><td width=80% align=left><a title='click here to view Sales Ref:' href='salesref.aspx?code=" + code +"'  target=_new><font class=linkButton>");
	Response.Write(code);
	Response.Write("</font></a>&nbsp;<a title='click here to edit item:' href='liveedit.aspx?code=" + code +"' class=o target=_new><font class=linkButton>Edit</font></a>");
	
	Response.Write("</a> </td><td>");
//	if(CheckPatent("viewsales"))
	{
		Response.Write("<input type=button title='View Sales History' onclick=\"javascript:viewsales_window=window.open('viewsales.aspx?");
		Response.Write("code=" + code + "','');\" value='S' class=sButton>");
	}
	Response.Write("</td>\r\n");
	Response.Write("</tr></table></td>");
	Response.Write("<td align=left>" + supplier_code + "</td>");
	Response.Write("<td> "+ StripHTMLtags(s_productdesc) +"</td>");
	
	if(Session["branch_support"] != null)
	{
//		if(Request.QueryString["update"] != null && Request.QueryString["update"] != "")
		{
			string s_branchName = dr["branch_name"].ToString();
			Response.Write("<td align=left>" + s_branchName + "</td>");	
			Response.Write("<input type=hidden name=branch_id" + i + " value='" + dr["branch_id"].ToString() + "'>");
		}
	}
	else
		Response.Write("<td>&nbsp;</td>");
	Response.Write("<input type=hidden name=code" + i + " value='" + code + "'>");
	Response.Write("<td nowrap>");
	Response.Write("<font color=");
	if(MyDoubleParse(s_qty) == 0)
		Response.Write("Green>");
	else if(MyDoubleParse(s_qty) < 0)
		Response.Write("Red>");
	else if(MyDoubleParse(s_qty) > 0)
		Response.Write("Black>");

	Response.Write(s_qty);
	Response.Write(" </td><td ><a href=stocktrace.aspx?p=0&c=" + code + " class=linkButton title='Trace'>Trace</a> ");
	
	Response.Write("<input type=button title='View Purchase & Sales Total' ");
	Response.Write(" onclick=\"javascript:viewsales_window=window.open('stock_ana.aspx?");
	Response.Write("c=" + code + "','');\" value='A' class=aButton>");
	Response.Write("<input type=button value=T title='Transfer' class=tButton onclick=window.location=('stock_adj.aspx?t=transfer&code=" + code + "') >");
	
	if(adjusted != "")
	{
		Response.Write(" <a href=vd.aspx?t=adjlog&code=" + code + " class=linkButton target=_blank title='Adjustment Log'>Adj. Log</a>");
	}
	Response.Write("</font></td>");

	int nAllocated = MyIntParse(dr["allocated_stock"].ToString());
	Response.Write("<td align=right>");
	Response.Write("<input type=text name=allocated" + i + " size=5 style=text-align:right; value=" + nAllocated + "></td>");
	Response.Write("<input type=hidden name=allocated_old" + i + " value=" + nAllocated + "></td>");
	Response.Write("<td align=right>");
	Response.Write("<input type=text name=txtQty" + i + " size=5 style=text-align:right; value='"+s_qty+"' ></td>");
	Response.Write("<input type=hidden name=qty_old" + i + " value='"+s_qty+"' >");
	Response.Write("<th align=right>");

	string uri = "&cat=" + HttpUtility.UrlEncode(cat);
	uri += "&scat=" + HttpUtility.UrlEncode(s_cat);
	uri += "&sscat=" + HttpUtility.UrlEncode(ss_cat);
	uri += "&page=" + m_page;

	Response.Write("<a title='clean up allocated stock quantity' href=stock_adj.aspx?allocode="+ code + uri);
	Response.Write(" class=linkButton>Recalculate</a>");
	Response.Write("</th>");
	if(m_bBarcode)
	{
	Response.Write("<th>");
	int nQty = int.Parse(GetSiteSettings("barcode_qty", "30"));

	Response.Write("<select name=qty"+ i +">");
	for(int j=1; j<=nQty; j++)
		Response.Write("<option value="+ j +">"+ j +"</option>");
	Response.Write("</select>" );
	string bc_uri = "barcode.aspx?code="+ code +"&qty="; //document.frmQtyAdjust.qty"+ i +".value;		
//DEBUG("bc_uri = ", bc_uri);
	//Response.Write("<a title='Print Barcode' class=o href='"+ bc_uri +"'+ document.frmQtyAdjust.qty"+ i +".selected");
	//Response.Write("<a title='Print Barcode' class=o href='barcode.aspx?code="+ code +"");
		
	//Response.Write(">BC</a>");
	Response.Write("<input type=button title='Print Barcode' value='BC' "+ Session["button_style"] +" onclick=\"window.location=('"+ bc_uri +"'+ document.frmQtyAdjust.qty"+ i +".value);\">");
	Response.Write("</th>");
	}
	Response.Write("</tr>");
	//Response.Write("</form>");

	return true;
}

void PrintPageIndex()
{
	Response.Write("<tr><td colspan=2>Page: ");
	int pages = dst.Tables["stock_qty"].Rows.Count / m_nPageSize + 1;
	//int pages = dst.Tables["stock"].Rows.Count / m_nPageSize;
	int start = 1; 
	if(m_page >= 2)
		start = m_page - 1;
	int end = pages;
	if(end - start > m_nIndexCount)
		end = start + m_nIndexCount;
	int i = start;
	if(i > 2)
	{
		Response.Write("<a href=stock_adj.aspx?page=" + (start - 1).ToString());
		if(cat != "")
			Response.Write("&cat=" + HttpUtility.UrlEncode(cat));
		if(s_cat != "")
			Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
		if(ss_cat != "")
			Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
		Response.Write(">...</a> ");
	}

	for(; i<=end; i++)
	{
		if(i != m_page)
		{
			Response.Write("<a href=stock_adj.aspx?page=");
			Response.Write(i.ToString());
			if(cat != "")
				Response.Write("&cat=" + HttpUtility.UrlEncode(cat));
			if(s_cat != "")
				Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
			if(ss_cat != "")
				Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
			Response.Write(">");
			Response.Write(i.ToString());
			Response.Write("</a> ");
		}
		else
		{
			Response.Write("<font color=red>" + i.ToString() + "</font> ");
		}
	}
	if(end < pages)
	{
		Response.Write("<a href=stock_adj.aspx?page=" + i.ToString());
		if(cat != "")
			Response.Write("&cat=" + HttpUtility.UrlEncode(cat));
		if(s_cat != "")
			Response.Write("&scat=" + HttpUtility.UrlEncode(s_cat));
		if(ss_cat != "")
			Response.Write("&sscat=" + HttpUtility.UrlEncode(ss_cat));
		Response.Write(">...</a>");
	}

	Response.Write("</td>");
	Response.Write("<td colspan=7 align=right>");
	Response.Write("<b>Adjustment Note : </b><input type=text name=note> ");
	Response.Write("<input type=submit class=updateOrderButton name=cmd value='Update Adjustment' title='Update Adjustment'");
	if(Session["employee_access_level"] != null)
	{
	if(int.Parse(Session["employee_access_level"].ToString()) <=6 )
		Response.Write(" disabled ");
	}
	Response.Write(">");
	Response.Write("</td>");
	Response.Write("</tr>");
}


bool PrintTransferForm()
{
	PrintAdminHeader();
	PrintAdminMenu();

	string code = Request.QueryString["code"];
	if(code == null || code == "")
	{
		MsgDie("Error, No Item Code");
		return false;
	}

	//get qty
	int rows = 0;
	string sc = " SELECT q.code, q.branch_id, q.qty, c.name, b.name AS branch_name ";
	sc += " FROM stock_qty q JOIN code_relations c ON c.code = q.code ";
	sc += " LEFT OUTER JOIN branch b ON b.id = q.branch_id ";
	sc += " WHERE q.code = " + code;
	sc += " ORDER BY q.branch_id ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "transfer");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	Response.Write("<br><center><h3>Stock Transfer</h3>");

	if(rows <= 0)
	{

		MsgDie("No stock found in any branch, please do purchase first.");
		return true;
	}

	Response.Write("<form name=f action=stock_adj.aspx?t=transfer&code=" + code + " method=post>");
    Response.Write("<script>");
	Response.Write("    function ShowAlert(){");
    Response.Write("        var con = confirm('Are you sure to transfer stock to other branch?');");
    Response.Write("        if(con === true){");
    Response.Write("            return true;");
    Response.Write("        }else{");
    Response.Write("            return false;");
    Response.Write("        }");
    Response.Write("    }");
    Response.Write("</");
    Response.Write("script>");
    Response.Write("<table cellspacing=1 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	string name = dst.Tables["transfer"].Rows[0]["name"].ToString();
	Response.Write("<tr><td colspan=2><b>Code : </b><font class=blueFont2>" + code + "</font></td></tr>");
	Response.Write("<tr><td colspan=2><b>Description : </b>" + name + "</b></td></tr>");
	Response.Write("<tr><td colspan=2><b>Current Stock : </b></td></tr>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["transfer"].Rows[i];
		string branch = dr["branch_name"].ToString();
		string qty = dr["qty"].ToString();
		Response.Write("<tr><td align=right><b>" + branch + "&nbsp;&nbsp;&nbsp;</b></td><td><font class=blueFont2>" + qty + "</font></td></tr>");
	}

	Response.Write("<tr><td colspan=2>&nbsp;</td></tr>");
	Response.Write("<tr><td colspan=2 align=center><b>Transfer </b></td></tr>");
	Response.Write("<tr><td align=right><b>QTY to transfer : </b></td><td><input type=text name=qty value=1></td></tr>");
	Response.Write("<tr><td align=right><b>From Branch : </b></td><td><select name=branch_from>" + SPrintBranchOptions("1") + "</select></td></tr>");
	Response.Write("<tr><td align=right><b>To Branch : </b></td><td><select name=branch_to>" + SPrintBranchOptions("2") + "</select></td></tr>");
	Response.Write("<tr><td colspan=2 align=center><input type=submit name=cmd value=Transfer  class=transferButton onclick='return ShowAlert();' ></td></tr>");
	Response.Write("</table></form>");
	return true;
}

string SPrintBranchOptions(string current_id)
{
	int rows = 0;
	string s = "";
	string sc = " SELECT id, name FROM branch ORDER BY id ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "branch");
	}
	catch(Exception e1) 
	{
		ShowExp(sc, e1);
		return "";
	}

	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["branch"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		s += "<option value=" + id;
		if(id == current_id)
			s += " selected";
		s += ">" + name + "</option>";
	}
	return s;	
}

bool DoStockTransfer()
{
	string code = Request.QueryString["code"];
	string from_branch = Request.Form["branch_from"];
	string to_branch = Request.Form["branch_to"];
	string from_branch_name = GetBranchName(from_branch);
	string to_branch_name = GetBranchName(to_branch);
	string qty = Request.Form["qty"];
	int nQty = MyIntParse(qty);

	string sc = "";
	sc += " IF NOT EXISTS";
	sc += " (SELECT * FROM stock_qty WHERE code=" + code + " AND branch_id = " + from_branch + ") ";
	sc += " INSERT INTO stock_qty (code, qty, branch_id) VALUES(" + code + ", " + (0 - nQty).ToString() + ", " + from_branch + ") ";
	sc += " ELSE ";
	sc += " UPDATE stock_qty SET qty = qty - " + qty + " WHERE code = " + code + " AND branch_id = " + from_branch;
	
	sc += " INSERT INTO stock_adj_log (staff, code, qty, branch_id, note) VALUES(" + Session["card_id"].ToString();
	sc += ", " + code + ", " + (0 - nQty).ToString() + ", " + from_branch + ", 'transfered to " + to_branch_name + " branch') "; 

	sc += " IF NOT EXISTS";
	sc += " (SELECT * FROM stock_qty WHERE code=" + code + " AND branch_id = " + to_branch + ") ";
	sc += " INSERT INTO stock_qty (code, qty, branch_id) VALUES(" + code + ", " + nQty.ToString() + ", " + to_branch + ") ";
	sc += " ELSE ";
	sc += " UPDATE stock_qty SET qty = qty + " + qty + " WHERE code = " + code + " AND branch_id = " + to_branch;

	sc += " INSERT INTO stock_adj_log (staff, code, qty, branch_id, note) VALUES(" + Session["card_id"].ToString();
	sc += ", " + code + ", " + qty + ", " + to_branch + ", 'transfered from " + from_branch_name + " branch') "; 

//DEBUG("sc=", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string GetBranchName(string id)
{
	if(dst.Tables["branch_name"] != null)
		dst.Tables["branch_name"].Clear();

	string sc = " SELECT name FROM branch WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "branch_name") == 1)
			return dst.Tables["branch_name"].Rows[0]["name"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	return "";
}


</script>

<asp:Label id=LFooter runat=server/>
