<!-- #include file="c.cs" -->

<script runat=server>

int MaxRows = 20;
string m_sGroupType = "group_by_vendor";
string m_cat = "";
string m_scat = "";
string m_brand = "";
bool m_bViewByVendor = true;
int m_ViewCatLevel = 1;  //set view cat level, ie: 1 only brnad, 2 for first cat, 3 for s_cat and ss_cat

string m_sNewMenuPage = "";
string m_KitName = "Package";
string m_leftsidemenu = "";
/*****************************************************************
program spec: disply menu by brands and catagory
create date: 13-05-05

*****************************************************************/
void MPage_Load()
{
	RememberLastPage();
//	m_sNewMenuPage = "<!----- **************Page Descriptions**************** --> ";
//	m_sNewMenuPage += "<!-- There is only 2 variables '@@ALL_CATALOG_LINK', and '@@LEFT_SIDE_MENU', this will display all the menu link by it self like the old menu page (m.aspx)--> ";
//	m_sNewMenuPage += "<!-- There are 2 link for this page. use this query string to display 2 links, by using: 1:'nm.aspx?viewby=catalog' and 2:'nm.aspx' --> ";
	
m_sNewMenuPage += ReadSitePage("new_menu_catalog_group");
m_leftsidemenu = ReadSitePage("left_side_menu");

	PrintHeaderAndMenu("");
	DataSet ds = new DataSet();
	
	m_KitName = GetSiteSettings("package_bundle_kit_name");
	
	if(Request.QueryString["viewby"] != null && Request.QueryString["viewby"] != "")
		m_sGroupType = Request.QueryString["viewby"].ToString();
	if(m_sGroupType == "group_by_catalog")
		m_bViewByVendor = false;
	
	
	string menu = Request.QueryString["m"];
	string type = Request.QueryString["t"];
	m_brand = Request.QueryString["brand"];
	m_cat = Request.QueryString["cat"];
	m_scat = Request.QueryString["scat"];

//DEBUG("m_brand = ", m_brand);
//DEBUG("Mcat = ", m_cat);
//DEBUG("mscat = ", m_scat);
	if(m_bViewByVendor)
	{
		if(m_brand != "" && m_brand != null && (m_cat == null || m_cat == "") && (m_scat == null || m_scat == ""))
			m_ViewCatLevel = 2;
		else if(m_brand != "" && m_brand != null && m_cat != null && m_cat != "" && (m_scat == null || m_scat == ""))
			m_ViewCatLevel = 3;
	}
	else
	{
		if((m_cat != null && m_cat != "") && (m_scat == null || m_scat == ""))
			m_ViewCatLevel = 2;
		else if(m_brand != "" && m_brand != null && m_cat != null && m_cat != "" && (m_scat != null || m_scat != ""))
			m_ViewCatLevel = 3;
	
	}

//DEBUG("matlive =", m_ViewCatLevel);	
	
	string sc = "";
StringBuilder sb = new StringBuilder();

	if(m_bViewByVendor)
	{
		sc += " SELECT DISTINCT ";
		if(m_ViewCatLevel == 2)
			sc += " cat ";
		else if(m_ViewCatLevel == 3)
			sc += " s_cat AS cat, ss_cat ";
		else
			sc += " brand ";
		sc += "  FROM product WHERE 1=1 ";

		if(m_brand != "" && m_brand != null)
			sc += " AND brand = '"+ EncodeQuote(m_brand) +"' ";
		if(m_cat != "" && m_cat != null)
			sc += " AND cat = '" + EncodeQuote(m_cat) +"' ";
		sc += " ORDER BY ";
		if(m_ViewCatLevel == 1)
			sc += " brand ";
		else if(m_ViewCatLevel == 2)
			sc += " cat ";
		else
			sc += " cat ";

	}
	else
	{
		sc = " SELECT DISTINCT ";
		if(m_ViewCatLevel == 1 )
			sc += " cat  ";
		else if(m_ViewCatLevel == 2 )
			sc += "s_cat, brand ";
		else if(m_ViewCatLevel == 3)
			sc += " ss_cat ";
		sc += " FROM product ";
		sc += " WHERE 1=1  ";
		if(m_ViewCatLevel == 2 )
			sc += " AND cat = '"+ EncodeQuote(m_cat) +"' ";
		if(m_ViewCatLevel == 3)
			sc += " AND s_cat = '"+ EncodeQuote(m_scat) +"' AND brand = '"+ EncodeQuote(m_brand) +"'";
		sc += " UNION ";
		sc += " SELECT DISTINCT ";
		if(m_ViewCatLevel == 1 )
			sc += "'"+ m_KitName +"' AS cat ";
		if(m_ViewCatLevel == 2 )
			sc += " s_cat, '" + m_sCompanyName +"' AS brand ";
		else if(m_ViewCatLevel == 3)
			sc += "ss_cat ";
		sc += " FROM kit ";
		sc += " WHERE 1=1 ";
		if(m_ViewCatLevel == 2 )
			sc += " AND '"+ m_KitName +"' = '"+ EncodeQuote(m_cat) +"' ";
		if(m_ViewCatLevel == 3)
			sc += " AND s_cat = '"+ EncodeQuote(m_scat) +"' ";
	
		if(m_ViewCatLevel == 1)
			sc += " ORDER BY  cat ";
			
	}
	int rows = 0;
//DEBUG("sc =", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(ds, "menu");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return;
	}

/*	m_sNewMenuPage += "<!----- **************Page Descriptions**************** --> ";
	m_sNewMenuPage += "<!-- There is only 2 variables '@@ALL_CATALOG_LINK', and '@@LEFT_SIDE_MENU', this will display all the menu link by it self like the old menu page (m.aspx)--> ";
	m_sNewMenuPage += "<!-- There are 2 link for this page. use this query string to display 2 links, by using: 1:'nm.aspx?viewby=catalog' and 2:'nm.aspx' --> ";
	*/
	sb.Append("<br><table border=0 cellspacing=0 cellpadding=2 style='border-style: solid; border-width: 0px; padding: 0'>");
	sb.Append("<tr><td><h5>");
	if(m_bViewByVendor)
	{
		sb.Append("<h5><u>View Product Group By Brands:</u> ");
		if(m_brand != "" && m_brand != null)
			sb.Append(" &nbsp;"+ m_brand +"");
		if(m_cat != null && m_cat != "")
			sb.Append(" - "+ m_cat +"");
		
	}
	else
	{
		sb.Append("<center><h5><u>View Product Group By Catagory:</u> ");
		if(m_brand != "" && m_brand != null)
			sb.Append(" "+ m_brand +"");
		if(m_cat != null && m_cat != "")
			sb.Append(" - "+ m_cat +"");
	}
	sb.Append("</td></tr></table><br>");
	sb.Append("<table border=0 cellspacing=0 cellpadding=2 align=center width=100% style='border-style: solid; border-width: 1px; padding: 0'>");
	bool bAlter = false;
	string brand = "";
	string cat = "";
	string ss_cat = "";
string url = "";
string old_scat = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dtr = ds.Tables[0].Rows[i];
	
		if(m_bViewByVendor)
		{
			if(m_ViewCatLevel == 1)
				brand = dtr["brand"].ToString();
			else if(m_ViewCatLevel == 2 || m_ViewCatLevel == 3)
				cat = dtr["cat"].ToString();
			
			if(m_ViewCatLevel == 1)
			{
				url = "nm.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&viewby=";
				url +="group_by_vendor";
				if(m_ViewCatLevel == 1)
						url += "&brand="+ HttpUtility.UrlEncode(brand);
			}
			else if(m_ViewCatLevel == 2)
			{
				if(cat != "" && cat != null && cat.ToLower() != "zzzothers")
				{
					url = "nm.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&viewby=";
					url +="group_by_vendor";
				}
				else
					url = "nm.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
				url += "&brand="+ HttpUtility.UrlEncode(m_brand);
				url += "&cat="+ HttpUtility.UrlEncode(cat)+"";
			}
			else if(m_ViewCatLevel == 3)
			{
				ss_cat = dtr["ss_cat"].ToString();
				url = "c.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&b="+ HttpUtility.UrlEncode(m_brand) +"&c="+ HttpUtility.UrlEncode(m_cat)+"&s="+ HttpUtility.UrlEncode(cat)+"";
				if(ss_cat != null && ss_cat != "" && ss_cat.ToLower() != "zzzothers")
					url += "&ss="+ HttpUtility.UrlEncode(ss_cat) +"";
			}
			if(m_ViewCatLevel == 1)
			{
				if(i > 0 && i % 2 == 0 )
					sb.Append("<td>");
			}
							
			if(i == 0 || i % 2 == 1)
			{
				sb.Append("<tr ");
				if(bAlter)
					sb.Append(" bgcolor=#EEEEEE ");
				sb.Append(">");
			
				bAlter = !bAlter;
			}			
			
			if(m_ViewCatLevel == 3)
			{
				if(old_scat != cat)
				{
					sb.Append("<td colspan=2 bgcolor=#EEEEEE ><img src='/i/reda1.gif'> "+ cat +"</td></tr>");
				}
				 
					sb.Append("<tr><td>&nbsp;</td><td>");
							
				old_scat = cat;
			}
			else
				sb.Append("<td><img src='/i/reda1.gif'> &nbsp;");

			sb.Append("<a href='"+ url);
				
			sb.Append("' class=f >");
			if(m_ViewCatLevel == 1)
				sb.Append(brand);
			else if(m_ViewCatLevel == 2)
			{
				if(cat != "" && cat != null)
					sb.Append(cat);
				else
					sb.Append("Other");
			}
			else if(m_ViewCatLevel == 3)
			{				
				if(ss_cat != null && ss_cat != "")
					sb.Append(" - "+ss_cat);
				else 
					sb.Append("Other");
				sb.Append(" </td></tr>");
			}
			if(m_ViewCatLevel == 1 || m_ViewCatLevel == 2)
			{
				sb.Append("</a>");
				if(m_ViewCatLevel == 1)
				{
					if(i % 2 == 0)
						sb.Append("</td><td>");
				}
				else
				{
					sb.Append("</td>");
					sb.Append("</tr>");
				}
			}
		}
		else
		{
			if(m_ViewCatLevel == 1)
				cat = dtr["cat"].ToString();
			if(m_ViewCatLevel == 2)
			{
				brand = dtr["brand"].ToString();
				cat = dtr["s_cat"].ToString();
			}
			if(m_ViewCatLevel == 3)
				ss_cat = dtr["ss_cat"].ToString();
				
			
			if(m_ViewCatLevel == 1)
			{
				url = "nm.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&viewby=";
				url += "group_by_catalog";
				if(m_ViewCatLevel == 1)
						url += "&cat="+ HttpUtility.UrlEncode(cat);
			}
			else if(m_ViewCatLevel == 2)
			{
				if(cat != null && cat != "" && cat.ToLower() == "zzzothers")
				{
					url = "nm.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&viewby=";
					url += "group_by_catalog";
				}
				else
					url = "c.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
				url += "&brand="+ HttpUtility.UrlEncode(brand);
				url += "&cat="+ HttpUtility.UrlEncode(m_cat)+"";
				url += "&scat="+HttpUtility.UrlEncode(cat)+"";
												
			}
			else if(m_ViewCatLevel == 3)
			{
				ss_cat = dtr["ss_cat"].ToString();
				url = "c.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&b="+ HttpUtility.UrlEncode(m_brand) +"&c="+ HttpUtility.UrlEncode(m_cat)+"&s="+ HttpUtility.UrlEncode(m_scat)+"&ss="+ HttpUtility.UrlEncode(ss_cat) +"";
			}
			
			if(i == 0 || i % 2 == 1)
			{
				sb.Append("<tr ");
				if(bAlter)
					sb.Append(" bgcolor=#EEEEEE ");
				sb.Append(">");
				if(m_ViewCatLevel == 1)
				bAlter = !bAlter;
			}
			
			if(m_ViewCatLevel == 2)
			{
				if(old_scat != cat)
					sb.Append("<td colspan=2 bgcolor=#EEEEEE ><img src='/i/reda1.gif'> "+ cat +"</td></tr>");
							
				sb.Append("<tr><td>&nbsp;</td><td>");
				
				old_scat = cat;
			}
			else
				sb.Append("<td><img src='/i/reda1.gif'> &nbsp;");

			sb.Append("<a href='"+ url);
				
			sb.Append("' class=f >");
		
			if(m_ViewCatLevel == 1)
					sb.Append(cat);
			else if(m_ViewCatLevel == 2)
				sb.Append(" - "+brand);
			else if(m_ViewCatLevel == 3)
			{
				sb.Append(""+m_brand +" - "+m_scat +" - "+ss_cat);
				sb.Append("</td></tr>");
			}
			if(m_ViewCatLevel == 1 || m_ViewCatLevel == 2)
			{
				sb.Append("</a>");
				if(m_ViewCatLevel == 1)
				{
					if(i % 2 == 0)
						sb.Append("</td><td>");
				}
				else
				{
					sb.Append("</td>");
					sb.Append("</tr>");
				}
			}
		}
		
		
	}
	sb.Append("</table><br><br>");
	m_sNewMenuPage = m_sNewMenuPage.Replace("@@LEFT_SIDE_MENU", m_leftsidemenu);
	m_sNewMenuPage = m_sNewMenuPage.Replace("@@TOP_CAT_MENU", doQueryCatalog());
m_sNewMenuPage = m_sNewMenuPage.Replace("@@ALL_CATALOG_LINK", sb.ToString());
	//Response.Write(sb.ToString());
Response.Write(m_sNewMenuPage);

}
</script>
