<script runat=server>
const string m_sDataSource = ";data source=localhost;";
const string m_sSecurityString = "Integrated Security=SSPI;";
const string m_emailAlertTo = "alert@eznz.com";

const string m_sCompanyName = "b2a";	//site identifer, used for cache, sql db name etc, highest priority
</script>