
<script runat="server">
int m_selected = 1;  //selected value 

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
string repair_warranty_note = "";
string term_condition = "";
string m_uri = "";

string ra_conditions = "";
string ra_header = "";
string ra_packslip = "";
string m_sEmail = "";
string m_repair_form_template = "";
string company_id = "";
bool bHide = true;

void Page_Load (Object Src, EventArgs E)
{
	TS_PageLoad(); //do common things, LogVisit etc...

	repair_warranty_note = ReadSitePage("ra_warranty_note");
	ra_header = ReadSitePage("repair_header");
	ra_conditions = ReadSitePage("repair_condition");
	ra_packslip = ReadSitePage("repair_pickup_slip");

	company_id = GetCompanyCardID(GetEnumID("card_type","others"));

	m_repair_form_template = ReadRATemplate(company_id);

	if(!TS_UserLoggedIn() || Session["email"] == null)
	{
		InitializeData();
		Response.Write("<center><h4><a href=login.aspx class=o>Click Here to Login First</a></h4>");
		return;
	}
	if(Request.QueryString["slt"] != null && Request.QueryString["slt"] != "")
		m_selected = int.Parse(Request.QueryString["slt"]);
	
	if(Request.Form["cmd"] == "Apply for RA Number")
	{
		//if(!GetNextRA_ID())
		//	return;
		if(!insertRepair())
			return;
		//Response.Redirect(Request.ServerVariables["URL"] +"?s=view");
		Session["slt_customer"] = null;
		Session["slt_name"] = null;
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL="+Request.ServerVariables["URL"]+"?s=view \">");
	}
	if(!getRepairDetails())
		return;
	if(Request.QueryString["s"] == "view")
	{
		InitializeData();
		if(!displayRA_Item())
			return;
		return;
	}
	else
	{
		if(Request.QueryString["ci"] != null && Request.QueryString["ci"] != "" || Request.QueryString["ci"] == "all")
		{	
			InitializeData();
			if(!GetCardID())
				return;
			return;
		}
		else
		{
			if(Request.QueryString["print"] == "form" && Request.QueryString["ra"] != null)
			{
				//Response.Write(PrintDocket());
				m_sEmail = PrintDocket();
				if(Request.QueryString["email"] != null && Request.QueryString["email"] != "")
				{
					string email = Request.QueryString["email"];
					string ra_id = Request.QueryString["ra"];
					if(Request.QueryString["confirm"] == "1")
					{
						Response.Write("<script Language=javascript");
						Response.Write(">");
						Response.Write("if(window.confirm('");
						Response.Write("Email RMA#" + ra_id + " to " + email + "?         ");
						Response.Write("\\r\\n\\r\\n");
						Response.Write("\\r\\nClick OK to send.\\r\\n");
						Response.Write("'))");
						Response.Write("window.location='m_repair.aspx?print=form&ra=" +ra_id + "&email=" + HttpUtility.UrlEncode(email) + "';\r\n");
						Response.Write("else window.close();\r\n");
						Response.Write("</script");
						Response.Write(">");
						return;
					}
					else
					{
						
						string mFrom = GetSiteSettings("service_email", "alert@ezsoft.com");
						string mTo = email;
						string mSubject= "RMA#" + " " + ra_id + " - " + m_sCompanyTitle;
						SendEmail(mFrom, mFrom, mTo, mSubject, m_sEmail);
					}
					Response.Write("<form name=frm onload='window.close()'>");
					Response.Write("<br><center><h3>RMA# " + ra_id + " Sent.</h3>");
					Response.Write("<input type=button value='Close Window' onclick=window.close() " + Session["button_style"] + ">");
					Response.Write("<br><br><br><br><br><br>");
					Response.Write("</from>");
					return;
				}	
				//else
				//{
					Response.Write(PrintDocket());
					return;
				//}
			}
			else
			{
				InitializeData();
				multipleDataForm();		
				return;
			}
		}
	}
}

bool GetCardID()
{
	int rows = 0;
	string sc = " SELECT TOP 50 id, name, trading_name, company, phone, email, contact ";
	sc += " FROM card WHERE 1=1 ";
	if(Request.QueryString["ci"] != null && Request.QueryString["ci"] != "" && Request.QueryString["ci"] != "all")
		sc += " AND id = "+ Request.QueryString["ci"];
	
	if(Request.Form["search"] != null && Request.Form["search"] != "")
	{
		//DEBUG(" Request serach = ", Request.Form["search"].ToString());
		//DEBUG(" true false = ", TSIsDigit(Request.Form["search"]).ToString());
		if(TSIsDigit(Request.Form["search"]))
			sc += " AND id = "+ Request.Form["search"];
		else
		{
			sc += " AND name LIKE '%"+ Request.Form["search"].ToString() +"%' OR trading_name LIKE '%"+ Request.Form["search"].ToString() +"%' ";
			sc += " OR company LIKE '%"+ Request.Form["search"].ToString() +"%' OR  email LIKE '%"+ Request.Form["search"].ToString()+"%'";
		}
	}
	else
		sc += "";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "card_id");
		//DEBUG("rows= ", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows == 1)
	{
		Session["slt_customer"] = dst.Tables["card_id"].Rows[0]["id"].ToString();
		if(g_bRetailVersion)
			Session["slt_name"] = dst.Tables["card_id"].Rows[0]["name"].ToString();
		else
			Session["slt_name"] = dst.Tables["card_id"].Rows[0]["company"].ToString();
		if(Session["slt_name"] == null || Session["slt_name"] == "")
			Session["slt_name"] = dst.Tables["card_id"].Rows[0]["trading_name"].ToString();
		//Response.Redirect(Request.ServerVariables["URL"]+"?slt="+ m_selected);
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL="+Request.ServerVariables["URL"]+"?slt="+m_selected+" \">");
	}
	Response.Write("<form name=frm method=post>");
	Response.Write("<table align=center width=90% cellspacing=1 cellpadding=1 border=1 bordercolor=black bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=6><input type=text name=search value=''><input type=submit name=cmd value='Search' "+Session["button_style"] +">");
	Response.Write("<input type=button name=addnew value='Add New Customer' "+ Session["button_style"] +" onclick=\"javascript:new_window=window.open('ecard.aspx?a=new&r="+ DateTime.UtcNow.AddHours(12).ToString("ddMMyyyyHHmm") +"', '',''); new_window.focus();\">");
	Response.Write("</td></tr>");
	Response.Write("<script language=javascript>");
	Response.Write("\n\r document.frm.search.focus();\r\n </script");
	Response.Write(">");
	Response.Write("<tr bgcolor=#EDE3E3>");
	Response.Write("<tr bgcolor=#EEDDDD><th>ID</th><th>Name</th><th>Contact</th><th>Trading Name</th><th>Company</th><th>Email</th></tr>");
	string uri = "m_repair.aspx?slt="+m_selected+"&ci=";
	bool bAlter = true;
	if(rows > 1)
	{
		for(int i=0; i<rows; i++)
		{
			DataRow dr = dst.Tables["card_id"].Rows[i];	
			string id = dr["id"].ToString();
			string name = dr["name"].ToString();
			string trading_name = dr["trading_name"].ToString();
			string contact = dr["contact"].ToString();
			string company = dr["company"].ToString();
			string email = dr["email"].ToString();
			Response.Write("<tr");
			if(bAlter)
				Response.Write(" bgcolor=#EEEEEE ");
			Response.Write(">");
			bAlter = !bAlter;
			Response.Write("<td><a title='select Customer' href='"+uri+id+"' class=o>"+id+"</a></td>");
			Response.Write("<td><a title='select Customer' href='"+uri+id+"' class=o>"+name+"</a></td>");
			Response.Write("<td><a title='select Customer' href='"+uri+id+"' class=o>"+contact+"</a></td>");
			Response.Write("<td><a title='select Customer' href='"+uri+id+"' class=o>"+trading_name+"</a></td>");
			Response.Write("<td><a title='select Customer' href='"+uri+id+"' class=o>"+company+"</a></td>");
			Response.Write("<td>"+email+"</td>");
			Response.Write("</tr>");
		}
	}
	
	Response.Write("</table>");
	Response.Write("</form>");
	return true;
}

string PrintDocket()
{
	StringBuilder sb = new StringBuilder();
	DataRow dr;
	sb.Append("<title>"+Session["CompanyName"]+" Repair Form</title>");
	sb.Append("<body onload='window.print()'>");
	sb.Append("<table align=center width=98% cellspacing=1 cellpadding=1 border=0 bordercolor=gray bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	//bgcolor=#cc766E
	sb.Append("<tr ><th align=left colspan=8>"+ra_header+"</th></tr>");
	sb.Append("<tr><td colspan=4>");

	string technician = "";
	string r_date = "";
	string ra_number = "";
	//DEBUG("rows = ", dst.Tables["ra_detail"].Rows.Count.ToString());
	
	if(dst.Tables["ra_detail"].Rows.Count > 0)
	{
		dr = dst.Tables["ra_detail"].Rows[0];
		string name = dr["cname"].ToString();
		if(name == "" && name == null)
			name = dr["trading_name"].ToString();
		string company = dr["ccompany"].ToString();
		string ticket = dr["ticket"].ToString();
		string addr1 = dr["addr1"].ToString();
		string addr2 = dr["addr2"].ToString();
		string city = dr["ccity"].ToString();
		string phone = dr["cphone"].ToString();
		string fax = dr["cfax"].ToString();
		string email = dr["cemail"].ToString();
		ra_number = dr["ra_number"].ToString();
		r_date = dr["repair_date"].ToString();
		r_date = DateTime.Parse(r_date).ToString("dd-MMM-yyyy");

		m_repair_form_template = m_repair_form_template.Replace("@@company", company);
		m_repair_form_template = m_repair_form_template.Replace("@@customer", name);
		m_repair_form_template = m_repair_form_template.Replace("@@ticket", ticket);
		m_repair_form_template = m_repair_form_template.Replace("@@addr1", addr1);
		m_repair_form_template = m_repair_form_template.Replace("@@addr2", addr2);
		m_repair_form_template = m_repair_form_template.Replace("@@city", city);
		m_repair_form_template = m_repair_form_template.Replace("@@phone", phone);
		m_repair_form_template = m_repair_form_template.Replace("@@fax", fax);
		m_repair_form_template = m_repair_form_template.Replace("@@email", email);
		m_repair_form_template = m_repair_form_template.Replace("@@ra_number", ra_number);
		m_repair_form_template = m_repair_form_template.Replace("@@repair_date", r_date);

		sb.Append("<table align=center width=98% cellspacing=3 cellpadding=2 border=0 bordercolor=black bgcolor=white");
		sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
		sb.Append("<tr><th colspan=2 align=left><font size=3>Customer Details:</font></th></tr>");
		//sb.Append("<tr><td>"+name+"</td><td>|&nbsp;</td></tr>");
		//sb.Append("<tr><td>"+company+"</td><td>|&nbsp;</td></tr>");
		sb.Append("<tr><td>"+name+"</td><td>&nbsp; ph: "+phone+"</td></tr>");
		sb.Append("<tr><td>"+company+"</td><td>&nbsp; fx: "+fax+"</td></tr>");
		sb.Append("<tr><td>"+addr1+"</td><td>&nbsp; email: "+email+"</td></tr>");
		if(addr2 != "")
			sb.Append("<tr><td>"+addr2+"</td><td>&nbsp;</td></tr>");
		if(city != "")
			sb.Append("<tr><td>"+city+"</td><td>&nbsp; </td></tr>");
		sb.Append("</table>");
		sb.Append("</td><th colspan=4 valign=top>");
		sb.Append("<table border=0 ><tr><th colspan=2>RMA#: "+ ra_number +"</th></tr>");
		sb.Append("<tr><td>Repair Date: </td><td>"+ r_date +"</td></tr>");
		sb.Append("<tr><td>Delivery Ticket: </td><td>"+ ticket +"</td></tr>");
		sb.Append("</table></td></tr>");
		
	}	
	sb.Append("<tr></tr><tr></tr><tr></tr>");
	//sb.Append("<tr><th colspan=8 align=left>Faulty Items:</th></tr>");
	sb.Append("<tr><th colspan=9 align=left><hr size=1 width=100%></th></tr>");
	sb.Append("<tr>");
	sb.Append("<th align=left width=3%>&nbsp;</th>");
	sb.Append("<th align=left width=15%>SN#</th>");
	sb.Append("<th align=left width=8%>INVOICE#</th>");
	sb.Append("<th align=left width=10%>PURCHASE DATE</th>");
	sb.Append("<th align=left width=7%>CODE#</th>");
	sb.Append("<th align=left width=10%>M_PN#</th>");
	sb.Append("<th align=left>DESCRIPTION</th>");
	sb.Append("<th align=left width=7%>STATUS</th>");
	sb.Append("<th align=right width=4%>QTY&nbsp;</th>");
	sb.Append("</tr>");
	sb.Append("<tr><th colspan=9 align=left><hr size=1 width=100%></th></tr>");
	
	for(int i=0; i<dst.Tables["ra_detail"].Rows.Count; i++)
	{
		dr = dst.Tables["ra_detail"].Rows[i];
		string rs_sn = dr["rs_sn"].ToString();
		string rs_invoice = dr["rs_invoice"].ToString();
		//string ticket = dr["ticket"].ToString();
		string staff = dr["staff"].ToString();
		string rs_code = dr["rs_code"].ToString();
		string rs_desc = dr["description"].ToString();
		string rs_date = dr["rs_date"].ToString();
		string rs_supp_code = dr["rs_supp_code"].ToString();
			//string rs_sn = dr["rs_sn"].ToString();
		//DEBUG("rs_sn =", rs_sn);
		//DEBUG("rs_invoice=", rs_invoice);
		//DEBUG("tickt=", ticket);
		//DEBUG("staff=", staff);
		string replaced = dr["replaced"].ToString();
		//DEBUG("replaced = ", replaced);
		string sn = dr["serial_number"].ToString();
		string rid = dr["rid"].ToString();
		string ra_id = dr["ra_number"].ToString();
		string code = dr["code"].ToString();
		string pur_date = dr["purchase_date"].ToString();
		//if(pur_date != "")
		//	pur_date = DateTime.Parse(pur_date).ToString("dd-MM-yy");
		string invoice = dr["invoice_number"].ToString();
		string fault = dr["fault_desc"].ToString();
		string desc = dr["prod_desc"].ToString();
		string card_id = dr["customer_id"].ToString();
		string repair_date = dr["repair_date"].ToString();
		string status = dr["ra_status"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		
		int nStatus = int.Parse(dr["status"].ToString());
		technician = dr["technician"].ToString();
		string note = dr["note"].ToString();
		m_repair_form_template = m_repair_form_template.Replace("@@replace_sn"+i, rs_sn);
		m_repair_form_template = m_repair_form_template.Replace("@@replace_inv"+i, rs_invoice);
		m_repair_form_template = m_repair_form_template.Replace("@@replace_code"+i, rs_code);
		m_repair_form_template = m_repair_form_template.Replace("@@replace_item_desc"+i, rs_desc);
		m_repair_form_template = m_repair_form_template.Replace("@@replace_date"+i, rs_date);
		m_repair_form_template = m_repair_form_template.Replace("@@replace_supp_code"+i, rs_supp_code);
		m_repair_form_template = m_repair_form_template.Replace("@@isreplaced"+i, replaced);
		m_repair_form_template = m_repair_form_template.Replace("@@sn"+i, sn);
		m_repair_form_template = m_repair_form_template.Replace("@@code"+i, code);
		m_repair_form_template = m_repair_form_template.Replace("@@invoice"+i, invoice);
		m_repair_form_template = m_repair_form_template.Replace("@@fault_desc"+i, fault);
		m_repair_form_template = m_repair_form_template.Replace("@@item_desc"+i, desc);
		m_repair_form_template = m_repair_form_template.Replace("@@status"+i, status);
		m_repair_form_template = m_repair_form_template.Replace("@@supp_code"+i, supplier_code);
		m_repair_form_template = m_repair_form_template.Replace("@@repaid_note"+i, note);
		m_repair_form_template = m_repair_form_template.Replace("@@technician"+i, technician);

		//sb.Append("<tr><th colspan=5 align=left>Faulty Items:</th></tr>");
		//sb.Append("<tr bgcolor=#EEEEEE>");
		sb.Append("<tr><td colspan=9>");
		sb.Append("<table align=center width=100% cellspacing=1 cellpadding=3 border=0 bordercolor=gray bgcolor=white");
		sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
			
		sb.Append("<tr><td width=3%>"+(i+1)+".</td><td width=15%>"+sn+"</td>");
		sb.Append("<td width=8%>"+invoice+"</td>");
		sb.Append("<td width=10%>"+pur_date+"</td>");
		sb.Append("<td width=7%>"+code+"</td>");
		sb.Append("<td width=10%>"+supplier_code+"</td>");
		sb.Append("<td>"+desc+"</td>");
		sb.Append("<td width=7%>&nbsp;</td>");
		sb.Append("<td align=right width=4%>");
		if(replaced == "1")
			sb.Append("-");
		else
			sb.Append("");
		sb.Append("1&nbsp;</td>");
		sb.Append("</tr>");
		
		if(replaced == "1")
		{
		
			sb.Append("<tr bgcolor=#EEEEEE><td>&nbsp;</td>");
			//sb.Append("<tr bgcolor=#eeeee><th align=left width=10%>Replaced With:</td>");
			sb.Append("<td>"+rs_sn.ToUpper()+"</td><td>"+ rs_invoice +"</td><td>"+ pur_date +"</td><td>&nbsp;</td><td>"+ rs_supp_code +"</td>");
			sb.Append("<td>"+ rs_desc +"</td>");
			sb.Append("<td width=7%>Replaced</td>");
			sb.Append("<td align=right>1&nbsp;");
			sb.Append("</td></tr>");

		}
		sb.Append("<tr ><td>&nbsp;</td><th colspan=3 align=left>REPAIR STATUS:&nbsp;&nbsp;<font color=Red>"+ status.ToUpper() +"</font></td>");
		sb.Append("<th colspan=2 align=right>REPAIR DESC:</td>");
		sb.Append("<td colspan=3>"+note+"</td></tr>");
		sb.Append("</table></td></tr>");
		//sb.Append("<tr></tr>");
		
	}

	if(dst.Tables["ra_detail"].Rows.Count<5)
	{
		int nCt = dst.Tables["ra_detail"].Rows.Count;
		for (int j=nCt; j<5; j++)
		{
		m_repair_form_template = m_repair_form_template.Replace("@@replace_sn"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@replace_inv"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@replace_code"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@replace_item_desc"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@replace_date"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@replace_supp_code"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@isreplaced"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@sn"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@code"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@invoice"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@fault_desc"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@item_desc"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@status"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@supp_code"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@repaid_note"+j, "&nbsp;");
		m_repair_form_template = m_repair_form_template.Replace("@@technician"+j, "&nbsp;");
		}
	}
	ra_packslip = ra_packslip.Replace("@@Technician", technician);
	ra_packslip = ra_packslip.Replace("@@Jobnumber", ra_number);
	ra_packslip = ra_packslip.Replace("@@Repairdate", r_date);
	//sb.Append("<tr><td colspan=6>&nbsp;</td></tr>");
	int rows = dst.Tables["ra_detail"].Rows.Count;
	if(rows == 1 )
	{
		for(int i=0; i<200; i++)
			sb.Append("<tr></tr>");
	}
	else if(rows == 2 )
	{
		for(int i=0; i<150; i++)
			sb.Append("<tr></tr>");
	}
	else if(rows == 3 )
	{
		for(int i=0; i<100; i++)
			sb.Append("<tr></tr>");
	}
	else if(rows == 4 )
	{
		for(int i=0; i<70; i++)
			sb.Append("<tr></tr>");
	}
	else if(rows == 5 )
	{
		for(int i=0; i<50; i++)
			sb.Append("<tr></tr>");
	}
	sb.Append("<tr><td colspan=8>"+ra_conditions+"</td></tr>");
	sb.Append("<tr><td colspan=8>"+ra_packslip+"</td></tr>");
	sb.Append("</table>");

//DEBUG("company_id =", company_id);
	if(company_id != "")
		return m_repair_form_template;
	else
		return sb.ToString();
	
}

string GetCompanyCardID(string type)
{
	string sc = "SELECT TOP 1 id FROM card WHERE type = "+ type;
//DEBUG("sc =", sc);
string card_id = "";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "card_id") == 1)
			card_id = dst.Tables["card_id"].Rows[0]["id"].ToString();
	
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	
	return card_id;

}
//copy from bb.c to decode the message with special char
string msgEncode(string s)
{
	if(s == null)
		return null;
	string ss = "";
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == '\'')
			ss += "\'\'"; //double it for SQL query
		else if(s[i] == '<')
			ss += '[';
		else if(s[i] == '>')
			ss += ']';
		else if(s[i] == '*')
			ss += '-';
		else if(s[i] == '.')
			ss += ' ';
		else if(s[i] == '~')
			ss += ' ';
		else if(s[i] == '`')
			ss += ' ';
		else
			ss += s[i];
	}
	return ss;
}

bool insertRepair()
{
	string sn = "";
	string invoice = "";
	string code = "";
	string desc = "";
	string fault = "";
	string purchase_date = "";
	string supplier_code = "";
	string supplier_id = "";
	for(int i=0; i<m_selected; i++)
	{
		if(Request.Form["sn"+i.ToString()] != null && Request.Form["s_sn"+i.ToString()] != "")
			sn = msgEncode(Request.Form["sn"+i.ToString()]).ToUpper();
		if(Request.Form["inv_date"+i.ToString()] != null && Request.Form["inv_date"+i.ToString()] != "")
			purchase_date = Request.Form["inv_date"+i.ToString()];
		if(Request.Form["invoice"+i.ToString()] != null && Request.Form["invoice"+i.ToString()] != "")
			invoice = Request.Form["invoice"+i.ToString()];
		if(Request.Form["code"+i.ToString()] != null && Request.Form["code"+i.ToString()] != "")
			code = Request.Form["code"+i.ToString()];
		if(Request.Form["fault"+i.ToString()] != null && Request.Form["fault"+i.ToString()] != "")
			fault = msgEncode(Request.Form["fault"+i.ToString()]);
		if(Request.Form["description"+i.ToString()] != null && Request.Form["description"+i.ToString()] != "")
			desc = msgEncode(Request.Form["description"+i.ToString()]);
		if(Request.Form["hide_supplier_id"+i.ToString()] != null && Request.Form["hide_supplier_id"+i.ToString()] != "")
			supplier_id = Request.Form["hide_supplier_id"+i.ToString()];
		if(Request.Form["hide_supplier_code"+i.ToString()] != null && Request.Form["hide_supplier_code"+i.ToString()] != "")
			supplier_code = Request.Form["hide_supplier_code"+i.ToString()];
		if(fault.Length > 1024)
			fault = fault.Substring(0, 1024);
		if(desc.Length > 512)
			desc = desc.Substring(0, 512);
		string customer_id = Request.Form["customer"];
			
		string sc = " INSERT INTO repair ";
		sc += " (system, ra_number, serial_number, customer_id, invoice_number, status, fault_desc, repair_date";
		sc += " , code, supplier_code ,prod_desc, purchase_date, supplier_id ) ";
		sc += "VALUES(0, '"+ Session["ra_id"] +"', '"+ sn.ToUpper() +"'";
		if(chckLogin() == "4")
			sc += ", "+ customer_id +"";
		else
			sc += ", "+ Session["card_id"] +"";
		sc += ", '"+ invoice +"'";
		if(chckLogin() == "4")
			sc += " ,3 ";
		else
			sc += " ,1 ";
		sc += " , '"+ fault +"' ";
		sc += " , GETDATE() , '"+ code +"', '"+ supplier_code +"', '"+ desc +"' ";
		sc += " ,'"+ purchase_date +"', '"+ supplier_id +"') ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

bool displayRA_Item()
{
	DataRow dr;
		
	if(dst.Tables["ra_detail"].Rows.Count <=0)
	{
		Response.Write("<center><h4>No RMA Items with "+Session["CompanyName"]+"</h4></center>");
		return false;
	}
	Response.Write("<br><center><h5>Thank You to using our RA Online. Our Technical Support Team will contact you in near future</h5></center>");
	Response.Write("<table align=center width=80% cellspacing=1 cellpadding=1 border=1 bordercolor=#EEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=6>Hi, "+Session["name"]+", You have : <b><font color=green>"+dst.Tables["ra_detail"].Rows.Count+"</font></b> item(s) for repairing with us</td></tr>");
	Response.Write("<tr bgcolor=#AA8888><th>&nbsp;</th><th>Status</th><th>Repair Date</th><th>Description</th><th>Repair#</th><th>&nbsp;</th></tr>");
	bool bAlter = true;
	for(int i=0; i<dst.Tables["ra_detail"].Rows.Count; i++)
	{
		dr = dst.Tables["ra_detail"].Rows[i];
		string sn = dr["serial_number"].ToString();
		string rid = dr["rid"].ToString();
		string ra_id = dr["ra_number"].ToString();
		string code = dr["code"].ToString();
		string pur_date = dr["purchase_date"].ToString();
		string invoice = dr["invoice_number"].ToString();
		string fault = dr["fault_desc"].ToString();
		string desc = dr["prod_desc"].ToString();
		string card_id = dr["customer_id"].ToString();
		string repair_date = dr["repair_date"].ToString();
		string status = dr["ra_status"].ToString();
		int nStatus = int.Parse(dr["status"].ToString());
		string technician = dr["technician"].ToString();
		string note = dr["note"].ToString();
		Response.Write("<tr ");
		if(!bAlter)
			Response.Write(" bgcolor=#E3E3EE");
		bAlter = !bAlter;
		Response.Write(">");
		//Response.Write("<td><a title='click me to view ur detial' href='"+ m_uri +"' class=o>"+ (i+1) +"</a></td>");
		Response.Write("<th>"+ (i+1) +"</th>");
		Response.Write("<th>"+status.ToUpper()+"</th>");
		Response.Write("<td>"+DateTime.Parse(repair_date).ToString("dd-MMM-yyyy")+"</td>");
		Response.Write("<td>"+desc+"</td>");
		if(nStatus >2 && nStatus <=6)
		{
			Response.Write("<td>"+ra_id+"</td>");
			Response.Write("<td>");
			if(ra_id != "")
				Response.Write("<a title='click to print repair docket'  href='m_repair.aspx?print=form&ra="+ ra_id +"' class=o target=_blank >P</a>&nbsp;&nbsp;");
				//Response.Write("");
			Response.Write("<a title='click me to view job status' href=\"javascript:viewcard_window=window.open('view_ra.aspx?");
			Response.Write("job=" + rid + "','viewcard_window','width=640,height=480'); viewcard_window.focus();\" class=o><font color=green><b>S</font></b></a></td>");
		}
		else
		{
			Response.Write("<td><font color=red>Waiting for Repair#</font></td>");
			Response.Write("<td><a title='click me to view job status' href=\"javascript:viewcard_window=window.open('view_ra.aspx?");
			Response.Write("job=" + rid + "','viewcard_window','width=640,height=480'); viewcard_window.focus();\" class=o><font color=green><b>S</font></b></a></td>");
		}
		Response.Write("</tr>");
		
	}
	//Response.Write("");
	Response.Write("</table>");

	return true;
}

string chckLogin()
{
	string stype = "";
	if(Session["card_id"] != null && Session["card_id"] != "")
	{
		string sc = " SELECT type FROM card ";
		sc += " WHERE id = "+ Session["card_id"];
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			int rows = myAdapter.Fill(dst, "login");
			if(rows > 0)
			{	
				stype = dst.Tables["login"].Rows[0]["type"].ToString();
				//return stype;
			}
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return "errer";
		}
	}
	return stype;
}

bool getRepairDetails()
{
	string type = chckLogin();

	string id = "";
	if(Request.QueryString["id"] != null && Request.QueryString["id"] != "")
		id = Request.QueryString["id"].ToString();
	string ra = "";
	if(Request.QueryString["ra"] != null && Request.QueryString["ra"] != "")
		ra = Request.QueryString["ra"].ToString();

	string sc = "SELECT r.*, r.id AS rid, e.name AS ra_status, c.fax AS cfax, c.name AS cname, c.trading_name";
	sc += " ,c.city AS ccity, c.company AS ccompany, c.address1 AS addr1, c.address2 AS addr2, c.phone AS cphone, c.email AS cemail ";
	sc += " ,rs.code AS rs_code, rs.sn AS rs_sn, rs.description, rs.invoice_number AS rs_invoice,  rs.rs_date , cr.supplier_code AS rs_supp_code ";
	sc += " ,c2.name AS staff, c2.email AS staff_email";
	sc += " FROM repair r JOIN card c ON c.id = r.customer_id ";
	sc += " LEFT OUTER JOIN enum e ON e.id = r.status ";
	sc += " LEFT OUTER JOIN ra_statement rs ON rs.ra_id = r.id ";
	sc += " LEFT OUTER JOIN code_relations cr ON cr.code = rs.code ";
	sc += " LEFT OUTER JOIN card c2 ON c2.id = rs.staff ";
	sc += " WHERE r.status < 6 ";
	sc += " AND e.class = 'rma_status' ";
	if(type != "4" )
		sc += " AND r.customer_id = "+ Session["card_id"].ToString() ;
	
	if(ra != null && ra != "")
		sc += " AND r.ra_number = "+ ra;
	if(Request.QueryString["id"] != null)
	{
		sc += " AND r.id = "+ id +" ";
		if(bHide)
			bHide = !bHide;
	}
	else
		bHide = true;

	sc += " ORDER BY r.id DESC ";
//DEBUG("sc = ", sc );
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "ra_detail");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}


/*bool GetNextRA_ID()
{
	int rNumber = int.Parse(GetSiteSettings("repair_id").ToString());
	
	if(dst.Tables["insertrma"] != null)
		dst.Tables["insertrma"].Clear();

	//DEBUG("rnumber = ", rNumber);
	string sc = "SELECT TOP 1 ra_number FROM repair ORDER BY id DESC";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "insertrma") == 1)
		{
			if(dst.Tables["insertrma"].Rows[0]["ra_number"].ToString() != null && dst.Tables["insertrma"].Rows[0]["ra_number"].ToString() != "")
			{
				rNumber = int.Parse(dst.Tables["insertrma"].Rows[0]["ra_number"].ToString()) + 1;
				string sNumber = "";
				sNumber = rNumber.ToString();
				if(sNumber == "" && sNumber == null)
					rNumber = int.Parse(dst.Tables["insertrma"].Rows[1]["ra_number"].ToString()) + 1;
			}
			else
				rNumber = rNumber + 1;
		}
		Session["ra_id"] = rNumber;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}
*/
DataRow CheckSN(string sn, string invoice)
{
	DataSet dscsn = new DataSet();
	bool isNum = true;
	int ptr = 0;
	while (ptr < invoice.Length)
	{
		if (!char.IsDigit(invoice, ptr++))
		{
			isNum = false;
			break;
		}
	}
	sn = sn.ToUpper();
	string sc = " SELECT t.sn, i.invoice_number, ss.invoice_number AS invoice_number2, s.name";
	sc += ", CONVERT(varchar(12),i.commit_date,13) AS commit_date, s.code, p.supplier_id ";
	sc += " , s.supplier_code ";
	sc += " FROM serial_trace t LEFT OUTER JOIN sales_serial ss ON ss.sn = t.sn ";
	sc += " LEFT OUTER JOIN invoice i ON (i.invoice_number = t.invoice_number AND i.invoice_number = ss.invoice_number)";
	sc += " LEFT OUTER JOIN sales s ON (s.invoice_number = i.invoice_number AND s.invoice_number = ss.invoice_number AND s.code = ss.code) ";
	sc += " LEFT OUTER JOIN purchase p ON p.id = t.po_id ";
	//if(isNum)
	//	sc += " WHERE i.invoice_number = '"+ invoice +"'";
	sc += " WHERE s.code = ss.code ";
	sc += " AND UPPER(RTRIM(t.sn)) = '"+ sn +"'  ";
//DEBUG("sc=", sc);		
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dscsn) > 0)
			return dscsn.Tables[0].Rows[0];
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
	}
	return null;
}


bool multipleDataForm()
{

	Response.Write("<script Language=javascript");
	Response.Write(">");
	Response.Write("<!-- hide from older browser");
	string s = @"
	function chkValid() 
	{	
		var rows = document.frm.hide_row.value;
		var bEmpty = true;
		if(document.frm.customer.value == '0')
		{
			window.alert('Please select Customer!!!');
			return false;
		}
		for(var i=0; i<rows; i++)
		{
		
			var desc = document.frm;
			var fault = document.frm;
			if(i==0)	{
				desc = desc.description0.value;
				fault = fault.fault0.value;
				if(desc=='' || fault=='') {
					bEmpty = false;
				}
			}
			if(i==1)	{
				desc = desc.description1.value;
				fault = fault.fault1.value;
				if(desc=='' || fault=='') {
					bEmpty = false;
				}
			}
			if(i==2)	{
				desc = desc.description2.value;
				fault = fault.fault2.value;
				if(desc=='' || fault=='') {
					bEmpty = false;
				}
			}
			if(i==3)	{
				desc = desc.description3.value;
				fault = fault.fault3.value;
				if(desc=='' || fault=='') {
					bEmpty = false;
				}
			}
			if(i==4)	{
				desc = desc.description4.value;
				fault = fault.fault4.value;
				if(desc=='' || fault=='') {
					bEmpty = false;
				}
			}
			if(!bEmpty)
			{
				window.alert('Please Enter all the Requir Fields');
				return false;
			}
			else
				bEmpty = true;
			
		}
		

		if(bEmpty)
		{
				var Agreement = 'Please read our Terms and Conditions before \r';
				Agreement += 'submit your application.\r';
				Agreement += '\r\r\r\r\r\r\r';
				if(!confirm(Agreement))
					return false;
				else
					return true;
		}
		return true;
	}
	";
	Response.Write("-->"); 
	Response.Write(s);
	Response.Write("</script");
	Response.Write("> \r\n");
	DataRow dr;
	Response.Write("<form name=frm method=post >");
	Response.Write("<br><center><h4>"+Session["CompanyName"]+" Online RA Form</h4> </center>");
	Response.Write("<table align=center width=90% cellspacing=0 cellpadding=2 border=1 bordercolor=gray bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=3> Select Number of faulty item(s) : <select name=multi onchange=\"window.location=('m_repair.aspx?slt='+this.options[this.selectedIndex].value)\" >\r\n");
	for(int i=1; i<6; i++)
	{
		if(m_selected == i)
			Response.Write("<option value='"+ i +"' selected> "+ i +"</option>");
		else
			Response.Write("<option value="+ i +"> "+ i +"</option>");
	}	
	Response.Write("</select>");
	Response.Write("&nbsp;&nbsp;&nbsp;<input type=submit value='Date :' "+Session["button_style"] +"> &nbsp;"+DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy")+"");
	Response.Write("</th><td colspan=2>");
	string stype = chckLogin();
	if(stype == "4")
	{
		//if(Session["slt_customer"] == null || Session["slt_customer"] == "")
		//	Response.Write("Select Customer: <select name=customer onclick=\"window.location=('m_repair.aspx?slt="+ m_selected +"&ci='+ this.options[this.selectedIndex].value)\" >\r\n");
		//else
		//Response.Write("Select Customer: <select name=customer onchange=\"window.location=('m_repair.aspx?slt="+ m_selected +"&ci='+ this.options[this.selectedIndex].value)\" >\r\n");
		Response.Write("Select Customer: <select name=customer onclick=\"window.location=('m_repair.aspx?slt="+ m_selected +"&ci=all')\" >\r\n");
		if(Session["slt_customer"] != null)
			Response.Write("<option value="+ Session["slt_customer"] +" selected>"+ Session["slt_name"] +" </option>");
		
		Response.Write("<option value=0>ALL");
		Response.Write("</select>");
		Response.Write("<input fgcolor=blue type=button onclick=\"javascript:viewcard_window=window.open('viewcard.aspx?");
		Response.Write("id=" + Session["slt_customer"] + "','', ' width=350,height=350');\" value='who?' " + Session["button_style"] + ">");
	}
	else
		Response.Write("&nbsp;<input type=hidden name=customer value=1>");
	Response.Write("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a title='view terms and conditions' href=\"javascript:terms_window=window.open('repair_terms.aspx','','width=550, height=650'); terms_window.focus()\" class=o >*<b>Terms Conditions</a>");
	Response.Write("</b></td></tr>");
	
	//Response.Write("<tr><td colspan=3 align=left><input type=submit value='Today\"s Date : ' "+Session["button_style"] +"> &nbsp;"+DateTime.UtcNow.AddHours(12).ToString()+" </th>");
	Response.Write("<tr><td colspan=3 align=left></th>");
	Response.Write("<td colspan=2 align=right><font color=red>*notice: all the Red fields are Mandatory</font></td>");
	string s_invoice = "";
	string s_sn = "";
	string s_code = "";
	string s_pur_date = "";
	string s_description = "";
	string s_fault = "";
	string s_supplier_id = "";
	string s_supplier_code = "";
	//string s_invoice = "";
	bool bChecked = true;
	int nNumber = 1;
	if(Request.QueryString["slt"] != null)
		nNumber = int.Parse(Request.QueryString["slt"]);
	Response.Write("<input type=hidden name='hide_row' value="+ nNumber +">");
	for(int i=0; i < m_selected; i++)
	{
		Response.Write("<tr bgcolor=#BBBEEE>");
		Response.Write("<th>ITEM#</th>");
		Response.Write("<th align=left>SN#</th>");
		Response.Write("<th align=left>INVOICE#</th>");
		Response.Write("<th align=left>PURCHASE DATE#</th>");
		Response.Write("<th align=left>CODE#</th>");
		//Response.Write("<th><font color=red>Description</font></th></tr>");
		Response.Write("<tr bgcolor=#E3E3E3>");
		
		if(Request.Form["sn"+i.ToString()] != null)
		{
			s_sn = Request.Form["sn"+i.ToString()];
			s_pur_date = Request.Form["inv_date"+i.ToString()];
			s_invoice = Request.Form["invoice"+i.ToString()];
			s_code = Request.Form["code"+i.ToString()];
			s_fault = Request.Form["fault"+i.ToString()];
			s_description = Request.Form["description"+i.ToString()];
			s_supplier_code = Request.Form["hide_supplier_code"+i.ToString()];
			s_supplier_id = Request.Form["hide_supplier_id"+i.ToString()];
			dr = CheckSN(s_sn, s_invoice);
			if(dr != null)
			{
				s_sn = dr["sn"].ToString();
				s_pur_date = dr["commit_date"].ToString();
				s_description = dr["name"].ToString();
				s_invoice = dr["invoice_number"].ToString();
				if(s_invoice == "")
					s_invoice = dr["invoice_number2"].ToString();
				s_code = dr["code"].ToString();
				s_supplier_id = dr["supplier_id"].ToString();
				s_supplier_code = dr["supplier_code"].ToString();
			}
		}
		Response.Write("<input type=hidden name='hide_supplier_id"+i.ToString() +"' value='"+ s_supplier_id +"'>");
		Response.Write("<input type=hidden name='hide_supplier_code"+i.ToString() +"' value='"+ s_supplier_code +"'>");
		Response.Write("<th>"+(i+1)+".</th><td><input type=text name='sn"+ i.ToString() +"' value='"+ s_sn.ToUpper() +"'></td>");
		Response.Write("<td><input type=text name='invoice"+ i.ToString() +"' value='"+ s_invoice +"'></td>");
		Response.Write("<td><input type=text name='inv_date"+ i.ToString() +"' value='"+ s_pur_date +"'>");
		Response.Write("<input type=button value='...' "+ Session["button_style"] +" ");
		Response.Write(" onclick=\"javascript:calendar_window=window.open('calendar.aspx?formname=frm.inv_date"+i.ToString()+"','calendar_window','width=190,height=230');calendar_window.focus()\"></td>");
		Response.Write("<td size=10%><input type=text name='code"+ i.ToString() +"'value='"+ s_code +"' ></td>");
		Response.Write("</tr>");
		//Response.Write("<td colspan=2><textarea name='description"+ i.ToString() +"' value='"+ s_invoice +"'></textarea></td></tr>");
		Response.Write("<tr bgcolor=#E3E3E3><th colspan=2 align=right><font color=red>DESCRIPTION : </font></th><td colspan=3><input type=text size=50% name='description"+ i.ToString() +"' value='"+ s_description +"'></td></tr>");
		Response.Write("<tr bgcolor=#E3E3E3><th colspan=2 align=right><font color=red>FAULT DETAILS : </font></th><td colspan=3><textarea rows=4 cols=50 name='fault"+ i.ToString() +"' >"+ s_fault +"</textarea></td></tr>");
		
	}

	Response.Write("<tr><th colspan=5 align=right><input type=submit name=cmd value='Apply for RA Number' "+Session["button_style"]+"  ");
	Response.Write(" onclick='return chkValid()' ");
	Response.Write(">");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=5>"+ repair_warranty_note +"</td></tr>");
	Response.Write("</table>");
	Response.Write("</form>");

	return true;
}

bool autoSendMail()
{
	
	string mTo = Session["email"].ToString();
	string mFrom = GetSiteSettings("service_email", "alert@ezsoft.com");
	string mSubject= "Repair Job with " + m_sCompanyTitle;
	
	SendEmail(mFrom, mFrom, mTo, mSubject, "");

	//cc to itself
	mTo = GetSiteSettings("service_email", "alert@ezsoft.com");
	mSubject = "New Repair Job ";
	SendEmail(mFrom, mFrom, mTo, mSubject, "");
	return true;
	
	
}



</script>
<asp:Label id=LFooter runat=server/>
