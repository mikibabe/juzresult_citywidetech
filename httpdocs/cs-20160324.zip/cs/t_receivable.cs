<!-- #include file="page_index.cs" -->

<script runat=server>

string m_branchID = "1";
string m_click = "1";
string listed = "";
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

void Page_Load(Object Src, EventArgs E) 
{
	TS_PageLoad(); //do common things, LogVisit etc...

	if(!SecurityCheck("accountant"))
		return;
	if(Session["branch_support"] != null)
	{
		if(Request.Form["branch"] != null)
			m_branchID = Request.Form["branch"];
		else if(Request.QueryString["_b"] != null && Request.QueryString["_b"] != "")
			m_branchID = Request.QueryString["_b"];
		else if(Session["branch_id"] != null)
			m_branchID = Session["branch_id"].ToString();
	}
//DEBUG("m_branchid =", m_branchID);	
	if(!getTotalDue())
		return;
	if(Request.QueryString["print"] == "sum")
	{
		printSummary();
	}
	else
	{
		InitializeData();
		BindTotalDueGrid();
	}
	
}

void printSummary()
{
//	Response.Write("<hmtl><body onload=\"window.print(); return confirm('Close this windows!!');\">");
	Response.Write("<hmtl><body onload=\"window.print(); \">");
	
	Response.Write("<table width=99% align=center cellspacing=1 cellpadding=1 border=0 bordercolor=gray bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	if(Request.QueryString["listed"] == "")
		listed = "ALL";
	else
		listed = Request.QueryString["listed"];
	Response.Write("<tr><th><h4>Receivable Summary for "+(listed).ToUpper()+" </h4></tr>");
	Response.Write("<tr><td>" + m_sCompanyTitle +"</td></tr>");
	if(Session["branch_support"] != null)
	{
		Response.Write("<tr><td>Branch: ");
		PrintBranchNameOptions(m_branchID);
	}
	Response.Write("</td></tr>");
	Response.Write("<tr><td>Requested By: "+ Session["name"].ToString() + "</td></tr>");
	Response.Write("<tr><td>Created Date: "+ DateTime.UtcNow.AddHours(12).ToString("dd/MMM/yyyy") + "</td></tr>");
	Response.Write("</table>");
	Response.Write("<table width=99% align=center cellspacing=1 cellpadding=1 border=0 bordercolor=gray bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	
	Response.Write("<tr align=left bgcolor=#CDDDDF><th>CUSTID#</th>");
	Response.Write("<th>COMPANY</th>");
	Response.Write("<th nowrap>CREDIT TERM</th>");
	Response.Write("<th align=right>TOTAL DUE</th>");
	Response.Write("<th align=right>CURRENT</th>");
	Response.Write("<th align=right>30Days</th>");
	Response.Write("<th align=right>60Days</th>");
	Response.Write("<th align=right>90Days+</th><th align=right>TOTAL CREDITS</th></tr>");

	int rows = dst.Tables["total_due"].Rows.Count;

	bool bAlter = true;
	DataRow dr ;
	double dSub_total_due = 0;
	double dSub_current_due = 0;
	double dSub_30days = 0;
	double dSub_60days = 0;
	double dSub_90days = 0;
	double dSub_total_credit = 0;
	Response.Write("<tr><td colspan=10><hr size=1 color=black</td></tr>");
	for(int m=0; m<rows; m++)
	{
		
		dr = dst.Tables["total_due"].Rows[m];
		string credit_term = dr["credit_term"].ToString();
		string company = dr["company"].ToString();
		if(company == "")
			company = dr["name"].ToString();
		string card_id = dr["id"].ToString();
		string total_due = dr["totaldue"].ToString();
		string days30 = dr["Days30"].ToString();
		string days60 = dr["Days60"].ToString();
		string days90 = dr["Days90"].ToString();
		string current_due = dr["current_due"].ToString();
		string total_credit = dr["total_credit"].ToString();

		if(total_credit == null || total_credit == "")
			total_credit = "0";
		if(total_due == null || total_due == "")
			total_due = "0";
		if(days30 == null || days30 == "")
			days30 = "0";
		if(days60 == null || days60 == "")
			days60 = "0";
		if(days90 == null || days90 == "")
			days90 = "0";
		if(current_due == null || current_due == "")
			current_due = "0";
		
		Response.Write("<tr ");
		if(bAlter)
			Response.Write(" bgcolor=#EEEEEE ");

		string stotal_due = "";
		string scurrent_due = "";
		string sdays30 = "";
		string sdays60 = "";
		string sdays90 = "";
		string stotal_credit = "";

		double dtotal_due = MyDoubleParse(total_due);
		double dcurrent_due = Math.Round(MyDoubleParse(current_due), 2);
		double ddays30 = MyDoubleParse(days30);
		double ddays60 = MyDoubleParse(days60);
		double ddays90 = MyDoubleParse(days90);
		double dtotal_credit = MyDoubleParse(total_credit);
		if(dtotal_due != 0)
			stotal_due = dtotal_due.ToString("c");
		if(dcurrent_due != 0)
			scurrent_due = dcurrent_due.ToString("c");
		if(ddays30 != 0)
			sdays30 = ddays30.ToString("c");
		if(ddays60 != 0)
			sdays60 = ddays60.ToString("c");
		if(ddays90 != 0)
			sdays90 = ddays90.ToString("c");
		if(dtotal_credit != 0)
			stotal_credit = dtotal_credit.ToString("c");

		bAlter = !bAlter;
		Response.Write(">");
		Response.Write("<td>" + card_id +"</td>"); 
		Response.Write("<th align=left>" + company +"</th>");
		Response.Write("<th align=left>" + credit_term +"</th>");
		Response.Write("<td align=right>" + stotal_due +"</td>");
		Response.Write("<td align=right>" + scurrent_due +"</td>");
		Response.Write("<td align=right>" + sdays30 +"</td>");
		Response.Write("<td align=right>" + sdays60 +"</td>");
		Response.Write("<td align=right>" + sdays90 +"</td>");
		Response.Write("<td align=right>" + stotal_credit +"</td>");
		Response.Write("</tr>");
		dSub_total_due += double.Parse(total_due);
		dSub_current_due += double.Parse(current_due);
		dSub_30days += double.Parse(days30);
		dSub_60days += double.Parse(days60);
		dSub_90days += double.Parse(days90);
		dSub_total_credit += double.Parse(total_credit);
	}
	
	Response.Write("<tr><td colspan=10>&nbsp;</td></tr>");
	Response.Write("<tr><td colspan=10><hr size=1 color=black</td></tr>");
	Response.Write("<tr><th colspan=3 align=right>Sub Total:</th><th align=right> "+dSub_total_due.ToString("c")+"</th>");
	Response.Write("<th align=right> "+dSub_current_due.ToString("c")+"</th>");
	Response.Write("<th align=right> "+dSub_30days.ToString("c")+"</th>");
	Response.Write("<th align=right> "+dSub_60days.ToString("c")+"</th>");
	Response.Write("<th align=right> "+dSub_90days.ToString("c")+"</th>");
	Response.Write("<th align=right> "+dSub_total_credit.ToString("c")+"</th></tr>");
	
	Response.Write("<tr><th align=right colspan=3>Ageing Percent:</th><th align=left> &nbsp;</th>");
	Response.Write("<th align=right> "+((dSub_current_due / dSub_total_due)).ToString("p")+"</th>");
	Response.Write("<th align=right> "+((dSub_30days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<th align=right> "+((dSub_60days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<th align=right> "+((dSub_90days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<th align=right> "+((dSub_total_credit / dSub_total_due) ).ToString("p")+"</th></tr>");
	

	Response.Write("<tr><td colspan=10>&nbsp;</td>");
	Response.Write("</tr>");
	Response.Write("</body></html>");
	Response.Write("</table>");
}

void BindTotalDueGrid()
{
	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
	
	int rows = dst.Tables["total_due"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.PageSize = 35;
	string sorted = "";
	if(Request.QueryString["sorted"] != null && Request.QueryString["sorted"] != "")
		sorted = Request.QueryString["sorted"].ToString();
	if(Request.QueryString["listed"] != "" && Request.QueryString["listed"] != null)
		listed = Request.QueryString["listed"].ToString();

	m_cPI.URI ="?listed="+ listed +"&sorted="+ sorted +"";
		int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	Response.Write("<form name=f method=post>");
	Response.Write("<br>");
	string search = "";
	if(Request.Form["search"] != "" && Request.Form["search"] != null)
		search = Request.Form["search"].ToString();
	string URI = "t_receivable.aspx?p="+ m_cPI.CurrentPage +"";
	if(m_branchID != "")
		URI += "&branch="+ m_branchID;
	URI += "&sorted=";
	
	Response.Write("<table width=99% align=center cellspacing=0 cellpadding=2 border=0 bordercolor=white bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><th><h4>Receivable Summary</h4></tr>");
	if(Session["branch_support"] != null)
	{
		//URI += "&branch=";
		Response.Write("<font size=2>Branch : </font>");
		PrintBranchNameOptions(m_branchID, "t_receivable.aspx?p="+ m_cPI.CurrentPage +"&branch=");
	}
	Response.Write("<tr><th align=left>" + m_sCompanyTitle +"</th></tr>");
	Response.Write("<tr><td>Requested By: "+ Session["name"].ToString() + "</td></tr>");
	Response.Write("<tr><td>Created Date: "+ DateTime.UtcNow.AddHours(12).ToString("dd/MMM/yyyy") + "</td></tr>");
	Response.Write("</table>");
	Response.Write("<table width=99% align=center cellspacing=1 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=11><input type=text name=search value='"+ search +"'><input type=submit value='Search Customer' "+Session["button_style"] +">");
	Response.Write("&nbsp;&nbsp;<a title='click to list by dealer' href='"+URI+sorted+"&click="+m_click+"&listed=dealer' class=o>Dealer</a>|");
	Response.Write("<a title='click to list by customer' href='"+URI+sorted+"&click="+m_click+"&listed=customer' class=o>Customer</a>|");
	Response.Write("<a title='click to list by all' href='"+URI+sorted+"&click="+m_click+"&listed=all' class=o>All</a>");
	Response.Write("</td>");
	Response.Write("<td colspan=4 align=right><input type=button value='Print Summary' "+Session["button_style"] +" ");
	Response.Write(" onclick=\"javascript:summary_window=window.open('t_receivable.aspx?print=sum&listed="+Request.QueryString["listed"]+"&sorted=" + Request.QueryString["sorted"] + "&branch="+ m_branchID +"');\" '', ''></td></tr>");
	
	Response.Write("<tr class=tableHeader><th align=left><a title='click to sort by card id' href='"+URI+"card_id&click="+m_click+"&listed="+listed+"' class=o>CID#</a></th>");
	Response.Write("<th><a title='click to sort by company' href='"+URI+"c.company&click="+m_click+"&listed="+listed+"' class=o>COMPANY</a></th>");
	Response.Write("<th><a title='click to sort by credit term' href='"+URI+"credit_term&click="+m_click+"&listed="+listed+"' class=o>CREDIT TERM</a></th>");
	Response.Write("<th colspan=2><a title='click to sort by total due' href='"+URI+"totaldue&click="+m_click+"&listed="+listed+"' class=o>TOTAL DUE</a></th>");
	Response.Write("<th colspan=2><a title='click to sort by current due' href='"+URI+"current_due&click="+m_click+"&listed="+listed+"' class=o>CURRENT</a></th>");
	Response.Write("<th colspan=2><a title='click to sort by 30 days' href='"+URI+"Days30&click="+m_click+"&listed="+listed+"' class=o>30Days</a></th>");
	Response.Write("<th colspan=2><a title='click to sort by 60 days' href='"+URI+"Days60&click="+m_click+"&listed="+listed+"' class=o>60Days</a></th>");
	Response.Write("<th colspan=2><a title='click to sort by 90 days' href='"+URI+"Days90&click="+m_click+"&listed="+listed+"' class=o>90Days+</a></th>");
	Response.Write("<th ><a title='click to sort by total credit' href='"+URI+"total_credit&click="+m_click+"&listed="+listed+"' class=o>TOTAL CREDIT</a></th></tr>");
	
	bool bAlter = true;
	DataRow dr ;
	double dSub_total_due = 0;
	double dSub_current_due = 0;
	double dSub_30days = 0;
	double dSub_60days = 0;
	double dSub_90days = 0;
	double dSub_total_credit = 0;

	double d_total_due = 0;
	double d_current_due = 0;
	double d_30days = 0;
	double d_60days = 0;
	double d_90days = 0;
	double d_total_credit = 0;

	for(int j=0; j<rows; j++)
	{
		dr = dst.Tables["total_due"].Rows[j];
		dSub_total_due += MyDoubleParse(dr["totaldue"].ToString());
		dSub_30days += MyDoubleParse(dr["Days30"].ToString());
		dSub_60days += MyDoubleParse(dr["Days60"].ToString());
		dSub_90days += MyDoubleParse(dr["Days90"].ToString());
		dSub_current_due += MyDoubleParse(dr["current_due"].ToString());
		dSub_total_credit += MyDoubleParse(dr["total_credit"].ToString());

	}
	
	for(; i < rows && i < end; i++)
	{
		dr = dst.Tables["total_due"].Rows[i];
		string company = dr["company"].ToString();
		if(company == "")
			company = dr["name"].ToString();
		string credit_term = dr["credit_term"].ToString();
		string card_id = dr["id"].ToString();
		string total_due = dr["totaldue"].ToString();
		string days30 = dr["Days30"].ToString();
		string days60 = dr["Days60"].ToString();
		string days90 = dr["Days90"].ToString();
		string current_due = dr["current_due"].ToString();
		string total_credit = dr["total_credit"].ToString();
		
		if(total_credit == null || total_credit == "")
			total_credit = "0";
		if(total_due == null || total_due == "")
			total_due = "0";
		if(days30 == null || days30 == "")
			days30 = "0";
		if(days60 == null || days60 == "")
			days60 = "0";
		if(days90 == null || days90 == "")
			days90 = "0";
		if(current_due == null || current_due == "")
			current_due = "0";
		
		string stotal_due = "";
		string scurrent_due = "";
		string sdays30 = "";
		string sdays60 = "";
		string sdays90 = "";
		string stotal_credit = "";

		double dtotal_due = MyDoubleParse(total_due);
		double dcurrent_due = Math.Round(MyDoubleParse(current_due), 2);
		double ddays30 = MyDoubleParse(days30);
		double ddays60 = MyDoubleParse(days60);
		double ddays90 = MyDoubleParse(days90);
		double dtotal_credit = MyDoubleParse(total_credit);
		if(dtotal_due != 0)
			stotal_due = dtotal_due.ToString("c");
		if(dcurrent_due != 0)
			scurrent_due = dcurrent_due.ToString("c");
		if(ddays30 != 0)
			sdays30 = ddays30.ToString("c");
		if(ddays60 != 0)
			sdays60 = ddays60.ToString("c");
		if(ddays90 != 0)
			sdays90 = ddays90.ToString("c");
		if(dtotal_credit != 0)
			stotal_credit = dtotal_credit.ToString("c");

		Response.Write("<tr ");
		if(bAlter)
			Response.Write(" class=rowColor");
		
		bAlter = !bAlter;
		string statement = "";
		if(dtotal_due > 0)
			statement = "statement.aspx?ci="+card_id+"&t=vd&p=4";
		if(dcurrent_due > 0)
			statement = "statement.aspx?ci="+card_id+"&t=vd&p=0";
		if(ddays30 > 0)
			statement = "statement.aspx?ci="+card_id+"&t=vd&p=1";
		if(ddays60 > 0)
			statement = "statement.aspx?ci="+card_id+"&t=vd&p=2";
		if(ddays90 > 0)
			statement = "statement.aspx?ci="+card_id+"&t=vd&p=3";

		Response.Write(">");
		Response.Write("<td><a title='click to edit card list' href='ecard.aspx?id="+card_id+"' target=blank class=o>" + card_id +"</a></td>"); 
		Response.Write("<td>");
		Response.Write(" <input type=button title='view customer details' onclick=\"javascript:viewcard_window=window.open('viewcard.aspx?");
		Response.Write("id=" + card_id + "','',' width=350,height=350');\" style='font-size: 7pt' value='who?' " + Session["button_style"] + ">&nbsp;");
		//Response.Write("<a title='view customer details' href=\"javascript:viewcard_window=window.open('viewcard.aspx?");
		//Response.Write("id=" + card_id + "','',' width=350,height=350');viewcard_window.focus();\" class=o><font color=purple>VW</font></a> ");
		Response.Write(company);
		Response.Write("</td><td>" + credit_term + "</td>");
		Response.Write("<td align=right >" + stotal_due +"</td>");
		if(double.Parse(total_due) > 0)
		{
			Response.Write("<td ><a title='print total due statement' href='"+statement+"' class=o target=blank>S</a>");
			Response.Write("&nbsp;<a title='Email to Customer' href='broadmail.aspx?ci="+card_id+"&t=m' class=o target=blank>E</a></td>");
		}
		else
			Response.Write("<td>&nbsp;</td>");
		Response.Write("<td align=right >" + scurrent_due +"</td>");
		if(double.Parse(current_due) > 0)
			Response.Write("<td><a title='print current due statement' href='"+statement+"' class=o target=blank>S</a>");
		else
			Response.Write("<td>&nbsp;</td>");
		Response.Write("<td align=right >" + sdays30 +"</td>");
		if(double.Parse(days30) > 0)
			Response.Write("<td><a title='print 30 days statement' href='"+statement+"' class=o target=blank>S</a>");
		else
			Response.Write("<td>&nbsp;</td>");
		Response.Write("<td align=right >" + sdays60 +"</td>");
		if(double.Parse(days60) > 0)
			Response.Write("<td><a title='print 60 days statement' href='"+statement+"' class=o target=blank>S</a>");
		else
			Response.Write("<td>&nbsp;</td>");
		Response.Write("<td align=right >" + sdays90 +"</td>");
		if(double.Parse(days90) > 0)
			Response.Write("<td><a title='print 90 days statement' href='"+statement+"' class=o target=blank>S</a>");
		else
			Response.Write("<td>&nbsp;</td>");

		if(dtotal_credit > 0 && dtotal_due > 0)
			Response.Write("<td align=right ><font color=Green><a title='click to apply credit' href='custpay.aspx?id="+card_id+"' class=o target=blank>"); // + double.Parse(total_credit).ToString("c") +"</font></td>");
		else
			Response.Write("<td align=right >");
		Response.Write(""+ stotal_credit +"</a></td>");
		Response.Write("</tr>");

		d_total_due += dtotal_due;
		d_current_due += dcurrent_due;
		d_30days += ddays30;
		d_60days += ddays60;
		d_90days += ddays90;
		d_total_credit += dtotal_credit;
	
	}
	
	Response.Write("<tr><th colspan=3 align=right> TOTAL:</th><th align=right> "+(d_total_due - d_total_credit).ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+(d_current_due).ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+d_30days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+d_60days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+d_90days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+d_total_credit.ToString("c")+"</th></tr>");

	Response.Write("<tr><td colspan=14><hr size=1 color=#eeeeee></td></tr>");
	Response.Write("<tr><th colspan=3 align=right>SUB_TOTAL:</th><th align=right> "+(dSub_total_due - dSub_total_credit).ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+dSub_current_due.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+dSub_30days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+dSub_60days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+dSub_90days.ToString("c")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+dSub_total_credit.ToString("c")+"</th></tr>");

	Response.Write("<tr><th colspan=3 align=right>AGEING (%):</th><th align=left> &nbsp;</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+((dSub_current_due / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+((dSub_30days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+((dSub_60days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+((dSub_90days / dSub_total_due) ).ToString("p")+"</th>");
	Response.Write("<td>&nbsp;</td><th colspan=1 align=right > "+((dSub_total_credit / dSub_total_due) ).ToString("p")+"</th></tr>");

	Response.Write("<tr><td colspan=12>");
	Response.Write(sPageIndex);
	Response.Write("</td>");
	
	Response.Write("<td colspan=4 align=right><input type=button value='Print Summary' "+Session["button_style"] +" ");
	Response.Write(" onclick=\"javascript:summary_window=window.open('t_receivable.aspx?print=sum&listed="+Request.QueryString["listed"]+"&branch="+ m_branchID +"');\" '', ''></td>");
	Response.Write("</tr>");

	Response.Write("</form>");
	Response.Write("</table>");
}

bool getTotalDue()
{

	string sc = "SELECT c.id, i.card_id, c.trading_name, c.name, c.balance, c.company, ";
	sc += " (SELECT name FROM enum WHERE class='credit_terms' AND id = (SELECT credit_term FROM card WHERE id = i.card_id OR id = t.card_id) ) AS credit_term, ";
	sc += " (SELECT  SUM(amount-amount_applied) AS totalcredit FROM credit ";
//    sc += " WHERE card_id = i.card_id) AS total_credit, ";
	sc += " WHERE card_id = t.card_id) AS total_credit, ";
	sc += "  (SELECT ISNULL((SUM(total-amount_paid)),0) AS  totalall ";
	sc += " FROM invoice  ";
	sc += "  WHERE card_id = i.card_id) AS 'totaldue', ";

	sc += "  (SELECT ISNULL(SUM(total-amount_paid),0) AS totalcur FROM invoice ";
	sc += "  WHERE card_id = i.card_id AND datediff(month, commit_date, getdate()) = 0) AS 'current_due', ";
	sc += "  (SELECT ISNULL(SUM(total-amount_paid),0) AS total30 FROM invoice ";
	sc += "  WHERE card_id = i.card_id AND datediff(month, commit_date, getdate()) = 1) AS 'Days30', ";
	sc += "  (SELECT ISNULL(SUM(total-amount_paid),0) AS total60 FROM invoice ";
	sc += "  WHERE card_id = i.card_id AND datediff(month, commit_date, getdate()) = 2) AS 'Days60', ";
	sc += "  (SELECT ISNULL(SUM(total-amount_paid),0) AS total90 FROM invoice ";
	sc += "  WHERE card_id = i.card_id AND datediff(month, commit_date, getdate()) >= 3) AS 'Days90' ";
	
//	sc += " FROM invoice i INNER JOIN card c ON c.id = i.card_id ";
	sc += " FROM card c LEFT OUTER JOIN invoice i ON c.id = i.card_id ";
	sc += " LEFT OUTER JOIN credit t ON t.card_id = c.id ";
//	sc += " WHERE (i.card_id IS NOT NULL) ";
//	sc += " AND (total IS NOT NULL) ";
	sc += " WHERE 1=1 ";
	if(Request.Form["search"] != "" && Request.Form["search"] != null)
	{
		if(TSIsDigit(Request.Form["search"]))
			sc += " AND c.id = " + Request.Form["search"].ToString() + " ";
		//	sc += " AND i.card_id = " + Request.Form["search"].ToString() + " ";
		else
		{
			sc += " AND (c.name LIKE '%"+ Request.Form["search"].ToString() + "%' OR c.company LIKE '%"+ Request.Form["search"].ToString() + "%'";
			sc += " OR c.trading_name LIKE '%"+ Request.Form["search"].ToString() + "%') ";
		}
	}
	if(Request.QueryString["listed"] != "" && Request.QueryString["listed"] != null)
	{
		if(Request.QueryString["listed"] == "customer")
			sc += " AND c.type = 1 ";
		else if(Request.QueryString["listed"]== "dealer")
			sc += " AND c.type = 2 ";
		else
			sc += "";
	}	
	if(Session["branch_support"] != null)
		sc += " AND i.branch = "+ m_branchID;
	
	sc += " GROUP BY t.card_id, c.id, i.card_id, c.name, c.company, c.trading_name, c.balance ";
//	sc += " HAVING (SUM(i.total - i.amount_paid) > 0) ";
	sc += " HAVING (SUM(i.total - i.amount_paid) > 0 OR SUM(i.total - i.amount_paid) < 0) OR (SUM(t.amount - t.amount_applied) > 0) ";
	if(Request.QueryString["sorted"] != null && Request.QueryString["sorted"] != "")
	{	
		if(Request.QueryString["click"] == "1")
		{
			sc += "ORDER BY "+Request.QueryString["sorted"].ToString()+ " ASC ";
			m_click = "0";
		}
		else
		{
			sc += "ORDER BY "+Request.QueryString["sorted"].ToString()+ " DESC ";
			m_click = "1";
		}
	}
	else
		sc += "ORDER BY totaldue, total_credit DESC ";
//DEBUG("sc =", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "total_due");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;

}

</script>

<asp:Label id=LFooter runat=server/>
