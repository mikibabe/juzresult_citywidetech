<!-- #include file="fifo_f.cs" -->
<!-- #include file="page_index.cs" -->

<script runat=server>

string m_branchID = "1";
bool m_bAllBranchs = false;

DataSet dst = new DataSet();
string m_staffName = "";
string m_staffID = "";

string m_stockManagerID = "";
string m_stockManagerName = "";
string m_stockManagerPass = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck(""))
		return;

	if(!GetStockManager())
		return;

	if(Session["branch_support"] != null)
	{
		if(Request.QueryString["b"] != null && Request.QueryString["b"] !="")
		{
			m_branchID = Request.QueryString["b"];
			if(m_branchID == "all")
				m_bAllBranchs = true;
		}
		else if(Session["branch_id"] != null)
		{
			m_branchID = Session["branch_id"].ToString();
		}
		if(Request.Form["branch"] != null && Request.Form["branch"] != "")
			m_branchID = Request.Form["branch"];
	}

	if(Request.Form["staff"] != null)
	{
		Session["borrow_staff"] = Request.Form["staff"];
	}
	if(Session["borrow_staff"] != null)
	{
		m_staffID = Session["borrow_staff"].ToString();
		m_staffName = TSGetUserNameByID(m_staffID);
	}

	if(Request.Form["mpass"] != null)
	{
		if(DoBorrowLogin())
		{
			string par = Request.Form["url"];
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=borrow.aspx?" + par + "\">");
		}
		return;
	}

	switch(Request.Form["cmd"])
	{
	case "Borrow":
		if(DoBorrowItem())
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=borrow.aspx?t=borrowok\">");
			return;
		}
		PrintNewBorrowForm();
		return;
	case "Search":
		PrintBorrowList();
		return;
	case "Return":
		if(DoReturnBorrowed())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=borrow.aspx?t=returned\">");
		return;
	default:
		break;
	}

	if(Request.Form["sn"] != null)
	{
		if(!DoBorrowScanSN())
			PrintNewBorrowForm();
		return;
	}
	if(Request.Form["kw"] != null)
	{
		PrintBorrowList();
		return;
	}

	string t = Request.QueryString["t"];
	if(t == "list")
	{
		PrintBorrowList();
		return;
	}
	else if(t == "returned")
	{
		PrintBorrowHeader();
		Response.Write("<br><br><h4><font color=green>Done, recorded.</font></h4>");
		Response.Write("<input type=button value=Done onclick=window.location=('borrow.aspx?t=end') class=b>");
		PrintBorrowFooter();
		return;
	}
	else if(t == "borrowok")
	{
		PrintBorrowOKPage();
	}
	else if(t == "end")
	{
		Session["stock_manager_loggedin"] = null;
		Session["borrow_staff"] = null;
		PrintWelcomePage();
		return;
	}
	else if(t != "borrow" && t != "return")
	{
		PrintWelcomePage();
		return;
	}

	if(Session["stock_manager_loggedin"] == null)
	{
		if(Session[m_sCompanyName + "AccessLevel"].ToString() == "6")
			Session["stock_manager_loggedin"] = true;
		else
			PrintLoginForm();
		return;
	}

	if(t == "borrow")
	{
		PrintNewBorrowForm();
	}
	else if(t == "return")
	{
		PrintReturnForm();
		return;
	}
}

void PrintWelcomePage()
{
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<br><br><br><center><h3>Borrow Stock</h3>");

	Response.Write("<br>");

	Response.Write("<input type=button value='New Borrow' onclick=window.location=('borrow.aspx?t=borrow') class=b>");
	Response.Write("<br>");
	Response.Write("<br>");

	Response.Write("<input type=button value='Return Item' onclick=window.location=('borrow.aspx?t=list') class=b>");
	Response.Write("<br>");
	Response.Write("<br>");

	Response.Write("<input type=button value='Borrowed Item List' onclick=window.location=('borrow.aspx?t=list') class=b>");
	Response.Write("<br>");
	Response.Write("<br>");

	PrintBorrowFooter();
}

void PrintBorrowHeader()
{
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<center><h4>Borrow Stock</h4>");
	Response.Write("<form name=f action=? method=post>");

	string t = Request.QueryString["t"];
	if(Session["branch_support"] != null & t != "return" && t != "returned")
		Response.Write("<b>Branch : </b>" + BorrowPrintBranchOptions(m_branchID));

}

void PrintBorrowFooter()
{
	Response.Write("<br><br><br>");
	Response.Write("<a href=borrow.aspx class=o title='home'>Home</a> &nbsp&nbsp; ");
	Response.Write("<a href=borrow.aspx?t=list class=o title='list borrowed itms'>Borrowed List</a> &nbsp&nbsp; ");
	Response.Write("<a href=borrow.aspx?t=borrow class=o title='borrow item'>New Borrow</a> &nbsp&nbsp; ");
	Response.Write("<a href=borrow.aspx?t=list class=o title='return borrowed item'>Return Borrowed</a>");
	PrintAdminFooter();
}

void PrintLoginForm()
{
	PrintBorrowHeader();

	Response.Write("<br><br><br>");
	Response.Write("<table cellspacing=10>");
//	Response.Write("<tr><td colspan=2><b>Only Staff can borrow stock, please select your account and enter password.</b></td></tr>");

//	Response.Write("<tr><td align=right><b>Borrower (staff only) : </b></td>");
//	Response.Write("<td><select name=staff>" + PrintStaffOptions() + "</select></td></tr>");
	Response.Write("<tr><td align=right><b>Stock Manager : </b></td><td>" + m_stockManagerName + "</td></tr>");
	Response.Write("<input type=hidden name=mpass value='" + m_stockManagerPass + "'>");
	Response.Write("<tr><td align=right><b>Password : </b></td><td><input type=password name=password></td></tr>");
	Response.Write("<script language=javascript>document.f.password.focus();</script");
	Response.Write(">");
	Response.Write("<tr><td colspan=2 align=center><input type=submit name=cmd value=' Go ' class=b>");
	Response.Write("</td></tr>");
	Response.Write("</table>");

	Response.Write("<input type=hidden name=url value='" + Request.ServerVariables["QUERY_STRING"] + "'>");
	Response.Write("</form>");

	PrintBorrowFooter();
}

void PrintNewBorrowForm()
{
	PrintBorrowHeader();

	string sn = "";
	string code = "";
	string name = "";
	string qty = "1";
	if(Request.QueryString["scan"] == "1")
	{
		sn = Request.QueryString["sn"];
		if(Request.QueryString["code"] != null) //found
		{
			code = Request.QueryString["code"];
			name = Request.QueryString["name"];
		}
	}

	Response.Write("<b> to </b><select name=staff>" + PrintStaffOptions() + "</select><br><br>");
	Response.Write("<table width=450 cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td><b>S/N</b></td><td><input type=text size=40 name=sn value='" + sn + "'>");
	Response.Write("<input type=submit name=cmd value=Scan class=b>");
	Response.Write("<input type=button value=Reset class=b onclick=window.location=('borrow.aspx?t=borrow')>");
	Response.Write("</td></tr>");
	Response.Write("<tr><td><b>Code</b></td><td><input type=text size=40 name=code value='" + code + "'></td></tr>");
	Response.Write("<tr><td><b>Name</b></td><td><input type=text size=40 name=name value='" + name + "'></td></tr>");
	Response.Write("<tr><td><b>Qty</b></td><td><input type=text size=40 name=qty value='" + qty + "'></td></tr>");
	Response.Write("<tr><td colspan=2><b>Note : </td></tr>");
	Response.Write("<tr><td colspan=2><textarea name=borrow_note rows=5 cols=40></textarea></td></tr>");
	Response.Write("<tr><td colspan=2 align=right>");
	Response.Write("<input type=submit name=cmd value=Borrow class=b>");
	Response.Write("<input type=button value=Cancel onclick=window.location=('borrow.aspx?t=end') class=b>");
	Response.Write("</td></tr>");
	Response.Write("</table>");
	Response.Write("</form>");
	Response.Write("<script language=javascript");
	Response.Write(">document.f.sn.focus();</script");
	Response.Write(">");

	ListMyBorrowed();

	PrintBorrowFooter();
}

bool ListMyBorrowed()
{
	return true;
}

string PrintStaffOptions()
{
	string sc = " SELECT id, name, email FROM card WHERE type=4 ORDER BY name";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "staff");
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return "";
	}

	StringBuilder sb = new StringBuilder();
	for(int i=0; i<dst.Tables["staff"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["staff"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		string email = dr["email"].ToString();
		if(name == "")
			name = email;
		sb.Append("<option value=" + id);
		if(id == m_staffID)
			sb.Append(" selected");
		sb.Append(">" + name + "</option>");
	}
	return sb.ToString();
}

bool DoBorrowScanSN()
{
	int nRows = 0;
	string sn = Request.Form["sn"];
	string scode = Request.Form["code"];
	string sc = " SELECT c.code, c.name ";
	sc += " FROM stock s JOIN code_relations c ON c.code=s.product_code ";
	sc += " WHERE ";
	if(sn != "")
		sc += " s.sn = '" + EncodeQuote(sn) + "' ";
	else if(scode != "")
	{
		if(!TSIsDigit(scode))
		{
			Response.Write("<br><center><h4><font color=red>Invalid item code, must be a number</font></h4>");
			return false;
		}
		sc += " c.code = " + EncodeQuote(scode);
	}
	else
		return false;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		nRows = myAdapter.Fill(dst, "sn");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(nRows > 0)
	{
		DataRow dr = dst.Tables["sn"].Rows[0];
		string code = dr["code"].ToString();
		string name = dr["name"].ToString();
		if(name.Length > 100)
			name = name.Substring(0, 100);
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=borrow.aspx?t=borrow&scan=1");
		Response.Write("&sn=" + HttpUtility.UrlEncode(sn));
		Response.Write("&code=" + code + "&name=" + HttpUtility.UrlEncode(name));
		Response.Write("\">");
		return true;
	}
	else
	{
		Response.Write("<br><center><h4><font color=red>S/N or Code Not Found, please try again</font></h4>");
		return false;
	}
	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=borrow.aspx?t=borrow&scan=1");
	Response.Write("&sn=" + HttpUtility.UrlEncode(sn));
	Response.Write("\">");
	return false;
}

bool DoBorrowLogin()
{
	string password = Request.Form["password"];
	string hashP = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "md5");
	string mpass = Request.Form["mpass"];

/*	string sc = " SELECT password FROM card WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "login") <= 0)
		{
			MsgDie("Staff account not found.");
			return false;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}
	
	string dbpass = dst.Tables["login"].Rows[0]["password"].ToString();]
*/
	if(hashP == mpass)
	{
		Session["stock_manager_loggedin"] = true;
		return true;
	}

	Response.Write("<br><center><h4><font color=red>Wrong Password, please try again</font></h4>");
	PrintLoginForm();
	return false;
}

bool DoBorrowItem()
{
	string branch = m_branchID;
	string code = Request.Form["code"];

	DataRow drp = null;
	GetProduct(code, ref drp);
	if(drp == null)
	{
		PrintBorrowHeader();
		MsgDie("Item Not found. code : " + code);
		return false;
	}

	int qty = MyIntParse(Request.Form["qty"]);
	string sn = Request.Form["sn"];
	string name = Request.Form["name"];
	string note = Request.Form["borrow_note"];
	string staff = Session["borrow_staff"].ToString();

	string sc = " BEGIN TRANSACTION ";
	sc += " INSERT INTO borrow (branch, code, name, qty, sn, staff, borrow_note) VALUES(";
	sc += m_branchID;
	sc += ", " + code;
	sc += ", '" + EncodeQuote(name) + "' ";
	sc += ", " + qty; 
	sc += ", '" + EncodeQuote(sn) + "' ";
	sc += ", " + staff;
	sc += ", '" + EncodeQuote(note) + "' ";
	sc += ") ";

	//serial trace log
	if(sn != "")
		sc += AddSerialLogString(sn, "borrowed by " + m_staffName, "", "", "", "");

	//stock adjustment log
	sc += " INSERT INTO stock_adj_log (staff, code, qty, branch_id, note) VALUES(" + m_staffID;
	sc += ", " + code + ", " + (0 - qty).ToString() + ", " + m_branchID + ", 'Borrow for " + EncodeQuote(note) + "') "; 
	sc += " IF EXISTS(SELECT * FROM stock_qty WHERE code=" + code + ") ";
	sc += " UPDATE stock_qty SET qty = qty - " + qty + " WHERE code=" + code + " AND branch_id = " + m_branchID;
	sc += " ELSE ";
	sc += " INSERT INTO stock_qty (code, qty, branch_id) VALUES(" + code + ", " + (0 - qty).ToString() + ", " + m_branchID + ") ";
	sc += " SELECT IDENT_CURRENT('stock_adj_log') AS id ";
	sc += " COMMIT ";

	DataSet dsid = new DataSet();
	string new_id = "";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dsid, "id") != 1)
		{
			Response.Write("<br><center><h3>Error getting new stock adjustment log record ID");
			return false;
		}
		new_id = dsid.Tables["id"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	return fifo_RecordStockLoss(code, m_branchID, (0 - qty), new_id);
}

void PrintBorrowOKPage()
{
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<br><br><center><h4>Recorded, borrow more? </h4><br>");
	Response.Write("<input type=button value=' Yes ' onclick=window.location=('borrow.aspx?t=borrow') class=b> ");
	Response.Write("<input type=button value=' No ' onclick=window.location=('borrow.aspx?t=end') class=b>");
	Response.Write("</h4>");

	PrintAdminFooter();
}

bool PrintBorrowList()
{
	string sc = " SELECT b.*, c.name AS staff_name ";
	sc += " FROM borrow b JOIN card c ON c.id = b.staff ";
	sc += " WHERE 1=1 ";
	if(Session["branch_support"] != null && m_branchID != "all")
		sc += " AND branch = " + m_branchID;
	if(Request.Form["kw"] != null && Request.Form["kw"] != "")
	{
		string kw = EncodeQuote(Request.Form["kw"]);
		if(TSIsDigit(kw))
		{
			sc += " AND (b.code = " + kw + " OR b.sn LIKE '%" + kw + "%') ";
		}
		else
		{
			kw = "'%" + kw + "%'";
			sc += " AND (";
			sc += " b.name LIKE " + kw + " OR c.name LIKE " + kw + " OR b.sn LIKE " + kw;
			sc += ")";
		}
	}
	if(Request.QueryString["staff"] != null && Request.QueryString["staff"] != "")
		sc += " AND staff = " + Request.QueryString["staff"];
	sc += " AND returned = 0 ORDER BY date_borrowed";
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, "item");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	PrintBorrowHeader();

	Response.Write("<table width=100% cellspacing=0 cellpadding=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr><td colspan=7>");
	Response.Write("<input type=text name=kw><input type=submit name=cmd value=Search class=b>");
	Response.Write("</td></tr>");

	Response.Write("<tr class=tableHeader>");
	Response.Write("<th>Date</th>");
	Response.Write("<th>Code</th>");
	Response.Write("<th>Name</th>");
	Response.Write("<th>Qty</th>");
	Response.Write("<th>Borrower</th>");
	Response.Write("<th>Note</th>");
	Response.Write("<th>&nbsp;</th>");
	Response.Write("</tr>");

	bool bAlterColor = false;
	for(int i=0; i<dst.Tables["item"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["item"].Rows[i];
		string id = dr["id"].ToString();
		string date = DateTime.Parse(dr["date_borrowed"].ToString()).ToString("dd/MM/yyyy");
		string code = dr["code"].ToString();
		string name = dr["name"].ToString();
		string qty = dr["qty"].ToString();
		string staff = dr["staff"].ToString();
		string staff_name = dr["staff_name"].ToString();
		string note = dr["borrow_note"].ToString();

		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=#EEEEEE");
		Response.Write(">");
		bAlterColor = !bAlterColor;

		Response.Write("<td>" + date + "</td>");
		Response.Write("<td>" + code + "</td>");
		Response.Write("<td>" + name + "</td>");
		Response.Write("<td align=center>" + qty + "</td>");
		Response.Write("<td align=center><a href=borrow.aspx?t=list&staff=" + staff + " class=o>" + staff_name + "</a></td>");
		Response.Write("<td>" + note + "</td>");
		Response.Write("<td>");
		Response.Write("<a href=borrow.aspx?t=return&id=" + id + " class=o>Return</a>");
		Response.Write("</td></tr>");
	}
	Response.Write("</table>");

	PrintBorrowFooter();
	return false;
}

string BorrowPrintBranchOptions(string current_id)
{
	if(dstcom.Tables["branch"] != null)
		dstcom.Tables["branch"].Clear();

	int rows = 0;
	string s = "";
	string sc = " SELECT id, name FROM branch ORDER BY id ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dstcom, "branch");
	}
	catch(Exception e1) 
	{
		ShowExp(sc, e1);
		return "";
	}

	s += "<select name=branch onchange=\"window.location=('" + Request.ServerVariables["URL"] + "?r=";
	if(Request.QueryString["t"] != null)
		s += "&t=" + Request.QueryString["t"];
	if(Request.QueryString["id"] != null)
		s += "&id=" + Request.QueryString["id"];
	s += "&b='+ this.options[this.selectedIndex].value)\">";
	s += "<option value=all>All Branches</option>";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dstcom.Tables["branch"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		s += "<option value=" + id;
		if(id == current_id)
			s += " selected";
		s += ">" + name + "</option>";
	}
	s += "</select>";
	return s;	
}

bool DoReturnBorrowed()
{
	string id = Request.QueryString["id"];
	if(id == null || id == "")
	{
		id = Request.Form["id"];
		if(id == null || id == "")
		{
			PrintBorrowHeader();
			MsgDie("No Borrow Record ID");
			return false;
		}
	}

	string sc = " SELECT * FROM borrow WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "id") <= 0)
		{
			PrintBorrowHeader();
			MsgDie("Record Not Found");
			return false;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}

	DataRow dr = dst.Tables["id"].Rows[0];
	string branch = dr["branch"].ToString();
	string code = dr["code"].ToString();
	string staff = dr["staff"].ToString();
	string sn_old = dr["sn"].ToString();
	string qty = dr["qty"].ToString();

	string sn = Request.Form["sn"];
	if(sn == "" && sn_old != "")
		sn = sn_old;
	string note = Request.Form["note"];

	sc = " BEGIN TRANSACTION ";
	sc += " UPDATE borrow SET returned = 1, date_returned = GETDATE(), return_note = '" + EncodeQuote(note) + "' ";
	sc += " WHERE id = " + id;

	//serial trace log
	if(sn != "")
		sc += AddSerialLogString(sn, "return borrowed item", "", "", "", "");

	//stock adjustment log
	sc += " INSERT INTO stock_adj_log (staff, code, qty, branch_id, note) VALUES(" + Session["card_id"].ToString();
	sc += ", " + code + ", " + qty + ", " + branch + ", 'return borrowed item for " + EncodeQuote(note) + "') "; 
	sc += " IF EXISTS(SELECT * FROM stock_qty WHERE code=" + code + ") ";
	sc += " UPDATE stock_qty SET qty = qty + " + qty + " WHERE code=" + code + " AND branch_id = " + branch;
	sc += " ELSE ";
	sc += " INSERT INTO stock_qty (code, qty, branch_id) VALUES(" + code + ", " + qty + ", " + branch + ") ";
	sc += " SELECT IDENT_CURRENT('stock_adj_log') AS id ";
	sc += " COMMIT ";

	DataSet dsid = new DataSet();
	string new_id = "";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dsid, "id") != 1)
		{
			Response.Write("<br><center><h3>Error getting new stock adjustment log record ID");
			return false;
		}
		new_id = dsid.Tables["id"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	return fifo_RecordStockLoss(code, branch, MyIntParse(qty), new_id);
}

bool PrintReturnForm()
{
	string id = Request.QueryString["id"];
	if(id == null || id == "")
	{
		PrintBorrowHeader();
		MsgDie("No Borrow Record ID");
		return false;
	}

	string sc = " SELECT * FROM borrow WHERE id = " + id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "id") <= 0)
		{
			PrintBorrowHeader();
			MsgDie("Record Not Found");
			return false;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}

	DataRow dr = dst.Tables["id"].Rows[0];
	string code = dr["code"].ToString();
	string name = dr["name"].ToString();
	string qty = dr["qty"].ToString();
	string sn = dr["sn"].ToString();
	string note = dr["borrow_note"].ToString();
	
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<center><h4>Return Item</h4>");
	Response.Write("<form name=f action=? method=post>");
	
	Response.Write("<input type=hidden name=id value=" + id + ">");

	Response.Write("<br>");
	Response.Write("<table cellspacing=3 cellpadding=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
//	Response.Write("<tr><td><b>Item Details : </b></td></tr>");
	Response.Write("<tr><td>Item Code : </td><td><b>" + code + "</b></td></tr>");
	Response.Write("<tr><td>Description : </td><td><b>" + name + "</b></td></tr>");
	Response.Write("<tr><td>Quantity : </td><td><b>" + qty + "</b></td></tr>");
	if(sn != "")
		Response.Write("<tr><td>S/N : </td><td><b>" + sn + "</b></td></tr>");
	Response.Write("<tr><td>Borrow Note : </td><td><b>" + note + "</b></td></tr>");

	if(sn != "")
		Response.Write("<tr><td>Return S/N : </td><td><input type=text name=sn></td></tr>");
	Response.Write("<tr><td>Return Note : </td></tr>");
	Response.Write("<tr><td colspan=2><textarea name=note rows=5 cols=40></textarea></td></tr>");
	Response.Write("</table>");

	Response.Write("<input type=submit name=cmd value=Return class=b>");
	Response.Write("<input type=button value=Cancel onclick=window.location=('borrow.aspx?t=end') class=b>");

	PrintBorrowFooter();
	return true;
}

bool GetStockManager()
{
	string sc = " SELECT TOP 1 id, name, password FROM card WHERE type=4 AND access_level=6 ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "stockman") <= 0)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h4><font color=red>Error, Stock manager not found, you need at least one employee has Stock Man access level");
			return false;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}
	
	DataRow dr = dst.Tables["stockman"].Rows[0];
	m_stockManagerID = dr["id"].ToString();
	m_stockManagerName = dr["name"].ToString();
	m_stockManagerPass = dr["password"].ToString();
	return true;
}
</script>
