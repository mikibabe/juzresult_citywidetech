<script runat=server>


protected void Page_Load(Object Src, EventArgs E ) 
{
	//Response.Cache.SetExpires(DateTime.UtcNow.AddHours(12).AddSeconds(1));
	//Response.Cache.SetNoServerCaching();
	
	
	WriteComment();
	PrintCheckValidate();
	//PrintThispage();
	//PrintVB();
	//date picker

	Response.Write("<xaspx:DatePicker runat=server");
	Response.Write("MinDate='2001/01/30'");
	Response.Write("MaxDate='2005/12/05');
	Response.Write("CultureName=en-US");
	Response.Write("Format=Custom");
	Response.Write("CustomFormat='yyyy MMM d'");
	Response.Writte("DateBox-Font-Name='Courier New'");
	Response.Write("DateBox-Font-Size=XLarge");
	Response.Write("DateBox-BackColor=LightSalmon");
	Response.Write("DateBox-ForeColor=Navy ");
	/>
}

void WriteComment()
{

	Response.Write("<br><center><table border=1 cellspacing=0 cellspadding=0 width=60%>");
	Response.Write("<form action='mailto:tee@ezsoft.com' method=POST name='comment'>");
	
	Response.Write("<tr><td>Please write comments here...</td></tr>\n\r");
	Response.Write("<tr><td><textarea row=50 cols=50 name='comment'></textarea></td></tr>");
	Response.Write("<tr><td>&nbsp;</td></tr>");
	//Response.Write("<tr><td><input type=text name=email width=50 ></td>");
	//Response.Write("<td>enter your email</td>");
	<asp valid
	Response.Write("<tr><td><input type=submit name=cmd value='send' OnClick='CheckValidate();'>");
	Response.Write("<input type=reset name=cmd value='Reset'></td></tr>");
	Response.Write("<tr><td><button style='border-style:outset;border-width:1' OnClick=history.go(-1)>");
	Response.Write("Back</button></td></tr>");
	Response.Write("<tr><td><a href=mailto:webmaster@ezsoft.com>send email to us</a>");
	Response.Write("<tr><td><a href='javascript:printWindows();'>Print This browser version</a>");
	
	//Response.Write("<tr><td><input type=button name=btclick value='Click Me'>");
	Response.Write("<tr><td><input type=button name=click value='Dont click Me' onClick='alert(farck)'>");
		
	Response.Write("</table></center>\r\n");
	Response.Write("</form>");

}
void PrintThispage()
{
	
	Response.Write("<script language='JavaScript'");
	Response.Write(">");
	Response.Write("<!-- hide from old browser");

	const string s = @"
	function printWindows()
	{
		BV=parseInt(navigator.appversion);
		if(BV>=4) window.pritn()
	}
	";

	Response.Write(s);
	Response.Write("<!-- end script -->");
	Response.Write("</script");
	Response.Write(">");
	
}	

void PrintCheckValidate()
{
	
	
	Response.Write("<script language='JavaScript'");
	Response.Write(">");
	Response.Write("<!-- hide from old browser");

	const string s = @"
	function CheckValidate()
	{
		if(document.comment.email.value == "") {	
			window.alert(Please Enter a Name!);
			return false;
		}
		if(document.comment.comment.value == "") {
			window.alert(pleaes write some comments!);
			return false;
		}
	}
	";  

	Response.Write(s);
	Response.Write("<!-- end script -->");
	Response.Write("</script");
	Response.Write(">");


}

void PrintVB()
{
	
	Response.Write("<script language='VBscript'");
	Response.Write(">");
	Response.Write("<!-- hide from old browser");

	const string s = @"
	sub btclick_OnClick	
		MsgBox WWW_ListWindows 
	end sub
	";

	Response.Write(s);
	Response.Write("<!-- end script -->");
	Response.Write("</script");
	Response.Write(">");
}


</script>
