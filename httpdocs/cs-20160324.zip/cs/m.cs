<script runat=server>

int MaxRows = 20;

void MPage_Load()
{
	RememberLastPage();

	PrintHeaderAndMenu("");



    
    
	DataSet ds = new DataSet();
	
	string menu = Request.QueryString["m"];
	string type = Request.QueryString["t"];
    string level = Request.QueryString["L"];

	if(string.Compare(menu, "brands", true) == 0)
	{
		type = "more";
		MaxRows = 20;
	}

	int rows = 0;
	string sc = "";
	sc = "SELECT DISTINCT s_cat ";
//	if(type != "more")
		sc += ", ss_cat";
	sc += " FROM catalog ";
    if(level != null){
        if(level == "1"){
            sc += "  WHERE cat='"+menu+"'";
        }else if(level == "2"){
            sc += "  WHERE s_cat='"+menu+"'";
        }else if(level == "3"){
            sc += "  WHERE ss_cat='"+menu+"'";
        }
    }
	
	sc += " ORDER BY s_cat";
//	if(type != "more")
		sc += ", ss_cat";
//DEBUG("sc=", sc);
	if(m_supplierString != "")
	{
		MaxRows = 24;
		if(type == "more")
		{
			sc = "SELECT DISTINCT p.brand AS s_cat, p.s_cat AS ss_cat FROM product p ";
				sc += " WHERE p.supplier IN" + m_supplierString + " ";
			sc += " ORDER BY p.brand, p.s_cat";
		}
		else
		{
			sc = "SELECT DISTINCT s_cat, ss_cat FROM product ";
				sc += " WHERE cat='" + menu + "' AND supplier IN" + m_supplierString + " ";
			sc += " ORDER BY s_cat, ss_cat";
		}
	}
	
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(ds, "menu");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return;
	}

	StringBuilder sb = new StringBuilder();
	
	//draw title
	sb.Append("<br><center><font size=+1><b>");
	if(type == "more")
		sb.Append("Brands");
	else
		sb.Append(menu);
	sb.Append("</b></font></center>");
	
	//begin menu list
	sb.Append("\r\n\r\n<table align=center cellspacing=0 cellpadding=0>");
	sb.Append("<tr>");

	if(rows <= 0)
	{
		sb.Append("<tr><td> ?</td></tr>");
	}

	string subTableIndex = "s_cat";
	Boolean bAlterColor = false;
	DataRow dr = null;
	string sti = null;
	string stiOld = null;
	string ss_cat = null;
	int j = 0;
	bool bColumn = true;
	for(int i=0; i < rows; i++)
	{
		if(j >= MaxRows)
			bColumn = true;
		j++;

		dr = ds.Tables[0].Rows[i];
		sti = dr[subTableIndex].ToString(); //sti: subTableIndex
		Trim(ref sti);
		if(sti.Length > 1)
			sti = sti.Substring(0, 1).ToUpper() + sti.Substring(1, sti.Length-1).ToLower();
//		if(type != "more")
			ss_cat = dr["ss_cat"].ToString();
//		string ss_cat_old = "";
		if(sti == "Zzzothers")
			continue;

		if(stiOld != sti)
		{
			if(bColumn || j == MaxRows-1)
			{
				bColumn = false;
				if(i != 0)
					sb.Append("</table></td>");
				sb.Append("\r\n\r\n<td width=170 valign=top><table cellspacing=0 cellpadding=0>");
				j = 0;
				if(i == 0)
					j = 1;
			}

			sb.Append("<tr><td colspan=2>&nbsp;</td></tr>");
			sb.Append("<tr><td><img src=/i/reddot.gif></td><td>&nbsp;<a href=c.aspx?");
			if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
				sb.Append("ssid="+ Request.QueryString["ssid"]+"&");
			if(String.Compare(menu, "brands", true) == 0)
			{
				sb.Append("b=");
				sb.Append(HttpUtility.UrlEncode(sti));
			}
			else
			{
				sb.Append("c=");
				if(Request.QueryString["L"] != null && Request.QueryString["L"] != ""){
                   sb.Append(getMenuFatherName(HttpUtility.UrlEncode(sti),"",2));
                }else{
                   sb.Append(HttpUtility.UrlEncode(menu));
                }
				sb.Append("&s=");
				sb.Append(HttpUtility.UrlEncode(sti));
			}
			sb.Append(" class=d><b>");
			if(sti == "Zzzothers" || sti == "")
				sb.Append("All Others");
			else
				sb.Append(sti);
			sb.Append("</b></a></td></tr>");
			j++;
		}
		
		stiOld = sti;
		
		if(type != "more")
		{
			sb.Append("<tr><td> </td>");
			sb.Append("<td>&nbsp;<img src=/i/reda1.gif> <a href=c.aspx?");
			if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
				sb.Append("ssid="+ Request.QueryString["ssid"]+"&");
			if(String.Compare(menu, "brands", true) == 0)
			{
				sb.Append("b=");
				sb.Append(HttpUtility.UrlEncode(sti));
				sb.Append("&s=");
			}
			else
			{
				sb.Append("c=");
                
                if(Request.QueryString["L"] != null && Request.QueryString["L"] != ""){
                   sb.Append(getMenuFatherName(HttpUtility.UrlEncode(sti),"",2));
                }else{
                   sb.Append(HttpUtility.UrlEncode(menu));
                }

				
				sb.Append("&s=");
				sb.Append(HttpUtility.UrlEncode(sti));
				sb.Append("&ss=");
			}
			sb.Append(HttpUtility.UrlEncode(ss_cat));
			sb.Append(" class=d>");
			if(ss_cat == "zzzOthers" || ss_cat == "")
				sb.Append("All Others");
			else
				sb.Append(ss_cat);
			sb.Append("</td></tr>");
		}
	}
	sb.Append("</table>");
	sb.Append("</td></tr></table><br>");
	Response.Write(sb.ToString());
//	Response.Write("<hr align=center width=80%>");
}
</script>
