<script runat=server>

DataSet ds = new DataSet();

string m_fileName = "";
string m_tables = "";
string m_columns = "";
string m_sql = "";

StringBuilder sb = new StringBuilder();

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("normal"))
		return;
	Session["export_tables"] = "account, branch, card, card_access_class, card_access_data, card_access_data_default, card_access_menu, enum, help, menu_access_class, menu_admin_access, menu_admin_catalog, menu_admin_id, menu_admin_sub, settings, ship, site_pages, site_sub_pages, color_name, color_set, templates";
//	Session["export_tables"] = "site_pages";

	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<br><center><h3>EXPORT DATA</h3>");

	Response.Write("<form action=export.aspx method=post>");
	Response.Write("<table>");
	Response.Write("<tr><td><b>Tables : </b></td><td><input type=text name=tables size=110 value='" + Session["export_tables"] + "'></td></tr>");
	Response.Write("<tr><td colspan=2 align=right><input type=submit name=cmd value=Query></td></tr>");
	Response.Write("</table></center>");

//	Response.Write("</td></tr></table>"); //close page bg table to show progress
	Response.Flush();

	string s = "";
	if(Request.Form["tables"] != null)
		s = Request.Form["tables"];

	Session["export_tables"] = s;

	Trim(ref s);
	string table = "";
	if(s == "")
		return;

	//start exporting
	for(int i=0; i<s.Length; i++)
	{
		if(s[i] == ',')
		{
			if(!DoQuery(table))
				break;
			table = "";
		}
		else
			table += s[i];
	}
	Trim(ref table);
	if(table != "")
		DoQuery(table);

	string strPath = Server.MapPath(".") + "\\dbdata.sql";
	Encoding enc = Encoding.GetEncoding("iso-8859-1");
//	Encoding enc = Encoding.GetEncoding(54936);
	byte[] Buffer = enc.GetBytes(sb.ToString());

	string sout = Encoding.ASCII.GetString(Buffer, 0, Buffer.Length);
	sout = sout.Replace("??", "&nbsp;"); //correct old textarea problem
	Buffer = enc.GetBytes(sout);

	// Create a file
	FileStream newFile = new FileStream(strPath, FileMode.Create);
	newFile.Write(Buffer, 0, Buffer.Length);
	newFile.Close();

	Response.Write("<br><center><h3>Done, file " + strPath + " saved.");
	Response.Write("</body></html>");
//	PrintAdminFooter();
}

bool DoQuery(string table)
{
	ds.Clear();

	string sc = "SELECT * FROM " + table;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(ds, table);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(!BuildResultSQL(table))
	{
		Response.Write("sth wrong");
		return false;;
	}
	return true;
}

bool HasIdent(string table)
{
	string sc = " SET IDENTITY_INSERT " + table + " ON ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		myCommand.Connection.Close();
		return false;
	}
	
	sc = " SET IDENTITY_INSERT " + table + " OFF ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		myCommand.Connection.Close();
		ShowExp(sc, e);
		return true;
	}
	return true;
}

bool BuildResultSQL(string table)
{
	int i = 0;
	
	Response.Write("<br>Exporting table <b>" + table + "</b> ..");
	Response.Flush();
	DataColumnCollection dc = ds.Tables[table].Columns;

	string[] dtype = new string[1024];
//
	bool bHasIden = HasIdent(table);
//	int idents = ds.Tables[table].PrimaryKey.Length;
//DEBUG("idents=", idents);
//return true;
	m_columns = "";
	for(i=0; i<dc.Count; i++)
	{
		m_columns += dc[i].ColumnName;
		if(i < dc.Count - 1)
			m_columns += ", ";
//		if(dc[i].AutoIncrement)
//		{
//DEBUG("identity=", "true");
//			bHaveIden = true;
//		}
//		dtype[i] = dc[i].DataType.ToString();
//DEBUG("type=", dtype[i]);
	}
//return true;
	if(bHasIden)
		sb.Append("SET IDENTITY_INSERT " + table + " ON \r\n");
	
	DataRow dr = null;
	
	Type t = null;
	Type tString = System.Type.GetType("System.String");
	Type tBool = System.Type.GetType("System.Boolean");
	Type tDateTime = System.Type.GetType("System.DateTime");

	bool bQuote = false;
	for(i=0; i<ds.Tables[table].Rows.Count; i++)
	{
		Response.Write(".");
		Response.Flush();

		dr = ds.Tables[table].Rows[i];
		sb.Append("INSERT INTO " + table + "(" + m_columns + ") VALUES(");
		for(int j=0; j<ds.Tables[table].Columns.Count; j++)
		{
			string svalue = ds.Tables[table].Rows[i][j].ToString();
			bQuote = false;
			t = ds.Tables[table].Columns[j].DataType;
			if(t == tString || t == tDateTime)
				bQuote = true;
			else if(t == tBool)
			{
				if(MyBooleanParse(svalue))
					svalue = "1";
				else
					svalue = "0";
			}

			if(j > 0)
				sb.Append(",");
			if(bQuote)
				sb.Append("'");
			else if(svalue == "")
				svalue = "null";
			sb.Append(EncodeQuote(svalue));
			if(bQuote)
				sb.Append("'");
		}
		sb.Append(")\r\n");
	}
	
	if(bHasIden)
		sb.Append("SET IDENTITY_INSERT " + table + " OFF\r\n");

//	Response.Write("</center>");
//	Response.Write(sb.ToString());
	return true;
}
</script>
