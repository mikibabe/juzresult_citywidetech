<!-- #include file="price.cs" -->

<script runat=server>

string ebrand;
string ecat;
string es_cat;
string ess_cat;

string brand;
string cat;
string s_cat;
string ss_cat;

string m_editPriceBox = ""; //for edit retail price

string m_type = null;
bool m_bPhasedOut = false;
bool m_bService = false;

int page = 1;
const int m_nPageSize = 35; //how many rows in oen page
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

const string cols = "10";	//how many columns main table has, used to write colspan=
string tableTitle = "Item List";
const string thisurl = "eprice.aspx";

string m_supplier = null;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("manager"))
		return;

	GetQueryStrings();

	PrintAdminHeader();
	PrintAdminMenu();

	if(Request.QueryString["ep"] != null)
		m_editPriceBox = Request.QueryString["ep"];
	
	if(Request.QueryString["d"] != null && Request.QueryString["d"] != "")
		m_supplier = Request.QueryString["d"];

/*	if(m_type == "update")
	{
		string update = Request.Form["update"];
		if(UpdateAllRows())
		{
			TSRemoveCache(m_sCompanyName + "_" + m_sHeaderCacheName);
			string s = "<br><br>done! wait a moment......... <br>\r\n";
			s += "<meta http-equiv=\"refresh\" content=\"1; URL=";
			s += WriteURLWithoutPageNumber();
			s += "&p=";
			s += page;
			s += "\"></body></html>";
			Response.Write(s);
		}
	}
	else
*/
	{
		if(!DoSearch())
			return;
	
		WriteHeaders();
		MyDrawTable();
		WriteFooter();
		PrintCatalogSelection();
	}

	PrintAdminFooter();
}

string WriteURLWithoutPageNumber()
{
	StringBuilder sb = new StringBuilder();

	sb.Append(thisurl + "?po=" + (m_bPhasedOut ? "1" : "0").ToString());
	sb.Append("&service=" + (m_bService ? "1" : "0").ToString() + "&");
	if(brand != null)
	{
		sb.Append("b=");
		sb.Append(ebrand);
	}
	else
	{
		sb.Append("c=");
		sb.Append(ecat);
	}
	if(s_cat != null)
	{
		sb.Append("&s=");
		sb.Append(es_cat);
	}
	if(ss_cat != null)
	{
		sb.Append("&ss=");
		sb.Append(ess_cat);
	}
	if(m_supplier != null)
	{
		sb.Append("&d=");
		sb.Append(m_supplier);
	}
	sb.Append("&r=" + DateTime.UtcNow.AddHours(12).ToOADate());

	if(Request.Form["search"] != null && Request.Form["search"] != "")
	{
		sb.Append("&kw=");
		sb.Append(Request.Form["search"]);
	}else if( Request.QueryString["kw"] != null && Request.QueryString["kw"] != ""){
    	sb.Append("&kw=");
		sb.Append(Request.QueryString["kw"]);
    }


	return sb.ToString();
}

void GetQueryStrings()
{
	brand = Request.QueryString["b"];
	cat = Request.QueryString["c"];
	s_cat = Request.QueryString["s"];
	ss_cat = Request.QueryString["ss"];

	ebrand = HttpUtility.UrlEncode(brand);
	ecat = HttpUtility.UrlEncode(cat);
	es_cat = HttpUtility.UrlEncode(s_cat);
	ess_cat = HttpUtility.UrlEncode(ss_cat);
	m_type = Request.QueryString["t"];
	m_bPhasedOut = (Request.QueryString["po"] == "1");
	if(m_bPhasedOut)
		tableTitle = "Phased Out Items";
	m_bService = (Request.QueryString["service"] == "1");
	if(m_bService)
		tableTitle = "Service Items";
	string spage = Request.QueryString["p"];
	if(spage != null)
		page = int.Parse(spage);
//DEBUG("page=", page);
}

Boolean DoSearch()
{
	StringBuilder sb = new StringBuilder();

	sb.Append("SELECT c.id, c.code, c.brand, c.name, c.cat, c.s_cat, c.ss_cat, p.stock, p.price, c.supplier_price, c.rate ");
//	sb.Append(", isnull(s.code, 0) AS special ");
	if(m_bPhasedOut){
        sb.Append(" FROM product_skip p JOIN code_relations c ON p.id=c.id ");
        //		sb.Append(" FROM code_relations c Left outer join product_skip p  ON p.id=c.id ");
    }
	else{
        //sb.Append(" FROM product p JOIN code_relations c ON p.supplier+p.supplier_code=c.id ");
        sb.Append(" FROM product p JOIN code_relations c ON p.code = c.code  ");
        //	sb.Append(" LEFT OUTER JOIN specials s on c.code=s.code ");
    }

	string swhere = "";
	if(m_bService)
		swhere += " c.is_service = 1 ";
	else
	{
		if(brand != null)
			swhere += " c.brand='" + brand + "'";
		else if(cat != null && cat != "")
			swhere += " c.cat='" + cat + "'";

		if(s_cat != null && s_cat != "")
		{
			if(swhere != "")
				swhere += " AND ";
			swhere += " c.s_cat='" + s_cat + "'";
		}
		if(ss_cat != null && ss_cat != "")
		{
			if(swhere != "")
				swhere += " AND ";
			swhere += " c.ss_cat='" + ss_cat + "'";
		}
		if(m_supplier != null)
		{
			if(swhere != "")
				swhere += " AND ";
			swhere += " c.supplier='" + m_supplier + "'";
		}
	}
	if(swhere != ""){
        sb.Append(" WHERE " + swhere);
    }
    if(Request.Form["search"] != null && Request.Form["search"] != "")
    {
	    string kw = Request.Form["search"];
		page = 1; //set post search to first page
	
	    if(TSIsDigit(kw))
		    sb.Append(" AND (c.code = "+ kw +" OR c.barcode = '"+ kw +"') ");
	    else
	    {
		    kw = EncodeQuote(kw);
		    sb.Append(" AND (c.supplier like '%"+kw+"%' OR c.barcode = '"+ kw +"' OR c.supplier_code = '"+ kw +"' OR c.name like '%"+ kw +"%') ");
	    }
    }else if( Request.QueryString["kw"] != null && Request.QueryString["kw"] != ""){
    	string kw = Request.QueryString["kw"];
    	if(TSIsDigit(kw))
		    sb.Append(" AND (c.code = "+ kw +" OR c.barcode = '"+ kw +"') ");
	    else
	    {
		    kw = EncodeQuote(kw);
		    sb.Append(" AND (c.supplier like '%"+kw+"%' OR c.barcode = '"+ kw +"' OR c.supplier_code = '"+ kw +"' OR c.name like '%"+ kw +"%') ");
	    }
    }
	if(Request.QueryString["st"] != null)
	{
		sb.Append(" ORDER BY ");
		sb.Append(" "+ Request.QueryString["st"] +"");
		if(Request.QueryString["desc"] == "1")
			sb.Append(" DESC ");
	}
	else
    {
        sb.Append(" ORDER BY c.code DESC, c.brand, c.s_cat, c.ss_cat, c.name DESC");
    }
	
//DEBUG("query=", sb.ToString());	
	try
	{
		myAdapter = new SqlDataAdapter(sb.ToString(), myConnection);
		int rows = myAdapter.Fill(dst, "product");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}
	return true;
}

Boolean UpdateAllRows()
{
	int i = (page-1) * m_nPageSize;
	string id = Request.Form["id"+i.ToString()];
	while(id != null)
	{
		if(!UpdateOneRow(i.ToString()))
			return false;;
		i++;
		id = Request.Form["id"+i.ToString()];
	}
	return true;
}

Boolean UpdateOneRow(string sRow)
{
	Boolean bRet = true;

	string id		= Request.Form["id"+sRow];
	string code		= Request.Form["code"+sRow];
	string name		= Request.Form["name"+sRow];
	string brand	= Request.Form["brand"+sRow];
	string supplier_price_old = Request.Form["supplier_price_old"+sRow];
	string supplier_price = Request.Form["supplier_price"+sRow];
	string rate = Request.Form["rate"+sRow];
	string price_old = Request.Form["price_old"+sRow];
	double dPrice_old = double.Parse(price_old, NumberStyles.Currency, null);
	string price = "";
	if(Request.Form["price"+sRow] != null)
		price = Request.Form["price"+sRow];
	string stock = Request.Form["stock"+sRow];
	if(stock == "" || string.Compare(stock, "yes", true) == 0)
		stock = "null";
	string stock_old = Request.Form["stock_old"+sRow];
	if(stock_old == "" || string.Compare(stock_old, "yes", true) == 0)
		stock_old = "null";

	bool bSpecial = (Request.Form["special"+sRow] == "on");
	bool bSpecial_old = (Request.Form["special_old"+sRow] == "on");

	double dsupplier_price = double.Parse(supplier_price, NumberStyles.Currency, null);
	double dPrice = 0;
	double dRate = double.Parse(rate);
	if(price != "")
	{
//DEBUG("price=", price);
		dPrice = double.Parse(price, NumberStyles.Currency, null);
//		dRate = CalculatePriceRate(dsupplier_price, dPrice);
	}
	else
	{
//DEBUG("rate=", dRate.ToString());
		dPrice = CalculateRetailPrice(dsupplier_price, dRate);
	}
	if(supplier_price_old != supplier_price || price != "")
	{
		//update product (live update)
		if(!UpdateSupplierPrice(code, id, dsupplier_price, dPrice))
			return false;
//		if(price != "")
//		{
//			if(!UpdatePriceRate(code, dRate))
//				return false;
//		}
	}

	//write price history
//	if(dPrice != dPrice_old)
	if(supplier_price_old != supplier_price)
	{
		if(!WritePriceHistory(code, dsupplier_price))
			return false;
	}

	if(stock_old != stock)
	{
		if(!UpdateStock(code, id, stock))
			return false;
	}

	if(bSpecial != bSpecial_old)
	{
		if(bSpecial) //do insert
			bRet = AddSpecial(code);
		else //do delete
			bRet = RemoveSpecial(code);
	}
	return bRet;
}

void WriteHeaders()
{
	StringBuilder sb = new StringBuilder();
//	sb.Append("<html><style type=\"text/css\">td{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}");
//	sb.Append("body{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}</style>");
//	sb.Append("<body bgcolor=#666696>\r\n");
//	sb.Append("<table width=100% height=100% bgcolor=white align=center valign=center><tr><td valign=top>");
	if(m_bPhasedOut)
		tableTitle = "Phased Out Items";
	sb.Append("<br><center><h3>" + tableTitle + "</h3></center>");
	
	sb.Append("<form action=");
//eprice.aspx?po=0&d=&r=40229.2260827083&c=
//eprice.aspx?po=0&service=0&c=&r=40229.2261168866&t=update&p=1
	sb.Append(WriteURLWithoutPageNumber());
	sb.Append("&t=update&p=");
	sb.Append(page);
	sb.Append(" method=post>\r\n");
	sb.Append("<input type=text name=search ><input type=submit name=cmd value='SEARCH PRODUCT' class=linkButtonCenter title='Search Product'>");
	if(m_bPhasedOut){
        sb.Append("<input type=button name=cmd value='SHOW All' onclick=\"window.location=('eprice.aspx?po=1&d=&r="+DateTime.UtcNow.AddHours(12).ToOADate()+"&c=');\" class=linkButtonCenter title='Show All'>");
    }else{
        sb.Append("<input type=button name=cmd value='SHOW All' onclick=\"window.location=('eprice.aspx?po=0&d=&r="+DateTime.UtcNow.AddHours(12).ToOADate()+"&c=');\" class=linkButtonCenter title='Show All'>");
    }
    
	sb.Append("<script language=javascript>window.froms[0].search.focus();</script");
	sb.Append(">");
	Response.Write(sb.ToString());
	Response.Flush();
}

void WriteFooter()
{
	StringBuilder sb = new StringBuilder();
//	sb.Append("</td></tr></table>");
	sb.Append("</form>");//</body></html>");
	Response.Write(sb.ToString());
}

Boolean MyDrawTable()
{
	Boolean bRet = true;
	DrawTableHeader();
	string s = "";
	DataRow dr;
	Boolean alterColor = true;
	int startPage = (page-1) * m_nPageSize;
	for(int i=startPage; i<dst.Tables["product"].Rows.Count; i++)
	{
		if(i-startPage >= m_nPageSize)
			break;
		dr = dst.Tables["product"].Rows[i];
		alterColor = !alterColor;
		if(!DrawRow(dr, i, alterColor))
		{
			bRet = false;
			break;
		}
	}

	StringBuilder sb = new StringBuilder();
//	sb.Append("<tr><td colspan=" + cols + " align=right><input type=submit name=update value='Update'></td></tr>");
	sb.Append("<tr><td colspan=" + cols + " align=right>Page: ");
	int pages = dst.Tables["product"].Rows.Count / m_nPageSize + 1;
	for(int i=1; i<=pages; i++)
	{
		if(i != page)
		{
			sb.Append("<a href=");
			sb.Append(WriteURLWithoutPageNumber());
			sb.Append("&p=");
			sb.Append(i.ToString());
			sb.Append(">");
			sb.Append(i.ToString());
			sb.Append("</a> ");
		}
		else
		{
			sb.Append("<font class=pageNumber>" + i.ToString() + "</font>");
			sb.Append(" ");
		}
	}
	sb.Append("</td></tr>");
	sb.Append("</table>\r\n");
	Response.Write(sb.ToString());
	return bRet;
}

void DrawTableHeader()
{
	StringBuilder sb = new StringBuilder();;
	sb.Append("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr class=tableHeader>\r\n");
	sb.Append("<td>DELETE</td>");
	sb.Append("<td>EDIT</td>");
	string uri = Request.ServerVariables["URL"] + "?d="+ Request.QueryString["d"] +"&c="+Request.QueryString["c"] +"&s="+Request.QueryString["s"] +"&ss="+Request.QueryString["ss"] +"&st=";
	string sorted = "";
	if(Request.QueryString["st"] != null && Request.QueryString["st"] != "")
		sorted = Request.QueryString["st"];

	sb.Append("<td width=50>");
	sb.Append("<a title='sort by code' href='"+ uri +"");

	sb.Append(HttpUtility.UrlEncode("c.code"));
	if(Request.QueryString["desc"] == null)
		sb.Append("&desc=1");
	sb.Append("' class=o><font color=white>");
	sb.Append("CODE");
	sb.Append("</a>");
	sb.Append("</td>");
	sb.Append("<td>");
	sb.Append("<a title='sort by code' href='"+ uri +"");
	sb.Append(HttpUtility.UrlEncode("c.brand"));	
	if(Request.QueryString["desc"] == null)
		sb.Append("&desc=1");
	sb.Append("' class=o><font color=white>");
	sb.Append("BRAND");
	sb.Append("</a>");
	sb.Append("</td>");
	sb.Append("<td>");
	sb.Append("<a title='sort by code' href='"+ uri +"");
//	if(sorted == "" )
	sb.Append(HttpUtility.UrlEncode("c.name"));
	if(Request.QueryString["desc"] == null)
		sb.Append("&desc=1");
	sb.Append("' class=o><font color=white>");
	sb.Append("NAME (description)");
	sb.Append("</a>");
	sb.Append("</td>");
//	sb.Append("<td width=50>cost</td>");
//	sb.Append("<td width=50>rate</td>");
//	sb.Append("<td>price</td>");
	sb.Append("<td>");
	sb.Append("<a title='sort by code' href='"+ uri +"");
//	if(sorted == "" )
	sb.Append(HttpUtility.UrlEncode("p.stock"));
	if(Request.QueryString["desc"] == null)
		sb.Append("&desc=1");
	sb.Append("' class=o><font color=white>");
	sb.Append("STOCK");
	sb.Append("</a>");
	sb.Append("</td>");
//	sb.Append("<td>special</td>");
	sb.Append("</tr>\r\n");
	
	Response.Write(sb.ToString());
	Response.Flush();
}

Boolean DrawRow(DataRow dr, int i, Boolean alterColor)
{
	string id = dr["id"].ToString();
	string code = dr["code"].ToString();
	string name = dr["name"].ToString();
	string brand = dr["brand"].ToString();
	string stock = GetStock(dr["code"].ToString()).ToString();//dr["stock"].ToString();
/*	string supplier_price = dr["supplier_price"].ToString();
	string rate = dr["rate"].ToString();
	string price = dr["price"].ToString();
	string special = dr["special"].ToString();
*/
	string index = i.ToString();

	bool bHaveStock = false;
	if(stock == "" || stock != "0")
		bHaveStock = true; //cannot delete

	StringBuilder sb = new StringBuilder();;
	
	sb.Append("<tr");
	if(alterColor)
		sb.Append(" class=rowColor");
	sb.Append(">");

	sb.Append("<input type=hidden name=id");
	sb.Append(index);
	sb.Append(" value='");
	sb.Append(id);
	sb.Append("'>");

	sb.Append("<input type=hidden name=code");
	sb.Append(index);
	sb.Append(" value='");
	sb.Append(code);
	sb.Append("'>");

/*	sb.Append("<input type=hidden name=special_old");
	sb.Append(index);
	sb.Append(" value=");
	if(special != "0")
		sb.Append("on");
	sb.Append(">");

	sb.Append("<input type=hidden name=supplier_price_old" + index + " value='" + supplier_price + "'>");
	sb.Append("<input type=hidden name=price_old" + index + " value='" + price + "'>");
*/
	sb.Append("<td>");
	if(bHaveStock)
		sb.Append("<font color=red>Have Stock</font>");
	else
		sb.Append("<a href=dp.aspx?" + code + " class=linkButtonCenter title='Delete'>DEL</a> ");
	Session["DeleteBackUrl"] = Request.Url.AbsoluteUri;
	sb.Append("</td>");
	string pageNumber = Request.QueryString["p"];
	if(String.IsNullOrEmpty(pageNumber)){
		pageNumber = "1";
	}
	
	sb.Append("<td><a href=liveedit.aspx?p="+ pageNumber +"&code=" + code + " class=linkButtonCenter title='Edit'>EDIT</a> </td>");

	sb.Append("<td>" + code + "</td>");
	sb.Append("<td>" + brand + "</td>");
	sb.Append("<td>" + name + "</td>");
/*
	sb.Append("<td>");
	sb.Append("<input type=text size=5 readonly=true name=supplier_price" + index + " value='" + supplier_price + "'>");
	sb.Append("</td>");

	sb.Append("<td><input type=hidden name=rate" + index + " value=" + rate + ">" + rate + "</td>");

	sb.Append("<td>");
	if(m_editPriceBox == code)
	{
		sb.Append("<input type=text size=5 name=price");
		sb.Append(index);
		sb.Append(" value='");
		sb.Append(price);
		sb.Append("'>");
	}
	else
	{
		sb.Append("<a href=");
		sb.Append(WriteURLWithoutPageNumber());
		sb.Append("&p=" + page + "&ep=" + code + ">");
		sb.Append(price);
		sb.Append("</a>");
	}
	sb.Append("</td>");
*/
	sb.Append("<td><input type=hidden name=stock_old" + index + " value='" + stock + "'>" + stock);
//	sb.Append("<input type=text size=5 readonly=true name=stock" + index + " value='");
//	if(stock != null && stock != "")
//		sb.Append(stock);
//	else
//		sb.Append("Yes");
//	sb.Append("'>");
	sb.Append("</td>");
/*
	sb.Append("<td><input type=checkbox name=special");
	sb.Append(index);
	if(special != "0")
		sb.Append(" checked");
	sb.Append("></td>");
*/
	sb.Append("</tr>");

	Response.Write(sb.ToString());
	Response.Flush();
	return true;
}

bool PrintCatalogSelection()
{
	int rows = 0;
	string sc = "SELECT DISTINCT cat FROM code_relations ";
	if(m_supplier != null)
		sc += " WHERE supplier='" + m_supplier + "' ";
	sc += " ORDER BY cat";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "cat");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows <= 0)
		return true;

//	Response.Write("<form action=eprice.aspx?d=" + m_supplier + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " method=Get>");
	Response.Write("Select Catalog : <select name=c");
	Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"] + "?po=" + (m_bPhasedOut ? "1" : "0").ToString() + "&d=" + m_supplier + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "&c='+ escape(this.options[this.selectedIndex].value))\"");
	Response.Write("><option value=''>Show All</option>");
	string s = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["cat"].Rows[i];
		s = dr["cat"].ToString();
		Response.Write("<option value='" + s + "'");
		string lcat = cat;
		if(cat != null)
			lcat = cat.ToLower();
		if(s.ToLower() == lcat)
			Response.Write(" selected");
		Response.Write(">" + s + "</option>");
	}
	Response.Write("</select>\r\n");

	//sub catalog
	sc = "SELECT DISTINCT s_cat FROM code_relations WHERE cat='" + cat + "' ";
	if(m_supplier != null)
		sc += " WHERE supplier='" + m_supplier + "' ";
	sc += " ORDER BY s_cat";
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "s_cat");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows <= 0)
		return true;

	Response.Write("<select name=s");
	Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"] + "?po=" + (m_bPhasedOut ? "1" : "0").ToString() + "&d=" + m_supplier + "&c=" + HttpUtility.UrlEncode(cat) + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "&s='+ escape(this.options[this.selectedIndex].value))\"");
	Response.Write("><option value=''>Show All</option>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["s_cat"].Rows[i];
		s = dr["s_cat"].ToString();
		Response.Write("<option value='" + s + "'");
		string ls_cat = s_cat;
		if(s_cat != null)
			ls_cat = s_cat.ToLower();
		if(s.ToLower() == ls_cat)
			Response.Write(" selected");
		Response.Write(">" + s + "</option>");
	}
	Response.Write("</select>\r\n");
	
	//ss_cat
	sc = "SELECT DISTINCT ss_cat FROM code_relations WHERE cat='" + cat + "' AND s_cat='" + s_cat;
	if(m_supplier != null)
		sc += " WHERE supplier='" + m_supplier + "' ";
	sc += "' ORDER BY ss_cat";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "ss_cat");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows <= 0)
		return true;

	Response.Write("<select name=ss");
	Response.Write(" onchange=\"window.location=('" + Request.ServerVariables["URL"] + "?po=" + (m_bPhasedOut ? "1" : "0").ToString() + "&d=" + m_supplier + "&c=" + HttpUtility.UrlEncode(cat) + "&s=" + HttpUtility.UrlEncode(s_cat) + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "&ss='+ escape(this.options[this.selectedIndex].value))\"");
	Response.Write("><option value=''>Show All</option>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["ss_cat"].Rows[i];
		s = dr["ss_cat"].ToString();
		Response.Write("<option value='" + s + "'");
		string lss_cat = ss_cat;
		if(ss_cat != null)
			lss_cat = ss_cat.ToLower();
		if(s.ToLower() == lss_cat)
			Response.Write(" selected");
		Response.Write(">" + s + "</option>");
	}
	Response.Write("</select>\r\n");

//	Response.Write("<input type=submit name=cmd value='List Product'></form>");
	return true;
}

</script>