<script runat=server>

string m_sInvoiceNumber = "";
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
//string sInvoiceNumber="";
string m_sDate="";
string m_sPackingSlipDisplay = "";
bool m_bDoSN = true;

protected void Page_Load(Object Src, EventArgs E) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
//	if(!SecurityCheck("sales"))
//		return;

		/*-- Querry Database --*/
	m_sInvoiceNumber = Request.QueryString["i"];
//DEBUG("msdn =", m_sInvoiceNumber);
	if(m_sInvoiceNumber == null || m_sInvoiceNumber == "")
	{
		Response.Write("<br><br><center><h3>Unable to Proceed the Packing Slip!!! No Packing Slip Number!!!");
		Response.Write("<script langauge=javascript>window.close();</script");
		Response.Write(">");
		return;
	}
	if(!TSIsDigit(m_sInvoiceNumber))
	{
		Response.Write("<br><br><center><h3>Unable to Proceed the Packing Slip!!! Invalid Packing Slip Number!!!");
		Response.Write("<script langauge=javascript>window.close();</script");
		Response.Write(">");
		return;
	}
	m_sPackingSlipDisplay = ReadSitePage("packingslip");
	StringBuilder sb = new StringBuilder();
	if(!DoGetInvoiceDetail(m_sInvoiceNumber))
		return;
	sb.Append(m_sPackingSlipDisplay);
	if(Request.QueryString["email"] != null && Request.QueryString["email"] != "")
	{
		string email = Request.QueryString["email"];
		if(Request.QueryString["confirm"] == "1")
        //{
        //    Response.Write("<script Language=javascript");
        //    Response.Write(">");
        //    Response.Write("if(window.confirm('");
        //    Response.Write("Email packing slip to " + email + "?         ");
        //    Response.Write("\\r\\n\\r\\n");
        //    Response.Write("\\r\\nClick OK to send.\\r\\n");
        //    Response.Write("'))");
        //    Response.Write("window.=location'pack.aspx?i=" + Request.QueryString["i"] + "&email=" + HttpUtility.UrlEncode(email) + "';\r\n");
        //    Response.Write("else window.close();\r\n");
        //    Response.Write("</script");
        //    Response.Write(">");
        //}
        //else
        //{
			

			SendEmail(m_sSalesEmail, m_sSalesEmail, email, "Packing Slip, Invoice " + Request.QueryString[0], sb.ToString());
		//}
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><center><h3>Packing Slip Sent.</h3></center><br>");

		Response.Write("<br><br><center><a href=invoice.aspx?" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Credit/Invoice</a>");
		Response.Write("<br><br><center><a href=pack.aspx?i=" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Packing Slip</a>");
		Response.Write("<br><br><center><a href=invoice.aspx?n=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(email));
		Response.Write(" class=blueFont2 target=_blank title='Email Invoice to customer'>Email Credit/Invoice</a>");
		Response.Write("<br><br><center><a href=pack.aspx?i=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(email));
		Response.Write(" target=_blank title='Email Packing Slip to customer' class=blueFont2>Email Packing Slip</a>");
		Response.Write("<br><br><br><br><br><br>");
	}
	else
		Response.Write(sb.ToString());
}
bool DoGetInvoiceDetail(string sInvoiceNumber)
{
	string sc = "SELECT s.code, s.supplier_code, s.quantity, s.name AS product_desc,i.freight AS freight_charge,c.*, i.pick_up_time, i.sales AS sales_name, i.commit_date,i.invoice_number,i.cust_ponumber,i.sales_note,i.special_shipto, i.shipto, i.address1, i.address2, i.address3, ss.name AS shipMethod, ss.description AS shipMethod_desc, ss.web AS shipMethod_web, i.shipping_method AS shipping_id ";
	//sc += ", c.address1, c.address2, c.address3, c.phone, c.fax ";
	sc += " FROM sales s JOIN invoice i ON s.invoice_number=i.invoice_number ";
	sc += " JOIN card c ON c.id=i.card_id ";
    sc += " left JOIN ship ss ON ss.id=i.shipping_method   ";
//	sc += " JOIN card c2 ON c2.id = i.card_id
	sc += " WHERE i.invoice_number=";
	sc += sInvoiceNumber;

	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "sales");
	}
	catch(Exception e) 
	{
		ShowExp("Invalid Query String", e);
		return false; 
	}

    string shipMethod  = "";
    string shipCompanyDetail = "Shipping ticket: ";

   if(rows > 0)
   {
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@COMPANY_NAME", m_sCompanyName);
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@RECORD_DATE", dst.Tables["sales"].Rows[0]["commit_date"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@TODAY_DATE", DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy hh:mm"));
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@INVOICE_NUMBER", dst.Tables["sales"].Rows[0]["invoice_number"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@CUSTOMER_PONUMBER", dst.Tables["sales"].Rows[0]["cust_ponumber"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@STAFF", dst.Tables["sales"].Rows[0]["sales_name"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@FREIGHT", MyDoubleParse(dst.Tables["sales"].Rows[0]["freight_charge"].ToString()).ToString("c"));
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@CUSTOMER_ID", dst.Tables["sales"].Rows[0]["cust_ponumber"].ToString());
        
        try 
	    {	
            shipMethod = dst.Tables["sales"].Rows[0]["shipMethod"].ToString();
            string shipping_id = dst.Tables["sales"].Rows[0]["shipping_id"].ToString();
            
            if(shipping_id == "1"){
                shipMethod = "Pick up";
                string p_time = "";
                try{
                    p_time = DateTime.Parse(dst.Tables["sales"].Rows[0]["pick_up_time"].ToString()).ToString("HH:mm dd-MM-yy");
                }catch(Exception){
            
                }
                shipCompanyDetail += "Pick up time :" + p_time;
            }else{
                //shipCompanyDetail += dst.Tables["sales"].Rows[0]["shipMethod"].ToString();
                //shipCompanyDetail += "   ";
                //shipCompanyDetail += dst.Tables["sales"].Rows[0]["shipMethod_desc"].ToString();
                //shipCompanyDetail += "   ";
                //shipCompanyDetail += dst.Tables["sales"].Rows[0]["shipMethod_web"].ToString();
                //shipCompanyDetail += "<br />";
                shipCompanyDetail += GetShippingTicket(sInvoiceNumber);
//DEBUG("120 shipCompanyDetail=", shipCompanyDetail);
            }
		    m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@SHIPPING_METHOD", GetEnumValue("shipping_method", shipping_id));
	    }
	    catch (global::System.Exception)
	    {
		    m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@SHIPPING_METHOD", "Pick up");
	    }
		//m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@CUSTOMER_COMPANY", dst.Tables["sales"].Rows[0]["Company"].ToString());
		//m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@CUSTOMER_NAME", dst.Tables["sales"].Rows[0]["Name"].ToString());
		//company name
		string sCompany = "";
		sCompany = dst.Tables["sales"].Rows[0]["trading_name"].ToString();

		if(sCompany == "")
		{
			sCompany = dst.Tables["sales"].Rows[0]["Name"].ToString();
		}
		
	    string sp_shipto = dst.Tables["sales"].Rows[0]["shipto"].ToString();
        
		
		
        if(String.IsNullOrEmpty(sp_shipto))
        {
			sp_shipto += sCompany + "<br />";
            sp_shipto += dst.Tables["sales"].Rows[0]["address1"].ToString() + "<br />" + 
            dst.Tables["sales"].Rows[0]["address2"].ToString() + "<br />" + 
            dst.Tables["sales"].Rows[0]["address3"].ToString() +"<br /><br /><br />" + 
            "TEL: " + dst.Tables["sales"].Rows[0]["phone"].ToString()  +"<br />"+
            "ATTN: " +dst.Tables["sales"].Rows[0]["Name"].ToString()  ;
        }else{
            string[] s = sp_shipto.Split(',');
            sp_shipto = "";
			//sp_shipto += sCompany + "<br />";
            foreach(string ss in s){
                sp_shipto += ss + "  <br />";
            }
        }

         if(shipMethod.ToLower().Contains("pick")){
                sp_shipto = " <br />";
        }


        //bill to 
        string sp_billto = "";
        try 
        {	
			if(dst.Tables["sales"].Rows[0]["company"].ToString() == ""){
				sp_billto = sCompany;
			}else{
				sp_billto = dst.Tables["sales"].Rows[0]["company"].ToString();
			}
            sp_billto += "<br />";
            sp_billto = dst.Tables["sales"].Rows[0]["Address1"].ToString();
            sp_billto += "<br />";
            sp_billto += dst.Tables["sales"].Rows[0]["Address2"].ToString();
            sp_billto += "<br />";
            sp_billto += dst.Tables["sales"].Rows[0]["City"].ToString();
            sp_billto += "<br />";
            sp_billto += dst.Tables["sales"].Rows[0]["Country"].ToString();
			sp_billto += "<br />";
			sp_billto += "TEL: " + dst.Tables["sales"].Rows[0]["phone"].ToString();

            if(dst.Tables["sales"].Rows[0]["postal1"] != null)
            {
                try 
	            {	
                    if(dst.Tables["sales"].Rows[0]["company"].ToString() == ""){
						sp_billto = sCompany + "<br />";
					}else{
						sp_billto = dst.Tables["sales"].Rows[0]["company"].ToString()+ "<br />";
					}      
		            sp_billto += dst.Tables["sales"].Rows[0]["postal1"].ToString() + "<br />";
                    sp_billto += dst.Tables["sales"].Rows[0]["postal2"].ToString() + "<br />";
                    sp_billto += dst.Tables["sales"].Rows[0]["postal3"].ToString() + "<br />";
                    sp_billto += dst.Tables["sales"].Rows[0]["Country"].ToString();
					sp_billto += "<br />";
					sp_billto += "TEL: " + dst.Tables["sales"].Rows[0]["phone"].ToString();
	            }
	            catch (global::System.Exception)
	            {
		        
	            }
            }
        }
        catch
        {
		            
        }
        m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@@@BILL_TO_ADDRESS", sp_billto);
        
	    //sp_shipto = sp_shipto.Replace("\r\n", "\r\n<br>");

        m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@ADDR1", sp_shipto);
		//m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@ADDR2", dst.Tables["sales"].Rows[0]["Address2"].ToString());
		//m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@ADDR3", dst.Tables["sales"].Rows[0]["Address3"].ToString());
		//m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@CITY", dst.Tables["sales"].Rows[0]["City"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@FAX", dst.Tables["sales"].Rows[0]["fax"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@EMAIL", dst.Tables["sales"].Rows[0]["Email"].ToString());
		m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@PHONE", dst.Tables["sales"].Rows[0]["phone"].ToString());
	}
	string stext = "";
	bool bAlter = false;
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["sales"].Rows[i];
		string code = dr["code"].ToString();
		string qty = dr["quantity"].ToString();
		string product_desc = dr["product_desc"].ToString();
		string m_code = dr["supplier_code"].ToString();
//		string sn = dr["sn"].ToString();

		stext += "<tr";
		if(bAlter)
			stext += " bgcolor=#EEEEE ";
		bAlter = !bAlter;
		stext += "><td>"+ code +"</td><td>"+ product_desc +"</td><td>"+ qty +"</td></tr>";
	}
	m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@ITEM_LIST", stext);
    m_sPackingSlipDisplay = m_sPackingSlipDisplay.Replace("@@comment", shipCompanyDetail + dst.Tables["sales"].Rows[0]["sales_note"].ToString());
	return true;

}

string GetShippingTicket(string invoiceNm){

    string value = "";
    string sc = "SELECT * ";
	//sc += ", c.address1, c.address2, c.address3, c.phone, c.fax ";
	sc += " FROM invoice_freight ";
	sc += " WHERE invoice_number=";
	sc += invoiceNm;
    //DEBUG("256 sc=", sc);
    int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "ticket");
	}
	catch(Exception e) 
	{
		ShowExp("Invalid Query String", e);
		return ""; 
	}
    
    if(rows > 0){
        value += "<br /><table>";
        for(int i=0; i<rows; i++){
            DataRow dr = dst.Tables["ticket"].Rows[i];
            string fTime = "";
            try{
                fTime = dr["ship_time"].ToString();
            }catch(Exception){

            }
            value += "<tr><td>" + dr["ticket"].ToString() + "</td><td>" + dr["ship_name"].ToString() + "</td><td>" + dr["ship_desc"].ToString() + "</td><td>" + fTime + "</td></tr>";
        }
         value += "</table>";
    }
   
    return value;
}
	
</script>
