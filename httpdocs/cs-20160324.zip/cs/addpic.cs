<!-- #include file="kit_fun.cs" -->
<%@ Import Namespace="System.Web.Configuration" %>
<%@ Import Namespace="System.Configuration" %>
<%@ Import Namespace="System.Text" %>
<script runat=server>

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
DataRow[] dracr;	//for sorting code_relations
string m_code = "";
string m_pic = "";
string m_name = "";
string m_fileName = "";

bool m_bKit = false;
string m_kit = "";

void Page_Load(Object Src, EventArgs E ) 
{

	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("editor"))
		return;

	InitKit();

	if(Request.QueryString["kit"] == "1")
	{	
		m_bKit = true;
		m_kit = "1";
	}

	GetQueryStrings();

	if(Request.QueryString["t"] == "da")
	{
		DoDelPic();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=addpic.aspx?kit=" + m_kit + "&code=" + m_code + "\">");
		return;
	}

	PrintAdminHeader();
	PrintAdminMenu();
	LFooter.Text = m_sAdminFooter;

	if(!m_bKit)
	{
		Response.Write("<img src=r.gif> <a href=ep.aspx?code=");
		Response.Write(m_code);
		Response.Write("   class=linkButton>Edit Specifications</a> ");

		Response.Write("<img src=r.gif> <a href=liveedit.aspx?code=");
		Response.Write(m_code);
		Response.Write("   class=linkButton>Edit Product Details</a>");
	}

	if(m_code != null)
	{
		LTitle.Text = "<h3>Upload Image for ";
		if(m_bKit)
			LTitle.Text += m_sKitTerm + " # ";
		else
			LTitle.Text += " product code ";
		LTitle.Text += m_code;
		LTitle.Text += "</h3> - " + m_name + "<br><br>";
		GetOldData(); //display old photo if exists, otherwise insert new row, prepare to upload
        GetProductImageList();
		Form1.Visible = true;
	}
	else
	{
		LTitle.Text = "<font size=+4><b>Product Code Error</b></font><br>";
		LTitle.Text +="<br><b>no product code, please use proper links. eg: addpic.aspx?code=100408</b>";
	}
}

// Processes click on our cmdSend button
void cmdSend_Click(object sender, System.EventArgs e)
{
	// Check to see if file was uploaded
	if( filMyFile.PostedFile != null )
	{
		// Get a reference to PostedFile object
		HttpPostedFile myFile = filMyFile.PostedFile;

		// Get size of uploaded file
		int nFileLen = myFile.ContentLength; 

		// make sure the size of the file is > 0
		if( nFileLen > 0 )
		{
			// Allocate a buffer for reading of the file
			byte[] myData = new byte[nFileLen];

			// Read uploaded file from the Stream
			myFile.InputStream.Read(myData, 0, nFileLen);

			// Create a name for the file to store
			string strFileName = m_code;
			string sExt = Path.GetExtension(myFile.FileName);
			strFileName += sExt;
			m_fileName = strFileName;
			string vpath = "";
			string imageType = "";
			if(m_bKit){
				vpath = "~/pk/";
				imageType = "pk\\";
			}			
			else{
				vpath = "~/pi/";
				imageType = "pi\\";
			}
				
			string strPath = Server.MapPath(vpath + strFileName);
			string purePath = Server.MapPath(vpath);
			//strPath += strFileName;
			String wholeSaleImageFolder = "";//WebConfigurationManager.AppSettings["wholesale_root"] ;

			if(isMainImage.Checked){
                //check old files, delete .gif or jpg (another type)if exists
			    string sExtOld = ".gif";
			    if(String.Compare(sExt, ".gif", true) == 0)
				    sExtOld = ".jpg";
			    string oldFile = purePath + m_code + sExtOld;
			    if(File.Exists(oldFile))
				    File.Delete(oldFile);

				oldFile = purePath + m_code + ".gif";
			    if(File.Exists(oldFile))
				    File.Delete(oldFile);
				oldFile = purePath + m_code + ".jpg";
			    if(File.Exists(oldFile))
				    File.Delete(oldFile);
				oldFile = purePath + m_code + ".png";
			    if(File.Exists(oldFile))
				    File.Delete(oldFile);
				oldFile = purePath + m_code + ".bmp";
			    if(File.Exists(oldFile))
				    File.Delete(oldFile);
            
			    // Write data into a file, overwrite if exists
			    WriteToFile(strPath, ref myData);
			    
			    if(!String.IsNullOrEmpty(wholeSaleImageFolder)){
			    	oldFile = wholeSaleImageFolder + imageType + m_code + ".gif";
				    if(File.Exists(oldFile))
					    File.Delete(oldFile);
					oldFile = wholeSaleImageFolder + imageType + m_code + ".jpg";
				    if(File.Exists(oldFile))
					    File.Delete(oldFile);
					oldFile = wholeSaleImageFolder + imageType + m_code + ".png";
				    if(File.Exists(oldFile))
					    File.Delete(oldFile);
					oldFile = wholeSaleImageFolder + imageType + m_code + ".bmp";
				    if(File.Exists(oldFile))
					    File.Delete(oldFile);

					WriteToFile(wholeSaleImageFolder + imageType + strFileName, ref myData);
			    }
			    	
            }else{
                UploadImageFileToFolder(myFile);
            }

			if(!m_bKit)
				WriteEditLog();

            //Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=addpic.aspx?kit=" + m_kit + "&code=");
            //Response.Write(m_code + "&name=" + HttpUtility.UrlEncode(m_name));
            //Response.Write("\">");
		    if(!m_bKit)
            	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=addpic.aspx?kit=" + m_kit + "&code=" + m_code + "\">");
            else
            	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=addpic.aspx?id=" + m_code + "\">");
		}
	}
}


void UploadImageFileToFolder(HttpPostedFile file){
	// Check to see if file was uploaded
	if( file != null )
	{
		// Get a reference to PostedFile object
		HttpPostedFile myFile = file;

		// Get size of uploaded file
		int nFileLen = myFile.ContentLength; 
		String wholeSaleImageFolder = "";//WebConfigurationManager.AppSettings["wholesale_root"] ;
		// make sure the size of the file is > 0
		if( nFileLen > 0 )
		{
			string vpath = "";
			string imageType = "";
			if(m_bKit){
				vpath = "~/pk/";
				imageType = "pk\\";
			}				
			else{
				vpath = "~/pi/";
				imageType = "pi\\";
			}
				
			//update image in retail site
            string productImageFolder = Server.MapPath(vpath + m_code + "/" );
            
            //check product directory exist or not
            if(!System.IO.Directory.Exists(productImageFolder)){
                System.IO.Directory.CreateDirectory(productImageFolder);
            }
            string savePath = productImageFolder;
            string fileName = myFile.FileName;
            //check old files, delete .gif or jpg (another type)if exists
            // Create the path and file name to check for duplicates.
            string pathToCheck = productImageFolder + fileName;

            // Create a temporary file name to use for checking duplicates.
            string tempfileName = "";

            // Check to see if a file already exists with the
            // same name as the file to upload.        
            if (System.IO.File.Exists(pathToCheck))
            {
                int counter = 2;
                while (System.IO.File.Exists(pathToCheck))
                {
                    // if a file with this name already exists,
                    // prefix the filename with a number.
                    tempfileName = counter.ToString() + fileName;
                    pathToCheck = savePath   + tempfileName;
                    counter++;
                }

                fileName = tempfileName;
                
                // Notify the user that the file name was changed.
            }
            productImageFolder = productImageFolder + fileName;
           
            // Write data into a file, overwrite if exists
            myFile.SaveAs(productImageFolder);


            //-------------------update image to whole sale site.
            if(!String.IsNullOrEmpty(wholeSaleImageFolder)){
            	productImageFolder = wholeSaleImageFolder + imageType + m_code + "\\" ;
	            
	            //check product directory exist or not
	            if(!System.IO.Directory.Exists(productImageFolder)){
	                System.IO.Directory.CreateDirectory(productImageFolder);
	            }
	            savePath = productImageFolder;
	            fileName = myFile.FileName;
	            //check old files, delete .gif or jpg (another type)if exists
	            // Create the path and file name to check for duplicates.
	            pathToCheck = productImageFolder + fileName;

	            // Create a temporary file name to use for checking duplicates.
	            tempfileName = "";

	            // Check to see if a file already exists with the
	            // same name as the file to upload.        
	            if (System.IO.File.Exists(pathToCheck))
	            {
	                int counter = 2;
	                while (System.IO.File.Exists(pathToCheck))
	                {
	                    // if a file with this name already exists,
	                    // prefix the filename with a number.
	                    tempfileName = counter.ToString() + fileName;
	                    pathToCheck = savePath   + tempfileName;
	                    counter++;
	                }

	                fileName = tempfileName;
	                
	                // Notify the user that the file name was changed.
	            }
	            productImageFolder = productImageFolder + fileName;
	           
	            // Write data into a file, overwrite if exists
	            myFile.SaveAs(productImageFolder);
            }
           

            if(!m_bKit)
                WriteEditLog();
		}
	}
}


bool WriteEditLog()
{
	string sc = "INSERT INTO edit_log (code, filename, editor, clienthost, site, logtime, type) VALUES(";
	sc += m_code + ", '" + m_fileName + "', '" + Session["name"] + "', '" + Session["rip"];
	sc += "', '" + Session["site"] + "', GETDATE(), 'pic')";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

// Writes file to current folder
void WriteToFile(string strPath, ref byte[] Buffer)
{
	// Create a file
	FileStream newFile = new FileStream(strPath, FileMode.Create);
	// Write data to the file
	newFile.Write(Buffer, 0, Buffer.Length);
	// Close file
	newFile.Close();
}

Boolean GetOldData()
{
	string sPicFile = "";
	if(m_bKit)
		sPicFile = GetKitImgSrc(m_code);
	else
		sPicFile = GetProductImgSrc(m_code);
	LOldPic.Text = "<b>Main Image:</b> ";
	LOldPic.Text += m_pic;
	LOldPic.Text += "<br><img src=" + sPicFile + ">";
	LOldPic.Text += "<br><a href=addpic.aspx?kit=" + m_kit + "&code=" + m_code + "&t=da&file=" + HttpUtility.UrlEncode(sPicFile);
	LOldPic.Text += " class=linkButton>DELETE</a>";
	return true;
}

void GetProductImageList(){
	System.Collections.Generic.List<string> imageSrcList ;
	if(m_bKit)
		imageSrcList = GetKitImgSrcList(m_code);
	else
		imageSrcList = GetProductImgSrcList(m_code);
    string imageSrcListShow = "";
    LOldPic.Text += " <br /><b>Sub Image:</b> ";
    if(imageSrcList != null){
        if(imageSrcList.Count > 0){
            foreach(string ims in imageSrcList){
                imageSrcListShow += "<br /><img src='"+ims+"'  />";
                imageSrcListShow += "<br><a href=addpic.aspx?kit=" + m_kit + "&code=" + m_code + "&t=da&file=" + HttpUtility.UrlEncode(ims);
	            imageSrcListShow += " class=linkButton>DELETE</a><br />";
            }
        }else{
            LOldPic.Text += " <br /><b>No sub image here. Please add it.</b> ";
        }
    }
    LOldPic.Text += imageSrcListShow; 
}


void GetQueryStrings()
{
	m_code = Request.QueryString["code"];
	m_name = Request.QueryString["name"];
}

void PrintForm()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<form id=Form1 method=post runat=server enctype='multipart/form-data'>");
	sb.Append("<input id=filMyFile type=file runat=server>");
	sb.Append("</form>");
	Response.Write(sb.ToString());
}

void DoDelPic()
{
	try{
		string file = Server.MapPath(Request.QueryString["file"]);
		File.Delete(file);
		//String wholeSaleImageFolder = WebConfigurationManager.AppSettings["wholesale_root"] ;
		//File.Delete(wholeSaleImageFolder + Request.QueryString["file"]);
	}catch(Exception ex){

	}
}

</script>

<asp:label id=LTitle runat=server/>

<form id="Form1" method="post" runat="server" enctype="multipart/form-data" visible=false>
<input id="filMyFile" type="file" runat="server">
<br />
Set to main image <input id="isMainImage" type="checkbox" runat="server" /> 
<br />

<asp:button id="cmdSend" runat="server" OnClick="cmdSend_Click" Text="Upload"/>

<br>
<asp:Label id=LOldPic runat=server/>

</FORM>
<asp:Label id=LFooter runat=server/>