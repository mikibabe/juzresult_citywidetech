﻿<script runat=server>

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	
	PrintHeaderAndMenu("About Us");

    LBody.Text = ReadSitePage("public_blog");

	LFooter.Text = m_sFooter;
}

void PrintBody()
{
	Response.Write(GetSiteSettings("about_page", "Type HTML code here"));
	if(m_sSite == "admin")
	{
		Response.Write("<br>&nbsp&nbsp&nbsp&nbsp;<a href=about.aspx?t=e class=o>EDIT TEXT</a>");
		Response.Write("&nbsp&nbsp&nbsp&nbsp;<a href=about.aspx?t=ei class=o>EDIT IMAGES</a>");
	}
}



</script>


<form id="Form1" method="post" runat="server" >
<asp:Label id=LBody runat=server/>

<asp:Label id=LFooter runat=server/>
</FORM>
