<script runat=server>

bool m_bDisplayFirstCat = true;
bool m_bDisplaySubCat = true;
bool m_bDisplaySubSubCat = false;

/*void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck(""))
		return;
	//InitializeData(); //init functions

//	PrintAdminHeader();
//	PrintAdminMenu();
		doQueryCatalog();
	
//	LFooter.Text = m_sAdminFooter;
}
*/
int doQuerySubCatalog(string cat)
{
	DataSet dst = new DataSet();
if(ds.Tables["subcatalog"] != null)
ds.Tables["subcatalog"].Clear();
	string sc = " SELECT DISTINCT s_cat, ss_cat ";
	sc += " FROM catalog ";
	sc += " WHERE cat != 'brands' AND cat = '" + EncodeQuote(cat) +"' ";
	sc += " ORDER BY s_cat, ss_cat ";
	int rows = 0; 
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds,"subcatalog");
	}
	catch (Exception e) 
	{
		ShowExp(sc,e);
		return 0;
	}
	return rows;
}

string doQueryCatalog()
{
	m_bDisplaySubCat = MyBooleanParse(GetSiteSettings("show_sub_cat_menu_on_left_side_panel", "1", true));
	DataSet dst = new DataSet();

	string sc = " SELECT DISTINCT cat ";
	sc += " FROM catalog ";
	sc += " WHERE cat != 'brands' ";
	sc += " ORDER BY cat  ";
	int rows = 0; 
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(ds,"catalog");
	}
	catch (Exception e) 
	{
		ShowExp(sc,e);
		return "";
	}

	string s = "";
//	PrintJavaFunction();

		s += "<table cellspacing=0 cellpadding=2 border=0 bordercolor=gray bgcolor=transparent";
	s += " style='font-family:Verdana;font-size:12pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed'>";

//	s += "<div id='masterdiv'>";
	

	string old_cat = "";
	
	for(int i=0; i<rows; i++)
	{
		
		DataRow dr = ds.Tables["catalog"].Rows[i];
		string cat = dr["cat"].ToString();
		int nRows = doQuerySubCatalog(cat);
				
		string uri = "c.aspx?c="+ HttpUtility.UrlEncode(cat) +"&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
		if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
			uri += "&ssid="+ Request.QueryString["ssid"].ToString();
	//	s += "<div class='menutitle' onclick='SwitchMenu('sub"+(i+1)+"');'>"+ cat +"</div>";
		
		
		s += "<tr><td background='i/cl.gif'><img src='/i/CatArrow.gif'> <a title='view this catagory : "+ cat +"' href='"+ uri +"' ><b>"+ cat +"</b></a>";
		
		s += "</td></tr>";
		s += "<tr><td>";
	//	s += "<span class='submenu' id='sub"+(i+1)+"'>";
		//s += "<table width=100%  border=0 cellspacing=0 cellpadding=0>";
			string old_scat = "";
		if(m_bDisplaySubCat)
		{
			s += "<table width=100%  border=0 cellspacing=1 cellpadding=0 style='font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed'>";
			for(int j=0; j<nRows; j++)
			{
				dr = ds.Tables["subcatalog"].Rows[j];
				string scat = dr["s_cat"].ToString();
				string sscat = dr["ss_cat"].ToString();
				if(scat != "" && scat != null)
				{
					if(old_scat != scat)
					{	
						if(scat.ToLower() != "zzzothers")
						{
							uri = "c.aspx?c="+ HttpUtility.UrlEncode(cat) +"&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&s="+ HttpUtility.UrlEncode(scat) +"";
							if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
								uri += "&ssid="+ Request.QueryString["ssid"].ToString();
						}
						if(sscat.ToLower() != "zzzothers")
						{
							uri = "c.aspx?c="+ HttpUtility.UrlEncode(cat) +"&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&s="+ HttpUtility.UrlEncode(scat) +"&ss="+ HttpUtility.UrlEncode(sscat) +"";
							if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
								uri += "&ssid="+ Request.QueryString["ssid"].ToString();
						}
						if(scat.ToLower() != "zzzothers")
						s += "<tr><td valign='top'><img src='/i/CatArrow.gif'> <a href='"+ uri +"' class=d >"+ scat +"</a></td></tr>";
						old_scat = scat;
					}
				}
			}
			s += "</table>";
		}
		s += "</td></tr>";
		
		//s += "</span>";
		
	}
//	s += "</td></tr>";
	s += "</table>";
	s += "</div>";
//	DEBUG("s =", s);
//	Response.Write(s);
	return s;


}


void PrintJavaFunction()
{
	Response.Write("<script TYPE=text/javascript");
	Response.Write(">");
	Response.Write("function OnTypeChange(mtype)");
	Response.Write("{	window.alert(mtype);	");
	Response.Write("	var m = mtype;\r\n");
	Response.Write("	if(m = mtype){document.all('tblCompare'+mtype).style.visibility='visible';}\r\n");
	Response.Write("	else{document.all('tblCompare'+mtype).style.visibility='hidden';}\r\n");
	Response.Write("}\r\n");
	Response.Write("</script");
	Response.Write(">");

	//	
Response.Write("<script type='text/javascript'>");
string s = @"
/***********************************************
* Switch Menu script- by Martial B of http://getElementById.com/
* Modified by Dynamic Drive for format & NS4/IE4 compatibility
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var persistmenu='yes'   //'yes' or 'no'. Make sure each SPAN content contains an incrementing ID starting at 1 (id='sub1', id='sub2', etc)
var persisttype='sitewide' //enter 'sitewide' for menu to persist across site, 'local' for this page only

if (document.getElementById){ //DynamicDrive.com change
document.write('<style type='text/css'>\n')
document.write('.submenu{display: none;}\n')
document.write('</style>\n')
}

function SwitchMenu(obj){
	if(document.getElementById){
	var el = document.getElementById(obj);
	var ar = document.getElementById('masterdiv').getElementsByTagName('span'); //DynamicDrive.com change
		if(el.style.display != 'block'){ //DynamicDrive.com change
			//for (var i=0; i<ar.length; i++){
				//if (ar[i].className=='submenu') //DynamicDrive.com change
				//ar[i].style.display = 'none'; 
			//}
			el.style.display = 'block';
		}else{
			el.style.display = 'none';
		}
	}
}

function get_cookie(Name) { 
var search = Name + '='
var returnvalue = '';
if (document.cookie.length > 0) {
offset = document.cookie.indexOf(search)
if (offset != -1) { 
offset += search.length
end = document.cookie.indexOf(';', offset);
if (end == -1) end = document.cookie.length;
returnvalue=unescape(document.cookie.substring(offset, end))
}
}
return returnvalue;
}

function onloadfunction(){
if (persistmenu=='yes'){
var cookiename=(persisttype=='sitewide')? 'switchmenu' : window.location.pathname
var cookievalue=get_cookie(cookiename)
if (cookievalue!='')
document.getElementById(cookievalue).style.display='block'
}
}

function savemenustate(){
var inc=1, blockid=''
while (document.getElementById('sub'+inc)){
if (document.getElementById('sub'+inc).style.display=='block'){
blockid='sub'+inc
break
}
inc++
}
var cookiename=(persisttype=='sitewide')? 'switchmenu' : window.location.pathname
var cookievalue=(persisttype=='sitewide')? blockid+';path=/' : blockid
document.cookie=cookiename+'='+cookievalue;
}

if (window.addEventListener)
window.addEventListener('load', onloadfunction, false);
else if (window.attachEvent)
window.attachEvent('onload', onloadfunction)
else if (document.getElementById)
window.onload=onloadfunction;

if (persistmenu=='yes' && document.getElementById)
window.onunload=savemenustate;

";
Response.Write(s);
Response.Write("</script");
Response.Write(">");

Response.Write("<style type='text/css'>");
Response.Write(".menutitle{");
Response.Write("cursor:pointer;");
Response.Write("background-image:url(http://demo.creativewebs.co.nz/salespointadv/menubg.gif);");
Response.Write("color:#FFFFFF;");
Response.Write("width:144px;");
Response.Write("height:21px;");
Response.Write("text-align:left;");
Response.Write("margin-top:8px;");
Response.Write("font-family:Arial, Helvetica, sans-serif;");
Response.Write("font-size:12px;");
Response.Write("font-weight:bold;");
Response.Write("}");

Response.Write(".submenu{");
Response.Write("margin-bottom: 0.5em;");
Response.Write("}");
Response.Write("</style>");
}
</script>



