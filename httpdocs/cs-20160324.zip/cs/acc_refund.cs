<!-- #include file="page_index.cs" -->

<script runat=server>

DataSet dst = new DataSet();
DataTable dtAssets = new DataTable();

string m_id = "";
bool m_bRecorded = false;
double dsub = 0;
string m_branch = "";
string m_fromAccount = "";
string m_toAccount = "";
string m_customerID = "-1";
string m_customerName = "";
string m_paymentType = "2";
string m_paymentDate = DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy");
string m_paymentRef = "";
string m_note = "";
string m_editRow = "";
string m_nextChequeNumber = "";
string m_command = "";
string m_search = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	RememberLastPage();

	if(!SecurityCheck("accountant"))
		return;
    m_nextChequeNumber = GetSiteSettings("next_cheque_number", "100000");
    
	try{
        if(TSIsDigit(m_nextChequeNumber))
		    m_paymentRef = (int.Parse(m_nextChequeNumber) + 1).ToString();
	    else
		    m_paymentRef = m_nextChequeNumber;
    }catch(Exception ex){
        m_paymentRef = "";
    }

	PrintAdminHeader();
	PrintAdminMenu();
	GetQueryString();
	if(Request.QueryString["done"] == "1")
	{
		Response.Write("<br><center><h3>Refund Credit Note Done...</h3>");
		Response.Write("<br><br><a title='more refund.' href='acc_refund.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' ><font class=blueFont2>More Refund</font></a>");
		Response.Write("<br><br><a title='view refund history...' href='ref_report.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' ><font class=blueFont2>View Refund History</font></a>");
		return;
	}
	if(Request.QueryString["false"] == "1")
	{
		Response.Write("<br><center><h4>No Credit Note Refund...");
		Response.Write("<br><br><a title='back to refund.' href='acc_refund.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' class=o>Back Refund</a>");
		//Response.Write("<br><br><a title='view refund history...' href='ref_report.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' class=o>View Refund History</a>");
		return;
	}
	if(m_command == "REFUND")
	{
		if(DoInsertRefund())
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=acc_refund.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&done=1\">");
			return;
		}
	}
    if(m_command == "CREDIT")
	{
		if(DoInsertCredit())
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=acc_refund.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&done=1\">");
			return;
		}
	}
	if(m_command == "SEARCH" || m_search != "" || m_command == "SEARCH PAYEE")
	{
		if(!GetInvoiceRefundCusotmer())
			return;
		PrintAdminFooter();
		return;
	}
	RefundForm();

	PrintAdminFooter();
}


void GetQueryString()
{
	if(Request.Form["cmd"] != null)
		m_command = Request.Form["cmd"];
	if(Request.Form["s_card_id"] != null && Request.Form["s_card_id"] != "" || m_command == "SEARCH PAYEE")
		m_search = Request.Form["s_card_id"];
	if(Request.QueryString["cid"] != null && Request.QueryString["cid"] != "")
		m_search = Request.QueryString["cid"];
	if(Request.QueryString["cmd"] != null && Request.QueryString["cmd"] != "")
		m_command = Request.QueryString["cmd"];
//	DEBUG("m_seaerch = ", m_search);
//	DEBUG("m_seaerch = ", m_command);
}

string GetNextCheaqueNO()
{
	string iCheaque = "100000";
	string sc = " SELECT TOP 1 payment_ref  FROM acc_refund ";
	sc += " WHERE payment_ref <> null OR payment_ref != '' ";
	sc += " ORDER BY payment_ref DESC ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "cheaque") == 1)
			return iCheaque = dst.Tables["cheaque"].Rows[0]["payment_ref"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "0";
	}
	
	return iCheaque;
}
bool GetAllRefundInvoice()
{
	string sc =" SELECT i.invoice_number, i.total, i.commit_date, i.amount_paid, i.cust_ponumber ";
	sc += " FROM invoice i ";
	sc += " WHERE i.paid = 0 ";
	sc += " AND i.type=6 ";
	//sc += " AND i.invoice_number NOT IN (SELECT ars.invoice_number FROM acc_refund ar JOIN acc_refund_sub ars ON ars.id = ar.id)";
	if(Session["rcard_id"] != null)
	sc += " AND i.card_id = "+ Session["rcard_id"] +"";
//DEBUG(" sc = ", sc);
int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "invoice");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	bool bAlter = false;
	double dbalance = 0;
	double dtotal = 0;
	double dtotalpaid = 0;
//	double dsub = 0;
	if(rows > 0)
	{
		Response.Write("<table width=100% align=center cellspacing=0 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr class=tableHeader><td>CR NOTE DATE</td><td>CR NOTE#</td><td>CUST PO#</td><td>TOTAL</td><td>TOTAL REFUNDED</td><td>BALANCE</td>");
		Response.Write("<td>TOTAL INVOICE PAID</td>");
		Response.Write("<td align=right>APPLIED AMOUNT</td>");
		Response.Write("</tr>");
		Response.Write("<input type=hidden name=rows value="+ rows +">");
		for(int i=0; i<rows; i++)
		{
			Response.Write("<tr");
			if(bAlter)
			Response.Write(" class=rowColor ");
			Response.Write(">");
			bAlter = !bAlter;
			DataRow dr = dst.Tables["invoice"].Rows[i];
			string invoice = dr["invoice_number"].ToString();
			string total = dr["total"].ToString();
			string po = dr["cust_ponumber"].ToString();
			string invoice_date = dr["commit_date"].ToString();
			string paid = dr["amount_paid"].ToString();
	
			if(total == "" && total == null)
				total = "0";
			//if(double.Parse(total) < 0)
			//	total = (0 - double.Parse(total)).ToString();
			if(paid == "" && paid == null)
				paid = "0";
			//if(double.Parse(paid) < 0)
			//	paid = (0 - double.Parse(paid)).ToString();
			//dtotal = Math.Round(double.Parse(total),2);
			//dtotalpaid = Math.Round(double.Parse(paid),2);
			total = total.Replace("-", "");
			dtotal = double.Parse(total);
			dtotalpaid = double.Parse(paid);
			dbalance = dtotal + dtotalpaid;
			dsub += dbalance;
			Response.Write("<td>"+ DateTime.Parse(invoice_date).ToString("dd-MM-yyyy") +"</td>");
			Response.Write("<td><a title='view invocie' href='invoice.aspx?i="+ invoice +"' class=o target=blank>"+ invoice +"</a></td>");
			Response.Write("<td>"+ po +"</td>");
			Response.Write("<td>"+ dtotal.ToString("c") +"</td>");
			Response.Write("<td>"+ dtotalpaid.ToString("c") +"</td>");
			Response.Write("<td>"+ dbalance.ToString("c") +"</td>");
			Response.Write("<td>");
			if(dbalance == 0)
				Response.Write("<font>");
			else
				Response.Write("<font class=blueFont2>");
			Response.Write(""+ dtotalpaid.ToString("c") +"</font></td>");
			
			//Response.Write("<td align=right><input type=checkbox name='refund_total"+i+"' value='"+ total +"' onclick=\"if(document.frm.refund_total\"+ i +\".checked){window.alert(document.frm.total_amount.value = eval(document.frm.total_amount.value) + eval(document.frm.refund_total\"+i+\".value));}\"></td>");
			Response.Write("<input type=hidden name='h_invoice"+ i +"' value='"+ invoice +"'>");
			Response.Write("<input type=hidden name='h_balance"+ i +"' value='"+ dbalance +"'>");
            Response.Write("<input type=hidden name='h_dtotal"+ i +"' value='"+ dtotal +"'>");
            Response.Write("<input type=hidden name='h_dtotalRefund"+ i +"' value='"+ dtotalpaid +"'>");
			Response.Write("<td align=right><input style='text-align:right' type=text name=refund_total"+ i +" value='"+ dbalance.ToString() +"' ");
			
			Response.Write("onclick=\"");
			Response.Write("if(this.value>0){this.value=0;} return CalOnChange(this, document.frm.bclick.value,'"+ i +"' ); this.select();");
			//Response.Write("this.value=0; this.select();");
			Response.Write("\" ");
				//	Response.Write("onchange=\"return Calculate('"+ i +"', document.frm.bclick.value );\"");
			Response.Write("onchange=\"return CalOnChange(this, document.frm.bclick.value,'"+ i +"' );\"");
			Response.Write("'></td>");
		
			Response.Write("</tr>");
		}
		Response.Write("<input type=hidden name=dsub value="+ dsub +">");
		Response.Write("<input type=hidden name=bclick value=false>");
		Response.Write("</table>");
	}
	javaFunction();
	
	

	return true;
}

void javaFunction()
{
		Response.Write("<script TYPE=text/javascript");
	Response.Write(">\r\n");

		Response.Write("function Calculate(ivalue, bClick)\r\n");
	Response.Write("{	\r\n");
	Response.Write("}\r\n");
	
		Response.Write("function CalOnChange(ivalue, bClick, irows)\r\n");
	Response.Write("{	\r\n");
		Response.Write("var dsub = 0;\r\n ");
		Response.Write("if(!IsNumberic(ivalue.value)) {");
		Response.Write("  ivalue.value='0'; ivalue.select(); return false; }\r\n");
		Response.Write(" if(eval(ivalue.value) > eval(eval(\"document.frm.h_balance\"+ irows +\".value\"))){ ");
			Response.Write(" ivalue.value ='0'; ivalue.select(); return false; }\r\n");
		Response.Write("for(var i=0; i<document.frm.rows.value; i++){ \r\n");
		Response.Write(" var total = eval(\"document.frm.refund_total\"+ i +\".value\") \r\n");
		Response.Write(" dsub = eval(total) + eval(dsub); ");
		Response.Write("} \r\n");
		Response.Write("document.frm.total_amount.value = eval(dsub); \r\n");
	Response.Write("}\r\n");
	Response.Write("function IsNumberic(sText)");
	Response.Write("{");
	Response.Write("var ValidChars = '0123456789-.';");
	Response.Write("		  var IsNumber=true;");
	Response.Write("		   var Char;");
	Response.Write("		   for (i = 0; i < sText.length && IsNumber == true; i++) ");
	Response.Write("		  { ");
	Response.Write("	  Char = sText.charAt(i); ");
	Response.Write("		if (ValidChars.indexOf(Char) == -1) ");
	Response.Write("{");
	Response.Write("			 IsNumber = false;");
	Response.Write("				 }");
	Response.Write("	   }");
	Response.Write("			return IsNumber;");
   	Response.Write("    }");
	Response.Write("</script");
	Response.Write(">");

}

bool DoInsertRefund()
{
	string total_amount = Request.Form["total_amount"];
	if(total_amount == "" && total_amount == null)
	total_amount = "0";
	double dtotal = double.Parse(total_amount);
	string account_id = Request.Form["from_account"];
	//DEBUG("account_id +", account_id);
	string note = Request.Form["note"];
	if(note != "")
	note = EncodeQuote(note);
	string payment_reference = Request.Form["payment_ref"];
	string refund_id = "";
	string payment_type = Request.Form["payment_type"];

	if(Request.Form["rows"] == null || Request.Form["rows"] == "")
	{
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=acc_refund.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&false=1\">");
		return false;
	}
	string sc = " SET DATEFORMAT dmy ";
	if(Request.Form["rows"] != null && Request.Form["rows"] != "")
	{
		if(total_amount != "0")
		{
	//		sc += " BEGIN TRANSACTION ";

			sc += " INSERT INTO acc_refund (total, recorded_by, recorded_date, card_id, from_account ";
			sc += " , note,  payment_ref, payment_type ";
			sc += " ) ";
			sc += " VALUES("+ dtotal +", '"+ Session["card_id"] +"', GETDATE(), '"+ Session["rcard_id"] +"' ";
			sc += " ,'"+ account_id +"', '"+ note +"',  '"+ payment_reference +"', "+ payment_type +" ";
			sc += " ) ";
			sc += " SELECT IDENT_CURRENT('acc_refund') AS id ";
	//		sc = " SELECT TOP 1 id FROM acc_refund ORDER BY id DESC ";
//	DEBUG("sc =", sc);
			
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				if(myCommand.Fill(dst, "refund_id") != 1)
				{
					Response.Write("<br><br><center><h3>Error getting IDENT");
					return false;
				}
				refund_id = dst.Tables["refund_id"].Rows[0]["id"].ToString();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}

			sc = " BEGIN TRANSACTION ";
//			sc += " UPDATE account SET balance = balance - "+ dtotal +" WHERE id = "+ account_id +" "; 
            //remove pay account move this function to daily statement.
			sc += " UPDATE settings SET value = '"+ payment_reference +"' WHERE name = 'next_cheque_number' ";
//	DEBUG("dtotal =", dtotal);
			sc += " COMMIT ";
//	DEBUG("sc =", sc);
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
		
//	DEBUG("rows = ", Request.Form["rows"].ToString());		
			for(int i=0; i<int.Parse(Request.Form["rows"].ToString()); i++)
			{
				
				string inv = Request.Form["h_invoice"+ i].ToString();
				string balance = Request.Form["h_balance"+ i].ToString();
                string dTotal = Request.Form["h_dtotal"+ i].ToString();
				string amount_paid = Request.Form["refund_total"+ i].ToString();
                string totalRefund = Request.Form["h_dtotalRefund" + i].ToString();
//	DEBUG(" amount_paid = ", amount_paid);
				string complete_trans = "0";
				if(double.Parse(amount_paid) >= double.Parse(balance))
					complete_trans = "1";
				if(amount_paid != "0" && refund_id != "")
				{				
					sc = " SET DATEFORMAT dmy ";
					sc += " BEGIN TRANSACTION ";
					sc += " INSERT INTO acc_refund_sub (id, invoice_number, amount_refund, amount_owe, complete_trans) ";
					sc += " VALUES ('"+ refund_id +"', '"+ inv +"', "+ amount_paid +", "+ balance +", ";
					sc += complete_trans;
					sc += " )";
	                //		if(double.Parse(amount_paid) > 0)
	                //		amount_paid = "-"+ amount_paid;
                    if(double.Parse(amount_paid) == double.Parse(balance)){ //if refund all then mark invoice paid and refund
					    //sc += " UPDATE invoice SET amount_paid = 0 - "+ dTotal +", paid=1, refunded=1 ";
                    } else if(double.Parse(amount_paid) > double.Parse(balance)){//if amount_paid grade than balance then plus to total paid
                        double totalPaid = double.Parse(dTotal) + (double.Parse(amount_paid) - double.Parse(balance));
                        //sc += " UPDATE invoice SET amount_paid = 0 - "+ totalPaid +", paid=1, refunded=1 ";
                    } else{ //if not paid all then just update amount paid
                        double t = (-double.Parse(totalRefund)) + double.Parse(amount_paid);
                        //sc += " UPDATE invoice SET amount_paid = 0 - "+ t +" ";
                    }
					//sc += " WHERE invoice_number = "+ inv +" ";

					sc += " COMMIT ";
                    //	DEBUG("sc =", sc);

					try
					{
						myCommand = new SqlCommand(sc);
						myCommand.Connection = myConnection;
						myConnection.Open();
						myCommand.ExecuteNonQuery();
						myCommand.Connection.Close();
					}
					catch(Exception e) 
					{
						ShowExp(sc, e);
						return false;
					}	

				}

			}
			
		}
	}

    //insert refund transaction.
    DoInsertRefundTran();

	return true;
}

bool PrintFromAccountList()
{
	int rows = 0;
	string sc = "SELECT * FROM account ";
	//sc += " WHERE class1=1 OR class1=2 ";
	sc += " ORDER BY class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "account");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=from_account>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["account"].Rows[i];
		string id = dr["id"].ToString();
		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		double dAccBalance = double.Parse(dr["balance"].ToString());
		Response.Write("<option value=" + id);
		if(id == m_fromAccount)
		{
			Response.Write(" selected");

		}
		Response.Write(">" + disnumber + " " + dr["name1"].ToString().ToUpper() +" - " + dr["name4"].ToString());
		Response.Write(" : "+ dAccBalance.ToString("c"));
	}
	Response.Write("</select>");

	return true;
}

bool PrintToAccountList()
{
	int rows = 0;
	string sc = "SELECT *, name4+' ' +name1 AS type ";
	sc += " FROM account ";
	//sc += " WHERE class1=1 AND class2=3 ";
	sc += " ORDER BY type ";//class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "toaccount");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=to_account>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccount"].Rows[i];
		string id = dr["id"].ToString();
		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		double dAccBalance = double.Parse(dr["balance"].ToString());
		Response.Write("<option value=" + id);
		if(id == m_toAccount)
		{
			Response.Write(" selected");
//			m_sAccBalance = dAccBalance.ToString("");
		}
		Response.Write(">" + dr["type"].ToString());
//		Response.Write(" " +dr["name1"].ToString());
//		Response.Write(" " + dAccBalance.ToString());		
	}
	Response.Write("</select>");
	return true;
}

void RefundForm()
{
	
	Response.Write("<br><center><h3>REFUND / CREDIT NOTE</center><h3>");
	Response.Write("<form name=frm method=post >");
	Response.Write("<table width=90% align=center cellspacing=0 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td><b>Branch : </b></td>");
	Response.Write("<td>");
	if(!PrintBranchNameOptions())
		return;
	Response.Write("</td>");
	Response.Write("<td align=right valign=top>");
		//payment table
		Response.Write("<b>Payment Type : </b></td>");
		Response.Write("<td>");

		Response.Write("<select name=payment_type onchange=");
		Response.Write(" \"if(this.options[this.selectedIndex].value == '2')");
		Response.Write("document.frm.payment_ref.value='" + m_paymentRef + "'; ");
		Response.Write("else document.frm.payment_ref.value=document.frm.payment_ref_old.value;");
		Response.Write("\">");
		Response.Write(GetEnumOptions("payment_method", m_paymentType));
		Response.Write("</select></td></tr>");
	Response.Write("<tr align=left><td><b>Payee :</b></td><td><table><tr><td><input type=text name=s_card_id value='"+ Session["rname"] + "' onclick=\"document.frm.s_card_id.value=''\"> </td>");
	Response.Write("<script");
		Response.Write(">\r\ndocument.frm.s_card_id.select();\r\n</script");
		Response.Write(">\r\n");
	Response.Write("<input type=hidden name=card_id value="+ Session["rcard_id"] +" >");
	
	if(Session["rcard_id"] != null)
	{
		Response.Write("<input type=button onclick=\"javascript:viewcard_window=window.open('viewcard.aspx?");
		Response.Write("id=" + Session["rcard_id"] + "','',' width=350,height=350');\" value='VIEW' class=linkButtonCenter title='VIEW'>");
	}
	Response.Write(" <td><input type=submit name=cmd value=SEARCH class=searchButton2></td></tr></table>");
	Response.Write("</td>");
	Response.Write("<td align=right><b>Reference : </b></td>");
		Response.Write("<td><input type=text name=payment_ref style='text-align:right' value='" + m_paymentRef + "'");
		Response.Write(" onchange=\"document.frm.payment_ref_old.value=this.value;\">");
		Response.Write("<input type=hidden name=payment_ref_old></td></tr>");

		//from account
	Response.Write("<tr><td><b>From Account : </b></td><td>");
	if(!PrintFromAccountList())
		return;
	Response.Write("</td>");
	Response.Write("<td align=right><b>Payment Date : </b></td><td>");
	Response.Write("<input type=text name=payment_date value='" + m_paymentDate + "' style='text-align:right'>");
	Response.Write("</td></tr>");
	
	//To account
//	Response.Write("<tr><td><b>Assets Type : </b></td><td>");
//	if(!PrintToAccountList())
//		return;
//	Response.Write("</td>");
//	Response.Write("<td align=right><b>Amount : </b></td><td>");
//	Response.Write("\r\n<input type=text name=total_amount style='text-align:right' value='"+ dsub +"' onclick=''>");
//	Response.Write("</td></tr>");
	
	if(Session["rcard_id"] != null)
	{
		Response.Write("<tr><td colspan=4>");
		if(!GetAllRefundInvoice())
			return;
		Response.Write("</td></tr>");
	}

    Response.Write("<tr><td></td><td></td>");
    Response.Write("<td align=right><b>Total Applied : </b></td>");
    Response.Write("<td><input type=text name=total_amount style='text-align:right' value='"+ dsub.ToString() +"' onclick=''> </td>");


    
	Response.Write("<tr><th align=left colspan=4 class=commentTable>NOTE: <br /><textarea class=commentText name=note cols=70 rows=7></textarea>");
	Response.Write("</td></tr>");

	//Response.Write("</td></tr>");
	//Response.Write("<td align=right valign=top>");
	//Response.Write("\r\n<b>Total Applied : </b><input type=text name=total_amount style='text-align:right' value='"+ dsub.ToString() +"' onclick=''>");
	//Response.Write("</td></tr>");
	Response.Write("<tr align=right>");
	Response.Write("<td valign=bottom colspan=4>");
	Response.Write("<input type=button name=cmd value='VIEW REFUND REPORT' style='line-height:0px;' class=viewRefundReportButton onclick=\"window.location=('ref_report.aspx')\"> ");
//	Response.Write("<i>Pls Check to do the Transaction</i> <input type=checkbox name=check_refund value='1'>&nbsp;&nbsp;");
	Response.Write("<input type=submit name=cmd value='REFUND' style='line-height:0px;' class=refundButton");
	Response.Write(" onclick=\"if(document.frm.card_id.value==''){window.alert('Please Select Payee!!!');return false;}else return confirm('Process Now...');\" ");
	Response.Write(" />");

	Response.Write(" or <input type=submit name=cmd value='CREDIT' style='line-height:0px;'  class=creditButton");
	Response.Write(" onclick=\"if(document.frm.card_id.value==''){window.alert('Please Select Payee!!!');return false;}else return confirm('Process Now...');\" ");
	Response.Write(" />");

	Response.Write("</td></tr>");
	Response.Write("</table>");
	Response.Write("</form>");
}

bool GetInvoiceRefundCusotmer()
{
	string sc = " SELECT sum(i.total - i.amount_paid) as total,c.name, c.company, c.email, c.phone, c.fax, c.id ";
	sc += " FROM card c JOIN invoice i on i.card_id = c.id  ";
	sc += " WHERE i.total - i.amount_paid < 0 ";
	sc += " AND i.type = 6 ";
//	sc += " AND i.refunded = 1 ";
	if(m_search != "")
	{
		sc += " AND ";
		if(TSIsDigit(m_search))
			sc += " c.id = "+ m_search +" ";
		else
		{
			m_search = EncodeQuote(m_search);
			m_search = "%"+ m_search +"%";
			sc += " (c.name LIKE '"+ m_search +"' OR c.company LIKE '"+ m_search +"' ";
			sc += " OR c.phone LIKE '"+ m_search +"' OR c.email LIKE '"+ m_search +"' )";
		}
	}
//	if(m_card_id != "")
//		sc += " AND c.id = "+ m_card_id +"";
	sc += " GROUP BY c.name, c.company, c.email, c.phone, c.fax, c.id ";
//	sc += " ORDER BY sum(i.total) ";
//DEBUG("sc = ",sc);
	int rows =0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "refund_cust");
		if(rows == 1)
		{
			Session["rname"] = dst.Tables["refund_cust"].Rows[0]["name"].ToString();
			if(Session["rname"] == null || Session["rname"] == "")
				Session["rname"] = dst.Tables["refund_cust"].Rows[0]["company"].ToString();
			Session["rcard_id"] = dst.Tables["refund_cust"].Rows[0]["id"].ToString();
			Response.Write("<script language=javascript>window.location=('"+ Request.ServerVariables["URL"] +"');</script");
			Response.Write(">");
			return false;
		}
		
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(rows <= 0)
	{
        Response.Write("<script language=javascript>window.alert('No Payee Found');window.location='acc_refund.aspx';</script");
        Response.Write(">");
		return false;
	}
	double dTotalRefund = 0;

	if(rows > 0)
	{
		//paging class
		PageIndex m_cPI = new PageIndex(); //page index class
		if(Request.QueryString["p"] != null)
			m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
		if(Request.QueryString["spb"] != null)
			m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
		rows = dst.Tables["refund_cust"].Rows.Count;
		m_cPI.TotalRows = rows;
		m_cPI.PageSize = 25;
		m_cPI.URI = "?";
		
		string uri = Request.ServerVariables["URL"] +"?";
		if(m_cPI.CurrentPage.ToString() != "" && m_cPI.CurrentPage.ToString() != null)
			uri += "p="+ m_cPI.CurrentPage.ToString() +"&";
		if(m_cPI.StartPageButton.ToString() != "" && m_cPI.StartPageButton.ToString() != null)
			uri += "spb="+ m_cPI.StartPageButton.ToString() +"&";
		if(m_command != "")
			m_cPI.URI += "cmd="+m_command;
		int i = m_cPI.GetStartRow();
		int end = i + m_cPI.PageSize;
		string sPageIndex = m_cPI.Print();

		Response.Write("<form name=frm method=post>");
		Response.Write("<table width=90% align=center cellspacing=2 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr><td colspan=3>");
		Response.Write("<b>SEARCH:</b> <input type=text name=s_card_id value=''><input type=submit name=cmd value='SEARCH PAYEE' class=linkButtonCenter title='SEARCH PAYEE'>");
		Response.Write("<script");
		Response.Write(">\r\ndocument.frm.s_card_id.select();\r\n</script");
		Response.Write(">\r\n");
		Response.Write("<input type=button name=cmd value='<< Back' class=linkButtonCenter title='<< Back' onclick=\"window.location=('"+ Request.ServerVariables["URL"]+"')\">");
		Response.Write("</td><td align=right colspan=3>");
		Response.Write(sPageIndex);
		Response.Write("</td></tr>");
		Response.Write("<tr class=tableHeader><td>CARD ID</td><td>NAME</td><td>COMPANY</td><td>PHONE</td><td>EMAIL</td><td>TOTAL</td></tr>");
		bool bAlter = false;
		for(; i<rows && i<end; i++)
		{
			DataRow dr = dst.Tables["refund_cust"].Rows[i];
			string id = dr["id"].ToString();
			string name = dr["name"].ToString();
			string company = dr["company"].ToString();
			string email = dr["email"].ToString();
			string phone = dr["phone"].ToString();
			string total = dr["total"].ToString();
			
			if(total == "" && total == null)
				total = "0";
			dTotalRefund = Math.Round(double.Parse(total), 2);
			Response.Write("<tr");
			if(bAlter)
				Response.Write(" class=rowColor ");
			Response.Write(">");
			bAlter = !bAlter;
			Response.Write("<td><a title='select this "+name+"' href='"+ uri +"cid="+ id +"' class=o>");
			Response.Write(id);
			Response.Write("</a></td>");
			Response.Write("<td><a title='select this "+name+"' href='"+ uri +"cid="+ id +"' class=o>");
			Response.Write(name);
			Response.Write("</td>");
			Response.Write("<td>");
			Response.Write(company);
			Response.Write("</td>");
			Response.Write("<td><a title='select this "+name+"' href='"+ uri +"cid="+ id +"' class=o>");
			Response.Write(email);
			Response.Write("</td>");
			Response.Write("<td>");
			Response.Write(phone);
			Response.Write("</td>");
			Response.Write("<td>");
			Response.Write(dTotalRefund.ToString("c"));
			Response.Write("</td>");
			
			Response.Write("</tr>");
		}
		Response.Write("</table>");
		Response.Write("</form>");
	}
	return true;
}



bool DoInsertCredit()
{
	string payment_method = Request.Form["payment_type"];//GetEnumID("payment_method", "cheque");
	//string sAmount = Request.Form["total_amount"];
	string sTotalApplied = Request.Form["total_applied"];
    string payDate = Request.Form["payment_date"];
	double dAmountForCardBalance = 0;
	double dCreditApplied = 0;
    //if(m_paymentType == "7") //GetEnumID("payment_method", "credit apply")
    //    dCreditApplied = MyMoneyParse(sTotalApplied) + MyMoneyParse(Request.Form["finance"]);
    //else
    //    dAmountForCardBalance = MyMoneyParse(sAmount) - MyMoneyParse(Request.Form["finance"]);

	String m_bank = Request.Form["from_account"];
    string m_bank_branch = "";
    string m_banknew = "";
    string m_bank_branchnew = "";
    //if(m_banknew != "")
    //    m_bank = m_banknew;
    //if(m_bank_branchnew != "")
    //    m_bank_branch = m_bank_branchnew;

	m_bank = EncodeQuote(m_bank);
	m_bank_branch = EncodeQuote(m_bank_branch);

    string m_paidby = Request.Form["paid_by"];

	string invoices = "";
	string amountList = "";
    int rows = int.Parse(Request.Form["rows"]);
	for(int i = 0; i < rows; i++)
	{
		//string s_sAmount = "applied_amount" + i.ToString();
		//double d_balance = MyDoubleParse(dst.Tables["cust_invoice"].Rows[i]["balance"].ToString());
		//d_balance = Math.Round(d_balance, 2);

		//double d_applied = 0;
        //if(Request.Form[s_sAmount] != null && Request.Form[s_sAmount].ToString() != "")
        //{
        //    d_applied = MyDoubleParse(Request.Form[s_sAmount].ToString());
        //    d_applied = Math.Round(d_applied, 2);
        //}

        ////record applied invoice number and amount applied to each
        //if(d_applied != 0 || d_balance == 0)
        //{
        //    invoices += Request.Form["h_invoice" + i.ToString()] + ",";
        //    amountList += Request.Form[s_sAmount] + ",";
        //}
        invoices += Request.Form["h_invoice" + i.ToString()] + ",";
		amountList += "-" + Request.Form["refund_total" + i.ToString()] + ",";
	}
	
	//do transaction
	SqlCommand myCommand = new SqlCommand("eznz_payment", myConnection);
	myCommand.CommandType = CommandType.StoredProcedure;
	myCommand.Parameters.Add("@Amount", SqlDbType.Money).Value = Request.Form["total_amount"];
	myCommand.Parameters.Add("@paid_by", SqlDbType.VarChar).Value = m_paidby;
	myCommand.Parameters.Add("@bank", SqlDbType.VarChar).Value = m_bank;
	myCommand.Parameters.Add("@branch", SqlDbType.VarChar).Value = m_bank_branch;
	myCommand.Parameters.Add("@nDest", SqlDbType.Int).Value = Request.Form["account"];
	myCommand.Parameters.Add("@amount_for_card_balance", SqlDbType.Money).Value = dAmountForCardBalance;
	myCommand.Parameters.Add("@shop_branch", SqlDbType.Int).Value = MyIntParse(Request.Form["branch"]);
	myCommand.Parameters.Add("@staff_id", SqlDbType.Int).Value = Session["card_id"].ToString();
	myCommand.Parameters.Add("@card_id", SqlDbType.Int).Value = Session["rcard_id"].ToString();
	myCommand.Parameters.Add("@payment_method", SqlDbType.Int).Value = 7;//Request.Form["payment_type"];
	myCommand.Parameters.Add("@invoice_number", SqlDbType.VarChar).Value = invoices;
	myCommand.Parameters.Add("@payment_ref", SqlDbType.VarChar).Value = Request.Form["payment_ref"];
	myCommand.Parameters.Add("@note", SqlDbType.VarChar).Value =  Request.Form["note"];
	myCommand.Parameters.Add("@finance", SqlDbType.Money).Value = 0;//Request.Form["finance"];
	myCommand.Parameters.Add("@credit", SqlDbType.Money).Value = dAmountForCardBalance + double.Parse(Request.Form["total_amount"]);
	myCommand.Parameters.Add("@bRefund", SqlDbType.Bit).Value = 0;
	myCommand.Parameters.Add("@amountList", SqlDbType.VarChar).Value = amountList;
	myCommand.Parameters.Add("@return_tran_id", SqlDbType.Int).Direction = ParameterDirection.Output;
    try
    {
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
    catch(Exception e) 
    {
        ShowExp("DoCustomerPayment", e);
        return false;
    }
	string m_tranid = myCommand.Parameters["@return_tran_id"].Value.ToString();
    string payDateString = DateTime.Now.ToString("yyyyMMdd");
    try{
        string[] s = payDate.Split('/');
        if(s[0].Length <= 1){
            s[0] = "0" + s[0];
        }
        if(s[1].Length <= 1){
            s[1] = "0" + s[1];
        }
        payDateString = s[2] + s[1] + s[0];
        string sql = "UPDATE trans ";
        sql += " SET trans_date = '"+ payDateString +"' ";
        sql += " WHERE id = "+ m_tranid +" ";
        
        payDateString = s[2] + "-" + s[1] + "-" + s[0] ;

        sql += " UPDATE tran_detail ";
        sql += " SET trans_date = '"+ payDateString +"' ";
        sql += " WHERE id = "+ m_tranid +" ";

        myCommand = new SqlCommand(sql);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();

        //DEBUG("SQL=", sql);

    }catch(Exception){
        return false;
    }
	return true;
}


bool DoInsertRefundTran()
{
	string payment_method = Request.Form["payment_type"];//GetEnumID("payment_method", "cheque");
	string sTotalApplied = Request.Form["total_applied"];
    string payDate = Request.Form["payment_date"];
	double dAmountForCardBalance = 0;
	double dCreditApplied = 0;
    string totalAmount = Request.Form["total_amount"];
    if(!totalAmount.Contains("-")){
        totalAmount = "-" + totalAmount;
    }

	String m_bank = Request.Form["from_account"];
    string m_bank_branch = "";
    string m_banknew = "";
    string m_bank_branchnew = "";


	m_bank = EncodeQuote(m_bank);
	m_bank_branch = EncodeQuote(m_bank_branch);

    string m_paidby = Request.Form["paid_by"];

	string invoices = "";
	string amountList = "";
    int rows = int.Parse(Request.Form["rows"]);
	for(int i = 0; i < rows; i++)
	{
        invoices += Request.Form["h_invoice" + i.ToString()] + ",";
		amountList += "-" + Request.Form["refund_total" + i.ToString()] + ",";
	}
	
	//do transaction
	SqlCommand myCommand = new SqlCommand("eznz_payment", myConnection);
	myCommand.CommandType = CommandType.StoredProcedure;
	myCommand.Parameters.Add("@Amount", SqlDbType.Money).Value = totalAmount;
	myCommand.Parameters.Add("@paid_by", SqlDbType.VarChar).Value = m_paidby;
	myCommand.Parameters.Add("@bank", SqlDbType.VarChar).Value = m_bank;
	myCommand.Parameters.Add("@branch", SqlDbType.VarChar).Value = m_bank_branch;
	myCommand.Parameters.Add("@nDest", SqlDbType.Int).Value = 1116;// Request.Form["card_id"];
	myCommand.Parameters.Add("@amount_for_card_balance", SqlDbType.Money).Value = 0;//dAmountForCardBalance;
	myCommand.Parameters.Add("@shop_branch", SqlDbType.Int).Value = MyIntParse(Request.Form["branch"]);
	myCommand.Parameters.Add("@staff_id", SqlDbType.Int).Value = Session["card_id"].ToString();
	myCommand.Parameters.Add("@card_id", SqlDbType.Int).Value = Session["rcard_id"].ToString();
	myCommand.Parameters.Add("@payment_method", SqlDbType.Int).Value = payment_method;//7;//Request.Form["payment_type"];
	myCommand.Parameters.Add("@invoice_number", SqlDbType.VarChar).Value = invoices;
	myCommand.Parameters.Add("@payment_ref", SqlDbType.VarChar).Value = Request.Form["payment_ref"];
	myCommand.Parameters.Add("@note", SqlDbType.VarChar).Value =  Request.Form["note"];
	myCommand.Parameters.Add("@finance", SqlDbType.Money).Value = 0;//Request.Form["finance"];
	myCommand.Parameters.Add("@credit", SqlDbType.Money).Value = 0;//dAmountForCardBalance + double.Parse(Request.Form["total_amount"]);
	myCommand.Parameters.Add("@bRefund", SqlDbType.Bit).Value = 1;
	myCommand.Parameters.Add("@amountList", SqlDbType.VarChar).Value = amountList;
	myCommand.Parameters.Add("@return_tran_id", SqlDbType.Int).Direction = ParameterDirection.Output;
    try
    {
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
    catch(Exception e) 
    {
     //   ShowExp("DoCustomerPayment", e);
        return false;
    }
	string m_tranid = myCommand.Parameters["@return_tran_id"].Value.ToString();
    string payDateString = DateTime.Now.ToString("yyyyMMdd");
    try{
        string[] s = payDate.Split('/');
        if(s[0].Length <= 1){
            s[0] = "0" + s[0];
        }
        if(s[1].Length <= 1){
            s[1] = "0" + s[1];
        }
        payDateString = s[2] + s[1] + s[0];
        string sql = "UPDATE trans ";
        sql += " SET trans_date = '"+ payDateString +"' ";
        sql += " WHERE id = "+ m_tranid +" ";
        
        payDateString = s[2] + "-" + s[1] + "-" + s[0] ;

        sql += " UPDATE tran_detail ";
        sql += " SET trans_date = '"+ payDateString +"' ";
        sql += " WHERE id = "+ m_tranid +" ";

        myCommand = new SqlCommand(sql);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();


    }catch(Exception){
        return false;
    }
	return true;
}


</script>
