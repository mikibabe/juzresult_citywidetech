
<script runat=server>
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("technician"))
		return;
	//InitializeData(); //init functions

	//PrintAdminHeader();
	//PrintAdminMenu();
	if(!getCustomer())
		return;
	//BindCustomer();
	//LFooter.Text = m_sAdminFooter;
}

bool getCustomer()
{
	int rows = 0;
	string card_id = "";
	if(Request.QueryString["id"] != "" && Request.QueryString["id"] != null)
		card_id = Request.QueryString["id"].ToString();
	else
		return true;
	string sc = "SELECT c.*, e.name AS card_type, e1.name AS term ";
	sc += " FROM card c LEFT OUTER JOIN enum e ON e.id = c.type AND e.class='card_type' ";
	sc += " LEFT OUTER JOIN enum e1 ON e1.id = c.credit_term AND e1.class = 'credit_terms' ";
	sc += " WHERE c.id = "+ card_id +" ";
	sc += " ORDER BY c.id ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "card");

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows <= 0)
	{
		Response.Write("<center><h5><font color=Red>NO Customer Details</h5></font></center>");
		return false;
	}

	DataRow dr = dst.Tables["card"].Rows[0];
	string id = dr["id"].ToString();
	string name = dr["name"].ToString();
	string company = dr["company"].ToString();
	string email = dr["email"].ToString();
	string trading_name = dr["trading_name"].ToString();
	string contact = dr["contact"].ToString();
	string phone = dr["phone"].ToString();
	string addr1 = dr["address1"].ToString();
	string addr2 = dr["address2"].ToString();
	string city = dr["city"].ToString();
	string fax = dr["fax"].ToString();
	string dealer_level = dr["dealer_level"].ToString();
	string card_type = dr["card_type"].ToString();
	string credit_term = dr["term"].ToString();
	//Response.Write("<center><h5>Customer Details</h5></center>");
	Response.Write("<div id=ezcardHolder><table align=center cellspacing=0 cellpadding=0 border=0  bgcolor=white");
	Response.Write(">");
	Response.Write("<tr class=tableHeader><th colspan=2 >Customer Details</th></tr>");
	Response.Write("<tr><td colspan=2>&nbsp;</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  nowrap style=\"color:#0066FF\">Customer ID:</th><td> "+ id +"</td></tr>");
	Response.Write("<tr ><td  style=\"color:#0066FF\">Name:</th><td > "+ name +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  style=\"color:#0066FF\">Trading Name:</th><td> "+ trading_name +"</td></tr>");
	Response.Write("<tr ><td  style=\"color:#0066FF\">Company:</th><td> "+ company +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  style=\"color:#0066FF\">Address:</th><td> "+ addr1 +"</td></tr>");
	Response.Write("<tr ><td  style=\"color:#0066FF\">&nbsp;</th><td> "+ addr2 +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  >&nbsp;</th><td> "+ city +"</td></tr>");
	Response.Write("<tr ><td  style=\"color:#0066FF\">Email:</th><td> "+ email +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  style=\"color:#0066FF\">Phone:</th><td> "+ phone +"</td></tr>");
	Response.Write("<tr ><td  style=\"color:#0066FF\">Fax:</th><td> "+ fax +"</td></tr>");
//	Response.Write("<tr><td  >Contact:</th><td> "+ contact +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  style=\"color:#0066FF\">Dealer Level:</th><td> "+ dealer_level +"</td></tr>");
	Response.Write("<tr ><td   style=\"color:#0066FF\">Card Type:</th><td> "+ card_type +"</td></tr>");
	Response.Write("<tr bgcolor=#f2fdff><td  style=\"color:#0066FF\">Credit Term:</th><td > "+ credit_term +"</td></tr>");
	Response.Write("<tr ><td colspan=2 align=center><input type=button value='    close   '  class=closeButton  onclick='window.close();'>");
	Response.Write("</table><div>");
	return true;
}

bool BindCustomer()
{
	string search = "";
	if(Request.Form["search"] != null)
		search = Request.Form["search"].ToString();
	
	Response.Write("<br>");
	Response.Write("<form name=frm >");
	Response.Write("<table width=100% align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	//Response.Write("<tr><td>&nbsp;</td></tr>");
	Response.Write("<tr><td colspan=6 >Customers&nbsp;&nbsp;&nbsp;");
	Response.Write("Dealers&nbsp;&nbsp;&nbsp;");
	Response.Write("Suppliers&nbsp;&nbsp;&nbsp;");
	Response.Write("Employees&nbsp;&nbsp;&nbsp;");
	Response.Write("Others&nbsp;&nbsp;&nbsp;");
	Response.Write("All&nbsp;&nbsp;&nbsp;");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=6><input type=text name=search value='"+search+"'><input type=submit name=cmd value='Search Customer'></td></tr>");
	Response.Write("<tr><td colspan=6>&nbsp;</td></tr>");
	Response.Write("<tr bgcolor=#B995A7><th>ID</th><th>Name</th><th>Trading Name</th><th>Email</th><th>Contact</th><th>Phone</th></tr>");
	bool bChange = true;
	for(int i=0; i<dst.Tables["card"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["card"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		string company = dr["company"].ToString();
		string email = dr["email"].ToString();
		string trading_name = dr["trading_name"].ToString();
		string contact = dr["contact"].ToString();
		string phone = dr["phone"].ToString();
		
		//string id = dr["id"].ToString();
		//string id = dr["id"].ToString();
		if(!bChange)
		{
			Response.Write("<tr bgcolor=#EDEDC7>");
			bChange = true;
		}
		else
		{
			Response.Write("<tr>");
			bChange = false;
		}
		Response.Write("<td>"+id+"</td>");
		Response.Write("<td>"+name+"</td>");
		Response.Write("<td>"+trading_name+"</td>");
		Response.Write("<td>"+email+"</td>");
		Response.Write("<td>"+contact+"</td>");
		Response.Write("<td>"+phone+"</td>");
		
		Response.Write("</tr>");
	}	
	
	Response.Write("</table></form>");
		
	return true;
}

</script>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html>
<head>
    <title>--- Customer Details ---</title> 
</head>
