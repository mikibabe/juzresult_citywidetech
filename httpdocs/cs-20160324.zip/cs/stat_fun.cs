<script runat=server>

string m_timeOpt = "0";
string m_custID = "";
DataSet dst = new DataSet();
string m_scredit_terms_id = "6";
string m_scredit_terms = "";
double _openingBlance = 0;
double _totalAmountDue = 0;

bool GetSelectedCust(string cardID)
{
	if(dst.Tables["cust_gen"] != null)
		dst.Tables["cust_gen"].Clear();

	string sc = "SELECT c.id, e.name AS credit_terms, e.id AS terms_id, c.email, c.ap_email, c.type, c.name, c.short_name, c.company, c.trading_name, c.phone, c.fax, c.balance, c.companyB, ";
	sc += "c.nameB, c.address1B, c.address2B, c.cityB, c.countryB, c.address1, c.address2, c.city, c.country, c.postal1, c.postal2, c.postal3 FROM card c";
	sc += " JOIN enum e ON e.id = c.credit_term ";
	sc += " WHERE e.class = 'credit_terms' ";
	sc += " AND c.id = " + cardID;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, "cust_gen");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}

bool GetInvRecords(string cardID)
{
	if(dst.Tables["invoice_rec"] != null)
		dst.Tables["invoice_rec"].Clear();
	string sc = "";
    
    if(!GetSelectedCust(cardID))
		return false;
	m_scredit_terms_id = dst.Tables["cust_gen"].Rows[0]["terms_id"].ToString();
	m_scredit_terms = dst.Tables["cust_gen"].Rows[0]["credit_terms"].ToString();

	if(!bCardType(ref cardID))
	{
		sc = "SELECT '0' AS pid, invoice_number, commit_date, freight, cust_ponumber, total, Isnull(amount_paid,0) AS amount_paid, ";
		sc += "(total - amount_paid) AS cur_bal FROM invoice ";
		sc += " WHERE paid = 0 "; 
		sc += " AND card_id = " + cardID;
		if(m_scredit_terms_id == "4")  // ** 7days
		{
			if(m_timeOpt == "0")
				sc += "	AND (DATEDIFF(day, commit_date, GETDATE()) >= 0 AND DATEDIFF(day, commit_date, GETDATE()) < 7)";
			else if(m_timeOpt == "1")
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 7 AND DATEDIFF(day, commit_date, GETDATE()) < 15)";
			else if(m_timeOpt == "2")
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 15 AND DATEDIFF(day, commit_date, GETDATE()) < 22)";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(day, commit_date, GETDATE()) >= 22";

		}
		else if(m_scredit_terms_id == "5") // ** 14days
		{
			if(m_timeOpt == "0")
				sc += "	AND (DATEDIFF(day, commit_date, GETDATE()) >= 0 AND DATEDIFF(day, commit_date, GETDATE()) < 14)";
			else if(m_timeOpt == "1")
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 14 AND DATEDIFF(day, commit_date, GETDATE()) < 29)";
			else if(m_timeOpt == "2")
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 29 AND DATEDIFF(day, commit_date, GETDATE()) < 59 )";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(day, commit_date, GETDATE()) >= 59";
		}
		/*else if(m_scredit_terms_id == "7") // ** 2oth of the month
		{
			if(m_timeOpt == "0")
				sc += "	AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
			else if(m_timeOpt == "1")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
			else if(m_timeOpt == "2")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
		}*/
		else // ** the rest 30days
		{
			if(m_timeOpt == "0")
				sc += "	AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
			else if(m_timeOpt == "1")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
			else if(m_timeOpt == "2")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
		}
		sc += " ORDER BY commit_date ";
	}
	else
	{
		sc = " SELECT id AS pid, inv_number AS invoice_number, isnull(date_invoiced, date_received) as commit_date, freight ";
		sc += " , po_number as cust_ponumber, total_amount AS total, amount_paid, ";
		sc += "(total_amount - amount_paid) AS cur_bal ";
		sc += " FROM purchase ";
		sc += " WHERE (type >= 2)  AND date_received IS NOT NULL "; //AND (total_amount - amount_paid) > 0
		sc += " AND supplier_id = " + cardID;
		if(m_scredit_terms_id == "4")
		{
			if(m_timeOpt == "0")
				sc += "	AND (DATEDIFF(day, date_received, GETDATE()) >= 0 AND DATEDIFF(day, date_received, GETDATE()) < 7)";
			else if(m_timeOpt == "1")
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 7 AND DATEDIFF(day, date_received, GETDATE()) < 15)";
			else if(m_timeOpt == "2")
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 15 AND DATEDIFF(day, date_received, GETDATE()) < 22)";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(day, date_received, GETDATE()) >= 22";

		}
		else if(m_scredit_terms_id == "5")// ** 14days
		{
				if(m_timeOpt == "0")
				sc += "	AND (DATEDIFF(day, date_received, GETDATE()) >= 0 AND DATEDIFF(day, date_received, GETDATE()) < 14)";
			else if(m_timeOpt == "1")
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 14 AND DATEDIFF(day, date_received, GETDATE()) < 29)";
			else if(m_timeOpt == "2")
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 29 AND DATEDIFF(day, date_received, GETDATE()) < 59 )";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(day, date_received, GETDATE()) >= 59";
		
		}
		/*else if(m_scredit_terms_id == "7")
		{
			if(m_timeOpt == "0")
				sc += "	AND DATEDIFF(month, date_received, GETDATE()) = 0 ";
			else if(m_timeOpt == "1")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 1 ";
			else if(m_timeOpt == "2")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 2";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) >= 3";
		}*/
		else// ** the rest 30days
		{
			if(m_timeOpt == "0")
				sc += "	AND DATEDIFF(month, date_received, GETDATE()) = 0 ";
			else if(m_timeOpt == "1")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 1 ";
			else if(m_timeOpt == "2")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 2";
			else if(m_timeOpt == "3")
				sc += " AND DATEDIFF(month, date_received, GETDATE()) >= 3";
		}

		sc += " ORDER BY date_received ";
	}
//DEBUG("m_scredit_terms_id=", m_scredit_terms_id);
//DEBUG("150sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, "invoice_rec");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}


//==========================================================

bool GetInvRecords(string cardID, string fromDate, string toDate, int paid)
{
	if(dst.Tables["invoice_rec"] != null)
		dst.Tables["invoice_rec"].Clear();
	string sc = "";
//DEBUG("169cardID=", cardID);
	if(!bCardType(ref cardID))
	{
		sc = "SELECT '0' AS pid, invoice_number, commit_date, freight, cust_ponumber, total, Isnull(amount_paid,0) AS amount_paid, ";
		sc += "(total - amount_paid) AS cur_bal FROM invoice ";
		//sc += " WHERE paid = "+paid+" ";
		//sc += " AND card_id = " + cardID;
        sc += " WHERE card_id = " + cardID;
		sc += " and commit_date BETWEEN  '"+fromDate+"'  and  '"+toDate+"'";
		sc += " ORDER BY commit_date ";
	}else{
        sc = " SELECT id AS pid, inv_number AS invoice_number, isnull(date_invoiced, date_received) as commit_date, freight ";
		sc += " , po_number as cust_ponumber, total_amount AS total, amount_paid, ";
		sc += "(total_amount - amount_paid) AS cur_bal ";
		sc += " FROM purchase ";
		sc += " WHERE (type >= 2)  AND date_received IS NOT NULL "; //AND (total_amount - amount_paid) > 0
		sc += " AND supplier_id = " + cardID;
		sc += " and date_received BETWEEN  '"+fromDate+"'  and  '"+toDate+"'";
		sc += " ORDER BY date_received ";
    }
//DEBUG("179sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, "invoice_rec");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
//==========================================================


String PrintStatmentDetails()
{
	string header = ReadSitePage("statement_header");
	string footer = ReadSitePage("statement_footer");

	header = header.Replace("@@title", "STATEMENT");
    DateTime fromDate = DateTime.Now;
    DateTime toDate = DateTime.Now;
//DEBUG("204 to date=", Request["toDate"].ToString());

    if(Request["fromDate"] != null){
        try{
            string t = Request["fromDate"].ToString();
            string[] temp = t.Split('/');

            int year = int.Parse (temp[2]);
            int month = int.Parse (temp[1]);
            int day = int.Parse (temp[0]);

            fromDate = new DateTime(year,month,day);
             _openingBlance = GetOpeningBlance(m_custID, fromDate);
            
            //set to date.
            t = Request["toDate"].ToString();
            temp = t.Split('/');

            year = int.Parse (temp[2]);
            month = int.Parse (temp[1]);
            day = int.Parse (temp[0]);

            toDate = new DateTime(year,month,day);

        }catch(Exception ex){

        }
        header = header.Replace("@@date", Request["toDate"].ToString());
    }else if(Request.QueryString["p"] == "0"){ //current date
        header = header.Replace("@@date", DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy"));
    }else if(Request.QueryString["p"] == "1"){ //14 days
        header = header.Replace("@@date", DateTime.UtcNow.AddDays(-14).ToString("dd/MM/yyyy"));
    }else if(Request.QueryString["p"] == "2"){ //30 days
        header = header.Replace("@@date", DateTime.UtcNow.AddHours(-30).ToString("dd/MM/yyyy"));
    }else if(Request.QueryString["p"] == "3"){ //60 days
        header = header.Replace("@@date", DateTime.UtcNow.AddHours(-60).ToString("dd/MM/yyyy"));
    }else if(Request.QueryString["p"] == "4"){
        header = header.Replace("@@date", DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy"));
    }else{
        header = header.Replace("@@date", DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy"));
    }

	//header = header.Replace("@@date", DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy"));
	header = header.Replace("@@account_id", dst.Tables["cust_gen"].Rows[0]["id"].ToString());
    footer = footer.Replace("@@account_id", dst.Tables["cust_gen"].Rows[0]["id"].ToString());
	header = header.Replace("@@compname", dst.Tables["cust_gen"].Rows[0]["trading_name"].ToString());
    footer = footer.Replace("@@compname", dst.Tables["cust_gen"].Rows[0]["trading_name"].ToString());
	header = header.Replace("@@credit_terms", dst.Tables["cust_gen"].Rows[0]["credit_terms"].ToString());
    footer = footer.Replace("@@credit_terms", dst.Tables["cust_gen"].Rows[0]["credit_terms"].ToString());

    if(!String.IsNullOrEmpty(dst.Tables["cust_gen"].Rows[0]["postal1"].ToString())){
        header = header.Replace("@@pobox", dst.Tables["cust_gen"].Rows[0]["postal1"].ToString());
    }else{
        header = header.Replace("@@pobox", dst.Tables["cust_gen"].Rows[0]["address1"].ToString());
    }
	if(!String.IsNullOrEmpty(dst.Tables["cust_gen"].Rows[0]["postal2"].ToString())){
        header = header.Replace("@@suburb", dst.Tables["cust_gen"].Rows[0]["postal2"].ToString());
    }else{
        header = header.Replace("@@suburb", dst.Tables["cust_gen"].Rows[0]["address2"].ToString());
    }
	if(!String.IsNullOrEmpty(dst.Tables["cust_gen"].Rows[0]["postal3"].ToString())){
        header = header.Replace("@@city", dst.Tables["cust_gen"].Rows[0]["postal3"].ToString());
    }else{
        header = header.Replace("@@city", dst.Tables["cust_gen"].Rows[0]["city"].ToString());
    }
	


	header = header.Replace("@@email", dst.Tables["cust_gen"].Rows[0]["email"].ToString());
	header = header.Replace("@@phone", dst.Tables["cust_gen"].Rows[0]["phone"].ToString());
	header = header.Replace("@@fax", dst.Tables["cust_gen"].Rows[0]["fax"].ToString());

	StringBuilder sb = new StringBuilder();

	//build up body
	sb.Append("<html><style type=\"text/css\">\r\n");
	sb.Append("td{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}\r\n");
	sb.Append("body{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}</style>\r\n");

	sb.Append(header);

	sb.Append("<table  width=650 border=0 cellspacing=0 cellpadding=0><tr><td valign=top>");

	sb.Append("<table width=100% align=center cellspacing=0 cellpadding=0 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");

	sb.Append("<tr><td width=73% valign=top>");
	sb.Append("<table  width=100% align=center cellspacing=3 cellpadding=3 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr><td valign=top><br /><br /><br /><br />\r\n");
	sb.Append("<table class='table table-bordered' width=100% align=center cellspacing=1 cellpadding=1 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"margin-left: 10px;font-family:Verdana;font-size:8pt;border-width:1.5px;border-color: black;border-style:Solid;border-collapse:collapse;fixed\">\r\n");
	sb.Append("<tr style='border-left: 2px solid black;background:#C0C0C0'><th width=15% align=center><b>DATE</b></th>");
	sb.Append("<th width=18% align=center><b>Invoice no.</b></th>");
	sb.Append("<th width=17% align=center><b>Order no.</b></th>");
	sb.Append("<th width=15% align=center><b>Charges</b></th>");
	sb.Append("<th width=15% align=center><b>Payment</b></th>");
	sb.Append("<th width=20% align=center><b>Total Due</b></th></tr>\r\n");

    //show opening blance
    sb.Append("<tr style='border-left: 2px solid black;'><td width=15% align=center><span class='red'>"+  fromDate.ToString("dd/MM/yy") + "</span></td>");
	sb.Append("<td width=18% align=center><span class='red'>Opening balance</span></td>");
	sb.Append("<td width=17% align=center></td>");
	sb.Append("<td width=15% align=center></td>");
	sb.Append("<td width=15% align=center></td>");
	sb.Append("<td width=20% style='text-align:right;'><span class='red'>"+ _openingBlance.ToString("c")  +"</span></td></tr>\r\n");





	//rows on left side of statement
	sb.Append(sStateRowsLeft());


    sb.Append("<tr style='border-left: 2px solid black;'>");
	sb.Append("<td width=15% align=left colspan='5' style='text-align:right;'>Balance due</td>");
	sb.Append("<td width=20% style='text-align:right;'>"+ (_totalAmountDue + _openingBlance).ToString("c")  +"</td></tr>\r\n");



	sb.Append("</table></td></tr>\r\n");
	sb.Append("</td></tr></table>\r\n");
	sb.Append("</td></tr></table>\r\n");

	sb.Append("</td>");		//end of left table		
	//sb.Append("<td>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|");
	//sb.Append("<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|</td>\r\n");

	sb.Append("<td><br><br><br><br><br><br><br><br><br><br><br><br><br>");
	sb.Append("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></td>\r\n");

	//sb.Append("<td width=27% valign=top>");
	//sb.Append("<table width=100% align=center cellspacing=3 cellpadding=3 border=0 bordercolor=#EEEEEE bgcolor=white");
	//sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">\r\n");
	//sb.Append("<tr><td valign=top>");
	//sb.Append("<table width=100% align=center cellspacing=1 cellpadding=1 border=0 bordercolor=#EEEEEE bgcolor=white");
	//sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">\r\n");
	//sb.Append("<tr><td width=50% align=center><b>Invoice No.</b></td>");
	//sb.Append("<td width=50% align=center><b>Total Due</b></td></tr>\r\n");

    //sb.Append("<tr><td width=50% align=center>Opening<br /> Blance</td>");
	//sb.Append("<td width=50% align=center>"+ _openingBlance.ToString("c")  +"</td></tr>\r\n");

    //sb.Append("<tr><td width=50% align=center></td>");
	//sb.Append("<td width=50% align=center></td></tr>\r\n");


	//rows on right side of statement
	//sb.Append(sStateRowsRight());	

	//sb.Append("</table></td></tr></table>\r\n");
	//sb.Append("</td></tr></table>\r\n");

	//sb.Append("</td></tr>\r\n");   //frame one: close first row;

	sb.Append("<tr><td valign=top><table width=650 border=0 cellspacing=0 cellpadding=0>\r\n");
	sb.Append("<tr><td width=100%>\r\n");
	sb.Append("<table width=100%  align=center valign=center cellspacing=3 cellpadding=3 border=1 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">\r\n");

    m_scredit_terms_id = dst.Tables["cust_gen"].Rows[0]["terms_id"].ToString();
    m_scredit_terms = dst.Tables["cust_gen"].Rows[0]["credit_terms"].ToString();
//DEBUG("348msftucret=", m_scredit_terms_id);





	sb.Append("<tr width=100% style='background: silver;'><td align=center><b> Current</b></td>\r\n");
	//sb.Append("<td align=center><b>30 Days</b></td>\r\n");
	if(m_scredit_terms_id == "4")
		sb.Append("<td align=center><b>7 Days</b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		sb.Append("<td align=center><b>14 Days</b></td>\r\n");
	//else if(m_scredit_terms_id == "7")
	//	sb.Append("<td align=center><b>20th of the Month</b></td>\r\n");
	else
		sb.Append("<td align=center><b>30 Days</b></td>\r\n");
	//sb.Append("<td align=center><b>60 Days</b></td>\r\n");
		if(m_scredit_terms_id == "4")
		   sb.Append("<td align=center><b>14 Days</b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		sb.Append("<td align=center><b>30 Days</b></td>\r\n");
	//else if(m_scredit_terms_id == "7")
	//	sb.Append("<td align=center><b>20th of the Month</b></td>\r\n");
	else
		sb.Append("<td align=center><b>60 Days</b></td>\r\n");
	//sb.Append("<td align=center><b>90 Days+ </b></td>\r\n");
		if(m_scredit_terms_id == "4")
		   sb.Append("<td align=center><b>30 Days+</b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		sb.Append("<td align=center><b>60 Days+</b></td>\r\n");
	else if(m_scredit_terms_id == "7")
		//sb.Append("<td align=center><b>20th of the Month</b></td>\r\n");
        sb.Append("<td align=center><b>90 Days+</b></td>\r\n");
	else
		sb.Append("<td align=center><b>90 Days+</b></td>\r\n");
	sb.Append("<td align=center><b>Credits Left</b></td>\r\n");
	sb.Append("<td align=center><b>Total Amount</b></td></tr>\r\n");

	double dCreditTotal = GetTotalCredit(m_custID);
	double[] dSubBalance = new double[4];
	for(int i = 0; i<4; i++)
	{
		GetSubBalance(i, m_custID, ref dSubBalance[i], toDate, fromDate);
		//if(!GetSubBalance(i, ref dSubBalance[i]))
		//	return;		
	}

	sb.Append("<tr style='background: silver;'><td align=center><b>" + dSubBalance[0].ToString("c") + "</b></td>\r\n");
	sb.Append("<td align=center><b>" + dSubBalance[1].ToString("c") + "</b></td>\r\n");
	sb.Append("<td align=center><b>" + dSubBalance[2].ToString("c") + "</b></td>\r\n");
	sb.Append("<td align=center><b>" + dSubBalance[3].ToString("c") + "</b></td>\r\n");
	sb.Append("<td align=center><b>" + dCreditTotal.ToString("c") + "</b></td>\r\n");
	double d_SumTotal = 0;
    if(m_scredit_terms_id == "1"){ //if credit terms is cash only then plus current total.
        d_SumTotal = dSubBalance[0] + dSubBalance[1] + dSubBalance[2] + dSubBalance[3];
    }else{
        d_SumTotal =  dSubBalance[1] + dSubBalance[2] + dSubBalance[3];
    }
    
	d_SumTotal -= dCreditTotal;
	sb.Append("<td align=center><b>" +  (_totalAmountDue + _openingBlance).ToString("c") + "</b></td></tr>\r\n");

	sb.Append("</table>");

	sb.Append("</td><td><br><br><br><br></td>");
	sb.Append("<td width=27%>");
	//sb.Append("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	//sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">\r\n");



    //sb.Append("<tr><td align=center><br /></td></tr>\r\n");

	//sb.Append("<tr><td align=right><b>Total Amount Due:</b></td></tr>\r\n");

	

	//sb.Append("<tr><td align=right><br><b>" + d_SumTotal.ToString("c") + "</b></td></tr>\r\n");
    //sb.Append("<tr><td align=right><br><b>" + (_totalAmountDue + _openingBlance).ToString("c") + "</b></td></tr>\r\n");
	sb.Append("</td></tr>\r\n");
	sb.Append("</table>\r\n</td></tr></table>\r\n");

	//footer = footer.Replace("@@amountdue", d_SumTotal.ToString("c"));
    footer = footer.Replace("@@amountdue", (_totalAmountDue + _openingBlance).ToString("c"));
	sb.Append(footer);

	sb.Append("</body></html>");
	return sb.ToString();
}

string sStateRowsLeft()
{
	StringBuilder sb = new StringBuilder();

	string s_empPOno = "";
	for(int i = 0; i < dst.Tables["invoice_rec"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["invoice_rec"].Rows[i];

        //if(double.Parse(dr["cur_bal"].ToString()) == 0){
        //    continue;
        //}

		sb.Append("<tr style='border-left: 2px solid black;'><td align=center>" + DateTime.Parse(dr["commit_date"].ToString()).ToString("dd/MM/yy") + "</td>\r\n");
		sb.Append("<td align=center>" + dr["invoice_number"].ToString() + "</td>\r\n");
		if(dr["cust_ponumber"].ToString() == "")
			sb.Append("<td align=center>&nbsp;</td>");
		else
			sb.Append("<td align=center>" + dr["cust_ponumber"].ToString() + "</td>\r\n");
		sb.Append("<td align=right style='text-align: right;'>" + double.Parse(dr["total"].ToString()).ToString("c")  + "</td>\r\n");
		if(dr["amount_paid"].ToString() == "0")
			sb.Append("<td align=right style='text-align: right;'>&nbsp;</td>\r\n");
		else
			sb.Append("<td align=right style='text-align: right;'>" + double.Parse(dr["amount_paid"].ToString()).ToString("c")  + "</td>\r\n");
		sb.Append("<td align=right style='text-align: right;'>" + double.Parse(dr["cur_bal"].ToString()).ToString("c") + "</td></tr>\r\n");
        _totalAmountDue = _totalAmountDue + double.Parse(dr["cur_bal"].ToString());
	}

	return sb.ToString();
}

string sStateRowsRight()
{
	StringBuilder sb = new StringBuilder();
	for(int i = 0; i < dst.Tables["invoice_rec"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["invoice_rec"].Rows[i];
		sb.Append("<tr><td align=right>" + dr["invoice_number"].ToString() + "</td>\r\n");
		sb.Append("<td align=right>" + double.Parse(dr["cur_bal"].ToString()).ToString("c") + "</td></tr>\r\n");

	}
	return sb.ToString();
}	
bool bCardType(ref string cardID)
{
	string stype = "1";
	bool bIsSupplier = false;
	if(dst.Tables["ctype"] != null)
		dst.Tables["ctype"].Clear();
	int rows = 0;
	string sc= " SELECT * FROM card WHERE id = " + cardID;

	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "ctype");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(rows == 1)
	{
		stype = dst.Tables["ctype"].Rows[0]["type"].ToString();
		if(GetEnumID("card_type", "supplier") == stype)
			bIsSupplier = true;
	}

	return bIsSupplier;
}
bool GetSubBalance(int i, string sCardID, ref double dtotal)
{
	if(dst.Tables["balance"] != null)
		dst.Tables["balance"].Clear();
	int rows = 0;
	string sc= "";

	if(!bCardType(ref sCardID))
	{
		sc= " SELECT SUM(total - amount_paid) AS sub_total FROM invoice WHERE card_id = " + sCardID;
		if(m_scredit_terms_id == "4")  // ** 7days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, commit_date, GETDATE()) >= 0 AND DATEDIFF(day, commit_date, GETDATE()) < 7)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 7 AND DATEDIFF(day, commit_date, GETDATE()) < 15)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 15 AND DATEDIFF(day, commit_date, GETDATE()) < 22)";
			else if(i == 3)
				sc += " AND DATEDIFF(day, commit_date, GETDATE()) >= 22";
			else
			{
				dtotal = 0.00;
				return true;
			}

		}
		else if(m_scredit_terms_id == "5") // ** 14days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, commit_date, GETDATE()) >= 0 AND DATEDIFF(day, commit_date, GETDATE()) < 14)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 14 AND DATEDIFF(day, commit_date, GETDATE()) < 29)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, commit_date, GETDATE()) >= 29 AND DATEDIFF(day, commit_date, GETDATE()) < 59 )";
			else if(i == 3)
				sc += " AND DATEDIFF(day, commit_date, GETDATE()) >= 59";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		/*else if(m_scredit_terms_id == "7") // ** 2oth of the month
		{
			if(i == 0)
				sc += "	AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
			else if(i == 1)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}*/
		else // ** the rest 30days
		{
			if(i == 0)
				sc += "	AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
			else if(i == 1)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		/*
		if(i == 0)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
		else if(i == 1)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
		else if(i == 2)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
		else if(i == 3)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
		else
		{
			dtotal = 0.00;
			return true;
		}
		*/
	}
	else
	{
		sc = " SELECT SUM(total_amount - amount_paid) AS sub_total FROM purchase WHERE supplier_id = " + sCardID;
		if(m_scredit_terms_id == "4")  // ** 7days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, date_received, GETDATE()) >= 0 AND DATEDIFF(day, date_received, GETDATE()) < 7)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 7 AND DATEDIFF(day, date_received, GETDATE()) < 15)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 15 AND DATEDIFF(day, date_received, GETDATE()) < 22)";
			else if(i == 3)
				sc += " AND DATEDIFF(day, date_received, GETDATE()) >= 22";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
			else if(m_scredit_terms_id == "5") // ** 14days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, date_received, GETDATE()) >= 0 AND DATEDIFF(day, date_received, GETDATE()) < 14)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 14 AND DATEDIFF(day, date_received, GETDATE()) < 29)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, date_received, GETDATE()) >= 29 AND DATEDIFF(day, date_received, GETDATE()) < 59 )";
			else if(i == 3)
				sc += " AND DATEDIFF(day, date_received, GETDATE()) >= 59";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		else // ** the rest 30days
		{
			if(i == 0)
				sc += "	AND DATEDIFF(month, date_received, GETDATE()) = 0 ";
			else if(i == 1)
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, date_received, GETDATE()) = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, date_received, GETDATE()) >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}

	
//		sc += " AND date_received is NOT NULL ";
	}
//DEBUG("sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "balance");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(dst.Tables["balance"].Rows[0]["sub_total"].ToString() == "" || dst.Tables["balance"].Rows[0]["sub_total"].ToString() == null)
		dtotal = 0;
	else
		dtotal = double.Parse(dst.Tables["balance"].Rows[0]["sub_total"].ToString());

	return true;
}



bool GetSubBalance(int i, string sCardID, ref double dtotal, DateTime toDate, DateTime fromDate)
{
	if(dst.Tables["balance"] != null)
		dst.Tables["balance"].Clear();
	int rows = 0;
	string sc= "";

	if(!bCardType(ref sCardID))
	{
		sc= " SELECT SUM(total - amount_paid) AS sub_total FROM invoice WHERE card_id = " + sCardID;
		if(m_scredit_terms_id == "4")  // ** 7days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 0 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 7)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 7 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 15)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 15 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 22)";
			else if(i == 3)
				sc += " AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 22";
			else
			{
				dtotal = 0.00;
				return true;
			}

		}
		else if(m_scredit_terms_id == "5") // ** 14days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 0 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 14)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 14 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 29)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 29 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') < 59 )";
			else if(i == 3)
				sc += " AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 59";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		/*else if(m_scredit_terms_id == "7") // ** 2oth of the month
		{
			if(i == 0)
				sc += "	AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
			else if(i == 1)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}*/
		else // ** the rest 30days
		{
            int totalDaysInMonth = DateTime.DaysInMonth(toDate.Year, toDate.Month);
            int leftDays = totalDaysInMonth - toDate.Day;
			if(i == 0)  {
                if(fromDate.Month == toDate.Month && fromDate != toDate){ //if same month
                    sc += " AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 0 AND DATEDIFF(day, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') <= "+ totalDaysInMonth +"";
                }else{
                   sc += " AND DATEDIFF(month, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') = 0";
                }
                //sc += " AND DATEDIFF(month, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') = 0";
            }
                
				//sc += "	AND (DATEDIFF(day, commit_date, '"+ toDate.AddMonths(-1).ToString("yyyy-MM-dd") +"') = 30 or  DATEDIFF(day, commit_date, '"+ toDate.AddMonths(-1).ToString("yyyy-MM-dd") +"') = 31)";
			else if(i == 1)
				sc += " AND DATEDIFF(month, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, commit_date, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		/*
		if(i == 0)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 0 ";
		else if(i == 1)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 1 ";
		else if(i == 2)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) = 2";
		else if(i == 3)
			sc += " AND DATEDIFF(month, commit_date, GETDATE()) >= 3";
		else
		{
			dtotal = 0.00;
			return true;
		}
		*/
	}
	else
	{
		sc = " SELECT SUM(total_amount - amount_paid) AS sub_total FROM purchase WHERE supplier_id = " + sCardID;
		if(m_scredit_terms_id == "4")  // ** 7days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 0 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 7)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 7 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 15)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 15 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 22)";
			else if(i == 3)
				sc += " AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 22";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
			else if(m_scredit_terms_id == "5") // ** 14days
		{
			if(i == 0)
				sc += "	AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 0 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 14)";
			else if(i == 1)
				sc += " AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 14 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 29)";
			else if(i == 2)
				sc += " AND (DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 29 AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') < 59 )";
			else if(i == 3)
				sc += " AND DATEDIFF(day, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 59";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}
		else // ** the rest 30days
		{
			if(i == 0)
				sc += "	AND DATEDIFF(month, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') = 0 ";
			else if(i == 1)
				sc += " AND DATEDIFF(month, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') = 1 ";
			else if(i == 2)
				sc += " AND DATEDIFF(month, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') = 2";
			else if(i == 3)
				sc += " AND DATEDIFF(month, date_received, '"+ toDate.ToString("yyyy-MM-dd") +"') >= 3";
			else
			{
				dtotal = 0.00;
				return true;
			}
		}

	
//		sc += " AND date_received is NOT NULL ";
	}
//DEBUG("sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "balance");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(dst.Tables["balance"].Rows[0]["sub_total"].ToString() == "" || dst.Tables["balance"].Rows[0]["sub_total"].ToString() == null)
		dtotal = 0;
	else
		dtotal = double.Parse(dst.Tables["balance"].Rows[0]["sub_total"].ToString());

    
	return true;
}


double GetTotalCredit(string cardID)
{
	if(dst.Tables["credit"] != null)
		dst.Tables["credit"].Clear();

	string sc = "SELECT SUM(amount - amount_applied) AS total ";
	sc += " FROM credit ";
	sc += " WHERE card_id = " + cardID;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "credit");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	return MyDoubleParse(dst.Tables["credit"].Rows[0]["total"].ToString());
}


//get opening blance
double GetOpeningBlance(string sCardID, DateTime toDate)
{
    double dtotal = 0;
	if(dst.Tables["bbb"] != null)
		dst.Tables["bbb"].Clear();
	int rows = 0;
	string sc= "";

	if(!bCardType(ref sCardID))
	{
		sc= " SELECT SUM(total - amount_paid) AS sub_total FROM invoice WHERE card_id = " + sCardID;
		sc += " AND	commit_date < '"+ toDate.Year + "-" + toDate.Month + "-" + toDate.Day +"' ";
	}
	else
	{
		sc = " SELECT SUM(total_amount - amount_paid) AS sub_total FROM purchase WHERE supplier_id = " + sCardID;
		sc += " AND	date_received < '"+ toDate.Year + "-" + toDate.Month + "-" + toDate.Day +"' ";
	}
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "bbb");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	
	if(dst.Tables["bbb"].Rows[0]["sub_total"] == null || dst.Tables["bbb"].Rows[0]["sub_total"].ToString() == "")
		dtotal = 0;
	else
		dtotal = double.Parse(dst.Tables["bbb"].Rows[0]["sub_total"].ToString());

	return dtotal;
}

</script>