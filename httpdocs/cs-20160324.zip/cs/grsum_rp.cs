<!-- #include file="page_index.cs" -->
<script runat=server>


DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
string m_branch = "1";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("sales"))
		return;
	m_branch = Request.QueryString["b"];
		PrintAdminHeader();
	PrintAdminMenu();
	setBranchOptions();
	if(Request.QueryString["s"] == "print" && Request.QueryString["b"] != null && Request.QueryString["b"] != "")
	{
		
		doPrintDailySummary();
		Response.Write("<script language=javascript>window.close();</script");
		Response.Write(">");
		return;
	}
	
//	Response.Write("<script language=javascript>if(confirm('Print Today Sales Summary')){ window.location=('"+ Request.ServerVariables["URL"]+"?s=print&r="+DateTime.UtcNow.AddHours(12).ToOADate() +"');}");
//	Response.Write("</script");
//	Response.Write(">");
	return;
	

}

bool setBranchOptions()
{
	string sc = " SELECT * FROM branch ";
	sc += " WHERE 1=1 ";
//	if(m_branch != "")
//	{
//		if(TSIsDigit(m_branch))
//			sc += " AND id ="+ m_branch +" ";
//	}
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "branch");
		if(rows <= 0)
		{
//			Response.Write("<br><br><center><h3>ERROR, Order Not Found</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	Response.Write("<br><br><table align=center cellspacing=0 cellpadding=2 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
//	Response.Write("<tr align=center><td>");
//	Response.Write("Tick View Daily Summary Only<input type=checkbox name=view>");
	Response.Write("Please Select Branch:<select name=branch onchange=\"window.location=('"+ Request.ServerVariables["URL"] +"?s=print&r="+DateTime.UtcNow.AddHours(12).ToOADate() +"&b='+ this.options[this.selectedIndex].value)\"");
	Response.Write(">");
	Response.Write("<option value=all>All</option>");
	for(int i=0; i<rows; ++i)
	{
		Response.Write("<option value="+ dst.Tables["branch"].Rows[i]["id"].ToString() +">"+ dst.Tables["branch"].Rows[i]["name"].ToString() +"</option>");
	}
	Response.Write("</select> for Print Out");
	Response.Write("<br><center><br><input type=button value='Close Window' "+ Session["button_style"] +" onclick='window.close()'>");
//	Response.Write(" <input type=checkbox name=view value=1>View Only (no print out)");
	Response.Write("</td></tr>");
	
	Response.Write("</table>");
	return true;
}

string doBuildDailySummary()
{
	int rows = 0;
	string s_dateSql = " AND DATEDIFF(day, i.commit_date, GETDATE()) = 0 ";
	
	string sc = "SET dateformat dmy ";
	sc += " SELECT sum(s.normal_price * s.quantity) AS gross ";
	sc += ", sum(s.commit_price * s.quantity) AS total_sales ";

	sc += ", sum(s.normal_price * s.quantity) - sum(s.commit_price * s.quantity) AS markdown ";
	sc += ", (SELECT DISTINCT sum(i.total) FROM sales ss WHERE ss.invoice_number = i.invoice_number AND refunded=1 ) AS total_return ";
	
	sc += " FROM sales s JOIN invoice i ON i.invoice_number = s.invoice_number ";
	sc += " WHERE 1=1 ";
//	sc += " AND i.paid = 1 ";
	sc += s_dateSql;
	if(m_branch != "")
	{
		if(TSIsDigit(m_branch))
		sc += " AND i.branch = "+ m_branch;
	}

	sc += s_dateSql;
//	sc += " AND i.paid = 1 ";
	sc += " GROUP BY i.invoice_number, i.paid, i.refunded ";

//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "summary");
		if(rows <= 0)
		{
//			Response.Write("<br><br><center><h3>ERROR, Order Not Found</h3>");
			return "No Sales Today.";
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "SQL Error";
	}
	
/*	sc = "Select COUNT(i.invoice_number) AS total_invoice FROM invoice i WHERE 1=1 ";
	if(m_branch != "")
	{
		if(TSIsDigit(m_branch))
		sc += " AND i.branch = "+ m_branch;
	}
	sc += s_dateSql;
	string total_invoice = "0";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "total_invoice") == 1)
			total_invoice = dst.Tables["total_invoice"].Rows[0]["total_invoice"].ToString();

	}
	catch(Exception e) 
	{
		return "";
	}

*/
	int n = 0;
	int len = 0;
	string s = "";
	double dGross = 0;
	double dTMarkDown = 0;
	double dTReturn = 0;
	double dNetSales = 0;
	double dTGST = 0;
	double dNetNoGST = 0;
	double dTSales = 0;
	string gst = GetSiteSettings("gst_rate_percent", "1.125");
if(gst != "")
	if(MyDoubleParse(gst) > 1.125)
		gst = (1 + (MyDoubleParse(gst) / 100)).ToString();
///DEBUG("gst =", gst);
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["summary"].Rows[i];
		string gross = dr["gross"].ToString();
		string markdown = dr["markdown"].ToString();
		string t_return = dr["total_return"].ToString();
		string t_sales = dr["total_sales"].ToString();
//		string price = Math.Round(MyDoubleParse(dr["price"].ToString()), 2).ToString("c");

		dGross += MyDoubleParse(gross);
		dTMarkDown += MyDoubleParse(markdown);
		dTReturn += MyDoubleParse(t_return);
		dTSales += MyDoubleParse(t_sales);

	}
	
	dGross = dGross * MyDoubleParse(gst);
	dTMarkDown = dTMarkDown * MyDoubleParse(gst);
	dTReturn = dTReturn * MyDoubleParse(gst);
	dTSales = dTSales * MyDoubleParse(gst);
	s += "\r\n------------------------------------------\r\n";
	s += "TRADING TOTALS\r\n";
	s += "------------------------------------------\r\n\r\n";
//	s += "Gross Sales\t\t\t"+ dGross.ToString("c") +"\r\n";
	s += "Gross Sales\t\t\t"+ (dTSales + dTMarkDown).ToString("c") +"\r\n";
	s += "\t- Returns\t\t"+ dTReturn.ToString("c") +"\r\n";
	s += "\t- Markdowns\t\t"+ dTMarkDown.ToString("c") +"\r\n";
	s += "\t\t\t\t----------\r\n\r\n";
	//dNetSales = dGross - dTReturn - dTMarkDown;
	dNetSales = dTSales;
	dNetNoGST = dNetSales / MyDoubleParse(gst);
	dTGST = dNetSales - dNetNoGST;
	
	s += "Total Merchandise Sales\t\t"+ dGross.ToString("c") +"\r\n";
	s += "Net Total Sales\t\t\t"+ dGross.ToString("c") +"\r\n\r\n";
	s += "\t\t\t\t----------\r\n\r\n";
	s += "Net Taxable Excluding GST\t"+ dNetNoGST.ToString("c") +"\r\n";
	s += "Net GST Collected\t\t"+ dTGST.ToString("c") +"\r\n";
	s += "\t\t\t\t==========\r\n\r\n";
	s += "Trading Total\t\t\t"+ (dNetNoGST + dTGST).ToString("c") +"\r\n\r\n";

	
	//***************** print media details *********************

	s += "------------------------------------------\r\n";
	s += "MEDIA TOTALS\r\n";
	s += "------------------------------------------\r\n";

	sc = " SET dateformat dmy SELECT sum(i.total) AS total, e.name, COUNT(i.invoice_number) AS total_invoice ";
	sc += " FROM invoice i INNER JOIN enum e ON e.id = i.payment_type AND e.class = 'payment_method' ";
	sc += s_dateSql;
	if(m_branch != "")
	{
		if(TSIsDigit(m_branch))
		sc += " AND i.branch = "+ m_branch;
	}
//	sc += " AND i.paid = 1 ";
	sc += "group by e.name  ";
	sc += " ORDER BY e.name ";
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "details");
		if(rows <= 0)
			return "Error, No Sales Today.";
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "SQL Error";
	}
	double dTCash = 0;
	double dTotal = 0;
	double dNetTotal = 0;
	string last_type = "1";
	int nInvoiceTotal = 0;
	for(int i=0; i<dst.Tables["details"].Rows.Count; ++i)
	{
		DataRow dr = dst.Tables["details"].Rows[i];
		string payment_type = dr["name"].ToString();
		string tNoInvoice = dr["total_invoice"].ToString();
		//string payment_type_id = dr["type_id"].ToString();
		//string invoice = dr["invoice_number"].ToString();
		string total = dr["total"].ToString();
		
		dNetTotal += MyDoubleParse(total);
		
		s += payment_type;
		if(payment_type.Length >= 16)
		s += "\t";
		if(payment_type.Length >=2 && payment_type.Length <9)
		s += "\t\t\t";
		if(payment_type.Length >=9 && payment_type.Length <16)
		s += "\t\t";
		s += tNoInvoice +"\t";
		s += MyDoubleParse(total).ToString("c") +"\r\n";
//s += payment_type +"\t\t\t"+ MyDoubleParse(total).ToString("c") +"\r\n";
		s += "\t\t\t\t----------\r\n";
		//s += invoice +"\t\t\t\t"+ MyDoubleParse(total).ToString("c") +"\r\n";
		nInvoiceTotal += MyIntParse(tNoInvoice);
	}

	
	s += "[/b]Media Total[/b]\t\t ";
	s += nInvoiceTotal.ToString();
	s += "\t"+ dNetTotal.ToString("c")+"";
	s += "\r\n\t\t\t\t==========\r\n";
//	s += "[/b]Invoice Total[/b]\t\t\t"+ total_invoice +"";
	s += "\r\n";
	//*****************end here*********************


//DEBUG("s =", s);
	return s;
}

bool doPrintDailySummary()
{
	
	string sReceiptBody = doBuildDailySummary(); //get m_dInvoiceTotal first before record payment
//DEBUG("sReceiptBody =", sReceiptBody);
		//print receipt
	byte[] bf = {0x1b, 0x21, 0x20, 0x0};//new char[4];
	byte[] sf = {0x1b, 0x21, 0x02, 0x0};//new char[4];
	byte[] cut = {0x1d, 0x56, 0x01, 0x00};//new char[4];
//	byte[] cut = {0x1B, 0x6D, 0x01, 0x00};//new char[4]; //original cut code idp3210 model
	byte[] kick = {0x1b, 0x70, 0x30, 0x7f};//, 0x0a, 0x0};//new char[6];
//	byte[] kick = {0x1B, 0x70, 0x30, 0x37, 0x79};//, 0x0a, 0x0};//new char[6]; //original kick drawer for idp3210 model
	

	ASCIIEncoding encoding = new ASCIIEncoding( );
    string bigfont = encoding.GetString(bf);	
    string smallfont = encoding.GetString(sf);
    string scut = encoding.GetString(cut);
    string kickout = encoding.GetString(kick);
	
	string header = " [b]Todays Sales Summary[/b]\r\n  ";
//	header += DateTime.UtcNow.AddHours(12).ToString();
	string footer = "\r\n\t  *******[/b]End of Summary[/b]*******\r\n\r\n\r\n\r\n\r\n";
	string sbody = sReceiptBody;
	string sdate = "\r\n         "+ DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy");
	string stime = "  "+ DateTime.UtcNow.AddHours(12).ToString("HH:mm");
	
//	string sprint = "\r\ntesting me\r\n";
//	sprint += scut;
	string sprint = header + sdate + stime + sbody + footer + scut;

//	if(Request.Form["pm"] == "cash")
		sprint += "\\r\\n\\r\\n" + kickout;
	sprint = sprint.Replace("\r\n", "\\r\\n");
	sprint = sprint.Replace("[/b]", smallfont);
	sprint = sprint.Replace("[b]", bigfont);
	sprint = sprint.Replace("[cut]", scut.ToString());
	sprint = sprint.Replace("[date]", sdate);
	sprint = sprint.Replace("[time]", stime);
///	sprint = sprint.Replace("[inv_num]", m_invoiceNumber);
//DEBUG("sprint = ", sprint);
	PrintAdminHeader();

	//AsPrint ActiveX Control
	Response.Write("\r\n<object classid=\"clsid:B816E029-CCCB-11D2-B6ED-444553540000\" ");
	Response.Write(" CODEBASE=\"..\\cs\\asprint.ocx\" ");
	Response.Write(" id=\"AsPrint1\">\r\n");
	Response.Write("<param name=\"_Version\" value=\"65536\">\r\n");
	Response.Write("<param name=\"_ExtentX\" value=\"2646\">\r\n");
	Response.Write("<param name=\"_ExtentY\" value=\"1323\">\r\n");
	Response.Write("<param name=\"_StockProps\" value=\"0\">\r\n");
	Response.Write("<param name=\"HideWinErrorMsg\" value=\"1\">\r\n");
	Response.Write("</object>\r\n");

	string s = "<script";
	s += ">\r\n";

	s += "	document.AsPrint1.Open('LPT1')\r\n";
//	s += "	document.AsPrint1.Open('COM1')\r\n";
	s += "	document.AsPrint1.PrintString('" + sprint + "');\r\n";
	s += "	document.AsPrint1.Close();\r\n";

	s += "</script";
	s += ">";

	Response.Write(s);

//	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=qpos.aspx?t=new\">");
	return true;
}
</script>
