<script runat=server>

DataSet dst = new DataSet();
DataTable dtExpense = new DataTable();

string m_id = "";
bool m_bRecorded = false;
bool m_bIsPaid = false;
bool m_bIsClose = false;

string m_branch = "";
string m_fromAccount = "";
string m_toAccount = "";
string m_customerID = "-1";
string m_customerName = "";
string m_paymentType = "1";
string m_paymentDate = "";
string m_paymentRef = "";
string m_note = "";
string m_editRow = "";
string m_nextChequeNumber = "";
string m_sAutoFrequency = "0";
string m_sNextAutoDate = "";
bool isNAL = false;
bool isPaid = false;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	RememberLastPage();
	
	if(Request.Form["cmd"] != null)
		UpdateAllFields();
	RestoreAllFields();

	if(Request.QueryString["sid"] != null && Request.QueryString["sid"] != "")
		Session["expense_customer"] = Request.QueryString["sid"];
	else
		Session["expense_customer"] = null;
	if(Session["expense_customer"] != null && Session["expense_customer"] != "")
		m_customerID = Session["expense_customer"].ToString();
	if(Request.QueryString["luri"] != null)
		Session["last_uri_recon"] = Request.QueryString["luri"].ToString();
	m_nextChequeNumber = GetSiteSettings("next_cheque_number", "1000");
	if(Session["last_uri_exp"] != null)
		Session["last_uri_exp"] = null;
	if(Session["luri_acc"] != null)
		Session["luri_acc"] = null;
	if(Request.QueryString["id"] != null && Request.QueryString["id"] != "")
	{
		m_id = Request.QueryString["id"];
		EmptyExpenseTable();
		if(!RestoreRecord())
			return;
		m_bRecorded = true;
		Session["expense_current_id"] = m_id;
		Session["expense_recorded"] = true;
	}
	else if(Request.Form["id"] != null && Request.Form["id"] != "")
	{
		m_id = Request.Form["id"];
		m_bRecorded = true;
		Session["expense_current_id"] = m_id;
		Session["expense_recorded"] = true;
	}
	if(Request.QueryString["t"] == "new")
	{
		EmptyExpenseTable();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=expense.aspx");
		if(Request.QueryString["auto"] == "1")
			Response.Write("?auto=1");		
		Response.Write("\">");
		return;
	}
	else if(Request.QueryString["t"] == "del")
	{
		CheckExpenseTable();		
		dtExpense.Rows.RemoveAt(MyIntParse(Request.QueryString["row"]));
	
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=expense.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"");
		if(Request.QueryString["sid"] != null && Request.QueryString["sid"] != "")
			Response.Write("&sid="+ Request.QueryString["sid"] +"");

//		Response.Write("&pd="+ m_bIsPaid +"");
		Response.Write("\">");
		
	}
	else if(Request.QueryString["t"] == "edit")
	{
		m_editRow = Request.QueryString["row"];
//		if(Request.QueryString["pd"] != null && Request.QueryString["pd"] != "")
//		m_bIsPaid = MyBooleanParse(Request.QueryString["pd"].ToString());
	}
	else if(Request.QueryString["saydone"] == "1")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>Done, expense saved");
		if(m_id != "")
		{
		//	Response.Write("<br><br><a title='go to main page' href='' class=o>Go to Main Page</a>");
            Response.Write("<br><br><a title='Add new expense' href='expense.aspx?t=new&r=' class=linkButtonCenter>Add new expense</a>");
			
			Response.Write("<br><br><a title='go to expense report' href='explist.aspx' class=linkButtonCenter>Go to Expense Report</a>");
			Response.Write("<br><br><a title='go to expense records' href='"+ Request.ServerVariables["URL"] +"?view=true&id="+ m_id +"' class=linkButtonCenter>Back to Expense Record</a>");
			
            return;
//			Response.Write(", please wait 1 second...<meta http-equiv=\"refresh\" content=\"2; URL=expense.aspx?id=" + m_id + "\">");
		}
		else
		{
			Response.Write("<input type=button value='Expense List' onclick=window.location=('explist.aspx') class=expenseListButton>");
			Response.Write("<br><br><br><br><br><br>");
		}
		PrintAdminFooter();
		return;
	}
	else if(Request.QueryString["search"] == "1")
	{
		DoCustomerSearchAndList();
		return;
	}
	else if(Request.QueryString["cid"] != null && Request.QueryString["cid"] != "")
	{
		m_customerID = Request.QueryString["cid"];
		Session["expense_customer"] = m_customerID;
		DataRow drc = GetCardData(m_customerID);
		if(drc != null)
		{
			m_customerName = drc["trading_name"].ToString();
			if(m_customerName == "")
				m_customerName = drc["company"].ToString();
			if(m_customerName == "")
				m_customerName = drc["name"].ToString();
		}
	}

	if(Request.Form["cmd"] == "OK")
	{
		DoUpdateExpenseRow();
	}
	else if(Request.Form["cmd"] == "Search Card")
	{
		Response.Redirect("expense.aspx?search=1");
		return;
	}
	else if(Request.Form["cmd"] == "Add")
	{
		if(!DoAddExpense())
			return;
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=expense.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"");
		if(Request.QueryString["sid"] != null && Request.QueryString["sid"] != "")
			Response.Write("&sid="+ Request.QueryString["sid"] +"");
//		Response.Write("&pd="+ m_bIsPaid +"");
		Response.Write("\">");
	}
	else if(Request.Form["cmd"] == "Pay/Save")
	{
	/*	if(Request.Form["confirm_record"] != "on")
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Please tick the Checkbox...'</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return;
		}
		*/
		if(DoRecordExpense())
		{			
			Response.Write("<center><h3>Save Done...</h3>");
            if(isPaid == true && isNAL == true){
                Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=custpay.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&id="+ Request.Form["supplier"] +" \">");
            }else{
                Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL="+ Request.ServerVariables["URL"] +"?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&id=" + m_id +"&saydone=1&acid="+ Request.Form["to_account"] +" \">");
            }
			
			return;
			
		}
			//Response.Redirect("expense.aspx?saydone=1&id=" + m_id);
		return;
	}
	else if(Request.Form["cmd"] == "Pay/Save Expense")
	{
	/*	if(Request.Form["confirm_record"] != "on")
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Please tick the Checkbox...</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return;
		}
		*/
		if(DoUpdateRecord())
		{
//			Response.Redirect("expense.aspx?saydone=1&id=" + m_id +"&acid="+ Request.Form["to_account"] +"");
            if(isPaid == true && isNAL == true){
                Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=custpay.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&id="+ Request.Form["supplier"] +" \">");
            }else{
                Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=expense.aspx?saydone=1&id=" + m_id +"&acid="+ Request.Form["to_account"] +" \">");
			
            }
			
			return;
		}
	}else if(Request.Form["cmd"] == "DeletePaid"){
        if(DoDeletePaidRecord())
		{
//			Response.Redirect("expense.aspx?saydone=1&id=" + m_id +"&acid="+ Request.Form["to_account"] +"");
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=explist.aspx\">");
			return;
		}
    }   
	else if(Request.Form["ckw"] != null)
	{
		DoCustomerSearchAndList();
		return;
	}

	PrintAdminHeader();
	PrintAdminMenu();

	PrintBody();

	PrintAdminFooter();
}

void UpdateAllFields()
{
	if(Session["branch_support"] != null)
	{
		if(Request.Form["branch"] != null)
			Session["expense_branch"] = Request.Form["branch"];
		else if(Session["branch_id"] != null)
			m_branch = Session["branch_id"].ToString();
	}

	Session["expense_customer"] = Request.Form["customer"];
	Session["expense_from_account"] = Request.Form["from_account"];
	Session["expense_to_account"] = Request.Form["to_account"];
	Session["expense_payment_type"] = Request.Form["payment_type"];
	Session["expense_payment_ref"] = Request.Form["payment_ref"];
	Session["expense_payment_date"] = Request.Form["payment_date"];
	Session["expense_note"] = Request.Form["note"];
	Session["expense_paid_status"] = Request.Form["ispaid"];
	Session["expense_customer"] = Request.Form["supplier"];
}	

void RestoreAllFields()
{
	if(Session["expense_branch"] != null)
		m_branch = Session["expense_branch"].ToString();
	if(Session["expense_customer"] != null)
	{
		m_customerID = Session["expense_customer"].ToString();
		if(m_customerID != "")
		{
			DataRow drc = GetCardData(m_customerID);
			if(drc != null)
			{
				m_customerName = drc["trading_name"].ToString();
				if(m_customerName == "")
					m_customerName = drc["company"].ToString();
				if(m_customerName == "")
					m_customerName = drc["name"].ToString();
			}
		}
	}
	if(Session["expense_from_account"] != null)
		m_fromAccount = Session["expense_from_account"].ToString();
	if(Session["expense_to_account"] != null)
		m_toAccount = Session["expense_to_account"].ToString();
	if(Session["expense_payment_type"] != null)
		m_paymentType = Session["expense_payment_type"].ToString();
	if(Session["expense_payment_ref"] != null)
		m_paymentRef = Session["expense_payment_ref"].ToString();
	if(Session["expense_payment_date"] != null)
		m_paymentDate = Session["expense_payment_date"].ToString();
	if(Session["expense_note"] != null)
		m_note = Session["expense_note"].ToString();
	if(Session["expense_recorded"] != null)
		m_bRecorded = true;
	if(Session["expense_current_id"] != null)
		m_id = Session["expense_current_id"].ToString();

	if(Session["expense_current_id"] != null)
		m_id = Session["expense_current_id"].ToString();

	if(Request.QueryString["ps"] != null && Request.QueryString["ps"] != "")
		Session["expense_paid_status"] = Request.QueryString["ps"];

	if(Session["expense_paid_status"] != null)
		m_bIsPaid = MyBooleanParse(Session["expense_paid_status"].ToString());

	if(m_paymentDate == "")
		m_paymentDate = DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy");
}

bool CheckExpenseTable()
{
	if(Session["ExpenseTable"] == null) 
	{
		dtExpense.Columns.Add(new DataColumn("invoice_number", typeof(String)));
		dtExpense.Columns.Add(new DataColumn("invoice_date", typeof(String)));
		dtExpense.Columns.Add(new DataColumn("tax", typeof(String)));
		dtExpense.Columns.Add(new DataColumn("total", typeof(String)));

		dtExpense.Columns.Add(new DataColumn("taxonly", typeof(String)));
		dtExpense.Columns.Add(new DataColumn("ispaid", typeof(Boolean)));
        dtExpense.Columns.Add(new DataColumn("expenseType", typeof(String)));
		Session["ExpenseTable"] = dtExpense;
		return false;
	}
	else
	{
		dtExpense = (DataTable)Session["ExpenseTable"];
	}
	return true;
}

void EmptyExpenseTable()
{
	CheckExpenseTable();
	for(int i=dtExpense.Rows.Count - 1; i>=0; i--)
		dtExpense.Rows.RemoveAt(i);

	//clear session objects for expense
	Session["expense_branch"] = null;
	Session["expense_customer"] = null;
	Session["expense_from_account"] = null;
	Session["expense_to_account"] = null;
	Session["expense_payment_type"] = null;
	Session["expense_payment_ref"] = null;
	Session["expense_payment_date"] = null;
	Session["expense_note"] = null;
	Session["expense_recorded"] = null;
	Session["expense_current_id"] = null;
	Session["expense_paid_status"] = null;
}

bool PrintBody()
{
	double dSubTotal = 0;

	StringBuilder sb = new StringBuilder();

	//main list


	sb.Append("\r\n<table width=100% cellspacing=0 cellpadding=0 border=0 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("\r\n<tr class=tableHeader>\r\n");
	sb.Append("\r\n<td >Invoice Number</td>");
	sb.Append("\r\n<td >Invoice Date</td>");
	sb.Append("\r\n<td >Is Custom GST?</td>");
    sb.Append("\r\n<td >Expense Type</td>");
	sb.Append("\r\n<td align=right>Amount</td>");
	sb.Append("\r\n<td width=70 align=center>TAX</td>");
	sb.Append("\r\n<td align=right>Total</td>");
	sb.Append("<td >&nbsp;</td>");
	sb.Append("</tr>\r\n");

	CheckExpenseTable();

	for(int i=0; i<dtExpense.Rows.Count; i++)
	{
		DataRow dr = dtExpense.Rows[i];
		string invoice_number = dr["invoice_number"].ToString();
		string invoice_date = dr["invoice_date"].ToString();
		string tax = dr["tax"].ToString();
		string taxonly = dr["taxonly"].ToString();
		string total = dr["total"].ToString();
        string expenseType = getexpenseTypeNameById(dr["expenseType"].ToString());//dr["expenseType"].ToString();
        string expenseTypeId = dr["expenseType"].ToString();
		
		double dTax = MyDoubleParse(tax);
		double dTotal = MyDoubleParse(total);
		double dAmount = dTotal - dTax;


		if(taxonly == "on")
			dAmount = 0;

		dSubTotal += dTotal;
		if(m_editRow == i.ToString())
		{
			if(taxonly == "on")
			{
				dTotal = dTax;
				dTax = 0;
			}

            if(i % 2 == 0){
                sb.Append("<tr>");
            }else{
                sb.Append("<tr class=rowColor>");
            }
            
			sb.Append("<input type=hidden name=edit_row value=" + i + ">");
			sb.Append("<td><input type=text name=invoice_number maxlength=49 value='" + invoice_number + "'></td>");
			sb.Append("<td><input type=text name=invoice_date maxlength=49 value='" + invoice_date + "'></td>");
			sb.Append("<td align=center>");
			sb.Append("<input type=checkbox name=taxonly ");
			if(taxonly == "on")
				sb.Append(" checked ");
//tee, why set 0.00000001?
			sb.Append(" onclick=\"if(document.f.taxonly.checked){document.f.amount.disabled=true;}else{document.f.amount.value='0';document.f.amount.disabled=false;}\">");
//			sb.Append(" onclick=\"if(document.f.taxonly.checked){document.f.amount.value='0.0000001';}else{document.f.amount.value='0';document.f.amount.disabled=false;}\">");
			sb.Append("</td>");
			
            sb.Append("<td>"+PrintToAccountListString(expenseTypeId)+"</td>");
            string ke = "onKeyDown=\"if(event.keyCode==13) event.keyCode=9;\"";
			sb.Append("<td align=right><input type=text id='amountText' name=amount maxlength=49 "+ ke +" ");
			if(taxonly == "on")
				sb.Append(" disabled=true ");
			sb.Append("></td>");
			sb.Append("<td align=center><input type=checkbox name=tax id=tax");
			if(dTax != 0)
				sb.Append(" checked");
			if(taxonly == "on"){
				sb.Append(" checked ");
            }else{
                //sb.Append(" disabled=false ");
            }
			sb.Append(" ></td>");
			sb.Append("<td align=right><input id='totalText' type=text name=total maxlength=49 value=" + dTotal + " "+ ke +" ></td>");
			sb.Append("<td align=right><input type=submit name=cmd value='OK' class=linkButtonLeft title='OK'></td>");

            sb.Append(doAutoFillAmountJSF());

		}
		else
		{
			
            if(i % 2 == 0){
                sb.Append("<tr>");
            }else{
                sb.Append("<tr class=rowColor>");
            }


			sb.Append("<td>" + invoice_number + "</td>");
			sb.Append("<td>" + invoice_date + "</td>");
			sb.Append("<td align=center>");
String t = "";
if(dTotal == 0){
    t = "on";
}
			sb.Append("<input type=checkbox name=taxonly1   ");
            if(t == "on")
                {
                    sb.Append(" checked ");
                }
				
			sb.Append(">");
			sb.Append("</td>");
            sb.Append("<td>"+expenseType+"</td>");
			sb.Append("<td align=right>" + dAmount.ToString("c") + "</td>");
			sb.Append("<td align=right>" + dTax.ToString("c") + "</td>");
			sb.Append("<td align=right>" + dTotal.ToString("c") + "</td>");
			sb.Append("<td align=right>");
			
			if(!m_bIsClose)
			{
			sb.Append("<a href='expense.aspx?t=edit&row=" + i + "");
			if(Request.QueryString["sid"] != null && Request.QueryString["sid"] != "")
				sb.Append("&sid="+ Request.QueryString["sid"] +"");
			sb.Append("&ps="+ m_bIsPaid +"");
			sb.Append("' class=o>EDIT</a> ");
		
			sb.Append("<a href='expense.aspx?t=del&row=" + i + "");
			if(Request.QueryString["sid"] != null && Request.QueryString["sid"] != "")
				sb.Append("&sid="+ Request.QueryString["sid"] +"");
			sb.Append("&ps="+ m_bIsPaid +"");
			sb.Append("' class=o>DEL</a> ");
			}
			sb.Append("</tr>");
		}
	}
	//when press enter will jump to next column 3-11-04
	string keyEnter = "onKeyDown=\"if(event.keyCode==13) event.keyCode=9;\"";
	if(m_editRow == "" && !m_bIsClose)
	{
		
		sb.Append("<tr>");
		sb.Append("<td><input type=text name=invoice_number maxlength=49 "+ keyEnter +" ></td>");
		sb.Append("<td><input type=text name=invoice_date maxlength=49 value='" + DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy") + "' "+ keyEnter +"></td>");
		//sb.Append("<td align=right><input type=text name=amount maxlength=49></td>");
		sb.Append("<td align=center><input type=checkbox name=taxonly ");
		sb.Append(" onclick=\"if(document.f.taxonly.checked)");
		sb.Append("{document.f.amount.disabled=true;document.f.tax.disabled=true;}");
		sb.Append("else");
		sb.Append("{document.f.amount.value='0';document.f.amount.disabled=false;}\" "+ keyEnter +"></td>");
        sb.Append("<td>"+PrintToAccountListString("")+"</td>");
		sb.Append("<td align=right>");
		sb.Append("<input id='amountText' type=text name=amount maxlength=49 ");
		sb.Append(" "+ keyEnter +" ></td>");
		sb.Append("<td align=center><input id=tax type=checkbox name=tax  "+ keyEnter +" disabled></td>");
		sb.Append("<td align=right><input id='totalText' type=text name=total maxlength=49 "+ keyEnter +"></td>");
		sb.Append("<td align=right><input type=submit name=cmd value='Add' class=linkButtonLeft title='Add'></td>");
		sb.Append("</tr>");

            //sb.Append("<script type='text/javascript'>");
            //sb.Append("$('#amountText').keyup(function () {");
            //sb.Append("$('#totalText').val($('#amountText').val());");
            //sb.Append(" });");
            //sb.Append(" </"   +   "script>");

         sb.Append(doAutoFillAmountJSF());

	}

//	sb.Append("<tr><td colspan=6 align=right>");
//	sb.Append("<input type=submit name=cmd value='Recalculate' " + Session["button_style"] + ">");
//	sb.Append("<br><br><br>");
//	sb.Append("</td></tr>");

	sb.Append("<tr><td colspan=6>&nbsp;<br><br><br></td></tr>");
	sb.Append("</table>");

	Response.Write("<br><center><h3>General Expense</h3></center>");
	Response.Write("<form name=f action='expense.aspx");
	if(Session["expense_customer"] != null && Session["expense_customer"] != "")
		Response.Write("?sid="+ Session["expense_customer"] +"");
	Response.Write("' method=post>");

	//hidden values
	Response.Write("<input type=hidden name=id value=" + m_id + ">");

	Response.Write("<table align=center width=99% cellspacing=0 cellpadding=0 border=0 bordercolor=#CCCCCC bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr><td valign=top>");

		Response.Write("<table>");
		Response.Write("<tr><td>");
		//branch
		if(Session["branch_support"] != null)
		{
			Response.Write("<b>Branch : </b></td>");
			Response.Write("<td>");
			if(!PrintBranchNameOptions())
				return false;
			Response.Write("</td>");
		}
		Response.Write("</tr>");
		string uri = Request.ServerVariables["URL"] +"?sid=";

		//payee
		if(m_customerID != "-1")
			Session["expense_customer"] = m_customerID;

		Response.Write("\r\n<tr><td><b>Payee : </b></td><td>");
		if(Session["expense_customer"] != null && Session["expense_customer"] != "")
			Response.Write(PrintSupplierOptions(Session["expense_customer"].ToString(), uri, ""));
		else
			Response.Write(PrintSupplierOptions("", uri, "others"));
/*		Response.Write("<input type=hidden name=customer value=" + m_customerID + ">");
		if(m_customerID != "" && m_customerID != "0")
			Response.Write("<input type=text name=custoemr_name value='" + m_customerName + "' readonly=true>");
		Response.Write(" ");
		if(m_customerID.Length > 2)
		{
			Response.Write("<input type=button onclick=\"javascript:viewcard_window=window.open('viewcard.aspx?");
			Response.Write("id=" + m_customerID + "','','width=350,height=340');\" value='View Card' " + Session["button_style"] + ">");
		}
		Response.Write("<input type=submit name=cmd value='Search Card' " + Session["button_style"] + ">");
		
		*/
		string last_uri = Request.ServerVariables["URL"] +"?"+ Request.ServerVariables["QUERY_STRING"];
		Response.Write("<input type=button name=cmd value='Add New Payee' class=linkButtonCenter title='Add New Payee'");
		Response.Write(" onclick=\"window.location=('ecard.aspx?a=new&n=others&r="+ DateTime.UtcNow.AddHours(12).ToString("ddMMyyyyhhmmss") +"&luri="+ HttpUtility.UrlEncode(last_uri) +"')\" ");
		Response.Write(">");
		//Response.Write(" <i><font color=red>(please refresh browser to get a new added payee)</font></i></td></tr>");

		//from account
		Response.Write("<tr><td><b>From Account : </b></td><td>");
		if(!PrintFromAccountList())
			return false;
		Response.Write("<input type=button name=cmd value='Add New ACC' class=linkButtonCenter title='Add New ACC' ");
		Response.Write(" onclick=\"window.location=('account.aspx?t=e&r="+ DateTime.UtcNow.AddHours(12).ToString("ddMMyyyyhhmmss") +"&c=1&luri="+ HttpUtility.UrlEncode(last_uri) +"')\" ");
		Response.Write(">");
		Response.Write("</td></tr>");

		//To account
        //Response.Write("<tr><td><b>Expense Type : </b></td><td>");
        //if(!PrintToAccountList())
        //    return false;
        //Response.Write("<input type=button name=cmd value='Add New ACC' class=linkButtonLeft title='Add New ACC'");
        //Response.Write(" onclick=\"window.location=('account.aspx?t=e&r="+ DateTime.UtcNow.AddHours(12).ToString("ddMMyyyyhhmmss") +"&c=6&luri="+ HttpUtility.UrlEncode(last_uri) +"')\" ");
        //Response.Write(">");
        //Response.Write("</td></tr>");
		Response.Write("</table>");

	Response.Write("</td><td align=right valign=top>");

		//payment table
		Response.Write("\r\n<table>");
		Response.Write("<tr><td><b>Payment Type : </b></td>");
		Response.Write("<td>");
		Response.Write("<select name=payment_type onchange=");
		Response.Write(" \"if(this.options[this.selectedIndex].value == '2')");
		Response.Write("document.f.payment_ref.value=" + m_nextChequeNumber + "; ");
		Response.Write("else document.f.payment_ref.value=document.f.payment_ref_old.value;");
		Response.Write("\">");
		Response.Write(GetEnumOptions("payment_method", m_paymentType));
		Response.Write("</select></td></tr>");
		Response.Write("\r\n<tr><td align=right><b>Reference : </b></td>");
		Response.Write("<td><input type=text name=payment_ref style='text-align:right' value='" + m_paymentRef + "'");
		Response.Write(" onchange=\"document.f.payment_ref_old.value=this.value;\" "+ keyEnter +">");
		Response.Write("<input type=hidden name=payment_ref_old></td></tr>");
		Response.Write("\r\n<tr><td align=right><b>Payment Date : </b></td><td>");
		Response.Write("<input type=text name=payment_date value='" + m_paymentDate + "' style='text-align:right' "+ keyEnter +"></td></tr>");
		Response.Write("\r\n<tr><td align=right><b>Amount : </b></td><td>");
		Response.Write("\r\n<input type=text name=total_amount onclick=\"if(this.value=='')this.value=" + dSubTotal + ";\" ");
		Response.Write("value=" + dSubTotal.ToString());
		Response.Write(" style='text-align:right' "+ keyEnter +"></td></tr>");
		Response.Write("\r\n</table>");

	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=2>");

	Response.Write(sb.ToString());

	Response.Write("</td></tr>");

    Response.Write("<tr><td>");
    Response.Write("<table class=commentTable>");
	Response.Write("<tr><td colspan=1 class=blueFont>Note : <br>");
	Response.Write("<textarea name=note rows=3 cols=50 class=commentText>" + m_note + "</textarea>");
    Response.Write("</table>");
//	Response.Write("</td>");
//	Response.Write("</tr>");

//	Response.Write("<td align=left valign=bottom>");
//	Response.Write("<table border=1>");
//	Response.Write("<tr><td>");
//	Response.Write("<font color=red><b> Auto Repeat : </b></font>");
//	Response.Write("<select name=autopayment_frequency>");
//	Response.Write(GetEnumOptions("autopayment_frequency", m_sAutoFrequency));
//	Response.Write("</select> <a href=autopay.aspx class=o>Auto Payment List</a>");
//	Response.Write("</td></tr>");
//	Response.Write("</table>");
//	Response.Write("</td></tr>");
	Response.Write("</td>");
//	if(m_bRecorded)
	{
		Response.Write("<td align=right>");
		Response.Write("<table width=100% cellspacing=0 cellpadding=4 border=0 bordercolor=#CCCCCC bgcolor=#EEEEE");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr><td>");
		Response.Write("<font color=red><b> Auto Repeat : </b></font>");
		Response.Write("<select name=autopayment_frequency>");
		Response.Write(GetEnumOptions("autopayment_frequency", m_sAutoFrequency));
		Response.Write("</select> ");
		Response.Write("</td></tr><tr><td>");
		Response.Write("<b>Next Payment Date : </b><input type=text size=10 name=next_payment_date value='" + m_sNextAutoDate + "'>");
		Response.Write(" <a href=explist.aspx?autolist=1 class=o target=_blank>Auto Payment List</a>");
		Response.Write("</td></tr>");
		Response.Write("</table>");
		Response.Write("</td>");
	}
//	else
//		Response.Write("<td>&nbsp;</td>");
	Response.Write("</tr>");
	Response.Write("<tr bgcolor=#EEEEE><td colspan=2 align=right>");
	if(Session["last_uri_recon"] != null)
	{
		Response.Write("<input type=button value='BACK to Reconciliate' class=linkButton3 title='Back To Reconciliate' onclick=\"window.location=('"+ Session["last_uri_recon"] +"')\"> ");
		m_bIsPaid = true;
	}
	if(!m_bIsClose)
	{
		Response.Write("<b>Type Record:</b> <select name=ispaid ");
		Response.Write(">");
		if(Session["expense_paid_status"] != null && Session["expense_paid_status"] != "")
			m_bIsPaid = MyBooleanParse(Session["expense_paid_status"].ToString());
		if(!m_bIsPaid)
		{
			Response.Write("<option value=0 ");
			if(!m_bIsPaid)
				Response.Write(" selected ");
			Response.Write(">Save Only");
		}
		Response.Write("<option value=1 ");
		if(m_bIsPaid){
			Response.Write(" selected  ");
            Response.Write(">View Only");
        }else{
		    Response.Write(">Pay Now");
        }
		Response.Write("</select> ");

	//	Response.Write("<input type=checkbox name=confirm_record>Tick to -> ");
		if(m_bRecorded)
		{		
            if(!m_bIsPaid){
                Response.Write("<input type=submit name=cmd value='Pay/Save Expense' class=payAndSaveButton");
			    //Response.Write(" onclick=\"if(document.f.supplier.value == '' || !document.f.confirm_record.checked){window.alert('Please Select Payee & Tick to Record check box');return false;}else if(!confirm('Process now...')){return false;}\" ");
			    Response.Write(" onclick=\"if(document.f.supplier.value == ''){window.alert('Please Select Payee!!!');return false;}else if(!confirm('Process now...')){return false;}\" ");
			    Response.Write(">");
            }else{
                Response.Write("<input type=submit name=cmd value='DeletePaid'  class=deleteButton3 title='Delete Paid'");
                Response.Write(" onclick='return confirm(\"Delete PAID expense!!!\\r\\r\\nContinue???\");' ");		
                Response.Write(" >");		
            }
			
			Response.Write("<input type=button value='Expense List' onclick=window.location=('explist.aspx') class=expenseListButton title='Expense List'>");
            
        }
		else
		{	
		//	Response.Write("<input type=checkbox name=confirm_record>Tick to -> ");
			Response.Write("<input type=submit name=cmd value=Pay/Save class=payAndSaveButton");
			//Response.Write(" onclick=\"if(document.f.supplier.value == '' || !document.f.confirm_record.checked){window.alert('Please Select Payee & Tick to Record check box');return false;}else if(!confirm('Process now...')){return false;}\" ");
			Response.Write(" onclick=\"if(document.f.supplier.value == ''){window.alert('Please Select Payee!!!');return false;}else if(!confirm('Process now...')){return false;}\" ");
			Response.Write(">");
		}
	}
	else
		Response.Write("<input type=button value='New Expense' "+ Session["button_style"] +" onclick=\"window.location=('expense.aspx?t=new')\">");
		Response.Write("</td></tr>");
	
	Response.Write("</table>");
	Response.Write("</form>");
	return true;
}

bool PrintFromAccountList()
{
	int rows = 0;
	string sc = "SELECT * FROM account WHERE class1=1 OR class1=2 ORDER BY class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "account");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=from_account>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["account"].Rows[i];
		string id = dr["id"].ToString();
		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		double dAccBalance = double.Parse(dr["balance"].ToString());
		Response.Write("<option value=" + id);
		if(id == m_fromAccount)
		{
			Response.Write(" selected");
//			m_sAccBalance = dAccBalance.ToString("c");
		}
//		Response.Write(">" + disnumber + " ");
		Response.Write(">" + number + " - ");
		Response.Write(dr["name1"].ToString().ToUpper() + " - ");
		Response.Write(dr["name4"].ToString());
		
//		Response.Write(" " + dAccBalance.ToString("c"));		
	}
	Response.Write("</select>");
//	if(m_sAccBalance != "")
//		Response.Write("<b>&nbsp&nbsp&nbsp; ------------ Balance : " + m_sAccBalance + "</b>");
	return true;
}

bool PrintToAccountList()
{
	int rows = 0;
	string sc = "SELECT *, name4+' ' +name1 AS type ";
	sc += " FROM account ";
	sc += " WHERE class1 = 6 OR class1 = 2 ";
	sc += " ORDER BY class1 ";//class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "toaccount");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	Response.Write("<select name=to_account>");
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccount"].Rows[i];
		string id = dr["id"].ToString();
		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		
		string snumber = disnumber;
		snumber = snumber.Replace("-", "");
		if(snumber == GetSiteSettings("account_stock_on_hand", "1121", true) || snumber == GetSiteSettings("account_trade_debtors", "1411", true)
	 || snumber == GetSiteSettings("account_trade_creditors", "2111", true) || snumber == GetSiteSettings("account_gst_collect", "2311", true)
	 || snumber == GetSiteSettings("account_gst_paid", "2312", true)	 || snumber == GetSiteSettings("account_current_year_earning", "3211", true)
	 || snumber == GetSiteSettings("account_retained_earning", "3221", true)	 || snumber == GetSiteSettings("account_historical_balancing", "3231", true)
	 || snumber == GetSiteSettings("account_sales_income", "4111", true) || snumber == GetSiteSettings("account_cost_of_sales", "5111", true) )
		{	continue;}

		double dAccBalance = double.Parse(dr["balance"].ToString());
		Response.Write("<option value=" + id);
		if(id == m_toAccount)
		{
			Response.Write(" selected");
//			m_sAccBalance = dAccBalance.ToString("c");
		}
//		Response.Write(">"+ number +" - " + dr["type"].ToString());
		Response.Write(">"+ number +" - " + dr["name1"].ToString().ToUpper() +" - "+ dr["name4"].ToString());
//		Response.Write(" " +dr["name1"].ToString());
//		Response.Write(" " + dAccBalance.ToString("c"));		
	}
	Response.Write("</select>");
	return true;
}



string PrintToAccountListString(string expenseType)
{
	int rows = 0;
	string sc = "SELECT *, name4+' ' +name1 AS type ";
	sc += " FROM account ";
	sc += " WHERE class1 = 6 OR class1 = 2 ";
	sc += " ORDER BY class1 ";//class1, class2, class3, class4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "toaccount");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	
    string printToAccountList = "";
	printToAccountList += "<select name=to_account id=expenseType onchange='expenseTypeChange()'>";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccount"].Rows[i];
		string id = dr["id"].ToString();
		string number = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		string disnumber = dr["class1"].ToString() + "-" + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		
		string snumber = disnumber;
		snumber = snumber.Replace("-", "");
		if(snumber == GetSiteSettings("account_stock_on_hand", "1121", true) || snumber == GetSiteSettings("account_trade_debtors", "1411", true)
	 || snumber == GetSiteSettings("account_trade_creditors", "2111", true) || snumber == GetSiteSettings("account_gst_collect", "2311", true)
	 || snumber == GetSiteSettings("account_gst_paid", "2312", true)	 || snumber == GetSiteSettings("account_current_year_earning", "3211", true)
	 || snumber == GetSiteSettings("account_retained_earning", "3221", true)	 || snumber == GetSiteSettings("account_historical_balancing", "3231", true)
	 || snumber == GetSiteSettings("account_sales_income", "4111", true) || snumber == GetSiteSettings("account_cost_of_sales", "5111", true) )
		{	continue;}

		double dAccBalance = double.Parse(dr["balance"].ToString());
		printToAccountList += "<option value=" + id;
		if(id == expenseType)
		{
			printToAccountList += " selected";
//			m_sAccBalance = dAccBalance.ToString("c");
		}
//		Response.Write(">"+ number +" - " + dr["type"].ToString());
		printToAccountList += ">"+ number +" - " + dr["name1"].ToString().ToUpper() +" - "+ dr["name4"].ToString();
//		Response.Write(" " +dr["name1"].ToString());
//		Response.Write(" " + dAccBalance.ToString("c"));		
	}
	printToAccountList += "</select>";

    printToAccountList += doCheckExpenseTypeJSF();    


	return printToAccountList;
}

bool DoCustomerSearchAndList()
{
	int rows = 0;
	string kw = "'%" + Request.Form["ckw"] + "%'";
	if(Request.Form["ckw"] == null || Request.Form["ckw"] == "")
		kw = "'%%'";
	string sc = "SELECT c.*, c1.name AS sales_name ";
	sc += " FROM card c LEFT OUTER JOIN card c1 ON c1.id = c.sales ";
	sc += " WHERE c.type<>6 AND c.type<>3  AND ("; //type 3: supplier;
	if(IsInteger(Request.Form["ckw"]))
		sc += " c.id=" + Request.Form["ckw"] + ") ";
	else
		sc += " c.name LIKE " + kw + " OR c.email LIKE " + kw + " OR c.trading_name LIKE " + kw + " OR c.company LIKE " + kw + ")";
	sc += " ORDER BY c.trading_name ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "card");
		if(rows == 1)
		{
			string search_id = dst.Tables["card"].Rows[0]["id"].ToString();
			Trim(ref search_id);
			Response.Write("<meta  http-equiv=\"refresh\" content=\"0; URL=expense.aspx?cid=" + search_id);
			Response.Write("\">");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<center><h3>Search for Payee</h3></center>");
	Response.Write("<form id=search action=expense.aspx method=post>");
	Response.Write("<table width=100/%><tr><td>");
	Response.Write("<input type=editbox size=7 name=ckw></td>");
	Response.Write("<td><input type=submit name=cmd value=Search " + Session["button_style"] + "></td>");
	Response.Write("<td><input type=button name=cmd value='Cancel'");
	Response.Write(" onClick=window.location=('expense.aspx') " + Session["button_style"] + "></td>");
	Response.Write("<td><input type=button onclick=window.open('ecard.aspx?n=customer&a=new') value='New Customer' " + Session["button_style"] + ">");
	Response.Write("</td></tr></table></form>");

	BindCustomer();
	PrintAdminFooter();

	return true;
}

void BindCustomer()
{
	if(dst.Tables["card"].Rows.Count == 0)
	{
		Response.Write("<br><center><h3>Your search for " + Request.Form["ckw"] + " returns 0 result</h3>");
		return;
	}
	string bgcolor = "lightblue";//GetSiteSettings("table_row_bgcolor", "#666696");
	Response.Write("<table width=90%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr style=\"color:white;background-color:" + bgcolor +";font-weight:bold;\">\r\n");
	Response.Write("<th>ACC#</th>");
	Response.Write("<th>Company</th>\r\n");
	Response.Write("<th>Contact</th>\r\n");
	Response.Write("<th>Email</th>\r\n");
	Response.Write("<th>Phone</th>\r\n");
	Response.Write("<th>Balance</td>\r\n");
	Response.Write("</tr>\r\n");

	bool bcolor = true;
	string scolor = "";

	int rows = 50;
	for(int i=0; i<rows; i++)
	{
		if(i >= dst.Tables["card"].Rows.Count)
			break;

		if(bcolor)
			scolor = " class=rowColor";
		else
			scolor = "";

		bcolor = !bcolor;

		DataRow dr = dst.Tables["card"].Rows[i];
		string id = dr["id"].ToString();
		string trading_name = dr["trading_name"].ToString();
		string name = dr["name"].ToString();
		string email = dr["email"].ToString();
		string balance = MyDoubleParse(dr["balance"].ToString()).ToString("c");
		string phone = dr["phone"].ToString();

		Response.Write("<tr" + scolor + ">");

		Response.Write("<td><a href=expense.aspx?cid=" + id + ">");
		Response.Write(id + "</a></td>\r\n");

		Response.Write("<td><a href=expense.aspx?cid=" + id + ">");
		Response.Write(trading_name + "</a></td>");

		Response.Write("<td><a href=expense.aspx?cid=" + id + ">");
		Response.Write(name + "</a></td>");

		Response.Write("<td><a href=expense.aspx?cid=" + id + ">");
		Response.Write(email + "</a></td>");

		Response.Write("<td>" + phone + "</td>");
		Response.Write("<td align=right>" + balance + "</td>");

		Response.Write("</tr>");
	}	
	Response.Write("</table>");
}

bool DoAddExpense()
{
	string invoice_number = Request.Form["invoice_number"];
	string invoice_date = Request.Form["invoice_date"];
	string amount = Request.Form["amount"];
	string total = Request.Form["total"];
	string taxonly = Request.Form["taxonly"];
    string expenseType = Request.Form["to_account"];
	m_bIsPaid = MyBooleanParse(Request.Form["ispaid"].ToString());
	double dAmount = 0;
	double dTotal = 0;

	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	DateTime tInvoice;
	string msg = "";
	dAmount = MyMoneyParse(amount);
	dTotal = MyMoneyParse(total);
	try
	{
		tInvoice = DateTime.Parse(invoice_date, format, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
	}
	catch(Exception e)
	{
		msg = "Invoice Date. Input string <font color=red>" + invoice_date + "</font> was not in a correct format";
	}

	double dGst = MyDoubleParse(GetSiteSettings("gst_rate_percent", "15")) / 100 + 1;
	
	double dTax = 0;
	bool bTaxOnly = false;
	if(taxonly == "on")
		bTaxOnly = true;

	bool bTax = false;
	if(Request.Form["tax"] == "on")
		bTax = true;
	if(bTaxOnly)
	{
		dTax = dTotal;
		dTotal = 0;
	}
	else
	{
		if(dTotal != 0 && dAmount != 0)
		{
			dTax = dTotal - dAmount;
		}
		else if(dTotal != 0)
		{
			if(bTax)
			{
				//dAmount = Math.Round(dTotal / dGst);
				dAmount = Math.Round(dTotal / dGst, 3);
				dTax = dTotal - dAmount;
			}
			else
				dAmount = dTotal;
		}
		else if(dAmount != 0)
		{
			if(bTax)
			{
				//dTotal = Math.Round(dAmount * dGst);
				dTotal = Math.Round(dAmount * dGst, 3);
				dTax = dTotal - dAmount;
			}
			else
				dTotal = dAmount;
		}
		else
		{
			msg = "Error, please enter either Amount or Total";
		}
	}

	if(msg != "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><br><center><h3>Error, " + msg + "</h3>");
		Response.Write("<br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}

	CheckExpenseTable();

	DataRow dr = dtExpense.NewRow();
	dr["invoice_number"] = invoice_number;
	dr["invoice_date"] = invoice_date;
	dr["tax"] = dTax.ToString();
	dr["total"] = dTotal.ToString();
	dr["taxonly"] = taxonly;
    dr["expenseType"] = expenseType;

	dtExpense.Rows.Add(dr);
	return true;
}

bool DoUpdateExpenseRow()
{
	CheckExpenseTable();
	int row = MyIntParse(Request.Form["edit_row"]);
	if(row >= dtExpense.Rows.Count)
		return false;
	string invoice_number = Request.Form["invoice_number"];
	string invoice_date = Request.Form["invoice_date"];
	string amount = Request.Form["amount"];
	string total = Request.Form["total"];
	string taxonly = Request.Form["taxonly"];
    string expenseType = Request.Form["to_account"];
//	m_bIsPaid = MyBooleanParse(Request.Form["ispaid"].ToString());
	double dAmount = 0;
	double dTotal = 0;
	
	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	DateTime tInvoice;
	string msg = "";
	dAmount = MyMoneyParse(amount);
	dTotal = MyMoneyParse(total);
	try
	{
		tInvoice = DateTime.Parse(invoice_date, format, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
	}
	catch(Exception e)
	{
		msg = "Invoice Date. Input string <font color=red>" + invoice_date + "</font> was not in a correct format";
	}

	double dGst = MyDoubleParse(GetSiteSettings("gst_rate_percent", "12.5")) / 100 + 1;
	bool bTax = false;
	if(Request.Form["tax"] == "on")
		bTax = true;
	double dTax = 0;

	bool bTaxOnly = false;
	if(taxonly == "on")
		bTaxOnly = true;

	if(bTaxOnly)
	{
		dTax = dTotal;
		dTotal = 0;
	}
	else
	{
		if(dTotal != 0 && dAmount != 0)
		{
			dTax = dTotal - dAmount;
		}
		else if(dTotal != 0)
		{
			if(bTax)
			{
				dAmount = Math.Round(dTotal / dGst, 3);
				dTax = dTotal - dAmount;
			}
			else
				dAmount = dTotal;
		}
		else if(dAmount != 0)
		{
			if(bTax)
			{
				dTotal = Math.Round(dAmount * dGst, 3);
				dTax = dTotal - dAmount;
			}
			else
				dTotal = dAmount;
		}
		else
		{
			msg = "Error, please enter either Amount or Total";
		}
	}

	if(msg != "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><br><center><h3>Error, " + msg + "</h3>");
		Response.Write("<br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}

	DataRow dr = dtExpense.Rows[row];
	dr["invoice_number"] = invoice_number;
	dr["invoice_date"] = invoice_date;
	dr["tax"] = dTax.ToString();
	dr["total"] = dTotal.ToString();
	dr["taxonly"] = taxonly;
    dr["expenseType"] = expenseType;
	dtExpense.AcceptChanges();
	return true;
}

bool DoRecordExpense()
{
	CheckExpenseTable();
	if(dtExpense.Rows.Count == 0 || Session["expense_customer"] == null && Session["expense_customer"] == "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<script language=javascript>");
		Response.Write("window.alert('Error, no expense to record!'); window.history.back();</script");
		Response.Write(">");
		Response.Write("<br><br><center><h3>Error, no expense to record");
		Response.Write("<br><br><a title='Back to Expense' onload=window.history.go(-1); class=o>BACK</a></h3>");
		Response.Write("<br><br><br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}
	
	string payment_date = Request.Form["payment_date"];
	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	DateTime tPayment;
	string msg = "";
	try
	{
		tPayment = DateTime.Parse(payment_date, format, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
	}
	catch(Exception e)
	{
		msg = "Payment Date. Input string <font color=red>" + payment_date + "</font> was not in a correct format";
	}
	if(msg != "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><br><center><h3>Error, " + msg + "</h3>");
		Response.Write("<br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}

	string new_id = "";
//DEBUG("ispaid = ", Request.Form["ispaid"].ToString());
    if(Request.Form["supplier"] != null && Request.Form["supplier"] != "")
    m_customerID = Request.Form["supplier"];

	Session["expense_customer"] = m_customerID;

	//get new id
	string sc = "BEGIN TRANSACTION ";
	sc += " SET DATEFORMAT dmy ";
	sc += " INSERT INTO expense (card_id, from_account, to_account, payment_type ";
	sc += ", payment_ref, payment_date, recorded_by ";
	sc += ", ispaid ";
	sc += ") ";
	sc += " VALUES(" + m_customerID;
	sc += ", " + m_fromAccount;
	sc += ", " + dtExpense.Rows[0]["expenseType"].ToString();
	sc += ", " + m_paymentType;
	sc += ", '" + EncodeQuote(m_paymentRef) + "' ";
	sc += ", '" + m_paymentDate + "' ";
	sc += ", " + Session["card_id"].ToString();
	sc += " , "+ Request.Form["ispaid"] +" ";
	sc += ") ";
	sc += " SELECT IDENT_CURRENT('expense') AS id";
	sc += " COMMIT ";
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dst, "id") == 1)
		{
			new_id = dst.Tables["id"].Rows[0]["id"].ToString();
			m_id = new_id;
		}
		else
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error recording expense, failed to get new id</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	//record items
	sc = " BEGIN TRANSACTION SET DATEFORMAT dmy ";
	double dSubTax = 0;
	double dSubTotal = 0;
	double dSubTotalWithTaxOnly = 0;
	for(int i=0; i<dtExpense.Rows.Count; i++)
	{
		DataRow dr = dtExpense.Rows[i];
		string invoice_number = dr["invoice_number"].ToString();
		string invoice_date = dr["invoice_date"].ToString();
		double dTax = MyDoubleParse(dr["tax"].ToString());
		double dTotal = MyDoubleParse(dr["total"].ToString());
        string expenseType = dr["expenseType"].ToString(); 
        string taxonly = dr["taxonly"].ToString();
		
		dSubTax += dTax;
		dSubTotal += dTotal;
		dSubTotalWithTaxOnly += dTotal;
		if(dTotal == 0)
			dSubTotalWithTaxOnly += dTax;
			

		sc += " SET DATEFORMAT dmy INSERT INTO expense_item (id, invoice_number, invoice_date, tax, total,to_account) ";
		sc += " VALUES(" + new_id + ", '" + EncodeQuote(invoice_number) + "', '" + invoice_date + "' ";
		sc += ", " + dTax + ", " + dTotal + ","+expenseType+") ";


        sc += " UPDATE expense SET ";
	    sc += " tax = " + dSubTax;

        if(Request.Form["ispaid"] == "1"){
	        sc += ", total = " + dSubTotal;
        }
	    sc += ", note = '" + EncodeQuote(m_note) + "' ";
	    sc += ", ispaid = "+ Request.Form["ispaid"] +" ";
	    sc += " WHERE id = " + new_id;


	    string sGSTAcc = GetSiteSettings("account_gst_paid", "2312", true);
        string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
        string accountTradeDebtors = GetSiteSettings("account_trade_debtors", "1411", true);
        string accountNAL = GetSiteSettings("account_nal", "1214", true);

        //check account is DR or CR
        string isDr = "+";
        if(expenseType == accountTradeCreditors){
            isDr = "+";
        }
        if(isDebitAccountType(expenseType)){
            isDr = "-";
        }
        //if is nal account
        
        if(isNALAccount(m_fromAccount,accountNAL)){
            isNAL    = true;
        }


        string isDr2 = "-";
        if(m_fromAccount == accountTradeCreditors){
            isDr2 = "-";
        }
        if(isDebitAccountType(m_fromAccount)){
            isDr2 = "+";
        }


	    if(Request.Form["ispaid"] == "1")
	    {
            isPaid = true;
            if(isNAL){
                sc += " UPDATE account SET balance = balance - "+ dTotal + " WHERE id=" + m_fromAccount; 
                sc += " UPDATE card SET  balance = balance - " + dTotal + " WHERE id = " + m_customerID;
                AddCreditToCustomer(dTotal, 1, m_customerID,  dTotal);
                //sc += " UPDATE account SET balance = balance - "+ dTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + accountTradeCreditors;
                sc += " UPDATE account SET balance = balance + " + (dTotal  - dTax) + " WHERE id = " + expenseType;
                sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
            }else{
                if(taxonly == "on"){
                    sc += "/*1328*/ UPDATE account SET balance = balance "+isDr2+" " + (dTax) + " WHERE id=" + m_fromAccount; 
                    sc += "/*1329*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                }else{
                      sc += " UPDATE account SET balance = balance "+isDr2+" " + (dTotal) + " WHERE id = " + m_fromAccount;
                         //		sc += " UPDATE account SET balance = balance + " + (dSubTotalWithTaxOnly  - dSubTax) + " WHERE id = " + m_toAccount;
		               //sc += " UPDATE account SET balance = balance + " + dSubTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";

		              sc += " UPDATE account SET balance = balance "+isDr+" " + (dTotal  - dTax) + " WHERE id = " + expenseType;
                      sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                }
            }
            
	    }
	    else
	    {
		    //sc += " UPDATE account SET balance = balance + " + (dTotal  - dTax) + " WHERE id = " + expenseType;
		    //sc += " UPDATE account SET balance = balance - " + (dTotal) + " WHERE id = " + m_fromAccount;
    //		sc += " UPDATE account SET balance = balance + " + (dSubTotalWithTaxOnly  - dSubTax) + " WHERE id = " + m_toAccount;
		    //sc += " UPDATE account SET balance = balance + " + dSubTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
            
		    //sc += " UPDATE account SET balance = balance "+isDr+" " + (dTotal  - dTax) + " WHERE id = " + expenseType;
            //sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
            if(isNAL){
                sc += " UPDATE account SET balance = balance + " + (dTotal) + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                sc += " UPDATE account SET balance = balance + " + (dTotal  - dTax) + " WHERE id = " + expenseType;
                sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
            }else{
                if(taxonly == "on"){
                        sc += "/*1349*/ UPDATE account SET balance = balance + " + (dTax) + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                        sc += "/*1350*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                }else{
                    sc += " UPDATE account SET balance = balance + " + (dTotal) + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                    sc += " UPDATE account SET balance = balance "+isDr+" " + (dTotal  - dTax) + " WHERE id = " + expenseType;
                    sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                }
            }
	    }
	}
//    sc += " UPDATE expense SET ";
//    sc += " tax = " + dSubTax;
//    sc += ", total = " + dSubTotal;
//    sc += ", note = '" + EncodeQuote(m_note) + "' ";
//    sc += ", ispaid = "+ Request.Form["ispaid"] +" ";
//    sc += " WHERE id = " + new_id;
//    string sGSTAcc = GetSiteSettings("account_gst_paid", "2312", true);
////DEBUG("is piad =", Request.Form["ispaid"].ToString());
//    if(Request.Form["ispaid"] == "1")
//    {
//        sc += " UPDATE account SET balance = balance - " + (dSubTotalWithTaxOnly) + " WHERE id = " + m_fromAccount;
////		sc += " UPDATE account SET balance = balance + " + (dSubTotalWithTaxOnly  - dSubTax) + " WHERE id = " + m_toAccount;
//        sc += " UPDATE account SET balance = balance + " + dSubTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
//        sc += " UPDATE account SET balance = balance + " + (dSubTotalWithTaxOnly  - dSubTax) + " WHERE id = " + m_toAccount;
//    }
//    else
//    {
//        sc += " UPDATE account SET balance = balance + " + (dSubTotalWithTaxOnly  - dSubTax) + " WHERE id = " + m_toAccount;
//    }


	sc += " COMMIT ";


    //----check ASSET account to 

	//DEBUG("1411sc=", sc);
//return false;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
        
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(m_paymentType == "2") //cheque
	{
		string s = m_paymentRef;
		int p = s.Length - 1;
		for(; p>=0; p--)
		{
			if(!Char.IsDigit(s[p]))
				break;
		}
		string tail = "";
		if(p < s.Length - 1)
			tail = s.Substring(p+1, s.Length - 1 - p);
		if(tail != "")
		{
			string head = "";
			if(p > 0)
				head = m_paymentRef.Substring(0, p);
			s = head + (MyIntParse(tail) + 1).ToString();
			SetSiteSettings("next_cheque_number", s);
		}
	}
	EmptyExpenseTable();

	CheckAutoPaymentChanges();
	return true;
}

bool RestoreRecord()
{
	string sc = " SELECT e.*,i.to_account AS expenseType ";
	sc += ", i.kid, i.invoice_number, i.invoice_date, i.tax AS item_tax, i.total AS item_total ";
	sc += " FROM expense e ";
	sc += " JOIN expense_item i ON i.id=e.id ";
	sc += " WHERE e.id = " + m_id;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dst, "restore") <= 0)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Record Not Found</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	DataRow dr = dst.Tables["restore"].Rows[0];
	m_branch = dr["branch"].ToString();
	m_customerID = dr["card_id"].ToString();
	m_fromAccount = dr["from_account"].ToString();
	m_toAccount = dr["to_account"].ToString();
	m_paymentType = dr["payment_type"].ToString();
	m_paymentRef = dr["payment_ref"].ToString();
	m_paymentDate = DateTime.Parse(dr["payment_date"].ToString()).ToString("dd-MM-yyyy");
	m_note = dr["note"].ToString();
	m_bIsPaid = bool.Parse(dr["ispaid"].ToString());
	m_bIsClose = bool.Parse(dr["isclose"].ToString());
    //string m_taxOnly = dr["taxOnly"];

	DataRow drc = GetCardData(m_customerID);
	if(drc != null)
	{
		m_customerName = drc["trading_name"].ToString();
		if(m_customerName == "")
			m_customerName = drc["company"].ToString();
		if(m_customerName == "")
			m_customerName = drc["name"].ToString();
	}

	Session["expense_branch"] = m_branch;
	Session["expense_customer"] = m_customerID;
	Session["expense_from_account"] = m_fromAccount;
	Session["expense_to_account"] = m_toAccount;
	Session["expense_payment_type"] = m_paymentType;
	Session["expense_payment_ref"] = m_paymentRef;
	Session["expense_payment_date"] = m_paymentDate;
	Session["expense_note"] = m_note;

	for(int i=0; i<dst.Tables["restore"].Rows.Count; i++)
	{
		dr = dst.Tables["restore"].Rows[i];
		string invoice_number = dr["invoice_number"].ToString();
		string invoice_date = DateTime.Parse(dr["invoice_date"].ToString()).ToString("dd-MM-yyyy");
		string tax = dr["item_tax"].ToString();
		string total = dr["item_total"].ToString();
        string expenseType = dr["expenseType"].ToString();

		DataRow dre = dtExpense.NewRow();
		dre["invoice_number"] = invoice_number;
		dre["invoice_date"] = invoice_date;
		dre["tax"] = tax;
		dre["total"] = total;
        dre["expenseType"] = expenseType;
		if(total == "0")
			dre["taxonly"] = "on";
		dtExpense.Rows.Add(dre);
	}

	if(!GetAutoPaymentInfo())
		return false;
	return true;
}

bool DoUpdateRecord()
{

    //string sc = " SELECT e.*,i.to_account AS expenseType ";
    //sc += ", i.kid, i.invoice_number, i.invoice_date, i.tax AS item_tax, i.total AS item_total ";
    //sc += " FROM expense e ";
    //sc += " JOIN expense_item i ON i.id=e.id ";
    //sc += " WHERE e.id = " + m_id;
    string sGSTAcc = GetSiteSettings("account_gst_paid", "2312", true);

	string sc = " SELECT * FROM expense WHERE id = " + m_id;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dst, "old") != 1)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Original record not found, cannot update</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	DataRow dr = dst.Tables["old"].Rows[0];
	string old_from = dr["from_account"].ToString();
	string old_to = dr["to_account"].ToString();
	string old_type = dr["ispaid"].ToString();
	double dOldTotal = getOldTotalById(m_id);
	double dOldTax = MyDoubleParse(dr["tax"].ToString());

	//do update first
	string payment_date = Request.Form["payment_date"];

	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	DateTime tPayment;
	string msg = "";
	try
	{
		tPayment = DateTime.Parse(payment_date, format, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
	}
	catch(Exception e)
	{
		msg = "Payment Date. Input string <font color=red>" + payment_date + "</font> was not in a correct format";
	}
	if(msg != "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><br><center><h3>Error, " + msg + "</h3>");
		Response.Write("<br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}

	CheckExpenseTable();

    
	//record items
	sc = " BEGIN TRANSACTION DELETE FROM expense_item WHERE id = " + m_id;
	sc += " SET DATEFORMAT dmy ";
    
    sc += doDeleteOldTotalForEachAccById(m_id , dOldTax);    
    if(newDOldTax != 0){
        dOldTax = newDOldTax;
    }

	double dSubTax = 0;
	double dSubTotal = 0;
     double dFinalTax = 0;
	for(int i=0; i<dtExpense.Rows.Count; i++)
	{
		dr = dtExpense.Rows[i];
		string invoice_number = dr["invoice_number"].ToString();
		string invoice_date = dr["invoice_date"].ToString();
		double dTax = MyDoubleParse(dr["tax"].ToString());
		double dTotal = MyDoubleParse(dr["total"].ToString());
        string expenseType = dr["expenseType"].ToString();
        string taxOnly = dr["taxonly"].ToString();
		
		dSubTax += dTax;
		dSubTotal += dTotal;
        dFinalTax += dTax;

		sc += " /*1573*/ INSERT INTO expense_item (id, invoice_number, invoice_date, tax, total, to_account) ";
		sc += " VALUES(" + m_id + ", '" + EncodeQuote(invoice_number) + "', '" + invoice_date + "' ";
		sc += ", " + dTax + ", " + dTotal + ", "+ expenseType +") ";

        string accountNAL = GetSiteSettings("account_nal", "1214", true);


        //if is nal account
        //bool isNAL = false;
        if(isNALAccount(m_fromAccount,accountNAL)){
            isNAL    = true;
        }

        if(MyBooleanParse(Request.Form["ispaid"].ToString()))//pay
        {
            //------check account is DR or CR
            string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
            string isDr = "+";
            string isDr2 = "-";
            if(expenseType == accountTradeCreditors){
                isDr = "+";
            }
            if(isDebitAccountType(expenseType)){
                isDr = "-";
            }
            if(isDebitAccountType(m_fromAccount)){
                    isDr2 = "+";
             }
            isPaid = true;
            if(isNAL){
                sc += " UPDATE account SET balance = balance - "+ dTotal + " WHERE id=" + m_fromAccount; 
                sc += " UPDATE card SET  balance = balance - " + dTotal + " WHERE id = " + m_customerID;
                AddCreditToCustomer(dTotal, 1, m_customerID,  dTotal);
                //sc += " UPDATE account SET balance = balance - "+ dTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + accountTradeCreditors;
                    sc += " /*1636 A-N 1-3*/ UPDATE account SET balance = balance + " + (dTotal - dTax) + " WHERE id = " + expenseType;
                    sc += " /*1638 A-N 2-3*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc; 
            }else {
                if(dTotal == 0){
                    sc += "/*1632 A-N 1-2*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;     
                    sc += " /*1633 A-N 2-2*/ UPDATE account SET balance = balance  "+isDr2+" " + dTax + " WHERE id = " + m_fromAccount;
                    //sc += "/*1634 A-N 3-3*/ UPDATE account SET balance = balance - " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                    //dSubTax = dSubTax - dTax;
                }else{
                    sc += " /*1636 A-N 1-3*/ UPDATE account SET balance = balance "+isDr+" " + (dTotal - dTax) + " WHERE id = " + expenseType;
                    sc += " /*1638 A-N 2-3*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;     
                    sc += " /*1639 A-N 2-3*/ UPDATE account SET balance = balance  "+isDr2+" " + dTotal + " WHERE id = " + m_fromAccount;
                    //sc += "/*1638 A-N 3-3*/ UPDATE account SET balance = balance - " + dTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                }
            }
            
            

        }else{ //save
            //------check account is DR or CR
            string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
            string isDr = "+";
            if(expenseType == accountTradeCreditors){
                isDr = "+";
            }
            if(isDebitAccountType(expenseType)){
                isDr = "-";
            }

            if(isNAL){
                sc += " UPDATE account SET balance = balance + " + (dTotal) + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                sc += " UPDATE account SET balance = balance + " + (dTotal  - dTax) + " WHERE id = " + expenseType;
                sc += " UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
            }else{
                if(dTotal == 0){
                    sc += "/*1651 A-N 1-2*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;        
                    sc += "/*1652 A-N 2-2*/ UPDATE account SET balance = balance + " + (dTax) + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                    dSubTax = dSubTax - dTax;
                }else{
                    sc += " /*1655 A-N 1-3*/ UPDATE account SET balance = balance "+isDr+" " + (dTotal - dTax) + " WHERE id = " + expenseType;
                    sc += " /*1656 A-N 2-3*/ UPDATE account SET balance = balance + " + dTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                    sc += " /*1657 A-N 3-3*/ UPDATE account SET balance = balance + " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc; 
                }   
            }
            
        }
	}

	sc += " UPDATE expense SET ";
	sc += " card_id = " + m_customerID;
	sc += ", from_account = " + m_fromAccount;
	//sc += ", to_account = " + m_toAccount;
	sc += ", payment_type = " + m_paymentType;

    //payment_date = Request.Form["payment_date"];

    sc += ", payment_date = '" + payment_date + "' ";
	sc += ", payment_ref = '" + m_paymentRef + "' ";
	sc += ", note = '" + EncodeQuote(m_note) + "' ";
	sc += ", last_edit_by = " + Session["card_id"];
	sc += ", last_edit_time = GETDATE() ";
	sc += ", tax = " + dFinalTax;
        
    if(MyBooleanParse(Request.Form["ispaid"].ToString())){
        sc += ", total = " + dSubTotal;
    }
	
	sc += ", ispaid = "+ Request.Form["ispaid"] +" ";
//	sc += ", ispaid = "+ m_bIsPaid +" ";
	sc += " WHERE id = " + m_id;
    
	//if(MyBooleanParse(old_type) && MyBooleanParse(Request.Form["ispaid"].ToString()))
    
    if(MyBooleanParse(Request.Form["ispaid"].ToString()))//paid
	{
            string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
            string isDr = "-";
            if(m_fromAccount == accountTradeCreditors){
                isDr = "-";
            }
            if(isDebitAccountType(m_fromAccount)){
                isDr = "+";
            }
	        //sc += " /*1705*/ UPDATE account SET balance = balance "+isDr+" " + dSubTotal + " WHERE id = " + m_fromAccount;
	        //--delete old tax
           // sc += " /*1709*/ UPDATE account SET balance = balance - " + dOldTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
            //--delete old trade creditors account
            //sc += " /*1711*/ UPDATE account SET balance = balance - " + dOldTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ accountTradeCreditors +"";	
            //--add new tax
            //sc += " /*1713*/ UPDATE account SET balance = balance + " + dSubTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
       
        }
        else //save
        {
                    string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
                    string isDr = "-";
                    if(m_fromAccount == accountTradeCreditors){
                        isDr = "-";
                    }
                    if(isDebitAccountType(m_fromAccount)){
                        isDr = "+";
                    }
                    //DEBUG("dOldTotal=" , dOldTotal);
                    //DEBUG("subtotal=" , dSubTotal);
                    //return false;

                    //delete old 
                    //--delete old tax
                    //sc += " /*1732*/ UPDATE account SET balance = balance - " + dOldTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
                    //--delete old trade creditors account
                    //sc += " /*1734*/ UPDATE account SET balance = balance - " + dOldTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ accountTradeCreditors +"";
                    //add new
                    //--add new tax
                    //sc += " /*1735*/ UPDATE account SET balance = balance + " + dSubTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ sGSTAcc +"";
                    //--add new total
                    //sc += " /*1739*/ UPDATE account SET balance = balance + " + dSubTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = "+ accountTradeCreditors +"";
        
         }
    //if(!MyBooleanParse(old_type) && MyBooleanParse(Request.Form["ispaid"].ToString()))
    //{
    //    sc += " UPDATE account SET balance = balance - " + dSubTotal + " WHERE id = " + m_fromAccount;
    //}
	sc += " COMMIT ";


//DEBUG("old_type =", old_type);
//DEBUG("1762 : s c= ", sc);
//return false;


	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return false;
	}
	
	EmptyExpenseTable();

	CheckAutoPaymentChanges();
	return true;
}

bool DoDeletePaidRecord()
{

	string sc = " SELECT * FROM expense WHERE id = " + m_id;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dst, "old") != 1)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Original record not found, cannot update</h3>");
			Response.Write("<br><br><br><br><br><br>");
			PrintAdminFooter();
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	DataRow dr = dst.Tables["old"].Rows[0];
	string old_from = dr["from_account"].ToString();
	string old_to = dr["to_account"].ToString();
	string old_type = dr["ispaid"].ToString();
	double dOldTotal = getOldTotalById(m_id);
	double dOldTax = MyDoubleParse(dr["tax"].ToString());

	//do update first
	string payment_date = Request.Form["payment_date"];

	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	DateTime tPayment;
	string msg = "";
	try
	{
		tPayment = DateTime.Parse(payment_date, format, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
	}
	catch(Exception e)
	{
		msg = "Payment Date. Input string <font color=red>" + payment_date + "</font> was not in a correct format";
	}
	if(msg != "")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><br><center><h3>Error, " + msg + "</h3>");
		Response.Write("<br><br><br><br><br><br><br>");
		PrintAdminFooter();
		return false;
	}

	CheckExpenseTable();

    
	//record items
	sc = " BEGIN TRANSACTION DELETE FROM expense_item WHERE id = " + m_id;
	sc += " SET DATEFORMAT dmy ";
    
    sc += doDeletePaidTotalForEachAccById(m_id);    
    sc += " DELETE FROM expense WHERE id = " + m_id;
	sc += " COMMIT ";



	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return false;
	}
	
	EmptyExpenseTable();

	CheckAutoPaymentChanges();
	return true;
}


bool GetAutoPaymentInfo()
{
	if(m_id == "")
		return true;

	if(dst.Tables["ap"] != null)
		dst.Tables["ap"].Clear();

	string sc = " SELECT * FROM auto_expense WHERE id = " + m_id;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dst, "ap") <= 0)
		{
			return true;
		}
		else
		{
			m_sAutoFrequency = dst.Tables["ap"].Rows[0]["frequency"].ToString();
			m_sNextAutoDate = DateTime.Parse(dst.Tables["ap"].Rows[0]["next_payment_date"].ToString()).ToString("dd-MM-yyyy");
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool CheckAutoPaymentChanges()
{
	GetAutoPaymentInfo();

	string newFrequency = Request.Form["autopayment_frequency"];
	string next_date = Request.Form["next_payment_date"];
	if(newFrequency == m_sAutoFrequency && next_date == m_sNextAutoDate)
		return true;

	string sc = "BEGIN TRANSACTION SET DATEFORMAT dmy ";
	if(next_date == m_sNextAutoDate) //frequency changed
	{
		if(newFrequency == "0") //remove
			sc += " DELETE FROM auto_expense WHERE id = " + m_id;
		else if(m_sAutoFrequency == "0") //add
		{
			if(next_date == "")
				next_date = GalcNextPaymentDate(newFrequency);//DateTime.UtcNow.AddHours(12).AddDays(7).ToString("dd-MM-yyyy");
			sc += " INSERT INTO auto_expense (id, frequency, next_payment_date) VALUES (" + m_id + ", " + newFrequency + ", '" + next_date + "') ";
		}
		else //update
			sc += " UPDATE auto_expense SET frequency = " + newFrequency + " WHERE id = " + m_id;
	}
	else //date changed
	{
		if(next_date == "")
			next_date = GalcNextPaymentDate(newFrequency);
		if(newFrequency != m_sAutoFrequency) //frequency changed too
		{
			if(newFrequency == "0")
				sc += " DELETE FROM auto_expense WHERE id = " + m_id;
			else if(m_sAutoFrequency == "0") //add
				sc += " INSERT INTO auto_expense (id, frequency, next_payment_date) VALUES (" + m_id + ", " + newFrequency + ", '" + next_date + "') ";
			else
				sc += " UPDATE auto_expense SET frequency = " + newFrequency + ", next_payment_date='" + next_date + "' WHERE id = " + m_id;
		}
		else
		{
			sc += " UPDATE auto_expense SET next_payment_date='" + next_date + "' WHERE id = " + m_id;
		}
	}
	sc += " COMMIT ";
//DEBUG("sc=", sc);
//Response.End();
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string GalcNextPaymentDate(string frequency)
{
	DateTime d = DateTime.UtcNow.AddHours(12);
	int nf = MyIntParse(frequency);
	switch(nf)
	{
	case 1:
		d = d.AddDays(7);
		break;
	case 2:
		d = d.AddDays(14);
		break;
	case 3:
		d = d.AddDays(28);
		break;
	case 4:
		d = d.AddMonths(1);
		break;
	case 5:
		d = d.AddMonths(2);
		break;
	case 6:
		d = d.AddDays(84); //12 weeks
		break;
	case 7:
		d = d.AddMonths(3);
		break;
	case 8:
		d = d.AddMonths(6);
		break;
	case 9:
		d = d.AddYears(1);
		break;
	default:
		break;
	}
	return d.ToString("dd-MM-yyyy");
}


bool isDebitAccountType(string expenseType){
    int rows = 0;
    string sc = "SELECT * ";
	sc += " FROM account ";
	sc += " WHERE id=" + expenseType;

    bool debitAccount = false;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
        dst = new DataSet();
		rows = myAdapter.Fill(dst, "toaccountById");
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return debitAccount;
	}

    for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccountById"].Rows[i];
        string isdebit_acc = dr["isdebit_acc"].ToString();
        if(isdebit_acc == "False"){
            debitAccount = true;
            break;
        }
    }
    return debitAccount;
}

bool isNALAccount(string fromAccount, string nalAccount){
    int rows = 0;
    string sc = "SELECT * ";
	sc += " FROM account ";
	sc += " WHERE id=" + fromAccount;

    bool a = false;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
        dst = new DataSet();
		rows = myAdapter.Fill(dst, "toaccountById");
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return a;
	}

    for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccountById"].Rows[i];
        string class1 = dr["class1"].ToString();
        string class2 = dr["class2"].ToString();
        string class3 = dr["class3"].ToString();
        string class4 = dr["class4"].ToString();
        string c = class1 + class2 + class3 + class4;
        if(c == nalAccount){
            a = true;
            break;
        }
    }
    return a;
}


string getexpenseTypeNameById(string expenseType){
    int rows = 0;
    string sc = "SELECT * ";
	sc += " FROM account ";
	sc += " WHERE id=" + expenseType;

    string expenseName = "";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
        dst = new DataSet();
		rows = myAdapter.Fill(dst, "toaccountById");
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return expenseName;
	}

    for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["toaccountById"].Rows[i];
        expenseName += dr["class1"].ToString();
        expenseName += dr["class2"].ToString();
        expenseName += dr["class3"].ToString();
        expenseName += dr["class4"].ToString();

        expenseName += " - ";

        expenseName += dr["name1"].ToString();
        expenseName += " - ";
        expenseName += dr["name4"].ToString();
     }

     return expenseName;
    }


string doAutoFillAmountJSF(){
    string js = "";
    
    js += "<script type='text/javascript'>";
    js += "$('#amountText').keyup(function () {";
    js += "var $total = 0;";
    js += "var $amount = 0;";
    js += "var var_name = $('#tax').attr('checked') ? 1 : 0;";
    js += "if (!isNaN($('#amountText').val())) {";
    js += " if (var_name == 1) {";
    js += "$total = $('#amountText').val() * 1.15;";
    js += " } else if (var_name == 0) {";
    js += "$total = $('#amountText').val();";
    js += "}";
    js += " $('#totalText').val($total);";
    js += " } else {";
    js += "$('#amountText').val('');";
    js += " $('#totalText').val('');";
    js += "}";
    js += "});";
    js += "$('#totalText').keyup(function () {";
    js += " var $total = 0;";
    js += "var $amount = 0;";
    js += "var var_name = $('#tax').attr('checked') ? 1 : 0;";
    js += " if (!isNaN($('#totalText').val())) {";
    js += " if (var_name == 1) {";
    js += "$amount = $('#totalText').val() * 0.86956;";
    js += "} else if (var_name == 0) {";
    js += "$amount = $('#totalText').val();";
    js += "}";
    js += "$('#amountText').val($amount);";
    js += "} else {";
    js += "$('#totalText').val('');";
    js += "$('#amountText').val('');";
    js += "}";
    js += "});";
    js += "$('#tax').click(function () {";
    js += " var var_name = $('#tax').attr('checked') ? 1 : 0;";
    js += "var $total = 0;";
    js += "var $amount = 0;";
    js += "if (var_name == 1) {";
    js += "$total = $('#amountText').val() * 1.15;";
    js += "$('#totalText').val($total);";
    js += "} else if (var_name == 0) {";
    js += "$('#totalText').val($('#amountText').val());";
    js += "}";
    js += " });";
    js += " </"   +   "script>";
    

    return js;
}


string doCheckExpenseTypeJSF(){
    string js = "";

    js += "<script type='text/javascript'>";
    js += "function expenseTypeChange() {";
    js += "     var $total = 0;";
    js += "     var $amount = 0;";
    js += "     var expenseType = $('#expenseType').find(\"option:selected\").text();";
    js += "     var $str1 = 'LIABILITIES';";
    js += "     if(expenseType.indexOf($str1) > 0 ){";
    js += "         if (!isNaN($('#amountText').val())) {";
    js += "           $total = $('#amountText').val();";
    js += "           $('#totalText').val($total);";
    js += "           $('#tax').attr('checked',false);";
    js += "           $('#tax').attr('disabled',true);";
    js += "          } ";
    js += "     } else {";
    js += "       $('#tax').attr('checked',true);";
    js += "       $total = $('#amountText').val() * 1.15;";
    js += "       $('#totalText').val($total);";
    js += "       $('#tax').attr('disabled',false);";
    js += "     };";
    js += "};";
    js += " </"   +   "script>";

    return js;

}    


double getOldTotalById(string id){
    double oldTotal = 0;
    int rows = 0;
    string sc = "";
    sc += "SELECT SUM(total) AS item_totals ";
    sc += " FROM expense_item ";
    sc += " WHERE id = " + id;

    try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
        dst = new DataSet();
		rows = myAdapter.Fill(dst, "getOldTotalById");
        oldTotal = MyDoubleParse(dst.Tables["getOldTotalById"].Rows[0]["item_totals"].ToString());
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
		return 0;
	}

    return oldTotal;

}

double newDOldTax = 0;
string doDeleteOldTotalForEachAccById(string id , double dOldTax){
    int rows = 0;
    DataSet theDataSet = new DataSet();
    string sc = "";
    sc += "SELECT * ";
    sc += " FROM expense_item ";
    sc += " WHERE id = " + id;
    try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(theDataSet, "tt");
        if(rows <= 0){
            return "/*--E--*/";
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "/*--E--*/";
	}      

    try
	{
        sc = "  ";
        for(int i=0; i<rows; i++)
	    {
		    DataRow dr = theDataSet.Tables["tt"].Rows[i];
            double dTotal = MyDoubleParse(dr["total"].ToString());
            double dTax = MyDoubleParse(dr["tax"].ToString());
            string expenseType = dr["to_account"].ToString();
            string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
            string sGSTAcc = GetSiteSettings("account_gst_paid", "2312", true);
            string isDr = "-";
            if(expenseType == accountTradeCreditors){
                isDr = "-";
            }
            if(isDebitAccountType(expenseType)){
                isDr = "+";
            }
            if(dTotal == 0){
                        string scc = "";
                        scc += "SELECT * ";
                        scc += " FROM expense ";
                        scc += " WHERE id = " + id;

                        myAdapter = new SqlDataAdapter(scc, myConnection);
		                int rows2 = myAdapter.Fill(theDataSet, "a");
                        if(rows2 <= 0){
                            return "/*--E--*/";
                        }
                        //get from account
                        DataRow drr = theDataSet.Tables["a"].Rows[0];
                        string fromAccount = drr["from_account"].ToString();
                         
                        //sc += " /*2056*/ UPDATE account SET balance = balance "+isDr+" " + (dTax) + " WHERE id = " + fromAccount;
                        sc += " /*2204 D-O 1-2*/ UPDATE account SET balance = balance - " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                        sc += " /*2205 D-O 2-2*/ UPDATE account SET balance = balance - " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                        newDOldTax = dOldTax - dTax;
            }else{
                        sc += " /*2219 D-O 1-3*/ UPDATE account SET balance = balance "+isDr+" " + (dTotal - dTax) + " WHERE id = " + expenseType;
                        sc += " /*2220 D-O 2-3*/ UPDATE account SET balance = balance - " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + sGSTAcc;
                        sc += " /*2221 D-O 3-3*/ UPDATE account SET balance = balance - " + dTotal + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 = " + accountTradeCreditors;
                        
            }
            
         }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "/*--E--*/";
	}

    return sc;
}



 string doDeletePaidTotalForEachAccById(string id){
    int rows = 0;
    DataSet theDataSet = new DataSet();
    string sc = "";
    sc += "SELECT * ";
    sc += " FROM expense_item ";
    sc += " WHERE id = " + id;
    try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(theDataSet, "tt");
        if(rows <= 0){
            return "";
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

    try
	{
        sc = "  ";
        for(int i=0; i<rows; i++)
	    {
		    DataRow dr = theDataSet.Tables["tt"].Rows[i];
            double dTotal = MyDoubleParse(dr["total"].ToString());
            double dTax = MyDoubleParse(dr["tax"].ToString());
            string expenseType = dr["to_account"].ToString();
            string accountTradeCreditors = GetSiteSettings("account_trade_creditors", "2111", true);
            string gstAccount = GetSiteSettings("account_gst_paid","2312",true);
            string isDr = "-";
            string isDr2 = "+";
            string fromAccount = getFromAccount(id);
            if(isDebitAccountType(expenseType)){
                isDr = "+";
            }
            if(isDebitAccountType(fromAccount)){
                isDr2 = "-";
            }

            sc += " /*2278*/  UPDATE account SET balance = balance - " + dTax + " WHERE (class1*1000) + (class2*100) + (class3*10) + class4 =" + gstAccount;
            if(dTotal != 0){
                sc += " /*2279*/ UPDATE account SET balance = balance "+isDr+" " + (dTotal - dTax) + " WHERE id = " + expenseType;
            }
            
            if(dTotal == 0){
                sc += " /*2282*/ UPDATE account SET balance = balance "+isDr2+" " + (dTax) + " WHERE id = " + fromAccount;
            }else{
                sc += " /*2280*/ UPDATE account SET balance = balance "+isDr2+" " + (dTotal) + " WHERE id = " + fromAccount;
            }
         }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

    return sc;
}

string getFromAccount(string id){
    int rows = 0;
    string fromAcc = "";
    DataSet theDataSet = new DataSet();
    string sc = "";
    sc += "SELECT * ";
    sc += " FROM expense ";
    sc += " WHERE id = " + id;
    try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(theDataSet, "ttt");
        if(rows <= 0){
            return "";
        }
       for(int i=0; i<rows; i++)
	    {
		    DataRow dr = theDataSet.Tables["ttt"].Rows[i];
             fromAcc = dr["from_account"].ToString();
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
    return fromAcc;
}



//======================================do direct save
bool DirectSave(){
    bool result = false;
    //======================================get data
    
    //======================================insert expense to expense table
    
    //======================================insert  expense item to expense_item table

    //======================================update Trade Creditors account 2111

    //======================================update GST account 2312

   //======================================update each to account

    return result;
}
//======================================do direct pay
bool DirectPay(){
    bool result = false;
    //======================================get data

    //======================================insert expense to expense table    

    //======================================insert  expense item to expense_item table

    //======================================update from account

    //======================================update GST account 2312

   //======================================update each to account

    return result;
}

//do second save
bool SecondSave(){
    bool result = false;
    //get old data
    
    //delete expense item 

    //delete expense

    //rest Trade Creditors account 2111

    //rest GST account 2312

    //get new data

    

    return result;
}
//do secound pay
bool SecondPay(){
    bool result = false;
    //

    return result;
}

void AddCreditToCustomer(double amount, int shop_branch, string card_id,  double credit){
    	//do transaction
	SqlCommand myCommand = new SqlCommand("eznz_payment", myConnection);
	myCommand.CommandType = CommandType.StoredProcedure;
	
	myCommand.Parameters.Add("@Amount", SqlDbType.Money).Value = amount;
	//myCommand.Parameters.Add("@paid_by", SqlDbType.VarChar).Value = "";
	//myCommand.Parameters.Add("@bank", SqlDbType.VarChar).Value = "";
	//myCommand.Parameters.Add("@branch", SqlDbType.VarChar).Value = "";
	//myCommand.Parameters.Add("@nDest", SqlDbType.Int).Value = "";
	myCommand.Parameters.Add("@amount_for_card_balance", SqlDbType.Money).Value = 0;
	myCommand.Parameters.Add("@shop_branch", SqlDbType.Int).Value = shop_branch;
	myCommand.Parameters.Add("@staff_id", SqlDbType.Int).Value = Session["card_id"].ToString();
	myCommand.Parameters.Add("@card_id", SqlDbType.Int).Value = card_id;
	myCommand.Parameters.Add("@payment_method", SqlDbType.Int).Value = 7;
	//myCommand.Parameters.Add("@invoice_number", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@payment_ref", SqlDbType.VarChar).Value = "Pay Expense";
	myCommand.Parameters.Add("@note", SqlDbType.VarChar).Value = "Pay Expense";
	myCommand.Parameters.Add("@finance", SqlDbType.Money).Value = 0;
	myCommand.Parameters.Add("@credit", SqlDbType.Money).Value = credit;
	myCommand.Parameters.Add("@bRefund", SqlDbType.Bit).Value = 0;
	//myCommand.Parameters.Add("@amountList", SqlDbType.VarChar).Value = "";
	myCommand.Parameters.Add("@return_tran_id", SqlDbType.Int).Direction = ParameterDirection.Output;
	try
	{
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp("DoCustomerPayment", e);
		//return false;
	}
}
</script>
