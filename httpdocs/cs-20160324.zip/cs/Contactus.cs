﻿<script runat=server>
protected void Page_Load(Object Src, EventArgs E ) 
{
        TS_PageLoad(); //do common things, LogVisit etc...
        PrintHeaderAndMenu("");
        string value = ReadSitePage("contact.html");
        Response.Write(value);
        PrintFooter();
}

</script>