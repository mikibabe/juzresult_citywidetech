<!-- #include file="kit_fun.cs" -->
<!-- #include file="sales_function.cs" -->
<!-- #include file="credit_limit.cs" -->


<script runat=server>
//Update 2011-04-15
/*
 * By LY
 *line 1436 
 *add function 
 *if not administrator login 
 *the other user can not change price.
 */


DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
const int m_cols = 8;	//how many columns main table has, used to write colspan=
string m_tableTitle = "";
string m_invoiceNumber = "";
string m_comment = "";	//Sales Comment in Invoice Table;
string m_custpo = "";
string m_salesNote = "";
string m_branchID = "1";
string m_sSalesType = ""; //as string, m_quoteType is receipt_type ID
string m_nShippingMethod = "1";
string m_specialShipto = "0";
string m_specialShiptoAddr = ""; //special
string m_pickupTime = "";
string m_sCurrencyName="NZD";
string m_orderStatus = "1"; //Being Processed
string m_isbuild = "0";

double m_dFreight = 0;
int m_nSearchReturn = 0;

bool b_create = false;
bool m_bCreditReturn = false;
bool m_bOrderCreated = false;
bool m_bCreditTermsOK = true;
bool m_bCreditLimitOK = true;
bool m_bNoIndividualPrice = false;
bool m_bUseOrderInterface = false;
bool m_bIsForSystemBuild = false;
void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("editor"))
		return;

	//sales session control
	if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
	{
		m_ssid = Request.QueryString["ssid"];
		if(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid] == null){
            PrepareNewSales();
        }
			
	}
	else
	{
		m_ssid = DateTime.UtcNow.AddHours(12).ToOADate().ToString(); //assign new Sales Session ID for this sales
		PrepareNewSales();
		string par = "?ssid=" + m_ssid;
		if(Request.QueryString.Count > 0)
			par = "?" + Request.ServerVariables["QUERY_STRING"] + "&ssid=" + m_ssid;
		Response.Redirect("pos.aspx" + par);
		return;
	}
	m_bIsForSystemBuild = MyBooleanParse(GetSiteSettings("allow_orders_as_system_build", "0", true));

	if(Request.QueryString["q"] == m_ssid)
		Session["use_order_interface"] = "true";
	if(Request.QueryString["p"] == "new")
		Session["use_order_interface"] = null;
	else if(Session["use_order_interface"] != null )
	{
		if(Session["use_order_interface"].ToString() == "true")
			m_bUseOrderInterface = true;
	}
	
	m_sCurrencyName=GetSiteSettings("default_currency_name", "NZD");

	m_dGstRate = MyDoubleParse(GetSiteSettings("gst_rate_percent", "10")) / 100;						//26.06.2003 NEO	

	if(Request.QueryString["t"] == "created")
	{
		m_orderID = Request.QueryString["id"];
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>" + m_sSalesType.ToUpper() + " Created</h3>");
		Response.Write("<h3>Number : </h3><h1><font class=blueFont2>" + m_orderID + "</h1><br>");
		Response.Write("<input type=button " );
		Response.Write("onclick=window.open('invoice.aspx?t=order&id=" + m_orderID + "') ");
		Response.Write(" value=' Print ' class=printInvoiceButton title='Print invoice'><br><br><br>");

		Response.Write("<input type=button " );
		Response.Write("onclick=window.location=('eorder.aspx?id=" + m_orderID + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') ");
		Response.Write(" value='Process' class=processButton title='Process'>");
		Response.Write("<br><br><br><br><br>");
		PrintSearchForm();
		LFooter.Text = m_sAdminFooter;
		return;
	}	
	else if(Request.QueryString["p"] == "new")
	{
		if(!PrepareNewSales())
			return;
		if(Request.QueryString["ft"] != null)
			m_sSalesType = Request.QueryString["ft"];
		if(m_sSalesType != null && m_sSalesType != "")
		{
			m_quoteType = GetEnumID("receipt_type", m_sSalesType);
			if(m_quoteType == "")
			{
				MsgDie("Error, sales type error, type <font color=red>" + m_sSalesType + "</font> not found, check your menu link");
			}
		}

		if(Request.QueryString["ft"] == "s")
			m_quoteType = "3";	//"3", indicating "invoice"
		else
		{
			if(Request.QueryString["ft"] == "o")
				m_quoteType = "2";	//"2", indicating "Order"
			else
			{
				if(Request.QueryString["ft"] == "q")
					m_quoteType = "1";	//"1", indicating "quote"
			}
		}
		Session["SalesType" + m_ssid] = m_quoteType;
        //DEBUG("460m_custpo=", m_custpo);
        if(String.IsNullOrEmpty(m_custpo)){
            m_custpo = Request.QueryString["po"];
        }
	}

	m_bOrder = true;
	Session[m_sCompanyName + "_ordering"] = true;
	Session[m_sCompanyName + "_salestype"] = "sales";

	//Print SN in invoice Options
	if(Request.QueryString["psn"] == "y")
		Session["print_sn" + m_ssid] = "true";
	else if(Request.QueryString["psn"] == "n")
		Session["print_sn" + m_ssid] = null;
	if(Session["print_sn" + m_ssid] != null)
		m_bPrintSN = true;						

	m_bSales = true; //switch in cart.cs
	string s_url = Request.ServerVariables["URL"];// + "?" + Request.ServerVariables["QUERY_STRING"];
	if(Request.QueryString["ssid"] == null)
		s_url += "?ssid=" + m_ssid;
	else if(Request.ServerVariables["QUERY_STRING"] != null && Request.ServerVariables["QUERY_STRING"] != "")
		s_url += "?" + Request.ServerVariables["QUERY_STRING"];

	m_sales = Session["card_id"].ToString(); //default

	//remember everything entered in Session Object
	if(Request.Form["branch"] != null)
		UpdateAllFields();

	RestoreAllFields();

	//customer account search
	if(Request.Form["branch"] != null && Request.Form["ckw"] != m_customerID)
	{
		DoCustomerSearchAndList();
		return;
	}
	
	//item search
	if(Request.Form["item_code_search"] != null && Request.Form["item_code_search"] != "")
	{

		Session["sales_customer_po_number" + m_ssid] = m_custpo;
		Session["sales_note" + m_ssid] = m_salesNote;

//******************* Code for serial search ************************************
		string s_SearchMsg = "";	
		s_SearchMsg = DoSerialSearch(Request.Form["item_code_search"]);
//*******************************************************************************

//		string s_SearchMsg = "notfound";
		if(s_SearchMsg == "found")
		{
			//found product by serial;
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=" + s_url + "\">");	
			return;
		}
		else if(s_SearchMsg == "notfound")
		{	
			bool bInteger = false;
			try
			{
				int.Parse(Request.Form["item_code_search"]);
				bInteger = true;
			}
			catch(Exception ei)
			{
				//ignore, not integer
			}

			if(bInteger)
			{
				//true - means find exactly, false - mean find similar;
				if(!DoSearchItem(Request.Form["item_code_search"], true))
				{
					//if(!DoSearchItem(Request.Form["item_code_search"], false))	
//DEBUG("m_nSearchReturn=", m_nSearchReturn);
					return;
				}
				if(m_nSearchReturn <= 0)
				{
					if(!DoSearchItem(Request.Form["item_code_search"], false))	
						return;
					
					if(m_nSearchReturn <=0 )
					{
						//PrintAdminHeader();
						//PrintAdminMenu();
						//Response.Write("<br><br><center><h3>No Item's code matches <b>" + Request.Form["supplier_code_search"] + "</b></h3>");
						//Response.Write("<input type=button  class=backButton2 title='Back'  value=Back onclick=window.location=('pos.aspx?ssid=" + m_ssid + "')>");
						//return;
                        
                        DoMPNSearch(Request.Form["item_code_search"]);
				        if(m_nSearchReturn <= 0)
				        {
					        PrintAdminHeader();
					        PrintAdminMenu();
					        Response.Write("<br><br><center><b>Search Result of  <font size=+1 color=red>" + Request.Form["item_code_search"] + "</b></font>");
					        Response.Write("<br><br><b>as S/N : Not Found!<br><br></b>");
					        Response.Write("<b>as product code : Not Found --- Not Valid Product Code!</b><br>");
					        Response.Write("<b>as supplier code : Not Found --- Not Valid Product Code!</b>");
					        Response.Write("<br><br><b><a href='pos.aspx?ssid="+m_ssid+"' class='linkButton'>Back</a></b>");
				        }
				        return;
                    

					}

					PrintSearchForm();
					LFooter.Text = m_sAdminFooter;
					return;
				}
			}
			else
			{
				DoMPNSearch(Request.Form["item_code_search"]);
				if(m_nSearchReturn <= 0)
				{
					PrintAdminHeader();
					PrintAdminMenu();
					Response.Write("<br><br><center><b>Search Result of  <font size=+1 color=red>" + Request.Form["item_code_search"] + "</b></font>");
					Response.Write("<br><br><b>as S/N : Not Found!<br><br></b>");
					Response.Write("<b>as product code : Not Found --- Not Valid Product Code!</b><br>");
					Response.Write("<b>as supplier code : Not Found --- Not Valid Product Code!</b>");
					Response.Write("<br><br><b><a href='pos.aspx?ssid="+m_ssid+"' class='linkButton'>Back</a></b>");
				}
				return;
			}
		}
		else
		{
			Response.Write("<br><br><h3><b><font size=+1>Error:<font><br><br><br>" +s_SearchMsg+ "</b></h3>");
			return;
		}

		//only one matches, add to cart, refresh sales
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=" + s_url + "\">");	
		return;
	}	

	if(Request.QueryString["a"] == "add")
	{
		string code = Request.QueryString["code"];
		double dSalesPrice = GetSalesPriceForDealer(code, "1", Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString(), m_customerID);
		AddToCart(code, Request.QueryString["supplier"], Request.QueryString["supplier_code"], "1", Request.QueryString["pri"], dSalesPrice.ToString(), "", "");
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=pos.aspx?ssid=" + m_ssid + "\">");
		return;
	}

	if(m_sSalesType == "" && m_quoteType != "")
		m_sSalesType = GetEnumValue("receipt_type", m_quoteType);

	if(Request.QueryString["t"] == "del")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		bool bKeyOK = true;
		if(Session["delete_order_key" + m_ssid] == null)
			bKeyOK = false;
		else if(Session["delete_order_key" + m_ssid].ToString() != Request.QueryString["r"])
			bKeyOK = false;

		if(!bKeyOK)
		{
			Response.Write("<br><br><center><h3>Please follow the proper link to delete order.</h3>");
		}
		else
		{
			m_orderID = Request.QueryString["id"];
			if(m_orderID == null || m_orderID == "")
			{
				Response.Write("<br><br><center><h3>Bad order number.</h3>");
			}
			else if(DoDeleteOrder())
			{
				Session["delete_order_key" + m_ssid] = null;
				Response.Write("<br><br><center><h3>Order Deleted.</h3>");
				Response.Write("<input type=button  "+ Session["button_style"] +"  onclick=window.location=('");
				Response.Write("olist.aspx?t=1&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value='Back to Order List'></center>");
			}
			else
			{
				Response.Write("<br><br><h3>Error Deleting Order");
			}
		}
		LFooter.Text = m_sFooter;
		return;
	}
	else if(Request.QueryString["t"] == "vpq")
	{
		m_bOrder = false;
		Response.Write(BuildQInvoice("", m_quoteType, true, false, m_custpo, m_salesNote));//no email msg, inocie only, no system
		m_bOrder = true;
		return;
	}	

	bool bJustRestored = false;
	
	if(m_orderID != "")
		m_bOrderCreated = true;

	CheckShoppingCart();
	CheckUserTable();	//get user details if logged on

	//get old invoice
	if(Request.QueryString["id"] != null && Request.QueryString["id"] != "")
	{
		m_orderID = Request.QueryString["id"];
        
		if(!IsInteger(m_orderID))
		{
			Response.Write("<h3>ERROR, WRONG NUMBER</h3>");
			return;
		}
        Session["brach_id" + m_ssid] = Request.QueryString["_b"];
		if(!RestoreOrder())
			return;

		m_bOrderCreated = true;
		m_quoteType = GetEnumID("receipt_type", "order");

		Session["order_created" + m_ssid] = true;
		Session["SalesType" + m_ssid] = m_quoteType;
		Session["EditingOrder" + m_ssid] = true;
		Session["sales_current_order_number" + m_ssid] = m_orderNumber;
		Session["sales_current_order_id" + m_ssid] = m_orderID;
	}
	else if(Request.QueryString["ci"] != null)
	{
        if(Request.QueryString["cii"] == "xxx"){
            m_customerID = Request.QueryString["ci"];
		    Session[m_sCompanyName + "_dealer_card_id" + m_ssid] = m_customerID;
		    GetCustomer();	
        }else{
            //clean up session for last uri
		    if(Session["last_uri_exp"] != null)
			    Session["last_uri_exp"] = null;

		    m_customerID = Request.QueryString["ci"];
		    Session[m_sCompanyName + "_dealer_card_id" + m_ssid] = m_customerID;
		    GetCustomer();	
		    Response.Write("<meta  http-equiv=\"refresh\" content=\"0; URL=pos.aspx?i=" + m_orderID + "&ssid=" + m_ssid);
		    Response.Write("\">");

		    return;
        } 
		
	}
	else if(Request.QueryString["search"] == "1")
	{
		DoCustomerSearchAndList();
		return;
	}
	else if(Request.Form["cmd"] == "SELECT")
	{
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=c.aspx?ssid=" + m_ssid + "\">");
		return;
	}
	else if(Request.Form["cmd"] == "Update Order")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		if(DoUpdateOrder())
		{
			Response.Write("<br><br><center><h3>Order Updated.</h3>");
			Response.Write("<input type=button  "+ Session["button_style"] +"  onclick=window.location=('");
			Response.Write("olist.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value='Back to Order List'></center>");
		}
		else
		{
			Response.Write("<br><br><h3>Error updating order");
		}
		PrintAdminFooter();
		return;
	}
	else if(Request.Form["cmd"] == "Delete Order")
	{
		PrintHeaderAndMenu("");
		string delkey = DateTime.UtcNow.AddHours(12).ToOADate().ToString();
		Session["delete_order_key" + m_ssid] = delkey;
		Response.Write("<script Language=javascript");
		Response.Write(">");
//		Response.Write(" rmsg = window.prompt('Are you sure you want to delete this order?')\r\n");
		Response.Write("if(window.confirm('Dear " + Session["name"]);
		Response.Write("\\r\\n\\r\\nAre you sure you want to delete this order?         ");
		Response.Write("\\r\\nThis action cannot be undone.\\r\\n");
		Response.Write("\\r\\nClick OK to delete order.\\r\\n");
		Response.Write("'))");
		Response.Write("window.location='pos.aspx?t=del&id=" + m_orderID + "&r=" + delkey + "&ssid=" + m_ssid + "';\r\n");
		Response.Write("else window.location='pos.aspx?id=" + m_orderID + "&r=" + delkey + "&ssid=" + m_ssid + "';\r\n");
		Response.Write("</script");
		Response.Write(">");
		return;
	}
	else if(Request.Form["cmd"] == "Cancel")
	{
		//unlock it
		if(m_orderID != "")
		{
			String sc = "UPDATE orders SET locked_by=null, time_locked=null WHERE id=" + m_orderID;
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return;
			}
		}
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=olist.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
		return;
	}
	else if(Request.Form["cmd"] == "Record")
	{
		dtCart = (DataTable)Session["ShoppingCart" + m_ssid];
		if(dtCart.Rows.Count <= 0)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error. Cannot create empty order");
			PrintAdminFooter();
			return;
		}
        
		m_custpo = Request.Form["custpo"];
		m_custpo = m_custpo.Replace("\"", "-");
		m_custpo = m_custpo.Replace("'", "-");
		m_salesNote = Request.Form["note"];
		
		Session["sales_customer_po_number" + m_ssid] = m_custpo;
		Session["sales_note" + m_ssid] = m_salesNote;
	
		b_create = true; //MyMoneyParse(Request.Form["totaldue"]) > 0;
		string limit_msg = "";
				bool bPutOnHold = false;
				string totaldue = Request.Form["totaldue"].ToString();
				if(totaldue != "")
				{
					totaldue = totaldue.Replace("$", "");
					totaldue = totaldue.Replace(",", "");
				}
		if(b_create)
		{
			if(!CheckBottomPrice())
				return;

			string term_msg = "";
			m_bCreditTermsOK = CreditTermsOK(m_customerID, ref term_msg);
			m_bCreditLimitOK = CreditLimitOK(m_customerID, MyDoubleParse(totaldue), ref bPutOnHold, ref limit_msg, false);
			if(!m_bOrderCreated)	//no double record for PageFresh(F5)
			{
				if(!DoCreateOrder(false, m_custpo, m_salesNote)) // false means not system quotation
				{
					Response.Write("<h3>ERROR CREATING QUOTE</h3>");
					return;
				}
				m_bOrderCreated = true;
				Session["order_created" + m_ssid] = true;
			}

			if(m_bCreditTermsOK && m_bCreditLimitOK)
			{
				Response.Write("<meta  http-equiv=\"refresh\" content=\"0; URL=pos.aspx?t=created&id=" + m_orderID + "&ssid=" + m_ssid + "\">");
			}
			else
			{
				PrintAdminHeader();
				PrintAdminMenu();
				Response.Write(term_msg);
				Response.Write(limit_msg);
				Response.Write("<br><center><input type=button onclick=window.location='pos.aspx?t=created&id=" + m_orderID + "&ssid=" + m_ssid + "'  class=continueButton  value=Continue>");
				PrintAdminFooter();
			}
			return;
		}
	}
	//else if(Request.Form["cmd"] == "Move To Quote")
	else if(Request.Form["cmd"] == "Back To Quote")
	{
		Response.Write("<script language=JavaScript");
		Response.Write(">");
		Response.Write("window.location=('q.aspx?ssid=" + m_ssid + "')");
		Response.Write("</script");
		Response.Write(">");
		return;
	}
	else if(Request.Form["cmd"] == "Change To Order")
	{
		if(DoChangeToOrder())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=pos.aspx?id=" + m_orderID + "&ssid=" + m_ssid + "\">");
		return;
	}
	else if(Request.Form["cmd"] == "Set" || (Request.Form["discount_total"] != null && Request.Form["discount_total"] != "") )
	{
		if(DoApplyDiscountTotal())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=pos.aspx?ssid=" + m_ssid + "\">");
		return;
	}

	if(m_orderNumber != "")
	{
		m_tableTitle = m_sSalesType.ToUpper() + " #<font color=red>" + m_orderNumber + "</font>";
		m_tableTitle += " - <font color=green>" + GetEnumValue("order_item_status", m_orderStatus) + "</font>";
	}
	else
		m_tableTitle = "NEW " + m_sSalesType.ToUpper();

	PrintAdminHeader();
	PrintAdminMenu();
	MyDrawTable();
	LFooter.Text = m_sAdminFooter;
}

bool RestoreCustomer()
{
	string status_invoiced = GetEnumID("order_item_status", "Invoiced");
	string status_shipped = GetEnumID("order_item_status", "Shipped");
	if(status_invoiced == "")
	{
		Response.Write("<br><br><center><h3>Error getting status ID 'Being Processed'");
		return false;
	}

	string sc = " SELECT branch, number, po_number, card_id, freight, shipping_method ";
	sc += ", special_shipto, shipto, pick_up_time, status ";
	sc += ", sales, sales_note, locked_by, time_locked, type, no_individual_price ";
	if(m_bIsForSystemBuild)
		sc += ", isbuild ";
	sc += " FROM orders ";
//	sc += " WHERE status<>" + status_invoiced + " AND status<>" + status_shipped;
	sc += " WHERE id=" + m_orderID;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "order") <= 0)
		{
			Response.Write("<br><br><center><h3>ERROR, Order Not Found</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	DataRow dr =  dst.Tables["order"].Rows[0];
	string locker = dr["locked_by"].ToString();
	Trim(ref locker);
	if(locker != "")
	{
		if(locker != Session["card_id"].ToString())
		{
			string lockname = TSGetUserNameByID(locker);
			string locktime = DateTime.Parse(dr["time_locked"].ToString()).ToString("dd-MM-yyyy HH:mm");
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3><font color=red>ORDER LOCKED</font></h3><br>");
			Response.Write("<h4>This order is locked by <font color=blue>" + lockname.ToUpper() + "</font> since " + locktime);
			PrintAdminFooter();
			return false;
		}
	}

	//lock it
	sc = " UPDATE orders SET locked_by=" + Session["card_id"].ToString();
	sc += ", time_locked=GETDATE() ";
	sc += " WHERE id="+ m_orderID + " ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	m_orderStatus = dr["status"].ToString();
	m_branchID = dr["branch"].ToString();
	m_orderNumber = dr["number"].ToString();
	m_customerID = dr["card_id"].ToString();
	m_customerName = TSGetUserCompanyByID(m_customerID);
	if(m_customerName == "")
		m_customerName = TSGetUserNameByID(m_customerID);
	m_custpo = dr["po_number"].ToString();

	m_dFreight = MyMoneyParse(dr["freight"].ToString());
	m_sales = dr["sales"].ToString();
	m_salesNote = dr["sales_note"].ToString();

	string sst = dr["special_shipto"].ToString();
	if(sst != "" && bool.Parse(sst))
		m_specialShipto = "1";
	m_specialShiptoAddr = dr["shipto"].ToString();
	m_nShippingMethod = dr["shipping_method"].ToString();
	m_pickupTime = dr["pick_up_time"].ToString();
	m_quoteType = dr["type"].ToString();
	m_sSalesType = GetEnumValue("receipt_type", m_quoteType);
	m_bNoIndividualPrice = MyBooleanParse(dr["no_individual_price"].ToString());
	if(m_bIsForSystemBuild)
		m_isbuild = dr["isbuild"].ToString();
	string nip = "0";
	if(m_bNoIndividualPrice)
		nip = "1";

	Session["SalesType" + m_ssid] = m_quoteType;
	Session["sales_freight" + m_ssid] = m_dFreight;
	Session["sales_customerid" + m_ssid] = m_customerID;
	Session["sales_shipping_method" + m_ssid] = m_nShippingMethod ;
	Session["sales_special_shipto" + m_ssid] = m_specialShipto;
	Session["sales_special_ship_to_addr" + m_ssid] = m_specialShiptoAddr;
	Session["sales_pick_up_time" + m_ssid] = m_pickupTime;
	Session["sales_no_individual_price" + m_ssid] = nip;

	dr = GetCardData(m_customerID);
	if(dr != null)
		Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid] = dr["dealer_level"].ToString();

	return true;
}

bool RestoreOrder()
{
	PrepareNewSales(); //empty session sales data 

	if(!RestoreCustomer())
		return false;

	int items = 0;
	string sc = "SELECT * FROM order_item WHERE id=" + m_orderID + " AND kit=0 ORDER BY kid ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		items = myAdapter.Fill(dst, "items");
//		if(items <= 0)
//		{
//			Response.Write("<br><br><center><h3>ERROR, no order item found</h3>");
//			return false;
//		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	int i = 0;
	for(i=0; i<items; i++)
	{
		DataRow dr = dst.Tables["items"].Rows[i];
		if(!AddToCart(dr["code"].ToString(), dr["supplier"].ToString(), dr["supplier_code"].ToString(), 
			dr["quantity"].ToString(), dr["supplier_price"].ToString(), dr["commit_price"].ToString(), 
			dr["item_name"].ToString(), "") )
			return false;
	}

	//get kit
	sc = "SELECT * FROM order_kit WHERE id=" + m_orderID;
//DEBUG("sc1 = ",sc);

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		items = myAdapter.Fill(dst, "kit");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	for(i=0; i<items; i++)
	{
		DataRow dr = dst.Tables["kit"].Rows[i];
		string kit_id = dr["kit_id"].ToString();
		string qty = dr["qty"].ToString();
		//if(!DoAddKit(kit_id, MyIntParse(qty)))
		if(!DoAddKit(kit_id, MyIntParse(qty), m_orderID))
			return false;
	}

	return true;
}

bool DoSearchItem(string kw, bool btype)
{
//	kw = EncodeQuote(kw);
	string sc = "SELECT code, supplier, supplier_code, name, ISNULL(supplier_price, 0) AS supplier_price ";
	sc += " FROM product WHERE code ";// LIKE '"+ kw;
	if(!btype)
	{
		sc += " LIKE '%" + kw + "%'";
	}
	else
		sc += " = '" + kw + "'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_nSearchReturn = myAdapter.Fill(dst, "isearch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(m_nSearchReturn == 1)
	{
		DataRow dr = dst.Tables["isearch"].Rows[0];
		string code = dr["code"].ToString();
		string supplier = dr["supplier"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		string supplier_price = dr["supplier_price"].ToString();
		double dSalesPrice = GetSalesPriceForDealer(code, "1", Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString(), m_customerID);
		AddToCart(code, supplier, supplier_code, "1", supplier_price, dSalesPrice.ToString(), "", "");
		string s_url = Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"] + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=" + s_url + "\">");	
		return false; //end response
	}
	else if(m_nSearchReturn > 1)
	{
		Response.Write("<center><h3>Search Result For " + Request.Form["item_code_search"] + "</h3></center>");
		if(m_nSearchReturn >= 100)
		{
			Response.Write("Top 100 rows returned, Display 1-100");
			m_nSearchReturn = 100;
		}
		else
			Response.Write("top " +(m_nSearchReturn).ToString()+ " rows returned, display 1-" + (m_nSearchReturn).ToString());
		BindISTable();
	}
	return true;
}


bool DoMPNSearch(string kw)
{
	kw = EncodeQuote(kw);
	string sc = "SELECT code, supplier, supplier_code, name, ISNULL(supplier_price, 0) AS supplier_price ";
	sc += " FROM product WHERE supplier_code ";// LIKE '"+ kw;
	sc += " LIKE '%" + kw + "%'";
//DEBUG("757sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_nSearchReturn = myAdapter.Fill(dst, "isearch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(m_nSearchReturn == 1)
	{
		DataRow dr = dst.Tables["isearch"].Rows[0];
		string code = dr["code"].ToString();
		string supplier = dr["supplier"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		string supplier_price = dr["supplier_price"].ToString();
		double dSalesPrice = GetSalesPriceForDealer(code, "1", Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString(), m_customerID);
		AddToCart(code, supplier, supplier_code, "1", supplier_price, dSalesPrice.ToString(), "", "");
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=pos.aspx?ssid=" + m_ssid + "\">");	
		return false; //end response
	}
	else if(m_nSearchReturn > 1)
	{
		Response.Write("<center><h3>Search Result For " + Request.Form["item_code_search"] + "</h3></center>");
		if(m_nSearchReturn >= 100)
		{
			Response.Write("Top 100 rows returned, Display 1-100");
			m_nSearchReturn = 100;
		}
		else
			Response.Write("top " +(m_nSearchReturn).ToString()+ " rows returned, display 1-" + (m_nSearchReturn).ToString());
		BindISTable();
        Response.Write("<a href='pos.aspx?ssid="+m_ssid+"' class='linkButton'>Back</a>");
	}
	return true;
}

void BindISTable()
{
	Response.Write("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>\r\n");
	Response.Write("<td>ProductID</td>\r\n");
	Response.Write("<td>Description</td>\r\n");
	Response.Write("<td>Supplier</td>\r\n");
	Response.Write("<td>SupplierCode</td>\r\n");
	
	Response.Write("<td>SupplierPrice</td>\r\n");
	Response.Write("</tr>\r\n");

	bool bcolor = true;
	string scolor = "";

	for(int i=0; i<m_nSearchReturn; i++)
	{
		if(bcolor)
			scolor = " class=rowColor";
		else
			scolor = "";

		bcolor = !bcolor;

		DataRow dr = dst.Tables["isearch"].Rows[i];
		string code = dr["code"].ToString();
		string supplier = dr["supplier"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		string name = dr["name"].ToString();
		string price = dr["supplier_price"].ToString();
		Response.Write("<tr" + scolor + ">");

		//Link on add items' Product ID
		Response.Write("<td><a href='pos.aspx?a=add&code="+code+"&supplier="+supplier);
		Response.Write("&supplier_code=" + HttpUtility.UrlEncode(supplier_code) + "&pri=" + price + "&ssid=" + m_ssid + "'>");
		Response.Write(code + "</a></td>\r\n");

		//Link to add items to sales from search result
		Response.Write("<td><a href='pos.aspx?a=add&code="+code+"&supplier="+supplier);
		Response.Write("&supplier_code=" + HttpUtility.UrlEncode(supplier_code) + "&pri=" + price + "&ssid=" + m_ssid + "'>");
		Response.Write(name + "</a></td>\r\n");

		Response.Write("<td>" + supplier + "</td>");
		Response.Write("<td>" + supplier_code+ "</td>");
		
		Response.Write("<td>" + double.Parse(price).ToString("c") + "</td>");
		Response.Write("</tr>");
	}	
	Response.Write("</table>");
}

void RestoreAllFields()
{
	if(Session["sales_type_credit" + m_ssid] != null)
	{
		m_bCreditReturn = (bool)Session["sales_type_credit" + m_ssid];
		m_quoteType = "6";//GetEnumID("receipt_type", "credit note");
	}

	if(Session["sales_freight" + m_ssid] != null && Session["sales_freight" + m_ssid] != "")
		m_dFreight = MyMoneyParse(Session["sales_freight" + m_ssid].ToString());

	if(Session["SalesType" + m_ssid] != null && Session["SalesType" + m_ssid].ToString() != "")
		m_quoteType = Session["SalesType" + m_ssid].ToString();

	if(Session["sales_customerid" + m_ssid] != null && Session["sales_customerid" + m_ssid].ToString() != "")
		m_customerID = Session["sales_customerid" + m_ssid].ToString();

	if(Session["order_created" + m_ssid] != null)
		m_bOrderCreated = true;
	if(Session["sales_current_order_number" + m_ssid] != null)
		m_orderNumber = Session["sales_current_order_number" + m_ssid].ToString();
	if(Session["sales_current_order_id" + m_ssid] != null)
		m_orderID = Session["sales_current_order_id" + m_ssid].ToString();
	
	if(Session["sales_shipping_method" + m_ssid] != null && Session["sales_shipping_method" + m_ssid].ToString() != "")
		m_nShippingMethod = Session["sales_shipping_method" + m_ssid].ToString();
	if(Session["sales_special_shipto" + m_ssid] != null && Session["sales_special_shipto" + m_ssid].ToString() != "")
		m_specialShipto = Session["sales_special_shipto" + m_ssid].ToString();
	if(Session["sales_special_ship_to_addr" + m_ssid] != null && Session["sales_special_ship_to_addr" + m_ssid].ToString() != "")
		m_specialShiptoAddr = Session["sales_special_ship_to_addr" + m_ssid].ToString();
	if(Session["sales_pick_up_time" + m_ssid] != null && Session["sales_pick_up_time" + m_ssid].ToString() != "")
		m_pickupTime = Session["sales_pick_up_time" + m_ssid].ToString();
	if(Session["sales_no_individual_price" + m_ssid] != null && Session["sales_no_individual_price" + m_ssid].ToString() != "")
		m_bNoIndividualPrice = MyBooleanParse(Session["sales_no_individual_price" + m_ssid].ToString());
	
	//order number
	if(Session["sales_customer_po_number" + m_ssid] != null)
		m_custpo = Session["sales_customer_po_number" + m_ssid].ToString();
	if(Session["sales_note" + m_ssid] != null)
		m_salesNote = Session["sales_note" + m_ssid].ToString();
}

bool UpdateAllFields()
{
	m_custpo = Request.Form["custpo"];
	m_salesNote = Request.Form["note"];
	if(Request.Form["branch"] != null && Request.Form["branch"] != "")
		m_branchID = Request.Form["branch"];
	m_dFreight = MyMoneyParse(Request.Form["freight"]);
	m_nShippingMethod = Request.Form["shipping_method"];
	m_specialShipto = "0";
	if(Request.Form["special_shipto"] == "on")
		m_specialShipto = "1";
	m_specialShiptoAddr = Request.Form["special_ship_to_addr"];
	m_pickupTime = EncodeQuote(Request.Form["pickup_time"]);
	if(m_pickupTime != null)
	{
		if(m_pickupTime.Length > 49)
			m_pickupTime = m_pickupTime.Substring(0, 49);
	}
	else
		m_pickupTime = "";

	string nip = "0";
	if(Request.Form["nip"] == "on")
		nip = "1";
	m_bNoIndividualPrice = MyBooleanParse(nip);

	Session["sales_customer_po_number" + m_ssid] = m_custpo;
	Session["sales_note" + m_ssid] = m_salesNote;
	Session["brach_id" + m_ssid] = m_branchID;
	Session["sales_shipping_method" + m_ssid] = m_nShippingMethod;
	Session["sales_special_shipto" + m_ssid] = m_specialShipto;
	Session["sales_special_ship_to_addr" + m_ssid] = m_specialShiptoAddr;
	Session["sales_pick_up_time" + m_ssid] = m_pickupTime;
	Session["sales_freight" + m_ssid] = m_dFreight;
	Session["sales_no_individual_price" + m_ssid] = nip;

	if(Session["ShoppingCart" + m_ssid] == null)
		return true;

	dtCart = (DataTable)Session["ShoppingCart" + m_ssid];

	dtCart.AcceptChanges(); //Commits all the changes made to this row since the last time AcceptChanges was called
	int quantity = 0;
	int quantityOld = 0;
	double dPrice = 0;
	double dPriceOld = 0;
	double dTotal = 0;
	int rows = dtCart.Rows.Count;
	for(int i=rows-1; i>=0; i--)
	{
//		if(dtCart.Rows[i]["site"].ToString() == m_sCompanyName)
		{
			if(dtCart.Rows[i]["system"] == "1")
				continue;
			string kit = dtCart.Rows[i]["kit"].ToString();
			string sqty_old = Request.Form["qty_old"+i.ToString()];
			string sqty = Request.Form["qty"+i.ToString()];
			string sprice_old = Request.Form["price_old"+i.ToString()];
			string sprice = Request.Form["price"+i.ToString()];
			if(sprice != "")
			{
				sprice = sprice.Replace(",", "");
				sprice = sprice.Replace("$", "");
			}
			dPriceOld = MyMoneyParse(sprice_old);
			quantity = MyIntParse(sqty);
			quantityOld = MyIntParse(sqty_old);
			if(quantity == 0 || Request.Form["del" + i.ToString()] == "X") //do delete
			{
				dtCart.Rows.RemoveAt(i);
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=pos.aspx?ssid=" + m_ssid + "\">");
				return false; //major bug fix, if delete row one then all prices messed up. we should refresh the page instead of continue print the cart list D.W. 24.May.2004
//				continue;
			}
			else if(quantity < 0)
			{
				m_bCreditReturn = true;
				Session["sales_type_credit" + m_ssid] = true;
				m_quoteType = "6";//GetEnumID("receipt_type", "credit note");
			}
//			else if(m_bCreditReturn)
//				quantity = 0 - quantity; //asume all items follw up are for credit

			if(!TSIsDigit(sprice))
				dPrice = dPriceOld;
			else
				dPrice = MyMoneyParse(sprice);

			if(quantity != quantityOld)
			{
				dtCart.Rows[i].BeginEdit();
				dtCart.Rows[i]["quantity"] = quantity;
				if(dPrice != dPriceOld)
				{
					dtCart.Rows[i]["salesPrice"] = dPrice.ToString();
				}
				else
				{
					double dQtyPrice = dPrice;
					//disable for search new price if changing qty.
					//if(kit != "1")
					//	dQtyPrice = GetSalesPriceForDealer(dtCart.Rows[i]["code"].ToString(), sqty, Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString(), m_customerID);
					dtCart.Rows[i]["salesPrice"] = dQtyPrice.ToString();
				}
				dtCart.Rows[i].EndEdit();			
			}
			else if(sprice != sprice_old)
			{
				dtCart.Rows[i]["salesPrice"] = dPrice.ToString();
			}
			dtCart.Rows[i]["name"] = Request.Form["name" + i];
		}
	}
	dtCart.AcceptChanges(); //Commits all the changes made to this row since the last time AcceptChanges was called

	return true;
}

bool MyDrawTable()
{
	if(!GetCustomer())
		return false;

	bool bRet = true;
	
	PrintJavaFunction();
	Response.Write("<form name=form1 action=pos.aspx?ssid=" + m_ssid + " method=post  >");
	Response.Write("<table width=100% height=100% bgcolor=white align=center valign=center><tr><td valign=top>");
	
	Response.Write("<br><center><h3>" + m_tableTitle + "</h3></center>");
	
	//print sales header table
	if(!PrintSalesHeaderTable(m_custpo))
		return false;
//	Response.Write("<table class=d align=center valign=center cellspacing=1 cellpadding=0 border=1>");

	Response.Write("<table width=97%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=" + m_cols + ">");

	if(!PrintShipToTable())
		return false;

	Response.Write("</td></tr>");
    Response.Write("</table>");

	Response.Write("<tr><td colspan=" + m_cols + ">");
	if(!PrintCartItemTable())
		return false;

	Response.Write("</td></tr>");

	//start comment table
    Response.Write("<tr><td>");
    Response.Write("<table class=commentTable>");
	Response.Write("<tr><td>&nbsp</td></tr><tr><td>&nbsp;Comment : </td></tr>");
	Response.Write("<tr><td><textarea class=commentText name=note cols=70 rows=5>" +m_salesNote+ "</textarea></td></tr>");
	Response.Write("</table>");

	//end comment table

	Response.Write("</td></tr>\r\n");
	
	Response.Write("</table></form>");
	return bRet;
}

void DrawTableHeader()
{
	Response.Write("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
}

bool PrintCartItemTable()
{
	CheckShoppingCart();
	int i = 0;

	Response.Write("<br>");
	Response.Write("<table border=0 cellpadding=0 width=100% cellspacing=0>");

	Response.Write("<tr class=tableHeader>\r\n");
	Response.Write("<td width=130 align=left >STOCK ID</td>");
	Response.Write("<td width=70 >CODE</td>");
	Response.Write("<td >DESCRIPTION</td>");
	Response.Write("<td align=right >PRICE</td>");
	Response.Write("<td align=right >STOCK</td>");
//	if(!g_bRetailVersion)
		Response.Write("<td align=right width=20 > &nbsp;ALLOCATED</td>");
	Response.Write("<td align=right >QTY</td>");
	Response.Write("<td align=right >TOTAL</td></tr>");

	dTotalPrice = 0;
	dTotalGST = 0;
	dAmount = 0;
	dTotalSaving = 0;

	double dCost = 0;
	double dRowPrice = 0;
	double dRowGST = 0;
	double dRowTotal = 0;
	double dRowSaving = 0;
/*	Response.Write("<tr><td colspan=7><input type=text name=item_code_search size=8 value=''>");
//	Response.Write("</td><td colspan=7 align=right><input type=submit name=cmd  "+ Session["button_style"] +"  value='Recalculate Price'></td></tr>");
	Response.Write("<input type=submit name=cmd  "+ Session["button_style"] +"  size=8 value='Select From Categories'></td></tr>");
*/	
	//build up row list
	for(i=0; i<dtCart.Rows.Count; i++)
	{
		if(dtCart.Rows[i]["site"].ToString() != m_sCompanyName)
			continue;

		DataRow dr = dtCart.Rows[i];
		string code = dr["code"].ToString();

		double dsupplierPrice = 0;

		int quantity = int.Parse(dr["quantity"].ToString());

		double dSalesPrice = 0;
		try
		{
			dSalesPrice = double.Parse(dr["salesPrice"].ToString());
			// if(Request.Form["del"+i] != "X")
			// {
			// 	string sprice = "";
			// 	if(Request.Form["price"+ i] != null && Request.QueryString["price"+ i] != "")
			// 		sprice = Request.Form["price"+ i];
			// 	if(sprice != null && sprice != "")
			// 	{
			// 		sprice = sprice.Replace("$", "");
			// 		dSalesPrice = MyDoubleParse(sprice);
			// 	}
			// }
		}
		catch(Exception e)
		{
		}
		dSalesPrice = Math.Round(dSalesPrice, 3);
		dRowTotal = dSalesPrice * quantity;
		dRowTotal = Math.Round(dRowTotal, 3);
		string s_prodName = dr["name"].ToString();
//	DEBUG("spricname = ", s_prodName);
//DEBUG("dsalesprice= ", dSalesPrice.ToString());
		string supplierCode = dr["supplier_code"].ToString();
		if(m_bOrder)
			SSPrintOneRow(i, dr["code"].ToString(), supplierCode, s_prodName, dsupplierPrice, dSalesPrice, quantity, dRowTotal, dr["s_serialNo"].ToString());
		else
			SSPrintOneRow(i, dr["code"].ToString(), dr["code"].ToString(), s_prodName, dsupplierPrice, dSalesPrice, quantity, dRowTotal, dr["s_serialNo"].ToString());

		dTotalPrice += dRowTotal;
		dCost += dsupplierPrice;
	}
	//put an empty row for user input, which is used to search product by code or SN;
//	if(m_quoteType != "3" || Request.QueryString["p"] == "new")
//	Response.Write("<tr><td><input type=text name=item_code_search size=8 value=''>");
	Response.Write("<tr><td>");

Response.Write("<script language=javascript>");
Response.Write("<!-- hide old browser ");
string sjava = @"
function iCalPrice(price, qty, i)
{
	var dtotal;
	
	price = price.replace('$', '');
	qty = qty.replace('$', '');
	if(IsNumberic(price) && IsNumberic(qty))
	{
		dtotal = price * qty;
";
sjava += "		eval(\"document.form1.dtotal\" + i + \".value = dtotal\")";
sjava += @"
	}
	var bfalse;
	bfalse = false;
	if(!IsNumberic(price))
	{
		bfalse = true;
	}
	if(!IsNumberic(qty))
	{
		bfalse = true;
	}
	if(bfalse)
		return false;
	else
		return true;
//	window.alert(dtotal);
	
}

function IsNumberic(sText)
	{
	   var ValidChars = '0123456789.';
	   var IsNumber=true;
	   var Char;
 	   for (i = 0; i < sText.length && IsNumber == true; i++) 
	   { 
		  Char = sText.charAt(i); 
		  if (ValidChars.indexOf(Char) == -1) 
		  {
			 IsNumber = false;
		  }
	   }
		   return IsNumber;
	}
";
Response.Write(sjava);
Response.Write("-->");
Response.Write("</script");
Response.Write(">");


/*	Response.Write("</td><td colspan=7 align=right><input type=submit name=cmd  "+ Session["button_style"] +"  value='Recalculate Price'></td></tr>");
	Response.Write("<tr><td colspan=7><input type=submit name=cmd  "+ Session["button_style"] +"  size=8 value='Select From Categories'></td></tr>");
	Response.Write("</td><td colspan=7 align=right><input type=submit name=cmd  "+ Session["button_style"] +"  value='Recalculate Price'></td></tr>");
*/
	Response.Write("<tr><td colspan="+ (m_cols-1).ToString() +"><input type=text name=item_code_search id='item_code_search' size=8 value=''>");

	Response.Write("<script");
	Response.Write(">");
	Response.Write("$('#item_code_search').focus();");
	Response.Write("</script");
	Response.Write(">");

	Response.Write("<input type=submit name=cmd  class=linkButton  value='SELECT' title='Slect product from categories'></td><td align=right><input type=submit name=cmd class=linkButton  value='RECALCULATE' title='RECALCULATE Price'></td></tr>");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan="+ m_cols +">&nbsp;</td></tr>");
	
	if(Request.Form["freight"] != null && Request.Form["freight"] != "")
	{
		m_dFreight = double.Parse(Request.Form["freight"], NumberStyles.Currency, null);
		Session["sales_freight" + m_ssid] = m_dFreight;
	}
	dTotalPrice = Math.Round(dTotalPrice + m_dFreight, 3);

	double dFinal = dTotalPrice;
	if(Request.Form["total"] != null && Request.Form["total"] != "")
	{
		if(Request.Form["total"] != Request.Form["total_old"])
			dFinal = double.Parse(Request.Form["total"], NumberStyles.Currency, null);
	}
	double discount = Math.Round((dTotalPrice - dFinal) / dTotalPrice * 100, 0);

	if(m_bOrder)
		discount = 0;

	dTotalGST = dTotalPrice * m_dGstRate;

	dAmount = dTotalPrice + dTotalGST;

	Response.Write("<tr bgcolor=#ffffff><td colspan=4>&nbsp;</td>");
	Response.Write("<td align=right>");
	if(m_bOrder)
	{
		Response.Write("&nbsp;");
	}
	else
	{
		Response.Write("<b>Discount : </b>");
		Response.Write("<input type=text size=1 style='text-align:right' align=right name=discount value='" + discount.ToString() + "'> % ");
	}
	Response.Write("</td></tr>");

	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-3).ToString() + ">&nbsp;</td>");
	if(m_bOrder)
	{
		Response.Write("<td>&nbsp;</td>");
	}
	else
	{
		Response.Write("<td title='" + dCost.ToString("c") + "'>");
		Response.Write("<input type=text size=7 style='text-align:right' name=total value='" + dFinal.ToString("c") + "'>");
		Response.Write("<input type=hidden name=total_old value='" + dFinal.ToString("c") + "'></td>");
	
	}

	//freight
	Response.Write("<td align=right><b>Freight : </b></td>");
	Response.Write("<td align=right>");
	Response.Write("<input type=text size=5 style='text-align:right' align=right name=freight value='");
	Response.Write(m_dFreight.ToString("c") + "'>");
	Response.Write("</td></tr>");

	//sub total
	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
	Response.Write("<b>Sub-Total : </b></td><td align=right>");
	Response.Write(dTotalPrice.ToString("c"));
	Response.Write("<input type=hidden name=subtotal value=" + dTotalPrice + ">");
	Response.Write("</td></tr>");

	//total GST
	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
	Response.Write("<b>TAX : </b></td>");
	Response.Write("<td align=right><b>");
	Response.Write(dTotalGST.ToString("c"));
	Response.Write("</b></td></tr>");

	//total amount due
	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
	Response.Write("<b>Total Amount Due : </b></td>");
	Response.Write("<td align=right><b>");
    dAmount = CheckPriceIf99(dAmount);
	Response.Write(dAmount.ToString("c"));
	Response.Write("</b><input type=hidden name=totaldue value='" + dAmount.ToString("c") + "'</td></tr>");

//	Response.Write("<tr bgcolor=#ffffff><td colspan=" + m_cols + " align=right>");
//	Response.Write("<input type=submit name=cmd value='Recalculate Price'></td>");

	double dCredit = 0;
	double dBalance = 0;
	bool bCredit = CreditLimitOK(m_customerID, dAmount, ref dCredit, ref dBalance, false);
	string term_msg = "";
	int nOverdues = 0;
	int nOverdueDays = 0;
	double dOverdueAmount = 0;
	bool bTermOK = CreditTermsOK(m_customerID, ref nOverdues, ref dOverdueAmount, ref nOverdueDays, ref term_msg);
	double dAvailable = dCredit - dBalance - dAmount;
/*	
	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
	Response.Write("<b>Credit Limit : </b></td>");
	Response.Write("<td align=right><b>" + dCredit.ToString("c") + "</td></tr>");
	
	Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
	Response.Write("<b>Account Balance : </b></td>");
	Response.Write("<td align=right><b>" + dBalance.ToString("c") + "</td></tr>");
*/	
	if(m_customerID != "" && m_customerID != "0")
	{
		//credit limit
		Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
		Response.Write("<b>Credit Available : </b></td>");
		Response.Write("<td align=right title='Credit Limit : " + dCredit.ToString("c") + ", Account Balance : " + dBalance.ToString("c") + "'>");
		if(bCredit)
			Response.Write("<font color=green>");
		else
			Response.Write("<font color=red>");
		Response.Write("<b>" + ((dCredit==0) ? "No Limit" : dAvailable.ToString("c")) + "</b></td></tr>");

		//credit term

		if(MyBooleanParse(GetSiteSettings("enable_credit_term_check", "0")))
		{
			Response.Write("<tr bgcolor=#ffffff><td colspan=" + (m_cols-1).ToString() + " align=right>");
			Response.Write("<b>Overdue Invoices/Amount : </b></td>");
			Response.Write("<td align=right title='Most Overdue Days : " + nOverdueDays.ToString() + "'>");
			if(bTermOK)
				Response.Write("<font class=blueFont2>");
			else
				Response.Write("<font class=blueFont2>");
			Response.Write( ((bTermOK) ? "None" : nOverdues.ToString()) + "/" + dOverdueAmount.ToString("c") + "</font></td></tr>");
		}
	}

	Response.Write("<tr><td>");
	Response.Write("&nbsp;</td><td colspan=" + (m_cols - 1).ToString() + " align=right>");

	if(!m_bUseOrderInterface)
	{
		if(m_bIsForSystemBuild)
		{
			Response.Write("<b>System: <select name=build><option value=0 >As Parts</option><option value=1 ");
			if(m_isbuild.ToLower() == "true")
				Response.Write(" selected ");
			Response.Write(">Build</select> | ");
		}
		Response.Write("Discount Total(GST EX):</b><input type=text name=discount_total size=5 style=text-align:right>");
		Response.Write("<input type=submit name=cmd value=Set  class=linkButton  title='Set final price'/> ");
	
	}
	if(m_bOrderCreated)
	{
//		if(bCredit)
		if(m_orderStatus != "2" && m_orderStatus != "3" && m_orderStatus != "6")
		{
			if(m_sSalesType == "quote")
				Response.Write("<input type=submit name=cmd value='Change To Order'  class=linkButton  title='Change to order'/>");
			Response.Write("<input type=submit  class=linkButton name=cmd value='Delete " + Capital(m_sSalesType) + "' title='Delete'/>");
			Response.Write("<div class=updateButton><input type=submit  class=updateOrderButton  onclick='return FreightEmpty();' name=cmd value='Update " + Capital(m_sSalesType) + "'/></div>");
			Response.Write("<input type=hidden name=order_id value=" + m_orderID + ">");
		}
	}
	else
	{
//		if(bCredit)
//			Response.Write("<input type=button onclick=window.location=('q.aspx?ssid=" + m_ssid + "') value='Move To Quote'  "+ Session["button_style"] +" >");
//		if(g_bUseSystemQuotation)
//			Response.Write("<input type=submit name=cmd value='Move To Quote'  "+ Session["button_style"] +" >");
		if(m_bUseOrderInterface)
			Response.Write("<br /><input type=submit name=cmd value='Back To Quote'   class='backButton2' title='Back To Quote' />");
		else
			//Response.Write("<input type=submit  "+ Session["button_style"] +"  name=cmd value='Record'>");
              Response.Write("<div class=recordButton><input type=submit  class=recordButton2  name=cmd value='Record' onclick=\"return FreightEmpty()\"></div>");
	}
	if(!m_bUseOrderInterface)
		//Response.Write("<input type=submit name=cmd  "+ Session["button_style"] +"  value='Cancel'>");
        Response.Write("<div class=cancelButton><input type=submit name=cmd  class=cancelButton2  value='Cancel'></div>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=" + m_cols + " align=right><font color=red><b>");
//	Response.Write("Important : Click 'Update Order' or 'Cancel' to unlock <br>your order before leaving this page!!");
	Response.Write("</b></font></td></tr>");

	Response.Write("</table>");
	return true;
}

bool SSPrintOneRow(int nRow, string sID, string code, string desc, double dCost, double dPrice, int qty, double dTotal, string sSNnum)
{
	string stock = "";
	string allocated_stock = "0";
	//if(IsInteger(sID))
	//{
    string _branchId = Session["brach_id" + m_ssid]  == null ? "1" : Session["brach_id" + m_ssid].ToString();

	stock = GetStock(sID, _branchId ).ToString();//GetProductStock(sID);
	allocated_stock = GetAllocatedStock(sID, _branchId ).ToString();//GetProductAllocated_Stock(sID);
	//}
	Response.Write("<tr ");
	if(bCartAlterColor)
		Response.Write("class=rowColor");
	else
		Response.Write("bgcolor=white");
	bCartAlterColor = !bCartAlterColor;

	Response.Write(">");

	//Online Store ID code;
	Response.Write("<td><a title='click here to view Sales Ref:' href='salesref.aspx?code=" + sID +"' class=o target=_new>");
	Response.Write(sID);
	Response.Write("</a> ");
    if(CheckPatent("viewsales"))
    {
        Response.Write("<input type=button class='smallButton'  title='View Sales History' onclick=\"javascript:viewsales_window=window.open('viewsales.aspx?");
        Response.Write("code=" + sID + "&cid="+ m_customerID +"','','left=0, top=0, width=550,height=550,resizable=1');\" value='S'   >");
        Response.Write("<input type=button class='smallButton' title='View Purchase History' onclick=\"window.open('viewpurchase.aspx?");
        Response.Write("code=" + sID + "')\" value='P'   >");
    }
	Response.Write("</td>\r\n");

	//code
	Response.Write("<td nowrap>");
	Response.Write(code);
	Response.Write("</td>\r\n");
	//description
	
	desc = StripHTMLtags(desc);
	Response.Write("<td>");
	Response.Write("<input type=text size=50 maxlength=255 name=name" + nRow.ToString() + " value='");
	Response.Write(desc);
	Response.Write("'></td>\r\n");

	//price
	Response.Write("<td title=");
	Response.Write(dCost.ToString("c"));
	Response.Write(" align=right>");




    //return a js function 
    // if customer is Cash Sale then the price textbox will readonly.
   // Response.Write(SetPriceReadOnly());
    
//checl is admin login or other.
//    string class_administrator = GetAccessClassID("Administrator");
//    string accessId = Session["employee_access_level"].ToString();
//    string enablePriceModify = "readonly=readonly";
//    if(accessId == class_administrator){
//        enablePriceModify = "";
//    }
////"+enablePriceModify+"
    Response.Write("<input type=text size=7 style='text-align:right' name=price" + nRow.ToString() + " value='");
	//Response.Write("<input type=text size=7  class='priceChangeEnable' style='text-align:right' name=price" + nRow.ToString() + " value='");
    if(isKit(sID)){
        dPrice = GetSalesKitPriceForDealer(sID,"1",GetDealerLevel().ToString(),Session["card_id"].ToString());
    }
	Response.Write(dPrice.ToString("c"));
	Response.Write("'");
	Response.Write(" onchange=\"return iCalPrice(document.form1.price"+ nRow +".value, document.form1.qty"+ nRow +".value, "+ nRow +");\" ");
	
    
    //if(Session["employee_access_level"] != null){
    //    if(Session["employee_access_level"].ToString() != "10"){
    //        Response.Write("readonly=\"readonly\"");
    //    }
    //}


    Response.Write("><input type=hidden name=price_old" + nRow.ToString() + " value='");
	Response.Write(dPrice.ToString("c"));
	Response.Write("'></td>\r\n");

	//current stock
	Response.Write("<td align=right>" + stock + "</td>");
	//if(!g_bRetailVersion)
		Response.Write("<td align=right>" + allocated_stock + "</td>");
	//quantity
	Response.Write("<td align=right><input type=text size=3 autocomplete=off style='text-align:right' name=qty" + nRow.ToString());
	Response.Write(" value='" + qty.ToString() + "' ");
	Response.Write(" onchange=\"return iCalPrice(document.form1.price"+ nRow +".value, document.form1.qty"+ nRow +".value, "+ nRow +");\" ");
	Response.Write(">");

	Response.Write("<input type=hidden name=qty_old" + nRow.ToString() + " value='" + qty.ToString() + "'>");
	Response.Write("<input type=submit name=del" + nRow + " class='smallButton'    value='X' title='Delete item'>");
	Response.Write("</td>\r\n");

	//total
	Response.Write("<td align=right>");
    if(isKit(sID)){
      dTotal = dPrice * qty;
    }
	Response.Write("<input style='text-align:right' size=10% type=textbox name=dtotal" + nRow.ToString() + " readonly value="+ dTotal.ToString("c") +">");
//	Response.Write(dTotal.ToString("c"));
//	Response.Write(dTotal.ToString());
	Response.Write("</td>");
    Response.Write("</tr>");
	return true;
}

bool PrintShipToTable()
{
	DataRow dr = null;
	bool bCashSales = false;
	if(Session["sales_customerid" + m_ssid] == null)
	{
		bCashSales = true;
	}
	else
	{
		GetCustomer();
		if(dst.Tables["card"].Rows.Count > 0)
			dr = dst.Tables["card"].Rows[0];
		else
			bCashSales = true;
	}

	Response.Write("<table width=100% align=center><tr><td valign=top>");
	//bill to
	Response.Write("<table><tr><td>");
	Response.Write("<b>Bill To : <br></b>");

	string sCompany = "";
	string sAddr = "";
	string sContact = "";

	if(!bCashSales)
	{
		sCompany = dr["trading_name"].ToString();
        if(!String.IsNullOrEmpty(dr["postal1"].ToString())){
            sAddr += dr["postal1"].ToString() + "<br>";
        }else{
            sAddr += dr["Address1"].ToString() + "<br>";
        }

		if(!String.IsNullOrEmpty(dr["postal2"].ToString())){
            sAddr += dr["postal2"].ToString() + "<br>";
        }else{
            sAddr += dr["Address2"].ToString() + "<br>";
        }

        if(!String.IsNullOrEmpty(dr["postal3"].ToString())){
            sAddr += dr["postal3"].ToString() + "<br>";
        }else{
            sAddr += dr["Address3"].ToString() + "<br>";
        }
		

		Response.Write(sCompany);
		Response.Write("<br>\r\n");
		Response.Write(sAddr);
		Response.Write("<br>\r\n");
//		Response.Write(dr["Email"].ToString());
//		Response.Write("<br>\r\n");
	}

	Response.Write("</td></tr></table></td><td valign=top align=right>");
	
	//ship to 
	Response.Write("<table>");

	//shipping method
	Response.Write("<tr><td valign=top>");
	
	Response.Write("<b>Shipping Method : </b>");
//DEBUG("bCashSales=", bCashSales.ToString());
	Response.Write("<select name=shipping_method onchange=\"OnShippingMethodChange();\">");

	if(bCashSales){
        Response.Write("<option value=1>PICK UP</option>");
    }
	else{
        string sm = Request.QueryString["sm"];
        if(!String.IsNullOrEmpty(sm)){
             m_nShippingMethod = sm;
        }
        Response.Write(GetEnumOptions("shipping_method", m_nShippingMethod));
        //Response.Write("<option value=1>PICK UP</option>");
        //Response.Write(ShowShipingOption(m_nShippingMethod));
    }
		
	Response.Write("</select>");

	Response.Write("<table align=right id=tPT");
	if(m_nShippingMethod != "1")
		Response.Write(" style='visibility:hidden' ");
	Response.Write("><tr><td>");
	Response.Write("<div style='display:none;'><b>Pick Up Time : </b><input type=text size=10 name=pickup_time maxlength=49 value=\"" + m_pickupTime + "\"></div>");
	Response.Write("</td></tr></table>");

	Response.Write("</td>");
	Response.Write("<td valign=top>");

	Response.Write("<table id=tShipTo");
	if(m_nShippingMethod == "1") //pickup
		Response.Write(" style='visibility:hidden' ");
	Response.Write(">");

	if(!bCashSales)
	{
		sAddr = dr["Address1"].ToString();
		sAddr += "<br>";
		sAddr += dr["Address2"].ToString();
		sAddr += "<br>";
		sAddr += dr["Address3"].ToString();
		sCompany = dr["trading_name"].ToString();
	}

	sAddr = sCompany + "<br>\r\n" + sAddr + "<br>\r\n";

	Response.Write("<tr><td><b>Ship To:</b>");
	Response.Write(" <input type=checkbox name=special_shipto ");
	if(m_specialShipto == "1")
		Response.Write(" checked");
	Response.Write(" onclick=\"OnSpecialShiptoChange();\">Special Shipping Address : ");
//	Response.Write("<br>\r\n");

	Response.Write("<table><tr><td valign=top>");

	Response.Write("<table id=tshiptoaddr ");
	if(m_specialShipto == "1")
		Response.Write(" style='visibility:hidden' ");
	Response.Write("><tr><td>");
	Response.Write(sAddr);
	Response.Write("</td></tr></table>");

	Response.Write("</td><td valign=top>");
	
	Response.Write("<table id=ssta ");
	if(m_specialShipto != "1")
		Response.Write(" style='visibility:hidden' ");
	Response.Write("><tr><td>");
	Response.Write("<textarea name=special_ship_to_addr cols=20 rows=4>");
	Response.Write(m_specialShiptoAddr);
	Response.Write("</textarea>");
	Response.Write("</td></tr></table>");

	Response.Write("</td></tr></table>");

	if(m_specialShipto == "1")
	{
	}
	else if(!bCashSales)
	{
	}

	Response.Write("</td></tr></table>");
	Response.Write("</td></tr></table>");
	//end of ship to

	Response.Write("</td></tr></table>");
	//end of bill and shipto table
	return true;
}

string DoSerialSearch(string s_SN)
{
	string s_msgSN = "";
	s_SN = EncodeQuote(s_SN);
/*	string sc = "SELECT sn, status, product_code, prod_desc, supplier_code, supplier, cost ";
	sc += "FROM stock WHERE sn = '" + s_SN + "' ORDER BY update_time DESC ";
*/
//	string sc = "SELECT top 1 s.sn, s.status, cr.code, cr.name AS prod_desc, cr.supplier_code, cr.supplier, cr.supplier_price AS cost ";
//	sc += "FROM stock s JOIN code_relations cr ON cr.code = s.product_code AND cr.supplier_code = s.supplier_code WHERE (s.sn = '" + s_SN + "'";
	string sc = "SELECT top 1 s.sn, s.status, cr.code, cr.name AS prod_desc, cr.supplier_code, cr.supplier, cr.supplier_price AS cost ";
	sc += "FROM stock s JOIN code_relations cr ON cr.code = s.product_code AND cr.supplier_code = s.supplier_code WHERE (s.sn = '" + s_SN + "'";
	sc += " OR cr.name = '" + s_SN + "' OR cr.id like '%"+ s_SN +"%' ) ";
	sc += " ORDER BY update_time DESC ";
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_nSearchReturn = myAdapter.Fill(dst, "prod_sn");
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}
    
    bool isKit = false;
    //May kit
    if(m_nSearchReturn < 1){
        sc = "SELECT top 1 k.id AS sn, 2 AS status, "+s_SN+" AS code, k.name AS prod_desc, ' ' AS supplier_code, ' ' AS supplier, k.price AS cost ";
	    sc += "FROM kit AS k WHERE k.id = " + s_SN + "";

        try
	    {
		    myAdapter = new SqlDataAdapter(sc, myConnection);
		    m_nSearchReturn = myAdapter.Fill(dst, "prod_sn");
            if(m_nSearchReturn == 1){
                isKit = true;
            }
	    }
	    catch(Exception e) 
	    {
		    //ShowExp(sc, e);
	    }
    }

	if(m_nSearchReturn == 1)  //> 0 )
	{
		DataRow dr = dst.Tables["prod_sn"].Rows[0];
		if(GetEnumValue("stock_status", dr["status"].ToString()) == "in stock")    // Stock Status : "2" indicating the item is in "stock";
		{
			string code = dr["code"].ToString();
			string supplier = dr["supplier"].ToString();
			string supplier_code = dr["supplier_code"].ToString();
			string supplier_price = dr["cost"].ToString();
			string prod_name = dr["prod_desc"].ToString();
			string s_serialNo = s_SN;
			double dSalesPrice = GetSalesPriceForDealer(code, "1", Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString(), m_customerID);
			if(isKit){
                AddToCart(code, supplier, supplier_code, "1", supplier_price, dSalesPrice.ToString(), prod_name, s_serialNo, isKit);
            }else{
                AddToCart(code, supplier, supplier_code, "1", supplier_price, dSalesPrice.ToString(), prod_name, s_serialNo);
            }
			return "found";
		}
		else
		{
			s_msgSN = "The item (SN #: " + s_SN + " ) is not for selling, it's sold already!  >_< !!!";
			return s_msgSN;
		}
	}

	return "notfound"; 
}

bool PrintSalesHeaderTable(string sCustomerPONumber)
{
	Response.Write("<table width=97% align=center valign=center cellspacing=1 cellpadding=1 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	//customer
	if(m_customerID == null && m_customerID == "" || m_customerID == "0")
		Session[m_sCompanyName + "_dealer_level_for_pos" + m_ssid] = "1";

string luri = Request.ServerVariables["URL"] +"?"+ Request.ServerVariables["QUERY_STRING"];
string _t = "";
if(m_sSalesType != null && m_sSalesType != ""){
    _t = "&ft="+m_sSalesType;
}


if(Session[m_sCompanyName + "_dealer_card_id" + m_ssid] == null)
	Session[m_sCompanyName + "_dealer_card_id" + m_ssid] = m_customerID;

	Response.Write("<tr><td>");
	Response.Write("<table><tr><td class=capsLabel>");
	Response.Write("Customer : </td><td>");
	Response.Write("<select class=\"customerSelector\" name=customer onclick=window.location=('pos.aspx?search=1"+ _t +"&ssid=" + m_ssid + "')>");
	Response.Write("<option value=213>Cash Sales</option>");
	if(m_customerID != "" && m_customerID != "0")
		Response.Write("<option value='" + m_customerID + "' selected>" + m_customerName + "</option>");
	Response.Write("</select>");

    Response.Write("<script>");
    Response.Write("function showExpressCard(url){");
    Response.Write("   $('#EzCard_frame').attr('src', url); ");
    Response.Write("   $('#EzCard').css('display', 'block'); ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("}");

    Response.Write("function hideExpressCard(){");
    Response.Write("   $('#EzCard_frame').attr('src', ''); ");
    Response.Write("   $('#EzCard').css('display', 'none'); ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("    ");
    Response.Write("}");

    Response.Write("function closeExpressCard(cardId){");
    Response.Write("   window.location = window.location + '&ci=' + cardId ");
    Response.Write("}");

    Response.Write("</");
    Response.Write("script>");


	Response.Write(" <input type=button title='add new customer' value='EXPRESS CARD' onclick=\"showExpressCard('ezcard.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&luri="+ HttpUtility.UrlEncode(luri) +"');\"  class=linkButton>");
	if(m_customerID.Length > 2)
	{
		Response.Write("  <input type=button onclick=\"javascript:viewcard_window=window.open('viewcard.aspx?");
		Response.Write("id=" + m_customerID + "','','width=350,height=340');\" value='View Card' class=linkButton>");
	}

    
    Response.Write("<div id='EzCard' style='display:none;' class='EzCard'><iframe id='EzCard_frame' src='' width='354' height='410' ></iframe></div>");


	Response.Write("</td></tr>");

	Response.Write("<tr><td class=capsLabel>ACC#/Search : </td>");
	Response.Write("<td><table cellpadding=0 cellspacing=0><tr><td><input type=text name=ckw size=20 value='" + m_customerID + "'>");
	Response.Write("</td><td valign=middle class=goButton2><input type=submit name=cmd value=GO  class=goButton2 ></td></tr></table>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td class=capsLabel>");
	Response.Write("P.O.Number : </td><td><input type=editbox name=custpo value='" + sCustomerPONumber + "'>");
	Response.Write("</td></tr>");

	Response.Write("</table>");
	
/*	//payment
	Response.Write("</td><td>");
	Response.Write("<table><tr><td>");
	Response.Write("<tr><td><b>Paid : </b></td><td><font color=red><b>");
	if(m_bPaid)
		Response.Write("YES");
	else
		Response.Write("NO");
	Response.Write("</b></font></td></tr><tr><td><b>Payment : </b></td><td><b>");
	if(m_bPaid)
		Response.Write(GetEnumValue("payment_method", m_paymentType).ToUpper());
	Response.Write("</b></td></tr></table>");
*/
	//branch and sales
	Response.Write("</td><td align=right valign=top>");
	Response.Write("<table><tr><td>");

	if(Session["branch_support"] != null)
	{
		Response.Write("<tr><td class=capsLabel>Branch : </td><td>");
        string _branchId = Session["brach_id" + m_ssid]  == null ? "" : Session["brach_id" + m_ssid].ToString();
//DEBUG("_branchId11=", _branchId);
        if(String.IsNullOrEmpty(_branchId)){
            _branchId = Request.QueryString["_b"] == null ? "" : Request.QueryString["_b"].ToString();
        }
//DEBUG("_branchId222=", _branchId);
        if(String.IsNullOrEmpty(_branchId)){
            _branchId = "1";
        }
//DEBUG("_branchId33=", _branchId);
        if(!PrintBranchNameOptions(_branchId, "pos.aspx?p=new&ft=order&ci=" + m_customerID + "&cii=xxx&sm='+document.form1.shipping_method.value+'&po='+document.form1.custpo.value+'"))
			return false;
		
		Response.Write("</tr>");
	}
	else
		Response.Write("<input type=hidden name=branch value=1>");

	Response.Write("<tr><td class=capsLabel>Sales : </td><td>");
	Response.Write("<select name=sales>");
	PrintSalesPersonOptions(m_sales);
	Response.Write("</select>");
//	Response.Write("<b>Sales : </b></td><td><input type=submit name=cmd value='" + TSGetUserNameByID(m_sales) + "'  "+ Session["button_style"] +" ></b>");
//	Response.Write("<input type=hidden name=sales value='" + m_sales + "'>");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=2 align=right class=capsLabel><input type=checkbox name=nip ");
	if(m_bNoIndividualPrice)
		Response.Write(" checked");
	Response.Write(">No Individual Price");
	Response.Write("</td></tr></table>");

	Response.Write("</td></tr>");
	Response.Write("</table><br>");

	return true;
}

void PrintSalesPersonOptions(string current)
{
	int rows = 0;
	string sc = " SELECT id, name FROM card WHERE type = 4 ORDER BY name ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "sales");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return;
	}
	Response.Write("<option value=-1>&nbsp;</option>");
	for(int i=0; i<rows; i++)
	{
		string id = dst.Tables["sales"].Rows[i]["id"].ToString();
		Response.Write("<option value=");
		Response.Write(id);
		if(id == current)
			Response.Write(" selected");
		Response.Write(">" + dst.Tables["sales"].Rows[i]["name"].ToString() + "</option>");
	}
}

bool DoCustomerSearchAndList()
{
	//string uri = Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"];
    string uri = Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"] ;//+ "&p=new";
	int rows = 0;
	//string kw = "'%" + Request.Form["ckw"] + "%'";
	string kw = "%" + Request.Form["ckw"] + "%";
	if(Request.Form["ckw"] == null || Request.Form["ckw"] == "")
		kw = "%%";
	//kw = "'%%'";
	kw = kw.Replace("'", "");
	string sc = "SELECT *, '" + uri + "' + '&p=new&ci=' + LTRIM(STR(id)) AS uri FROM card ";
	sc += " WHERE type <> 3 AND type > 0 AND main_card_id IS NULL ";
	if(IsInteger(Request.Form["ckw"]))
		sc += " AND id=" + Request.Form["ckw"];
	else
	{
		sc += " AND (name LIKE '" + kw + "' OR email LIKE '" + kw + "' OR company LIKE '" + kw + "' OR trading_name LIKE '" + kw + "') ";
		sc += " AND type<>" + GetEnumID("card_type", "supplier");
	}
	sc += " AND type <> 6 ";
	sc += " ORDER BY company";
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "card");

		if(rows == 1)
		{
			Session[m_sCompanyName + "_dealer_level_for_pos" + m_ssid] = dst.Tables["card"].Rows[0]["dealer_level"].ToString();
			m_customerID = dst.Tables["card"].Rows[0]["id"].ToString();
			ApplyPriceForCustomer();
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; ");
			Response.Write("URL=" + uri + "&ci=" + dst.Tables["card"].Rows[0]["id"].ToString() + "\">");
			
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	BindGrid();

	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<center><h3>Search for Customer</h3></center>");
	Response.Write("<form id=search action=" + uri + " method=post>");
	Response.Write("<input type=hidden name=invoice_number value=" + m_invoiceNumber + ">");
	Response.Write("<table width=100/%><tr><td>");
	Response.Write("<input type=editbox size=7 name=ckw></td><td>");
	Response.Write("<input type=submit name=cmd value=Search  class=linkButton title=Search ></td><td>  ");
	Response.Write("<input type=button name=cmd value='Cancel'");
	Response.Write(" onClick=window.location=('pos.aspx?ssid=" + m_ssid + "') class=linkButton title=Cancel > </td><td> ");
	Response.Write("<input type=button onclick=window.location=('pos.aspx?ci=0&ssid=" + m_ssid + "') value='Cash Sales' class=linkButton title='Cash Sales'></td><td>  ");
	//	Response.Write("<input type=button onclick=window.open('ecard.aspx?n=customer&a=new') value='New Customer'  "+ Session["button_style"] +" >");
	string luri = Request.ServerVariables["URL"] + "?"+ Request.ServerVariables["QUERY_STRING"];
	Response.Write("<input type=button onclick=window.location=('ecard.aspx?n=customer&a=new&luri="+ HttpUtility.UrlEncode(luri) +"') value='New Customer' class=linkButton title='New Customer'>");
	Response.Write("</td></tr></table></form>");

	LFooter.Text = m_sAdminFooter;
	return true;
}

string GetSalesManager(string card_id)
{
	if(dst.Tables["salesmanager"] != null)
		dst.Tables["salesmanager"].Clear();

	string sc = " SELECT sales FROM card WHERE id = " + card_id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "salesmanager") <= 0)
			return "null";
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "null";
	}
	
	string output = dst.Tables["salesmanager"].Rows[0]["sales"].ToString();
	if(output == "")
		output = "null";
	return output;
}

bool CreateOrder(string branch_id, string card_id, string po_number, string special_shipto, string shipto, 
				 string shipping_method, string pickup_time, string contact, string sales_id, string sales_note, 
				 bool bNoIndividualPrice, ref string order_number)
{
	string reason = "";
	bool bStopOrdering = IsStopOrdering(card_id, ref reason);
	if(bStopOrdering)
	{
		if(reason == "")
			reason = "No reason given.";
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>This account has been disabled to place order</h3><br>");
		Response.Write("<h4><font color=red>" + reason + "<font color=red></h4><br>");
		Response.Write("<h4><a href=ecard.aspx?id=" + card_id + " class=o>Edit Account</a></h4>");
		Response.Write("<br><br><br><br><br><br><br>");
		LFooter.Text = m_sFooter;
		return false;
	}

//	if(!CheckBottomPrice())
//		return false;

	if(branch_id == null || branch_id == "")
		branch_id = "1"; 

	DataSet dsco = new DataSet();

	string sc = "BEGIN TRANSACTION ";
	sc += " INSERT INTO orders (branch, number, type, card_id, po_number, freight, sales_manager) ";
	sc += " VALUES("+branch_id+", 0, " + m_quoteType + ", " + card_id + ", '";
	sc += po_number + "', " + MyMoneyParse(Request.Form["freight"]);
	sc += ", " + GetSalesManager(card_id);
	sc += ") SELECT IDENT_CURRENT('orders') AS id";
	sc += " COMMIT ";
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(dsco, "id") == 1)
		{
			string nip = "0";
			if(bNoIndividualPrice)
				nip = "1";
			m_orderID = dsco.Tables["id"].Rows[0]["id"].ToString();
			m_orderNumber = m_orderID; //new order, same
			//assign ordernumber same as id
			sc = "UPDATE orders SET number=" + m_orderNumber + ", branch=" + branch_id + ", sales_note='" + sales_note + "' ";
			if(special_shipto == "1")
				sc += ", special_shipto=1, shipto='" + EncodeQuote(shipto) + "' ";
			sc += ", contact='" + contact + "' ";
			if(sales_id != "")	
				sc += ", sales=" + sales_id;
			if(!m_bCreditTermsOK || !m_bCreditLimitOK)
				sc += ", status=5 "; //put on hold
			sc += ", shipping_method=" + shipping_method;
			sc += ", pick_up_time='" + EncodeQuote(pickup_time) + "' ";
			sc += ", no_individual_price = " + nip;
			if(m_bIsForSystemBuild)
				sc += ", isbuild = "+ Request.Form["build"].ToString() +"";
			sc += " WHERE id=" + order_number;
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
		}
		else
		{
			Response.Write("<br><br><center><h3>Create Order failed, error getting new order number</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(!WriteOrderItems(m_orderID))
		return false;
	Session["sales_current_order_id" + m_ssid] = m_orderID;
	return true;
}

bool DoCreateOrder(bool bSystem, string sCustPONumber, string sSalesNote)
{
	string branch = Request.Form["branch"];
	string contact = "";
	string ssales = Request.Form["sales"].ToString();
	if(ssales != "-1")
		m_sales = ssales;
	return CreateOrder(branch, m_customerID, sCustPONumber, m_specialShipto, m_specialShiptoAddr, m_nShippingMethod, 
		m_pickupTime, contact, m_sales,  EncodeQuote(sSalesNote), m_bNoIndividualPrice, ref m_orderID);
}

bool CheckBottomPrice()
{
	if(!MyBooleanParse(GetSiteSettings("enable_bottom_price_check", "1")))
		return true;

	for(int i=0; i<dtCart.Rows.Count; i++)
	{
		string supplier_code = dtCart.Rows[i]["supplier_code"].ToString();
		if(supplier_code.ToLower() == "ac200") //temperory code for unknow product
			return true;

		if(dtCart.Rows[i]["kit"].ToString() == "1")
			continue; //ignore kit price

		string code = dtCart.Rows[i]["code"].ToString();
		double dPriceCheck = MyMoneyParse(dtCart.Rows[i]["salesPrice"].ToString());
		int iQty = MyIntParse(dtCart.Rows[i]["quantity"].ToString());

		DataRow drp = null;
		if(!GetProduct(code, ref drp))
		{
			Response.Write("<br><br><center><h3>Product not found");
			return false;
		}
		dPriceCheck = Math.Round(dPriceCheck, 3);
//		double dBottomPrice = Math.Round(MyMoneyParse(drp["price"].ToString()), 2);
		double dLastCostNZD = Math.Round(MyMoneyParse(drp["supplier_price"].ToString()), 3);
		double dManualCostNZD = Math.Round(MyMoneyParse(drp["manual_cost_nzd"].ToString()), 3);

		if(iQty > 0 && dPriceCheck < dLastCostNZD && dPriceCheck < dManualCostNZD)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error, Under-Cost sales detected.</h3>");
			Response.Write("<br>Product Code : " + code);
			Response.Write("<br>Description : " + drp["name"].ToString());
			Response.Write("<br>Last Cost "+m_sCurrencyName+" : " + dLastCostNZD.ToString("c"));
			Response.Write("<br>Manual Cost "+m_sCurrencyName+" : " + dManualCostNZD.ToString("c"));
			Response.Write("<br>Sales Price : " + dPriceCheck.ToString("c"));
			Response.Write("<br><br><input type=button    value=Back onclick=history.go(-1)>");
			return false;
		}
	}
	return true;
}

bool DoDeleteOrder()
{
	DeleteOrderItems(m_orderID);
	string sc = " DELETE FROM orders WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DoUpdateOrder()
{
	if(m_orderID == "")
		return false;

	if(!CheckBottomPrice())
		return false;

	string freight = "0";
	if(Request.Form["freight"] != null && Request.Form["freight"] != "")
		freight = Request.Form["freight"].ToString();
	m_orderID = Request.Form["order_id"];
	string ssales = Request.Form["sales"].ToString();
	if(ssales != "-1")
		m_sales = ssales;
	string nip = "0";
	if(m_bNoIndividualPrice)
		nip = "1";
	
	string sc = "UPDATE orders SET ";
	sc += " branch=" + m_branchID;
	sc += ", card_id=" + m_customerID;
	sc += ", freight=" + freight;
	sc += ", po_number='" + EncodeQuote(m_custpo) + "' ";
	sc += ", sales_note='" + EncodeQuote(m_salesNote) + "' ";
	sc += ", shipping_method=" + m_nShippingMethod;
	sc += ", special_shipto=" + m_specialShipto;
	sc += ", shipto='" + EncodeQuote(m_specialShiptoAddr) + "' ";
	sc += ", pick_up_time='" + EncodeQuote(m_pickupTime) + "' ";
	sc += ", locked_by=null, time_locked=null "; //unlock
	sc += ", no_individual_price = " + nip;
	if(m_bIsForSystemBuild)
		sc += ", isbuild = "+ Request.Form["build"].ToString() +"";
	sc += " WHERE id=" + m_orderID;
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	DeleteOrderItems(m_orderID);
	WriteOrderItems(m_orderID);
	return true;
}

bool DeleteOrderKits(string m_orderID)
{
	string sc = " DELETE FROM order_kit WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DeleteOrderItems(string m_orderID)
{
	if(!DeleteOrderKits(m_orderID))
		return false;

	int items = 0;

	//check if there's any items to delete
	string sc = " SELECT o.branch, i.code, i.quantity ";
	sc += " FROM order_item i JOIN orders o ON o.id=i.id ";
	sc += " WHERE i.id=" + m_orderID;
	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		items = myCommand1.Fill(dst, "delete_items");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(items <= 0)
		return true;

	m_branchID = dst.Tables["delete_items"].Rows[0]["branch"].ToString();
	if(m_branchID == "")
		m_branchID = "1";

	sc = "";
	for(int i=0; i<items; i++)
	{
		DataRow dr = dst.Tables["delete_items"].Rows[i];
		string code = dr["code"].ToString();
		string sqty = dr["quantity"].ToString();
		int nqty = MyIntParse(sqty);
//		if(g_bRetailVersion)
		{
			sc += " Update stock_qty SET ";
			sc += " allocated_stock = allocated_stock - " + sqty;
			sc += " WHERE code=" + code + " AND branch_id = " + m_branchID;
		}
//		else
			sc += " UPDATE product SET allocated_stock = allocated_stock - " + sqty + " WHERE code=" + code;
	}
	sc += " DELETE FROM order_item WHERE id=" + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool WriteOrderItems(string order_id)
{
	CheckShoppingCart();

	for(int i=0; i<dtCart.Rows.Count; i++)
	{
		DataRow dr = dtCart.Rows[i];
		if(dr["site"].ToString() != m_sCompanyName)
			continue;

		string kit = dr["kit"].ToString();
		double dPrice = MyMoneyParse(dr["salesPrice"].ToString());
		dPrice = Math.Round(dPrice, 3);
		string name = EncodeQuote(dr["name"].ToString());
		if(name.Length > 255)
			name = name.Substring(0, 255);

		if(kit == "1")
		{
			RecordKitToOrder(order_id, dr["code"].ToString(), name, dr["quantity"].ToString(), dPrice, m_branchID);
			continue;
		}

		string sc = "INSERT INTO order_item (id, code, quantity, item_name, supplier, supplier_code, supplier_price ";
		sc += ", commit_price) VALUES(" + order_id + ", " + dr["code"].ToString() + ", ";
		sc += dr["quantity"].ToString() + ", '" + name + "', '" + dr["supplier"].ToString();
		sc += "', '" + dr["supplier_code"].ToString() + "', " + Math.Round(MyMoneyParse(dr["supplierPrice"].ToString()), 3);
		sc += ", " + Math.Round(MyMoneyParse(dr["salesPrice"].ToString()), 3) + ") ";
//		if(g_bRetailVersion)
		{
			sc += " IF NOT EXISTS (SELECT code FROM stock_qty where code ="+ dr["code"].ToString() +" ";
			if(Session["Branch_support"] != null)
				sc += " AND branch_id = "+ m_branchID; 
			sc += ")";
				sc += " INSERT INTO stock_qty (code, qty, branch_id, supplier_price, allocated_stock)";
			sc += " VALUES("+ dr["code"].ToString() +", 0 ";
			if(Session["branch_support"] != null)
				sc += ", "+m_branchID;
			else
				sc += ", 1 ";
			sc += ", "+ Math.Round(MyMoneyParse(dr["supplierPrice"].ToString()), 3) +"";
			sc += ", "+ dr["quantity"].ToString() +")";
			sc += " ELSE ";
			sc += " UPDATE stock_qty SET allocated_stock = allocated_stock + " + dr["quantity"].ToString();
			sc += " WHERE code = " + dr["code"].ToString();
			sc += " AND branch_id = " + m_branchID;
		}
//		else
		{
			sc += " UPDATE product SET allocated_stock = allocated_stock + " + dr["quantity"].ToString();
			sc += " WHERE code=" + dr["code"].ToString() + " ";
		}
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

void PrintJavaFunction()
{
	Response.Write("<script TYPE=text/javascript");
	Response.Write(">");
	Response.Write("function OnShippingMethodChange()");
	Response.Write("{		");
	Response.Write("	var m = Number(document.form1.shipping_method.value);\r\n");
	Response.Write("	if(m == 1){document.all('tShipTo').style.visibility='hidden';document.all('tPT').style.visibility='visible';}\r\n");
	Response.Write("	else{document.all('tShipTo').style.visibility='visible';document.all('tPT').style.visibility='hidden';}\r\n");
	Response.Write("}\r\n");

	Response.Write("function OnSpecialShiptoChange()								");
	Response.Write("{																");
	Response.Write("	var v = document.all('ssta').style.visibility;				");
	Response.Write("	if(v != 'hidden')											");
	Response.Write("	{															");
	Response.Write("		document.all('ssta').style.visibility='hidden';			");
	Response.Write("		document.all('tshiptoaddr').style.visibility='visible';	");
	Response.Write("		document.all('tshiptoaddr').style.top = 10;			");
	Response.Write("	}															");
	Response.Write("	else														");
	Response.Write("	{															");
	Response.Write("		document.all('ssta').style.visibility='visible';		");
	Response.Write("		document.all('tshiptoaddr').style.visibility='hidden';	");
	Response.Write("	}															");
	Response.Write("}																");

	Response.Write("function FreightEmpty(){								");
	Response.Write(" var shipping_method_text = document.all(\"shipping_method\").value;	");
    Response.Write(" var isItem_code_search = document.all(\"item_code_search\").value; ");
	Response.Write("	 if (shipping_method_text != 1 && isItem_code_search == \"\"){		");
	Response.Write("			  if (   document.all(\"freight\").value == \"$0.00\" ){										");
	Response.Write("				  alert (\"Please enter Freight fee\");  											");
	Response.Write("		       return false;}else{return true;}");
	Response.Write("	 }else{return true;}");
	Response.Write("}");


	Response.Write("</script");
	Response.Write(">");
}

bool ApplyPriceForCustomer()
{
	string customerLevel = Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString();
	CheckShoppingCart();
	for(int i=0; i<dtCart.Rows.Count; i++)
	{
		if(dtCart.Rows[i]["site"].ToString() != m_sCompanyName)
			continue;
		if(dtCart.Rows[i]["system"].ToString() == "1")
			continue;

		DataRow dr = dtCart.Rows[i];
		string code = dr["code"].ToString();
		string qty = dr["quantity"].ToString();
		if(qty == "") //some sales just delete the qty not enter 0
			qty = "0"; //assume
		double dPrice = GetSalesPriceForDealer(code, qty, customerLevel, m_customerID);
//DEBUG("dprice = ", dPrice.ToString());
		dr["SalesPrice"] = dPrice.ToString();
	}
	return true;
}

bool DoChangeToOrder()
{
	string sc = " UPDATE orders SET type = 2 WHERE id = " + m_orderID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
bool PutOrderOnHold(string order_id)
{
	string sc = " UPDATE orders SET status = 5 WHERE id = " + order_id;
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool isKit(string kitCode){
   bool kit = false;
      //get kit item
   string sc = "SELECT * FROM [kit_item] where [id] = "+kitCode+"";
   DataSet dsgspfd = new DataSet();
   myAdapter = new SqlDataAdapter(sc, myConnection);
   int rows = myAdapter.Fill(dsgspfd, "kitItem");
   if(rows > 0){
       kit = true;
    }
   return kit;
}


    //return a js function 
    // if customer is Cash Sale then the price textbox will readonly.
    String SetPriceReadOnly() {
        string value = "";
        value += "<script type=\"text/javascript\">";
        value += "$(document).ready(function(){";
        value += "  $(\".priceChangeEnable\").click(function(){";
        value += "     var checkText = $(\".customerSelector\").find(\"option:selected\").text(); ";
        value += "     if(checkText === 'Cash Sales'){";
        value += "          $(this).attr(\"readonly\", \"readonly\");";
        value += "     }else{";
        value += "          $(this).removeAttr(\"readonly\");";
        value += "     }";
        value += "  });";
        value += "});";
        value += "</";
        value += "script>";
        return value;
    }

</script>

<asp:Label id=LFooter runat=server/>

