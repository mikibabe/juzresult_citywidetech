<!-- #include file="page_index.cs" -->
<script runat=server>
//////////////////////////////////////////////
// data grid template

DataSet ds = new DataSet();	//for creating Temp talbes templated on an existing sql table

string m_action = "";
string m_sOrderBy = "";
string m_tpName = "card_list";
string m_table = "card";
string m_sc = "";
string m_sk = "";
string m_newID = "";
string m_title = "Receivable Analyze";
int m_nTableWidth = 0;
int m_nPageSize = 0;
bool m_bAllowPaging = true;

bool m_bDescent = false; //order by xxx DESC

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...

	if(!SecurityCheck("administrator"))
		return;

	if(Request.QueryString["t"] != null)
		m_action = Request.QueryString["t"];
	if(Request.QueryString["n"] != null)
		m_tpName = Request.QueryString["n"];
	if(Request.QueryString["sk"] != null)
		m_sk = Request.QueryString["sk"];

	m_tpName = "";

	if(Request.QueryString["ob"] != null)
		m_sOrderBy = Request.QueryString["ob"];
	
	if(Request.QueryString["desc"] == "1")
		m_bDescent = true;

	if(!GetData())
		return;

	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<br><center><h3>" + m_title + "</h3>");

	BindGrid();
}

bool GetData()
{
	string mThisMonth = "m" + MyIntParse(DateTime.UtcNow.AddHours(12).ToString("MM")).ToString();
	string mLastMonth = "m" + MyIntParse(DateTime.UtcNow.AddHours(12).AddMonths(-1).ToString("MM")).ToString();
	string mMonthBefore = "m" + MyIntParse(DateTime.UtcNow.AddHours(12).AddMonths(-2).ToString("MM")).ToString();

	m_sc = " SELECT id AS ID, '<a href=viewcard.aspx?id=' + CONVERT(varchar(50), id) + ' class=o target=_blank>'";
	m_sc += " + SUBSTRING(trading_name, 0, 30) + '</a>' AS Customer, ";
    m_sc += @"  dealer_level AS Level,
          (SELECT name FROM enum WHERE class = 'credit_terms' AND id = card.credit_term) AS Term, credit_limit AS Limit, 
           (SELECT ROUND(SUM(total - amount_paid), 2) FROM invoice
         WHERE card_id = card.id AND paid = 0 AND DATEDIFF(month, commit_date, GETDATE()) = 0) AS 'Current',
          (SELECT ROUND(SUM(total - amount_paid), 2) FROM invoice
         WHERE card_id = card.id AND paid = 0 AND DATEDIFF(month, commit_date, GETDATE()) = 1) AS '30_Days',
          (SELECT ROUND(SUM(total - amount_paid), 2) FROM invoice
         WHERE card_id = card.id AND paid = 0 AND DATEDIFF(month, commit_date, GETDATE()) = 2) AS '60_Days',
          (SELECT ROUND(SUM(total - amount_paid), 2) FROM invoice 
		  WHERE card_id = card.id AND paid = 0 AND DATEDIFF(month, commit_date, GETDATE()) > 2) AS '>90_Days',
          (SELECT ROUND(SUM(total - amount_paid), 2) FROM invoice
         WHERE card_id = card.id AND paid = 0) AS 'Total', 
		 '<a href=ecard.aspx?_burl=rlist.aspx&id=' + CONVERT(varchar, id) + '>Edit</a>' AS 'Action'
		FROM card	WHERE (type < 3) ";

	string sortDescent = m_bDescent?"&desc=0":"&desc=1";
	string r = sortDescent;
	string sc = m_sc;
	if(m_sk != "")
		sc += " " + m_sk;
	if(m_action == "e" || m_action == "a")
		sc = " SELECT TOP 1 * FROM " + m_table + " " + m_sk;
	if(m_sOrderBy != "")
		sc += " ORDER BY '" + m_sOrderBy + "' ";
	if(m_bDescent)
		sc += " DESC";

	if(sc == "")
		return false;

//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(ds, "data");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

/////////////////////////////////////////////////////////////////
void BindGrid()
{
	Type t = null;
	Type tString = System.Type.GetType("System.String");
	Type tMoney = System.Type.GetType("System.Money");
	Type tDecimal = System.Type.GetType("System.Decimal");
	Type tBool = System.Type.GetType("System.Boolean");

	string tableName = "data";
	DataColumnCollection dc = ds.Tables[tableName].Columns;

	int i = 0;

	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);

	int rows = 0;
	if(ds.Tables[tableName] != null)
		rows = ds.Tables[tableName].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?n=" + m_tpName;
	if(m_sOrderBy != "")
		m_cPI.URI += "&ob=" + m_sOrderBy;
	if(m_bDescent)
		m_cPI.URI += "&desc=1";
	if(!m_bAllowPaging && m_nPageSize > 0)
		m_cPI.PageSize = m_nPageSize;
	i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	string tableWidth = "100%";
	if(m_nTableWidth > 0)
		tableWidth = m_nTableWidth.ToString();

	Response.Write("<table width=" + tableWidth + " align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr class=tableHeader>");

	int cols = 0;
	for(int m=0; m<dc.Count; m++)
	{
		string cname = dc[m].ColumnName;
		t = dc[m].DataType;
//DEBUG("type=", t.ToString());
		if(cname == " " || cname == "seq")
			continue;
		string uri = "<a href=rlist.aspx?n=" + m_tpName + "&ob=" + HttpUtility.UrlEncode(cname);
		if(!m_bDescent)
			uri += "&desc=1";
		uri += " class=o>";
		Response.Write("<th>" + uri + cname + "</a></th>");
		cols++;
	}

	Response.Write("</tr>");

	if(rows <= 0)
	{
		Response.Write("</table>");
		return;
	}
	bool bAlterColor = false;

	if(!m_bAllowPaging)
		end = rows;

	for(; i < rows && i < end; i++)
	{
		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=" + GetSiteSettings("table_row_bgcolor", "#EEEEEE"));
		bAlterColor = !bAlterColor;
		Response.Write(">");

		DataRow dr = ds.Tables[tableName].Rows[i];
		string cid = dr["id"].ToString();
		for(int j=0; j<ds.Tables[tableName].Columns.Count; j++)
		{
			string cname = dc[j].ColumnName;
			if(cname == " " || cname == "seq")
				continue;
			string value = dr[j].ToString();
			double dValue = 0;
			bool bMoney = false;
			if(j > 3)
			{
				bMoney = true;
				try
				{
					dValue = Double.Parse(value);
				}
				catch(Exception e)
				{
					bMoney = false;
				}
			}
			if(bMoney)
			{
				value = dValue.ToString("c");
				value = value.Replace("$", "");
			}

			if(cname == "Total")
				value = "<a href=statement.aspx?ci=" + cid + " class=o target=_blank>" + value + "</a>";
			Response.Write("<td nowrap");
			if(j > 3)
				Response.Write(" align=right");
			Response.Write(">" + value + "</td>");
		}
		Response.Write("</tr>");
	}
	if(m_bAllowPaging)
		Response.Write("<tr><td colspan=" + cols + ">" + sPageIndex + "</td></tr>");
	Response.Write("</table>");
	return;
}
</script>
