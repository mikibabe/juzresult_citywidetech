<script runat=server>

DataSet dsfifo = new DataSet();

bool fifo_updateDatabase() //compatible with old version
{
	string sc = "";
	sc += @"
CREATE TABLE [dbo].[sales_cost] (
	[id] [int] IDENTITY (1, 1) NOT FOR REPLICATION  NOT NULL ,
	[invoice_number] [int] NOT NULL ,
	[code] [int] NOT NULL ,
	[qty] [int] NOT NULL ,
	[cost] [money] NOT NULL ,
	[purchase_id] [int] NOT NULL ,
	[need_update_cost] [bit] NOT NULL 
) ON [PRIMARY]
ALTER TABLE [dbo].[sales_cost] WITH NOCHECK ADD 
	CONSTRAINT [PK_sales_cost] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
ALTER TABLE [dbo].[sales_cost] WITH NOCHECK ADD 
	CONSTRAINT [DF_sales_cost_need_update_cost] DEFAULT (0) FOR [need_update_cost]
ALTER TABLE [dbo].[sales] ADD stock_at_sales INT NULL
	";

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool fifo_createStockLossTable() //compatible with old version
{
	string sc = "";
	sc += @"
CREATE TABLE [dbo].[stock_loss] (
	[kid] [int] IDENTITY (1, 1) NOT FOR REPLICATION  NOT NULL ,
	[id] [int] NOT NULL ,
	[qty] [int] NOT NULL ,
	[cost] [money] NOT NULL ,
	[purchase_id] [int] NOT NULL ,
	[need_update_cost] [bit] NOT NULL 
) ON [PRIMARY]
ALTER TABLE [dbo].[stock_loss] WITH NOCHECK ADD 
	CONSTRAINT [PK_stock_loss] PRIMARY KEY  CLUSTERED 
	(
		[kid]
	)  ON [PRIMARY] 
ALTER TABLE [dbo].[stock_loss] WITH NOCHECK ADD 
	CONSTRAINT [DF_stock_loss_need_update_cost] DEFAULT (0) FOR [need_update_cost]
	";

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool fifo_sales_update_cost(string invoice_number, string code, string branch, double dQty)
{
	return fifo_sales_update_cost(invoice_number, code, branch, MyIntParse(Math.Round(dQty, 0).ToString()));
}

bool fifo_sales_update_cost(string invoice_number, string code, string branch, int nQty)
{
	double dCost = 0;
	string purchaseID = "-1";
	double dStock = 0;

	if(!fifo_getStock(code, branch, ref dStock))
		return false;
	if(!fifo_getCost(code, branch, MyIntParse(Math.Round(dStock, 0).ToString()), nQty, invoice_number, ref dCost, ref purchaseID))
		return false;

	double dNormalPrice = GetNormalPrice(code);

	string sc = " UPDATE sales SET supplier_price = " + dCost;
	sc += ", stock_at_sales = " + dStock;
	sc += ", normal_price = " + dNormalPrice;
	sc += " WHERE invoice_number = " + invoice_number + " AND code = " + code;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

double GetNormalPrice(string code)
{
	if(dsfifo.Tables["normal_price"] != null)
		dsfifo.Tables["normal_price"].Clear();

	string sc = " SELECT price2 FROM code_relations WHERE code = " + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsfifo, "normal_price") <= 0)
		{
			//bad news, not found
			return 0;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	return MyDoubleParse(dsfifo.Tables["normal_price"].Rows[0]["price2"].ToString());
}

bool fifo_getStock(string code, string branch, ref double dStock)
{
	if(dsfifo.Tables["stock"] != null)
		dsfifo.Tables["stock"].Clear();

	string sc = " SELECT stock FROM product WHERE code = " + code;
	if(g_bRetailVersion)
		sc = " SELECT qty AS 'stock' FROM stock_qty WHERE code = " + code + " AND branch_id = " + branch;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsfifo, "stock") <= 0)
		{
			//bad news, no stock
			dStock = 0;
			return true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	dStock = MyDoubleParse(dsfifo.Tables["stock"].Rows[0]["stock"].ToString());
	return true;
}

bool fifo_getLastCost(string code, string branch, ref double dCost)
{
	if(dsfifo.Tables["last_cost"] != null)
		dsfifo.Tables["last_cost"].Clear();

	string sc = " SELECT supplier_price FROM code_relations WHERE code = " + code;
	if(g_bRetailVersion)
		sc = " SELECT supplier_price FROM stock_qty WHERE code = " + code + " AND branch_id = " + branch;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dsfifo, "last_cost") <= 0)
		{
			if(g_bRetailVersion) //no purchase record, get last virtual cost
			{
				sc = " SELECT supplier_price FROM code_relations WHERE code = " + code;
				try
				{
					myAdapter = new SqlDataAdapter(sc, myConnection);
					if(myAdapter.Fill(dsfifo, "last_cost") <= 0)
					{
						Response.Write("<br><center><h3>Product(code#" + code + ") Not Found, get last cost failed</h3>");
						return false;
					}
				}
				catch(Exception e) 
				{
					ShowExp(sc, e);
					return false;
				}
			}
			else
			{
				Response.Write("<br><center><h3>Product(code#" + code + ") Not Found, get last cost failed</h3>");
				return false;
			}
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	dCost = MyDoubleParse(dsfifo.Tables["last_cost"].Rows[0]["supplier_price"].ToString());
	return true;
}

bool fifo_getCost(string code, string branch, int nStock, int nQty, string invoice_number, 
						ref double dAveCost, ref string purchaseID)
{
	string need_update_cost = "0";
	if(nStock <= 0 || nQty <= 0) //out of stock or refund
	{
		if(!fifo_getLastCost(code, branch, ref dAveCost))
			return false;
		purchaseID = "-1";	//no purchase made yet
		need_update_cost = "1"; //flag to update on next purchase ("change to bill")

		if(!fifo_writeCostTrace(invoice_number, code, nQty, dAveCost, purchaseID, need_update_cost))
			return false;
		return true;
	}

	double dCost = 0;
	int q = 0; //total quantity
	int q_left = nQty;
	string dTime = "";
	if(dsfifo.Tables["purchase"] != null)
		dsfifo.Tables["purchase"].Clear();

	int rows = 0;

	//try get enough(nQty) purchase orders
	string sc = " SET DATEFORMAT dmy ";
	sc += " SELECT TOP " + nQty.ToString() + " p.id, p.type, i.qty, i.price, p.date_received ";
	sc += " FROM purchase_item i JOIN purchase p ON p.id = i.id";
	sc += " WHERE i.code = " + code;
	sc += " AND p.status = 2 "; //status received
	sc += " AND p.date_received IS NOT NULL "; //protection
	if(dTime != "")
		sc += " AND p.date_received < '" + dTime + "' ";
	sc += " ORDER BY p.date_received DESC ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsfifo, "purchase");
		if(rows <= 0)
		{
//			Response.Write("<br><center><h3>Error, Less Purchase Record, get cost failed.");
			return false; //didn't find
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	for(int i=0; i<rows; i++)
	{
		int pq = MyIntParse(dsfifo.Tables["purchase"].Rows[i]["qty"].ToString()); //qty from this purchase
		q += pq; //total qty add up

		if(q >= nStock) //all current stock from this purchase and later purchase, here we begin
		{
			dCost = MyDoubleParse(dsfifo.Tables["purchase"].Rows[i]["price"].ToString());
			purchaseID = dsfifo.Tables["purchase"].Rows[i]["id"].ToString();
			string type = dsfifo.Tables["purchase"].Rows[i]["type"].ToString();
			if(type == "4") //billed
				need_update_cost = "0";
			else
				need_update_cost = "1";
			int sq = nStock - (q - pq); //stock qty in this cost
			int aq = q_left; //applied qty in this cost
			if(sq < q_left) //qty in this cost not enough for this sale
				aq = sq; //apply all stock in this cost
			if(!fifo_writeCostTrace(invoice_number, code, aq, dCost, purchaseID, need_update_cost))
				return false;
			if(aq >= q_left) //all in this cost, out
			{
				dAveCost = dCost;
				return true;
			}
			dAveCost += dCost * aq; //save for late calculation

			q_left -= aq; //qty left to get cost
			i--; //next purchase
			for(int j=i; j>=0; j--)
			{
				pq = MyIntParse(dsfifo.Tables["purchase"].Rows[j]["qty"].ToString()); //qty from this purchase
				dCost = MyDoubleParse(dsfifo.Tables["purchase"].Rows[j]["price"].ToString());
				purchaseID = dsfifo.Tables["purchase"].Rows[j]["id"].ToString();
				type = dsfifo.Tables["purchase"].Rows[j]["type"].ToString();
				if(type == "4") //billed
					need_update_cost = "0";
				else
					need_update_cost = "1";
				aq = q_left; //applied qty in this cost
				if(pq < q_left) //qty in this cost not enough for this sale
					aq = pq; //apply all stock in this cost
				if(!fifo_writeCostTrace(invoice_number, code, aq, dCost, purchaseID, need_update_cost))
					return false;
				dAveCost += dCost * aq; //save for late calculation
				if(aq >= q_left) //all in this cost, out
				{
					dAveCost /= nQty;
					return true;
				}
				q_left -= aq;
			}

			//we got here only if nQty > nStock
			if(!fifo_getLastCost(code, branch, ref dCost))
				return false;
			need_update_cost = "1";
			if(!fifo_writeCostTrace(invoice_number, code, q_left, dCost, "-1", need_update_cost))
				return false;
			
			dAveCost += dCost * q_left;
			dAveCost /= nQty;
			dAveCost = Math.Round(dAveCost, 2);
			return true;
		}
		dTime = DateTime.Parse(dsfifo.Tables["purchase"].Rows[i]["date_received"].ToString()).ToString("dd/MM/yyyy HH:mm");
	}
	return true;
}

bool fifo_writeCostTrace(string invoice_number, string code, int aq, double dCost, string purchaseID, string need_update_cost)
{
	string sc = " INSERT INTO sales_cost (invoice_number, code, qty, cost, purchase_id, need_update_cost) ";
	sc += " VALUES(" + invoice_number;
	sc += ", " + code;
	sc += ", " + aq;
	sc += ", " + dCost;
	sc += ", " + purchaseID;
	sc += ", " + need_update_cost;
	sc += ")";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		string err = e.ToString().ToLower();
		if(err.IndexOf("invalid object name 'sales_cost'") >= 0)
		{
			myCommand.Connection.Close(); //close it first
			if(!fifo_updateDatabase()) //compatible with old version
				return false;

			//db updated, try again
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e1)
			{
				ShowExp(sc, e1);
				return false;
			}
		}
		else
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

bool fifo_purchase_update_cost(string purchase_id)
{
//	if(dsfifo.Tables["sales_cost"] != null)
//		dsfifo.Tables["sales_cost"].Clear();

	string sc = "";
	int rows = 0;

	DataSet dsfp = new DataSet();

	//get all item code in this purchase first
	sc = " SELECT DISTINCT code FROM purchase_item WHERE id = " + purchase_id;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsfp, "codes");
		if(rows <= 0)
		{
			return true; //no record need to update
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	string codes = "";
	for(int i=0; i<rows; i++)
	{
		codes += dsfp.Tables["codes"].Rows[i]["code"].ToString();
		if(i < rows - 1)
			codes += ",";
	}

	sc = " SELECT * FROM sales_cost ";
	sc += " WHERE (purchase_id = " + purchase_id + " OR purchase_id = -1) ";
	sc += " AND need_update_cost = 1";
	sc += " AND code IN (" + codes + ") "; //major bug fix for slowing "change to bill" 12.May.2004 DW
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsfp, "sales_cost");
		if(rows <= 0)
		{
			return true; //no record need to update
		}
	}
	catch(Exception e) 
	{
		string err = e.ToString().ToLower();
		if(err.IndexOf("invalid object name 'sales_cost'") >= 0)
		{
			myConnection.Close(); //close it first
			if(!fifo_updateDatabase()) //compatible with old version
				return false;
			return true; //no record need to update
		}
		ShowExp(sc, e);
		return false;
	}
	
	sc = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dsfp.Tables["sales_cost"].Rows[i];
		string invoice_number = dr["invoice_number"].ToString();
		string id = dr["id"].ToString();
		string code = dr["code"].ToString();
		sc = " IF EXISTS (SELECT price FROM purchase_item WHERE id=" + purchase_id + " AND code=" + code + ") ";
		sc += " UPDATE sales_cost SET cost = ";
		sc += " (SELECT DISTINCT price FROM purchase_item WHERE id=" + purchase_id + " AND code=" + code + ") ";
		sc += ", need_update_cost = 0 ";
		sc += ", purchase_id = " + purchase_id;
		sc += " WHERE id = " + id;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
		
		if(!fifo_updateSalesAveCost(invoice_number, code))
			return false;
	}

	if(!fifo_purchase_update_stock_loss_cost(purchase_id))
		return false;

	return true;
}

bool fifo_updateSalesAveCost(string invoice_number, string code)
{
	if(dsfifo.Tables["sales_ave_cost"] != null)
		dsfifo.Tables["sales_ave_cost"].Clear();

	int rows = 0;
	double dTotal = 0;
	string sc = " SELECT SUM(cost*qty) AS total FROM sales_cost ";
	sc += " WHERE invoice_number = " + invoice_number;
	sc += " AND code = " + code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dsfifo, "sales_ave_cost");
		dTotal = MyDoubleParse(dsfifo.Tables["sales_ave_cost"].Rows[0]["total"].ToString());
		if(dTotal <= 0)
		{
//			AlertAdmin("alert-" + m_sCompanyName, "update sales average cost failed, no sales record found (cost=0), inv#" + invoice_number + ", code:" + code);
			return true; //item which waiting to be updated not in this purchase order
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	sc = " UPDATE sales SET supplier_price = " + dTotal + " / quantity ";
	sc += " WHERE invoice_number = " + invoice_number + " AND code = " + code;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool fifo_writeStockLoss(string log_id, double dQty, double dCost, string purchaseID, string need_update_cost)
{
	string sc = " INSERT INTO stock_loss ";
	sc += " (id, qty, cost, purchase_id, need_update_cost) VALUES( ";
	sc += log_id;
	sc += ", " + dQty;
	sc += ", " + dCost;
	sc += ", " + purchaseID;
	sc += ", " + need_update_cost;
	sc += ") ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		string err = e.ToString().ToLower();
		if(err.IndexOf("invalid object name 'stock_loss'") >= 0)
		{
			myConnection.Close(); //close it first
			if(!fifo_createStockLossTable()) //compatible with old version
				return false;
			//try again
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e1)
			{
				ShowExp(sc, e1);
				return false;
			}
			return true; //no record need to update
		}
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool fifo_RecordStockLoss(string code, string branch, int nStock, int nQty, string log_id)
{
	return fifo_RecordStockLoss(code, branch, MyDoubleParse(nStock.ToString()), MyDoubleParse(nQty.ToString()), log_id);
}

bool fifo_RecordStockLoss(string code, string branch, double dStock, double dQty, string log_id)
{
	double dAveCost = 0;
	string purchaseID = "";

	string need_update_cost = "0";
	if(dStock <= 0 || dQty <= 0) //out of stock
	{
		if(!fifo_getLastCost(code, branch, ref dAveCost))
			return false;
		purchaseID = "-1";	//no purchase made yet
		need_update_cost = "1"; //flag to update on next purchase ("change to bill")

		if(!fifo_writeStockLoss(log_id, dQty, dAveCost, purchaseID, need_update_cost))
			return false;
		return true;
	}

	double dCost = 0;
	double q = 0; //total quantity
	double q_left = dQty;
	string dTime = "";
	if(dsfifo.Tables["purchase"] != null)
		dsfifo.Tables["purchase"].Clear();

	int rows = 0;

	string sc = " SET DATEFORMAT dmy ";
	sc += " SELECT TOP " + MyIntParse((dQty+1).ToString()).ToString() + " p.id, p.type, i.qty, i.price, p.date_received ";
	sc += " FROM purchase_item i JOIN purchase p ON p.id = i.id";
	sc += " WHERE i.code = " + code;
	sc += " AND p.status = 2 "; //status received
	sc += " AND p.date_received IS NOT NULL "; //protection
	if(dTime != "")
		sc += " AND p.date_received < '" + dTime + "' ";
	sc += " ORDER BY p.date_received DESC ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsfifo, "purchase");
		if(rows <= 0)
		{
//			Response.Write("<br><center><h3>Error, Less Purchase Record, get cost failed.");
			return false; //didn't find
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	for(int i=0; i<rows; i++)
	{
		double pq = MyDoubleParse(dsfifo.Tables["purchase"].Rows[i]["qty"].ToString()); //qty from this purchase
		q += pq; //total qty add up

		if(q >= dStock) //all current stock from this purchase and later purchase, here we begin
		{
			dCost = MyDoubleParse(dsfifo.Tables["purchase"].Rows[i]["price"].ToString());
			purchaseID = dsfifo.Tables["purchase"].Rows[i]["id"].ToString();
			string type = dsfifo.Tables["purchase"].Rows[i]["type"].ToString();
			if(type == "4") //billed
				need_update_cost = "0";
			else
				need_update_cost = "1";
			double sq = dStock - (q - pq); //stock qty in this cost
			double aq = q_left; //applied qty in this cost
			if(sq < q_left) //qty in this cost not enough for this sale
				aq = sq; //apply all stock in this cost
			if(!fifo_writeStockLoss(log_id, aq, dCost, purchaseID, need_update_cost))
				return false;
			if(aq >= q_left) //all in this cost, out
			{
				dAveCost = dCost;
				return true;
			}
			dAveCost += dCost * aq; //save for late calculation

			q_left -= aq; //qty left to get cost
			i--; //next purchase
			for(int j=i; j>=0; j--)
			{
				pq = MyDoubleParse(dsfifo.Tables["purchase"].Rows[j]["qty"].ToString()); //qty from this purchase
				dCost = MyDoubleParse(dsfifo.Tables["purchase"].Rows[j]["price"].ToString());
				purchaseID = dsfifo.Tables["purchase"].Rows[j]["id"].ToString();
				type = dsfifo.Tables["purchase"].Rows[j]["type"].ToString();
				if(type == "4") //billed
					need_update_cost = "0";
				else
					need_update_cost = "1";
				aq = q_left; //applied qty in this cost
				if(pq < q_left) //qty in this cost not enough for this sale
					aq = pq; //apply all stock in this cost
				if(!fifo_writeStockLoss(log_id, aq, dCost, purchaseID, need_update_cost))
					return false;
				dAveCost += dCost * aq; //save for late calculation
				if(aq >= q_left) //all in this cost, out
				{
					dAveCost /= dQty;
					return true;
				}
				q_left -= aq;
			}

			//we got here only if dQty > dStock
			if(!fifo_getLastCost(code, branch, ref dCost))
				return false;
			need_update_cost = "1";
			if(!fifo_writeStockLoss(log_id, q_left, dCost, "-1", need_update_cost))
				return false;
			
			dAveCost += dCost * q_left;
			dAveCost /= dQty;
			dAveCost = Math.Round(dAveCost, 2);
			return true;
		}
		dTime = DateTime.Parse(dsfifo.Tables["purchase"].Rows[i]["date_received"].ToString()).ToString("dd/MM/yyyy HH:mm");
	}
	return true;
}

bool fifo_purchase_update_stock_loss_cost(string purchase_id)
{
	DataSet dsfp = new DataSet();

	int rows = 0;
	string sc = " SELECT s.*, j.code FROM stock_loss s JOIN stock_adj_log j ON j.id = s.id ";
	sc += " WHERE (s.purchase_id = " + purchase_id + " OR s.purchase_id = -1) ";
	sc += " AND s.need_update_cost = 1";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsfp, "sales_cost");
		if(rows <= 0)
		{
			return true; //no record need to update
		}
	}
	catch(Exception e) 
	{
		string err = e.ToString().ToLower();
		if(err.IndexOf("invalid object name 'stock_loss'") >= 0)
		{
			myConnection.Close(); //close it first
			if(!fifo_createStockLossTable()) //compatible with old version
				return false;
			return true; //no record need to update
		}
		ShowExp(sc, e);
		return false;
	}
	
	sc = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dsfp.Tables["sales_cost"].Rows[i];
		string id = dr["id"].ToString();
		string code = dr["code"].ToString();
		sc = " IF EXISTS (SELECT price FROM purchase_item WHERE id=" + purchase_id + " AND code=" + code + ") ";
		sc += " UPDATE stock_loss SET cost = ";
		sc += " (SELECT price FROM purchase_item WHERE id=" + purchase_id + " AND code=" + code + ") ";
		sc += ", need_update_cost = 0 ";
		sc += ", purchase_id = " + purchase_id;
		sc += " WHERE id = " + id;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

bool fifo_updateStockQty(int qty, string code, string branch_id)
{
	string sc = "";
	sc += " IF NOT EXISTS (SELECT code FROM stock_qty WHERE code=" + code;
	sc += " AND branch_id = " + branch_id;
	sc += ")";
	sc += " INSERT INTO stock_qty (code, branch_id, qty, supplier_price) ";
	sc += " VALUES (" + code + ", " + branch_id + ", " + (0 - qty).ToString() + ", ";
	sc += GetSupPrice(code) + ") "; //" (SELECT supplier_price FROM code_relations WHERE code=" + code + ")) "; 
	sc += " ELSE Update stock_qty SET ";
	sc += "qty = qty - " + qty + ", allocated_stock = allocated_stock - " + qty;
	sc += " WHERE code=" + code + " AND branch_id = " + branch_id;
	if(!g_bRetailVersion)
	{
		sc += " UPDATE product SET stock = stock - " + qty + ", allocated_stock = allocated_stock - " + qty;
		sc += " WHERE code=" + code;
	}
	else //retail version only update allocated stock in product table
	{
		sc += " UPDATE product SET allocated_stock = allocated_stock - " + qty;
		sc += " WHERE code=" + code;
	}
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string GetSupPrice(string code)
{
	if(dst.Tables["sup_price"] != null)
		dst.Tables["sup_price"].Clear();

	string s_price ="0";
	int nRows = 0;
	string sc = " SELECT supplier_price FROM code_relations WHERE code=" + code;	
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		nRows = myAdapter.Fill(dst, "sup_price");
		if(nRows != 1)
		{
			return s_price;
		}
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return s_price;
	}
	s_price = dst.Tables["sup_price"].Rows[0]["supplier_price"].ToString();
	return s_price;
}

bool fifo_checkAC200Item(string invoice_number, string code, string supplier_code, string commit_price)
{
	if(supplier_code.ToLower() != "ac200")
		return true;

	double dPrice = MyDoubleParse(commit_price);
	dPrice *= 0.9;
	dPrice = Math.Round(dPrice, 2);
	string sc = " UPDATE sales SET supplier_price = " + dPrice;
	sc += " WHERE invoice_number=" + invoice_number + " AND code=" + code;	
	sc += " UPDATE sales_cost SET cost = " + dPrice + ", need_update_cost=0 ";
	sc += " WHERE invoice_number=" + invoice_number + " AND code=" + code;	
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

</script>
