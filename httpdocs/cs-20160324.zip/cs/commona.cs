<script runat=server>
//////////////////////////////////////////////////////////////////////////////////////
//additional common functions


string GetAdminData(string class1)
{
	return GetSiteSettings(name, "");
}

string GetAdminData(string class1, string class2)
{
	return
}

string GetSiteSettings(string name, string sDefault)
{
	return GetSiteSettings(name, sDefault, false);
}
	
string GetAdminData(string name, string sDefault, bool bHide)
{
	string s = "";
	string sc = "SELECT value FROM settings WHERE name='";
	sc += name;
	sc += "'"; 
	int rows = 0;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		DataSet ds = new DataSet();
		rows = myCommand.Fill(ds);
		if(rows > 0)
			s = ds.Tables[0].Rows[0].ItemArray[0].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	if(rows == 0)
	{
		string sHide = "0";
		if(bHide)
			sHide = "1";
		if(name == "next_cheque_number")
			s = "100000";
		else
			s = sDefault;
		s = EncodeQuote(s);
		sc = " INSERT INTO settings (name, value, hidden) VALUES('" + name + "', '" + s + "', " + sHide + ") ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
		}
	}
	return s;
}

bool SetSiteSettings(string name, string value)
{
	string sc = "UPDATE settings SET value='";
	sc += EncodeQuote(value);
	sc += "' WHERE name='"; 
	sc += name;
	sc += "'";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}


</script>
