
<script runat=server>

string m_page = "about";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...

	if(Request.QueryString.Count > 0)
		m_page = Request.QueryString[0];

	PrintHeaderAndMenu("");
	if(m_page.IndexOf(".") >= 0)
	{
		PrintFooter();
		return;
	}
	Response.Write("<div class='spContent'>");
	Response.Write(ReadSitePage(m_page));
	Response.Write("</div><div style='clear:both;'></div>");
	PrintFooter();

	String adminEmail = WebConfigurationManager.AppSettings["adminEmail"];

	if(Request.Form["formType"] == "contactusform"){
			//do send email
		string emailSubject = "";
	    string emailBody = "";

	    try
	    {
	        emailSubject = Request.Form["subject"].ToString();
	    }
	    catch (Exception ex)
	    {
	        emailSubject = "";
	    }

	    try
	    {
	    	emailBody += "Name: " + Request.Form["firstname"].ToString();
	    	emailBody += " " + Request.Form["lastname"].ToString();
	    	emailBody += "<br />Email: " + Request.Form["email"].ToString();

	        emailBody += "<br />Message: " + Request.Form["message"].ToString();
	        emailBody = emailBody.Replace("\n", "<br />");
	        emailBody += "<br /><br />";
	    }
	    catch (Exception ex)
	    {
	        emailBody = "";
	//DEBUG("54=", ex.Message);
	    }
	    

	    try
	    {
	    	SendEmail(adminEmail, "Contact Us", adminEmail,   emailSubject,  emailBody);
	    }catch(Exception ex){
	    	Response.Write(ex.Message);
	    	Response.Write(ex.InnerException.Message);
	    }

	    
	    Response.Write("<script>");
	    Response.Write("alert('Your message has been sent.');");
	    Response.Write("</");
	    Response.Write("script>");
	}

}
</script>
