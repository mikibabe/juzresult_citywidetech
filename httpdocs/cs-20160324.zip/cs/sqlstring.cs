


<script runat=server>
//const string m_sDataSource = ";data source=.\\SQLEXPRESS;";
////const string m_sDataSource = ";data source=mssql501.ixwebhosting.com;";
//const string m_sSecurityString = "User id=C281332_haulanderp;Password=A9seqxtf7;Integrated Security=false;";
////const string m_emailAlertTo = "customer@pixellive.co.nz";
//const string m_emailAlertTo = "sale@cyetek.co.nz";

//const string m_sCompanyName = "C281332_haulandnew";	//site identifer, used for cache, sql db name etc, highest priority





const string m_sDataSource = ";data source=mssql3.openhost.net.nz;";
//const string m_sDataSource = ";data source=mssql501.ixwebhosting.com;";
const string m_sSecurityString = "User id=cyetekcity;Password=A9seqxtf7;Integrated Security=false;";
//const string m_emailAlertTo = "customer@pixellive.co.nz";
const string m_emailAlertTo = "salse@cyetek.com";
const string m_sCompanyName = "cyetekcity";	//site identifer, used for cache, sql db name etc, highest priority

</script>