<!-- #include file="pnote.cs" -->
<!-- #include file="menu_link.cs" -->
<script runat=server>

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("editor"))
		return;

	PrintAdminHeader();
	PrintAdminMenu();
	GetQueryStrings();	
	bool m_bShowPic = false;
	m_bShowPic = MyBooleanParse(GetSiteSettings("Show_menu_image", "false", true));
	if(m_bShowPic)
	{
		if(Request.QueryString["ms"] != null && Request.QueryString["ms"] != "" && Request.QueryString["ms"] != "File")
				GetAllCatalog();
		else
		{
			if(g_bOrderOnlyVersion)
				Response.Write(ReadSitePage("admin_default_orderonly").Replace("@@companyTitle", m_sCompanyTitle));
			else{
                string adminDefaultPage = ReadSitePage("admin_default");
                adminDefaultPage = adminDefaultPage.Replace("@@companyTitle", m_sCompanyTitle);
                adminDefaultPage = adminDefaultPage.Replace("@@shortCut@@", getShortcut());
    
                Response.Write(adminDefaultPage);
            }
				

			if(!IsPostBack)
			{
			}
			//	GetAllCatalog();
			if(!g_bOrderOnlyVersion)
				ShowPublicNotice();
		}
	}
	else
	{
		if(g_bOrderOnlyVersion)
			Response.Write(ReadSitePage("admin_default_orderonly").Replace("@@companyTitle", m_sCompanyTitle));
		else
			Response.Write(ReadSitePage("admin_default").Replace("@@companyTitle", m_sCompanyTitle));

		if(!IsPostBack)
		{
		}

		if(!g_bOrderOnlyVersion)
			ShowPublicNotice();
	}
	LFooter.Text = m_sAdminFooter;
}

void GetQueryStrings()
{
}

string getShortcut(){
    string returnValue = "";
    try{
        String userMenuPath = Server.MapPath("~/admin/img/userMenu/");
     returnValue = outputMenuList();
     string userId = Session["login_card_id"] as string;
     userMenuPath = userMenuPath + userId + "\\";
//DEBUG("userMenuPath=", userMenuPath);
     AdminMenu.menuClass mClass = new AdminMenu.menuClass();
     AdminMenu.XmlOperator xo = new AdminMenu.XmlOperator();
     if(System.IO.Directory.Exists(userMenuPath)){
                System.Collections.Generic.List<String[]> userMenuList = xo.GetMenuList(userMenuPath);
                foreach (String[] f in userMenuList)
                {
                    string name = f[0];
                    String fileExtension = Path.GetExtension(f[1]).ToLower();
                    name = name.Replace(fileExtension, "");
                    fileExtension = fileExtension.Replace(".", "");
                    string[] menuDetail = getShortcutDetail(name);
                    returnValue += "<div class='shortcutItem'>";
                    returnValue += "   <a href='" + menuDetail[1] + "'>";
                    returnValue += "      <span class='shortcutItemImage'>" +
                                   "        <img src='data:image/" + fileExtension + ";base64," + mClass.ImageToBase64String(f[1]) + "' height='70' width='70' />" +
                                   "      </span>" +
                                   "      <br />" +
                                   "      <span class='shortcutItemName'>" + menuDetail[0] + "</span>" +
                                   "    </a>" +
                                   "    <br />" ;
                    returnValue += "</div>";
                }
     }
    }catch(Exception e){

    }
     
    return returnValue;
}

//{string: name, string: link}
string[] getShortcutDetail(string id){
     string[] returnValue = {"", ""};
     DataSet dstcom = new DataSet();
     string sqlConnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["b2aSQLConnection"].ToString();
     string sc = " SELECT * FROM menu_admin_id WHERE id='" + id + "'";
     try
     {
       SqlDataAdapter myCommand = new SqlDataAdapter(sc, sqlConnString);
       if (myCommand.Fill(dstcom, "getclassid") == 1){
            returnValue[0] = dstcom.Tables["getclassid"].Rows[0]["name"].ToString();
            returnValue[1] = dstcom.Tables["getclassid"].Rows[0]["uri"].ToString();
        }
        myCommand.Dispose();
     }
     catch (Exception e)
     {
                // ShowExp(sc, e);
     }
     return returnValue;
}


string outputMenuList(){
     string returnValue = "";
     //string userLevel = Session["employee_access_level"] as string;
     //AdminMenu.menuClass mClass = new AdminMenu.menuClass(userLevel);
     //DataSet ds = mClass.loadMainMenu(userLevel);
     //returnValue += "<h2>Shortcut</h2>";
     //returnValue += "<form action='addMenu.aspx' method='post' class='addMenuForm'>";
     //returnValue += "<select name='menuId' class='menuList'>";
     //if (ds.Tables[0].Rows.Count > 0){
     //   for (int i = 0; i < ds.Tables[0].Rows.Count; i++){
     //        returnValue += "<option value='-1'>"+ ds.Tables[0].Rows[i]["name"].ToString() +"</option>";
     //        String catId = ds.Tables[0].Rows[i]["id"].ToString();
     //        DataSet subMenuDS = mClass.getMenuItem(catId, userLevel);
     //        if(subMenuDS.Tables[0].Rows.Count > 0){
     //               for (int j = 0; j < subMenuDS.Tables[0].Rows.Count; j++){
     //                   returnValue += "<option value='"+ subMenuDS.Tables[0].Rows[j]["id"].ToString() +"'>&nbsp;&nbsp;&nbsp;"+ subMenuDS.Tables[0].Rows[j]["name"].ToString() +"</option>";
     //               }
     //        }
     //   }
     //}
     //returnValue += "</select>";
     //returnValue += "<input type='submit' value='Add' />";
     //returnValue += "</form>";
     return returnValue;
}

</script>
<asp:Label id=LFooter runat=server/>
