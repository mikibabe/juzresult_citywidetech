<script runat=server>

const string date_format = "MMM-dd HH:mm";
string m_file = "";

//for configuration
int aNameCount = 64;
string[] aName = new string[64];
string[] aValue = new string[64];
string[] aColumn = new string[64];

bool m_bTestFormat = false;
//int debug_del = 0; //for debug only

DataSet ds = new DataSet();	//DataSet cache for code_relations and product_drop
DataSet dsc = new DataSet();	//DataSet cache for code_relations and product_drop
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
DataRow[] dracr;	//for sorting code_relations

int m_nMapOptions = 0;
string[] m_aMapOption = new String[64];

int m_nSkipLine = 0;
StringBuilder sbTest = new StringBuilder();
string m_subCatSeperator = "";
string m_last_scat = "";
string m_last_sscat = "";

int	m_nNoCodeItem = 0;
int	m_nExistsItem = 0;
int	m_nNoPriceItem = 0;
int m_nNewItem = 0;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("administrator"))
		return;

	if(!GetColumns())
		return;

	if(Request.QueryString["file"] != null)
		m_file = Request.QueryString["file"];

	if(Request.Form["cmd"] != null)
	{
		if(!DoSaveConfiguration())
		{
			Response.Write("<br><br><center><h3>Error Save Configuration</h3>");
			return;
		}

		if(Request.Form["cmd"] == "Test")
		{
			PrintAdminHeader();
			PrintAdminMenu();
			m_bTestFormat = true;
			m_bShowProgress = true;
			CheckSCVFormat();
			DoTest();
			PrintAnalyzePage();
		}
		else
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=import.aspx?t=analyze&file=" + HttpUtility.UrlEncode(m_file) + "\">");
		}
		return;
	}

	string type = Request.QueryString["t"];
//	if(type == null || type == "")
//	{
//		PrintMainForm();
//		return;
//	}
	if(type == "process")
	{
		CheckSCVFormat();
		if(DoProcessFile())
		{
		}
		return;
	}
	else if(type == "delete")
	{
		string root = GetRootPath() + "/admin/data/item";
		root = Server.MapPath(root);
		string pathname = root + "\\" +  m_file;
		if(File.Exists(pathname))
			File.Delete(pathname);
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=import.aspx\">");
		return;
	}
	else if(type == "analyze")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		CheckSCVFormat();
		PrintAnalyzePage();
		return;
	}
	else
	{
		PrintAdminHeader();
		PrintAdminMenu();

		string root = GetRootPath() + "/admin/data/item";
		root = Server.MapPath(root);
		if(!Directory.Exists(root))
			Directory.CreateDirectory(root);

		Response.Write("<br><center><h3>Import Product</h3>");
		Response.Write("<table align=center ");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;fixed\">");
		Response.Write("<tr class=tableHeader>\r\n");
		Response.Write("<td><b>FILE</b></td>");
		Response.Write("<td><b>SUPPLIER</b></td>");
		Response.Write("<td><b>SIZE</b></td>");
		Response.Write("<td><b>FILE DATE</b></td>");
		Response.Write("<td><b>ACTION</b></td>");
		Response.Write("</tr>");

		string[] dirs = Directory.GetDirectories(root);
		string path = "";
		string dir = "";
		DirectoryInfo di = new DirectoryInfo(root);
        int i = 0;
		foreach (FileInfo f in di.GetFiles("*.csv")) 
		{
			string s = f.FullName;
			string file = f.Name;//s.Substring(path.Length+1, s.Length-path.Length-1);
			string file_id = file + "_" + (f.Length/1000).ToString() + "K_" + f.LastWriteTime.ToString(date_format);
			
            if(i % 2 == 0){
                Response.Write("<tr class=rowColor>");
            }else{
                Response.Write("<tr>");
            }

            Response.Write("<td><a href=import.aspx?supplier=" + dir + "&file=");
			Response.Write(HttpUtility.UrlEncode(file));
			Response.Write(">");
			Response.Write(file);
			Response.Write("</a></td><td>"+ dir + "</td>");
			Response.Write("<td>" + (f.Length/1000).ToString() + "K</td>");
			Response.Write("<td>" + f.LastWriteTime.ToString(date_format) + "</td>");

			Response.Write("<td>");
			Response.Write("<input type=button class=linkButtonLeft title='Process' onclick=window.location=('import.aspx?t=process&file=" + HttpUtility.UrlEncode(file) + "') value=Process>");
			Response.Write("<input type=button class=linkButtonLeft title='Delete' onclick=window.location=('import.aspx?t=delete&file=" + HttpUtility.UrlEncode(file) + "') value=Delete>");
			string sp = dir.ToUpper();
			Response.Write("<input type=button class=linkButtonLeft title='Analyze' onclick=window.location=('import.aspx?t=analyze&file=" + HttpUtility.UrlEncode(file) + "') value='Analyze'>");
			Response.Write("</td>");
			Response.Write("</tr>");

            i++;
		}
		Response.Write("</table>");
		Form1.Visible = true;
		return;
	}
}

bool GetColumns()
{
	string sc = " SELECT TOP 1 * FROM import_item_format ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(ds, "columns");
	}
	catch(Exception e) 
	{
		PrintAdminHeader();
		PrintAdminMenu();
		ShowExp(sc, e);
		return false;
	}

	DataColumnCollection dc = ds.Tables["columns"].Columns;
	aNameCount = dc.Count - 2; //ignore id, file_name
	int m = 0;
	for(int i=0; i<dc.Count; i++)
	{
		string name = dc[i].ColumnName;
		if(name == "id" || name == "file_name")
			continue;
		aName[m++] = name;
	}

	for(int i=0; i<aNameCount; i++)
		aValue[i] = "0";

	return true;
}

void PrintMainForm()
{
	PrintAdminHeader();
	PrintAdminMenu();
	Response.Write("<br><br><center><h4>Import Data</h4>");
	Response.Write("<h5><a href=import.aspx?t=item class=o>Import Product</a><h5>");
	Response.Write("<h5><a href=import.aspx?t=customer class=o>Import Customer</a><h5>");
	Response.Write("<h5><a href=import.aspx?t=supplier class=o>Import Supplier</a><h5>");
}

bool CheckSCVFormat()
{
	string sc = "SELECT * FROM import_item_format WHERE file_name = '" + m_file + "'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "csv") <= 0)
			return false;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(dst.Tables["csv"].Rows.Count > 0)
	{
		DataRow dr = dst.Tables["csv"].Rows[0];
		for(int i=0; i<aNameCount; i++)
		{
			string s = dr[aName[i]].ToString();
			if(s == "")
				s = "0"; //this column (aColumn[0]) is set to blank
			string nstr = dr[aName[i]].ToString();
			Trim(ref nstr);
			aValue[i] = nstr;
			if(aName[i] == "lines_to_skip")
				m_nSkipLine = MyIntParse(nstr);
			else if(aName[i] == "sub_cat_seperator")
				m_subCatSeperator = nstr;
		}
	}
	return true;	
}

string CSVNextColumn(char[] cb, ref int pos)
{
	if(pos >= cb.Length)
		return "";

	char[] cbr = new char[cb.Length];
	int i = 0;

	if(cb[pos] == '\"')
	{
		while(true)
		{
			pos++;
			if(pos == cb.Length)
				break;
			if(cb[pos] == '\"')
			{
				pos++;
				if(pos >= cb.Length)
					break;
				if(cb[pos] == '\"')
				{
					cbr[i++] = '\"';
					continue;
				}
				else if(cb[pos] != ',')
				{
					Response.Write("<br><font color=red>Error</font>. CSV file corrupt, comma not followed quote. Line=");
					Response.Write(new string(cb));
					Response.Write("<br>\r\n");
					break;
				}
				else
				{
					pos++;
					break;
				}
			}
			cbr[i++] = cb[pos];
			if(cb[pos] == '\'')
				cbr[i++] = '\'';
		}
	}
	else
	{
		while(cb[pos] != ',')
		{
			if(i >= cbr.Length || pos >= cb.Length)
				break;
			cbr[i++] = cb[pos];
			if(cb[pos] == '\'')
				cbr[i++] = '\'';
			pos++;
			if(pos == cb.Length)
				break;
		}
		pos++;
	}
	return new string(cbr, 0, i);
}

bool GetSampleLine(string sLine)
{
	m_aMapOption[0] = "<option value=''></option>";
	char[] cb = sLine.ToCharArray();
	int pos = 0;
	int i = 1;
	for(i=1; i<64; i++)
	{
		if(pos >= cb.Length)
			break;
		m_aMapOption[i] = CSVNextColumn(cb, ref pos);
	}
	m_nMapOptions = i;
	return true;
}

string BuildMapOptions(int current)
{
	StringBuilder sb = new StringBuilder();
	sb.Append(m_aMapOption[0]);

	for(int i=1; i<m_nMapOptions; i++)
	{
		sb.Append("<option value=" + i.ToString());
		if(current == i)
			sb.Append(" selected");
		sb.Append(">" + m_aMapOption[i] + "</option>");
	}
	return sb.ToString();
}

bool PrintAnalyzePage()
{
	//read a few lines of the file
	string root = GetRootPath() + "/admin/data/item/";
	root = Server.MapPath(root);
	string fileName = root + m_file;
	FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
	StreamReader r = new StreamReader(fs);
	r.BaseStream.Seek(0, SeekOrigin.Begin);
	
	string line = r.ReadLine();
	string text = "";
	bool bGetSample = true;
	for(int i=0; i<30; i++)
	{
		if(line == null)
			break;
		if(bGetSample)
		{
			bGetSample = false;
			GetSampleLine(line);
		}
		text += "\r\n";
		text += line;
		line = r.ReadLine();
	}
	r.Close();
	fs.Close();

	Response.Write("<br><center><font size=3><b>File Format Configuration</b></font>");
	Response.Write("<table width=90%>");
	Response.Write("<tr><td><b>" + m_file + "</b></td></tr>");

	Response.Write("<tr><td><textarea name=text wrap=off cols=110 rows=10>");
	Response.Write(text);
	Response.Write("</textarea></td></tr>");

	Response.Write("<tr><td><br><b>Column Mapping</b>");

	//configuration table
	Response.Write("<table valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>\r\n");
	Response.Write("<td width=50>Name</td>\r\n");
	Response.Write("<td width=50>MapTo</td>\r\n");
	Response.Write("</tr>\r\n");

	Response.Write("<form action=import.aspx?file=" + HttpUtility.UrlEncode(m_file) + " method=post>");

	for(int i=0; i<aNameCount; i++)
	{
		Response.Write("<tr><td><b>" + aName[i].ToUpper() + "</b></td><td>");
		if(aName[i] == "sub_cat_seperator")
		{
			Response.Write("<input type=text size=10 name=" + aName[i] + " value='");
			if(aValue[i] != "0")
				Response.Write(aValue[i]);
			Response.Write("'>ie:'/','-' if main cat field has these characters for sub categories");
		}
		else if(aName[i] == "lines_to_skip")
		{
			Response.Write("<input type=text size=10 name=" + aName[i] + " value='");
			Response.Write(aValue[i]);
			Response.Write("'>");
		}
		else
		{
			Response.Write("<select name=" + aName[i] + ">");
			Response.Write(BuildMapOptions( MyIntParse(aValue[i]) ));
			Response.Write("</select>");
		}
		Response.Write("</td></tr>");
	}

	Response.Write("<tr><td colspan=2 align=right>");
	Response.Write("<input type=submit name=cmd value=Test class=linkButton title='Text'>");
	Response.Write("<input type=submit name=cmd value=Save class=linkButton title='Save'>");
	Response.Write("<input type=button class=linkButton title='OK' onclick=window.location=('import.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value=OK>");
	Response.Write("</td></tr>");
	Response.Write("</form>");
	Response.Write("</table>");

	Response.Write("</td></tr></table>");
	Response.Write("</center>");
	return true;
}

/////////////////////////////////////////////////////////////////
void cmdSend_Click(object sender, System.EventArgs e)
{
	if(filMyFile.PostedFile != null)
	{
		HttpPostedFile myFile = filMyFile.PostedFile;
		int nFileLen = myFile.ContentLength; 
		if( nFileLen > 0 )
		{
			byte[] myData = new byte[nFileLen];
			myFile.InputStream.Read(myData, 0, nFileLen);
			string strFileName = Path.GetFileName(myFile.FileName);
			string sExt = Path.GetExtension(myFile.FileName);
			if(sExt.ToLower() != ".csv")
			{
				Response.Write("<h3>Error, " + strFileName + " is not a .csv file</h3>");
				return;
			}
			string m_fileName = strFileName;
			string vpath = GetRootPath() + "/admin/data/item/";
			string strPath = Server.MapPath(vpath);
			if(!Directory.Exists(strPath))
				Directory.CreateDirectory(strPath);
			strPath += strFileName;
			
			WriteToFile(strPath, ref myData);
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=import.aspx\">");
		}
	}
}

void WriteToFile(string strPath, ref byte[] Buffer)
{
	FileStream newFile = new FileStream(strPath, FileMode.Create);
	newFile.Write(Buffer, 0, Buffer.Length);
	newFile.Close();
}

bool DoSaveConfiguration()
{
	string sc = "IF NOT EXISTS (SELECT id FROM import_item_format WHERE file_name = '" + m_file + "') ";
	sc += " INSERT INTO import_item_format (file_name";
	for(int i=0; i<aNameCount; i++)
	{
		sc += "," + aName[i];
	}
	sc += ") VALUES('" + m_file + "'";
	for(int i=0; i<aNameCount-1; i++)
	{
		sc += ",'" + Request.Form[aName[i]] + "' ";
	}
	sc += ", '" + EncodeQuote(Request.Form[aName[aNameCount-1]]) + "' ";
	sc += ") ELSE UPDATE import_item_format SET ";
	for(int i=0; i<aNameCount-1; i++)
	{
		sc += aName[i] + "='" + Request.Form[aName[i]] + "', ";
	}
	sc += aName[aNameCount-1] + "='" + EncodeQuote(Request.Form[aName[aNameCount-1]]) + "' ";
	sc += " WHERE file_name = '" + m_file + "' ";

	if(Request.Form["sub_cat_seperator"] != "")
		sc += " UPDATE import_item_format SET s_cat = '-1', ss_cat = '-1' WHERE file_name = '" + m_file + "' ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DoTest()
{
	//read a few lines of the file
	string root = GetRootPath() + "/admin/data/item/";
	root = Server.MapPath(root);
	string fileName = root + m_file;
	FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
	StreamReader r = new StreamReader(fs);
	r.BaseStream.Seek(0, SeekOrigin.Begin);
	
	string line = r.ReadLine();
	string text = "";

	int i = 1;
	for(; i<2000; i++)
	{
		if(i == m_nSkipLine)
		{
			line = r.ReadLine();
			continue;
		}
		if(line == null)
			break;
		text += "\r\n";
		text += line;
		if(!ProcessLine(line,i))
			break;
		line = r.ReadLine();
	}
	r.Close();
	fs.Close();

	Response.Write("<table width=100% ");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>");
	for(i=0; i<aNameCount; i++)
	{
		if(aName[i] == "sub_cat_seperator" || aName[i] == "lines_to_skip")
			continue;
		if(aValue[i] == "" || aValue[i] == "0")
		{
//			if(aName[i] != "s_cat" && aName[i] != "ss_cat")
				continue;
		}
		Response.Write("<th>" + aName[i] + "</th>");
	}
	Response.Write("</tr>");
	Response.Write(sbTest.ToString());
	Response.Write("</table>");
	return true;
}

bool DoAddItem()
{
	string supplier = "";
	string supplier_code = "";
	string id = "";
	string ref_code = "";
	string name = "";
	string brand = "";
	string cat = "";
	string s_cat = "";
	string ss_cat = "";
	string barcode = "";
	string average_cost = "";
	string supplier_price = "";
	string manual_cost_frd = "";
	string manual_cost_nzd = "";
	string stock = "";
	string eta = "";
	string location = "";
	string expire_date = "";
	string price1 = "";
	string price2 = "";
	string price3 = "";
	string price4 = "";
	string price5 = "";
	string price6 = "";
	string spec = "";
	string retail_price = "";

	if(Session["import_item_supplier"] != null)
	{
		supplier = Session["import_item_supplier"].ToString();
		
	}
	if(Session["import_item_m_pn"] != null)
	{
		supplier_code = Session["import_item_m_pn"].ToString();

	}
	if(Session["import_item_ref_code"] != null)
	{
		ref_code = Session["import_item_ref_code"].ToString();

	}
	if(Session["import_item_description"] != null)
	{
		name = Session["import_item_description"].ToString();

	}
	if(Session["import_item_brand"] != null)
	{
		brand = Session["import_item_brand"].ToString();

	}
	if(Session["import_item_cat"] != null)
	{
		cat = Session["import_item_cat"].ToString();

	}
	if(Session["import_item_s_cat"] != null)
	{
		s_cat = Session["import_item_s_cat"].ToString();

	}
	if(Session["import_item_ss_cat"] != null)
	{
		ss_cat = Session["import_item_ss_cat"].ToString();

	}
	if(Session["import_item_barcode"] != null)
	{
		barcode = Session["import_item_barcode"].ToString();

	}
	if(Session["import_item_average_cost"] != null)
	{
		average_cost = Session["import_item_average_cost"].ToString();

	}
	if(Session["import_item_last_cost"] != null)
	{
		supplier_price = Session["import_item_last_cost"].ToString();

	}
	if(Session["import_item_stock"] != null)
	{
		stock = Session["import_item_stock"].ToString();

	}
	if(Session["import_item_eta"] != null)
	{
		eta = Session["import_item_eta"].ToString();

	}
	if(Session["import_item_location"] != null)
	{
		location = Session["import_item_location"].ToString();

	}
	if(Session["import_item_expire_date"] != null)
	{
		expire_date = Session["import_item_expire_date"].ToString();

	}
	if(Session["import_item_price1"] != null)
	{
		price1 = Session["import_item_price1"].ToString();

	}
	if(Session["import_item_price2"] != null)
	{
		price2 = Session["import_item_price2"].ToString();

	}
	if(Session["import_item_price3"] != null)
	{
		price3 = Session["import_item_price3"].ToString();

	}
	if(Session["import_item_price4"] != null)
	{
		price4 = Session["import_item_price4"].ToString();

	}
	if(Session["import_item_price5"] != null)
	{
		price5 = Session["import_item_price5"].ToString();

	}
	if(Session["import_item_price6"] != null)
	{
		price6 = Session["import_item_price6"].ToString();

	}
	if(Session["import_item_spec"] != null)
	{
		spec = Session["import_item_spec"].ToString();

	}
	if(Session["import_item_retail_price"] != null){
		retail_price = Session["import_item_retail_price"].ToString();

	}

	Trim(ref supplier);
	Trim(ref supplier_code);
	Trim(ref ref_code);
	
	id = supplier + supplier_code;
	if(supplier_code == "")
		id = supplier + ref_code;
	if(id == "")
	{
		m_nNoCodeItem++;
		return true; //skip this one
	}

	if(ItemExists(id))
	{
		m_nExistsItem++;
		return true;
	}

	//clear data
	Session["import_item_retail_price"] = null;
	Session["import_item_spec"] = null;
	Session["import_item_price6"] = null;
	Session["import_item_price5"] = null;
	Session["import_item_price4"] = null;
	Session["import_item_price3"] = null;
	Session["import_item_price2"] = null;
	Session["import_item_price1"] = null;
	Session["import_item_expire_date"] = null;
	Session["import_item_location"] = null;
	Session["import_item_eta"] = null;
	Session["import_item_stock"] = null;
	Session["import_item_last_cost"] = null;
	Session["import_item_average_cost"] = null;
	Session["import_item_barcode"] = null;
	Session["import_item_ss_cat"] = null;
	Session["import_item_s_cat"] = null;
	Session["import_item_cat"] = null;
	Session["import_item_brand"] = null;
	Session["import_item_description"] = null;
	Session["import_item_ref_code"] = null;
	Session["import_item_m_pn"] = null;
	Session["import_item_supplier"] = null;



	
	double dprice1 = MyMoneyParse(price1);
	double dsupplier_price = MyMoneyParse(supplier_price);
	double daverage_cost = MyMoneyParse(average_cost);
	double dretail_price = MyMoneyParse(retail_price);
	if(dsupplier_price == 0)
		dsupplier_price = dprice1;
	if(dsupplier_price == 0)
		dsupplier_price = daverage_cost;
	if(dsupplier_price == 0)
	{
		m_nNoPriceItem++;
		return true; //skip this one
	}
	
	manual_cost_frd = dsupplier_price.ToString();
	manual_cost_nzd = manual_cost_frd;
	manual_cost_frd = manual_cost_frd.Replace("$", "");
	manual_cost_frd = manual_cost_frd.Replace(",", "");
	manual_cost_nzd = manual_cost_nzd.Replace("$", "");
	manual_cost_nzd = manual_cost_nzd.Replace(",", "");
	if(average_cost == "")
		average_cost = "0";
	if(supplier_price == "")
		supplier_price = "0";

	supplier_price = supplier_price.Replace("$", "");
	supplier_price = supplier_price.Replace(",", "");

	average_cost = average_cost.Replace("$", "");
	average_cost = average_cost.Replace(",", "");

	retail_price = retail_price.Replace("$", "");
	retail_price = retail_price.Replace(",", "");
	
	double dStock = MyDoubleParse(stock);
	stock = ((int)dStock).ToString();
	eta = EncodeQuote(eta);
	expire_date = EncodeQuote(expire_date);
	location = EncodeQuote(location);
	price2 = MyMoneyParse(price2).ToString();
	price3 = MyMoneyParse(price3).ToString();
	price4 = MyMoneyParse(price4).ToString();
	price5 = MyMoneyParse(price5).ToString();
	price6 = MyMoneyParse(price6).ToString();
	retail_price = MyMoneyParse(retail_price).ToString();
	spec = EncodeQuote(spec);
	if(price1 == "")
		price1 = "0";
	price1 = price1.Replace("$", "");
	price1 = price1.Replace(",", "");
	int nCode = GetNextCode();
	if(nCode <= 0)
	{
		Response.Write("Error generating code for new product");
		return false;
	}

	name = name.Replace("<", "").Replace(">", "");


	string sc = " BEGIN TRANSACTION ";
	sc += " INSERT INTO code_relations (code, id, supplier, supplier_code, ref_code, name, brand, cat, s_cat, ss_cat ";
	sc += ", barcode, average_cost, supplier_price, manual_cost_frd, manual_cost_nzd, stock_location, expire_date ";
	sc += ", price1, price2, price3, price4, price5, price6, rrp) VALUES(" + nCode.ToString();
	if(id.Length > 100){
		id = id.Substring(0, 99);
	}
	sc += ", '" + EncodeQuote(id) + "' ";
	sc += ", '" + EncodeQuote(supplier) + "' ";
	sc += ", '" + EncodeQuote(supplier_code) + "' ";
	sc += ", '" + EncodeQuote(ref_code) + "' ";
	sc += ", '" + EncodeQuote(name) + "' ";
	sc += ", '" + EncodeQuote(brand) + "' ";
	sc += ", '" + EncodeQuote(cat) + "' ";
	sc += ", '" + EncodeQuote(s_cat) + "' ";
	sc += ", '" + EncodeQuote(ss_cat) + "' "
;	sc += ", '" + EncodeQuote(barcode) + "' ";
	sc += ", " + average_cost;
	sc += ", " + supplier_price;
	sc += ", " + manual_cost_frd;
	sc += ", " + manual_cost_nzd;
	sc += ", '" + EncodeQuote(location) + "' ";
	sc += ", '" + EncodeQuote(expire_date) + "' ";
	sc += ", " + price1;
	sc += ", " + price2;
	sc += ", " + price3;
	sc += ", " + price4;
	sc += ", " + price5;
	sc += ", " + price6;
	sc += ", " + retail_price;
	sc += ") ";

	sc += " INSERT INTO product (code, supplier, supplier_code, name, brand, cat, s_cat, ss_cat, supplier_price ";
	sc += ", price, stock, eta) VALUES(" + nCode.ToString();
	sc += ", '" + EncodeQuote(supplier) + "' ";
	sc += ", '" + EncodeQuote(supplier_code) + "' ";
	sc += ", '" + EncodeQuote(name) + "' ";
	sc += ", '" + EncodeQuote(brand) + "' ";
	sc += ", '" + EncodeQuote(cat) + "' ";
	sc += ", '" + EncodeQuote(s_cat) + "' ";
	sc += ", '" + EncodeQuote(ss_cat) + "' ";
	sc += ", " + supplier_price;
	sc += ", " + price1;
	sc += ", " + stock;
	sc += ", '" + EncodeQuote(eta) + "') ";


	sc += "   INSERT INTO product_details (code, spec)";
	sc += "   VALUES ('"+ nCode.ToString() +"', '"+ spec +"')";


	sc += " IF NOT EXISTS (SELECT code FROM stock_qty WHERE code = "+ nCode.ToString() +") ";
	sc += " INSERT INTO stock_qty (code, qty, supplier_price) VALUES(" + nCode.ToString() + ", " + stock + ", " + supplier_price + ") ";
	//sc += " ELSE UPDATE stock_qty SET qty = qty + "+ stock +" AND supplier_price = AVG(supplier_price + "+ supplier_price +") WHERE code = "+ nCode.ToString() +" ";
    //did know what is AVG(supplier_price + "+ supplier_price +")  mean
    sc += " ELSE UPDATE stock_qty SET qty = qty + "+ stock +" , supplier_price = supplier_price + "+ supplier_price +" WHERE code = "+ nCode.ToString() +" ";

	sc += " UPDATE account set opening_balance += "+ supplier_price +" WHERE (class1 *1000) + (class2 * 100) + (class3 * 10) + (class4) = 1121 ";
	sc += " UPDATE account set opening_balance += "+ supplier_price +" WHERE (class1 *1000) + (class2 * 100) + (class3 * 10) + (class4) = 2111 ";

	sc += " COMMIT ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	m_nNewItem++;
	return true;
}

bool ItemExists(string id)
{
	if(id.Length > 100){
		id = id.Substring(0, 99);
	}
	string sc = " SELECT TOP 1 code FROM code_relations WHERE id = '" + EncodeQuote(id) + "' ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		ds = new DataSet();
		if(myAdapter.Fill(ds, "exists") > 0){
			    DataRow dr = ds.Tables["exists"].Rows[0];
			    string pCode = dr["code"].ToString();
			//update exist item start
				string supplier = "";
				string supplier_code = "";
				string ref_code = "";
				string name = "";
				string brand = "";
				string cat = "";
				string s_cat = "";
				string ss_cat = "";
				string barcode = "";
				string average_cost = "";
				string supplier_price = "";
				string manual_cost_frd = "";
				string manual_cost_nzd = "";
				string stock = "";
				string eta = "";
				string location = "";
				string expire_date = "";
				string price1 = "";
				string price2 = "";
				string price3 = "";
				string price4 = "";
				string price5 = "";
				string price6 = "";
				string spec = "";
				string retail_price = "";

				if(Session["import_item_supplier"] != null)
				{
					supplier = Session["import_item_supplier"].ToString();
				}
				if(Session["import_item_m_pn"] != null)
				{
					supplier_code = Session["import_item_m_pn"].ToString();
				}
				if(Session["import_item_ref_code"] != null)
				{
					ref_code = Session["import_item_ref_code"].ToString();
				}
				if(Session["import_item_description"] != null)
				{
					name = Session["import_item_description"].ToString();
				}
				if(Session["import_item_brand"] != null)
				{
					brand = Session["import_item_brand"].ToString();
				}
				if(Session["import_item_cat"] != null)
				{
					cat = Session["import_item_cat"].ToString();
				}
				if(Session["import_item_s_cat"] != null)
				{
					s_cat = Session["import_item_s_cat"].ToString();
				}
				if(Session["import_item_ss_cat"] != null)
				{
					ss_cat = Session["import_item_ss_cat"].ToString();
				}
				if(Session["import_item_barcode"] != null)
				{
					barcode = Session["import_item_barcode"].ToString();
				}
				if(Session["import_item_average_cost"] != null)
				{
					average_cost = Session["import_item_average_cost"].ToString();
				}
				if(Session["import_item_last_cost"] != null)
				{
					supplier_price = Session["import_item_last_cost"].ToString();
				}
				if(Session["import_item_stock"] != null)
				{
					stock = Session["import_item_stock"].ToString();
				}
				if(Session["import_item_eta"] != null)
				{
					eta = Session["import_item_eta"].ToString();
				}
				if(Session["import_item_location"] != null)
				{
					location = Session["import_item_location"].ToString();
				}
				if(Session["import_item_expire_date"] != null)
				{
					expire_date = Session["import_item_expire_date"].ToString();
				}
				if(Session["import_item_price1"] != null)
				{
					price1 = Session["import_item_price1"].ToString();
				}
				if(Session["import_item_price2"] != null)
				{
					price2 = Session["import_item_price2"].ToString();
				}
				if(Session["import_item_price3"] != null)
				{
					price3 = Session["import_item_price3"].ToString();
				}
				if(Session["import_item_price4"] != null)
				{
					price4 = Session["import_item_price4"].ToString();
				}
				if(Session["import_item_price5"] != null)
				{
					price5 = Session["import_item_price5"].ToString();
				}
				if(Session["import_item_price6"] != null)
				{
					price6 = Session["import_item_price6"].ToString();
				}
				if(Session["import_item_spec"] != null)
				{
					spec = Session["import_item_spec"].ToString();
				}
				if(Session["import_item_retail_price"] != null){
					retail_price = Session["import_item_retail_price"].ToString();
				}

				Trim(ref supplier);
				Trim(ref supplier_code);
				Trim(ref ref_code);
				

				double dprice1 = MyMoneyParse(price1);
				double dsupplier_price = MyMoneyParse(supplier_price);
				double daverage_cost = MyMoneyParse(average_cost);
				double dretail_price = MyMoneyParse(retail_price);
				if(dsupplier_price == 0)
					dsupplier_price = dprice1;
				if(dsupplier_price == 0)
					dsupplier_price = daverage_cost;
				if(dsupplier_price == 0)
				{
					m_nNoPriceItem++;
					return true; //skip this one
				}
				
				manual_cost_frd = dsupplier_price.ToString();
				manual_cost_nzd = manual_cost_frd;
				manual_cost_frd = manual_cost_frd.Replace("$", "");
				manual_cost_frd = manual_cost_frd.Replace(",", "");
				manual_cost_nzd = manual_cost_nzd.Replace("$", "");
				manual_cost_nzd = manual_cost_nzd.Replace(",", "");
				if(average_cost == "")
					average_cost = "0";
				if(supplier_price == "")
					supplier_price = "0";

				supplier_price = supplier_price.Replace("$", "");
				supplier_price = supplier_price.Replace(",", "");

				average_cost = average_cost.Replace("$", "");
				average_cost = average_cost.Replace(",", "");

				retail_price = retail_price.Replace("$", "");
				retail_price = retail_price.Replace(",", "");
				
				double dStock = MyDoubleParse(stock);
				stock = ((int)dStock).ToString();
				eta = EncodeQuote(eta);
				expire_date = EncodeQuote(expire_date);
				location = EncodeQuote(location);
				price2 = MyMoneyParse(price2).ToString();
				price3 = MyMoneyParse(price3).ToString();
				price4 = MyMoneyParse(price4).ToString();
				price5 = MyMoneyParse(price5).ToString();
				price6 = MyMoneyParse(price6).ToString();
				retail_price = MyMoneyParse(retail_price).ToString();
				spec = EncodeQuote(spec);
				if(price1 == "")
					price1 = "0";
				price1 = price1.Replace("$", "");
				price1 = price1.Replace(",", "");
				

				sc = " BEGIN TRANSACTION ";



				sc += "   UPDATE  code_relations";
				sc += "   SET ";
				sc += "   supplier = '"  + EncodeQuote(supplier) + "', ";
				sc += "   supplier_code = '"  + EncodeQuote(supplier_code) + "', ";
				sc += "   ref_code = '"  + EncodeQuote(ref_code) + "', ";
				sc += "   name = '"  + EncodeQuote(name) + "', ";
				sc += "   brand = '"  + EncodeQuote(brand) + "', ";
				sc += "   cat = '"  + EncodeQuote(cat) + "', ";
				sc += "   s_cat = '"  + EncodeQuote(s_cat) + "', ";
				sc += "   ss_cat = '"  + EncodeQuote(ss_cat) + "', ";
				sc += "   barcode = '"  + EncodeQuote(barcode) + "', ";
				sc += "   average_cost = "  + average_cost + ", ";
				sc += "   supplier_price = "  + supplier_price + ", ";
				sc += "   manual_cost_frd = "  + manual_cost_frd + ", ";
				sc += "   manual_cost_nzd = "  + manual_cost_nzd + ", ";
				sc += "   stock_location = '"  + EncodeQuote(location) + "', ";
				sc += "   expire_date = '"  + EncodeQuote(expire_date) + "', ";
				sc += "   price1 = "  + price1 + ", ";
				sc += "   price2 = "  + price2 + ", ";
				sc += "   price3 = "  + price3 + ", ";
				sc += "   price4 = "  + price4 + ", ";
				sc += "   price5 = "  + price5 + ", ";
				sc += "   price6 = "  + price6 + ", ";
				sc += "   rrp = "  + retail_price ;

				sc += "   WHERE id = '" + EncodeQuote(id) + "'";



				sc += "   UPDATE product";
				sc += "   SET ";
				sc += "   supplier = '"  + EncodeQuote(supplier) + "', ";
				sc += "   supplier_code = '"  + EncodeQuote(supplier_code) + "', ";
				sc += "   name = '"  + EncodeQuote(name) + "', ";
				sc += "   brand = '"  + EncodeQuote(brand) + "', ";
				sc += "   cat = '"  + EncodeQuote(cat) + "', ";
				sc += "   s_cat = '"  + EncodeQuote(s_cat) + "', ";
				sc += "   ss_cat = '"  + EncodeQuote(ss_cat) + "', ";
				sc += "   supplier_price = '"  + EncodeQuote(supplier_price) + "'";
				sc += "   WHERE code = " + pCode;
				

				if(!String.IsNullOrEmpty(spec)){
					sc += "   UPDATE product_details";
					sc += "   SET ";
					sc += "   spec = '"+ spec +"'";
					sc += "   WHERE code = " + pCode;
				}
				


				sc += " COMMIT ";
				try
				{
					myCommand = new SqlCommand(sc);
					myCommand.Connection = myConnection;
					myConnection.Open();
					myCommand.ExecuteNonQuery();
					myCommand.Connection.Close();
				}
				catch(Exception e) 
				{
					ShowExp(sc, e);
					return false;
				}

			//update exist item end

			return true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		Response.End();
		return false;
	}
	return false;
}

bool ProcessLine(string sLine, int lineNumber)
{
	char[] cb = sLine.Replace("<", "").Replace(">", "").ToCharArray();
	int pos = 0;
	int i = 1;
	for(i=1; i<64; i++)
	{
		if(pos >= cb.Length)
			break;
		//DEBUG("cb", sLine);
		//DEBUG("pos", pos);
		aColumn[i] = CSVNextColumn(cb, ref pos);
	}
	if(m_bTestFormat)
		if(lineNumber % 2 == 0){
            sbTest.Append("<tr class=rowColor>");
        }else{
            sbTest.Append("<tr>");
        }
	for(i=0; i<aNameCount; i++)
	{
		if(aName[i] == "sub_cat_seperator" || aName[i] == "lines_to_skip")
			continue;
		if(aValue[i] == "" || aValue[i] == "0")
			continue;
		string v = "";
		int n = MyIntParse(aValue[i]);
		if(n >= 0)
			v = aColumn[n];
		else
		{
			if(aName[i] == "s_cat")
				v = m_last_scat;
			else if(aName[i] == "ss_cat")
				v = m_last_sscat;
		}
		if(m_subCatSeperator != "" && aName[i] == "cat")
			v = GetSubCat(v);
		if(m_bTestFormat)
			sbTest.Append("<td>" + v + "</td>");
		else
		{
			Session["import_item_" + aName[i]] = v;
		}
	}
	if(m_bTestFormat)
		sbTest.Append("</tr>");
	else
	{
		if(!DoAddItem())
			return false;
	}
	return true;
}

string GetSubCat(string cat)
{
	m_last_scat = "";
	m_last_sscat = "";

	if(cat == null || cat == "")
		return cat;
	string sp = m_subCatSeperator;
	int p1 = cat.IndexOf(sp);
	if(p1 <= 0)
		return cat;
	int p2 = cat.IndexOf(sp, p1 + 1);
	if(p2 <= 0)
		p2 = cat.Length;
	
	string c = cat.Substring(0, p1);
	m_last_scat = cat.Substring(p1 + 1, p2 - p1 - 1);
	if(p2 != cat.Length)
		m_last_sscat = cat.Substring(p2 + 1, cat.Length - p2 - 1);
	return c;
}

bool DoProcessFile()
{
	PrintAdminHeader();
	Response.Write("Opening file....");
	string root = GetRootPath() + "/admin/data/item/";
	root = Server.MapPath(root);
	string fileName = root + m_file;
	FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
	StreamReader r = new StreamReader(fs);
	r.BaseStream.Seek(0, SeekOrigin.Begin);
	Response.Write("done.<br>");
	Response.Write("Processing, please wait...");
	
	string line = r.ReadLine();
	string text = "";

	bool bRet = true;
	int i = 0;
	while(line != null)
	{
		i++;
		if(i == m_nSkipLine)
		{
			line = r.ReadLine();
			continue;
		}
		text += "\r\n";
		text += line;
		if(!ProcessLine(line,i))
		{
			bRet = false;
			break;
		}
		MonitorProcess(300);
		line = r.ReadLine();
	}
	r.Close();
	fs.Close();
	Response.Write("done.<br>");
	Response.Write("<h5>Total lines processed : <b>" + (i - m_nSkipLine - 1).ToString() + "</b><br>");
	Response.Write("Existing Items : <b>" + m_nExistsItem + "</b><br>");
	Response.Write("No Code Items(skipped) : <b>" + m_nNoCodeItem + "</b><br>");
	Response.Write("No Price Items(skipped) : <b>" + m_nNoPriceItem + "</b><br>");
	Response.Write("New Items(Imported) : <b>" + m_nNewItem + "</b></h5>");
	Response.Write("<h4><a href=ec.aspx class=o>Update Category</a> &nbsp;&nbsp;");
	Response.Write(" <a href=default.aspx class=o>Done</a></h4>");
	return bRet;
}
</script>

<form id="Form1" method="post" runat="server" enctype="multipart/form-data" visible=false>
<br>
<table align=center>
<tr><td colspan=4 align=center><font size=+1><b>Upload File</b><br>&nbsp;</td></tr>
<tr><td><b> File : </b><input id="filMyFile" type="file" runat="server"></td><td>&nbsp;</td>
<td> <asp:button id="cmdSend" runat="server" OnClick="cmdSend_Click" Text="Upload"/></td>
</tr></table>
</form>
<br><br><br><br><br>
<h5><a href=importc.aspx class=linkButton title='Import Customer'>Import Customer</a></h5>
