<script runat=server>

protected void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("administrator"))
		return;
	
	PrintAdminHeader();
	PrintAdminMenu();

	if(Request.Form["cmd"] == "Convert")
	{
		if(!DoConvert())
			Response.Write("<br><h3>Error</h3>");
	}

//	if(!IsPostBack && !m_bFormPrinted)
	{
		Response.Write("<form action=? method=post>");
//		Response.Write("<textarea name=sql rows=10 cols=90>");
//		Response.Write(Session["tools_sql"]);
//		Response.Write("</textarea><br><input type=submit name=cmd value='Execute SQL'>");
//		Response.Write("<input type=submit name=cmd value='Query ODBC'>");
		Response.Write("<textarea name=strin rows=10 cols=110>");
		Response.Write(Session["mytools_strin"]);
		Response.Write("</textarea><br>");
		Response.Write("<input type=submit name=cmd value='Convert'><br>");
		Response.Write("<textarea name=str rows=10 cols=110>");
		Response.Write(Session["mytools_strout"]);
		Response.Write("</textarea>");
		Response.Write("</form>");
	}
}

bool DoConvert()
{
	string si = Request.Form["strin"];
	if(si == null || si == "")
		return true;

	Session["mytools_strin"] = si;

	string so = "";
	string sh = "";
	int p = 0;
	int q = 0;
	int i = 0;
	bool bCR = false;
	p = si.IndexOf(" ");
	q = si.IndexOf("\r\n");
	if(q > 0 && q < p)
	{
		p = q;
		bCR = true;
	}

	while(si.Length > 0 && p > 0)
	{
		if(i++ > 10000)
			break;

		if(si.Length > 1)
		{
			if(si.Substring(0, 2) == "\r\n")
			{
				so += "\r\n";
				si = si.Substring(2, si.Length - 2);
				p = si.IndexOf(" ");
				q = si.IndexOf("\r\n");
				if(q > 0 && q < p)
				{
					p = q;
					bCR = true;
				}
				continue;
			}
		}

		sh = si.Substring(0, p);
		p++;
		if(bCR)
			p++; //get \r\n

		si = si.Substring(p, si.Length - p);
		try
		{
			int sn = int.Parse(sh, NumberStyles.HexNumber);
			so += InvertReverse(sn);
		}
		catch(Exception e)
		{
			so += sh;
		}

		if(!bCR)
		{
			so += " ";
		}
		else
		{
			so += "\r\n";
			bCR = false;
		}

		p = si.IndexOf(" ");
		q = si.IndexOf("\r\n");
		if(q > 0 && q < p)
		{
			p = q;
			bCR = true;
		}
	}

	if(si.Length > 0)
	{
		try
		{
			int sn = int.Parse(si, NumberStyles.HexNumber);
			so += InvertReverse(sn);
		}
		catch(Exception e)
		{
			so += si;
		}
	}

	Session["mytools_strout"] = so;

	return true;
}

string InvertReverse(int n)
{
	byte m = (Byte)n;
	byte o = 0;

	byte a = 0x80;
	byte x = (byte)(m & a); //extract the most left one
//DEBUG("m=", m.ToString("x"));
	x >>= 7;
//DEBUG("x=", x.ToString("x"));
	o |= x;
//DEBUG("o=", o.ToString("x"));

	a = 0x40;
	x = (byte)(m & a);
	x >>= 5;
	o |= x;

	a = 0x20;
	x = (byte)(m & a);
	x >>= 3;
	o |= x;

	a = 0x10;
	x = (byte)(m & a);
	x >>= 1;
	o |= x;

	//half done
	a = 0x08;
	x = (byte)(m & a);
	x <<= 1;
	o |= x;
	
	a = 0x04;
	x = (byte)(m & a);
	x <<= 3;
	o |= x;
	
	a = 0x02;
	x = (byte)(m & a);
	x <<= 5;
	o |= x;
	
	a = 0x01;
	x = (byte)(m & a);
	x <<= 7;
	o |= x;

//	o = m;
	o = (Byte)~o;
	string s = o.ToString("x").ToUpper();
	if(s.Length == 1)
		s = "0" + s;
	return s;
}

</script>
