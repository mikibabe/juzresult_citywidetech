<!-- #include file="resolver.cs" -->
<!-- #include file="statement.cs" -->
<script runat=server>

bool bSortAscend = false;	//list records order by balance in ASC or DESC

DataSet dsc = new DataSet();

void SmailPage_Load()
{
	if(Request.QueryString["reset"] == "1")
		Session["smail_already_sent"] = null;

	if(Request.Form["cmd"] != null && Request.Form["cmd"] == " Send Statement ")
	{
		DoMailStatement();
		Response.Write("<center><h5>You have succesfully sent statement notice to customers</h5>");
		Response.Write("<input type=button value='Send Others' class=linkButtonCenter title='Send Others' onclick=window.location=('smail.aspx?reset=1')></center>");
	//	return;
	}
	else if(Request.Form["cmd"] == " Print Statement ")
	{
		string stylesheet = "<STYLE TYPE='text/css'> P.breakhere {page-break-before: always}</STYLE>"; 
		
		Response.Write(stylesheet);
		Response.Write("<body onload=window.print()>");
		DoPrintStatement();
		Response.Write("</body>");
	}
	else
	{
		PrintAdminMenu();
		if(!GetStatementList())
			return;

		MyDrawTable();
		PrintAdminFooter();
	}

	return;
}

bool GetStatementList()
{
	string sc = " SELECT c.id, c.trading_name, c.name, c.city, c.balance ";
	sc += ", c.email, c.credit_limit, e.name AS credit_terms ";
	sc += " FROM card c JOIN enum e ON e.id = c.credit_term ";
	sc += " WHERE e.class = 'credit_terms' ";
	sc += " AND c.balance > 0 ";
	if(Session["smail_already_sent"] != null)
		sc += " AND c.id NOT IN(" + Session["smail_already_sent"].ToString() + ") ";
	if((Request.QueryString["type"] != null && Request.QueryString["type"] != "") && Request.QueryString["type"] != "all")
		sc += " AND c.type = "+ Request.QueryString["type"].ToString() + "";
	if(Request.QueryString["type"] == "all")
		sc += "";
	if(bSortAscend)
		sc += " ORDER BY c.balance";
	else
		sc += " ORDER BY c.balance DESC";

	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dsc, "card");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void MyDrawTable()
{
	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
	string s_type = "";
	if(Request.QueryString["type"] != null && Request.QueryString["type"] != "")
		s_type = Request.QueryString["type"].ToString();
	int rows = 0;
	if(dsc.Tables["card"] != null)
		rows = dsc.Tables["card"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.PageSize = 20;
	m_cPI.URI = "?type="+ s_type +"&r=" + DateTime.UtcNow.AddHours(12).ToOADate();
	int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	//Header
	Response.Write("<br><h3><center>Mail Statement</center></h3>");
	
	Response.Write("<form action=? method=post>");
	Response.Write("<table width=95% align=center valign=top cellspacing=1 cellpadding=0 border=0");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td colspan=8>");
	Response.Write(sPageIndex);
	Response.Write("&nbsp;<a title='click to list only suppliers' href='smail.aspx?reset=1&type=3' class=o>Suppliers</a>|");
	Response.Write("<a title='click to list only dealers' href='smail.aspx?reset=1&type=2' class=o>Dealers</a>|");
	Response.Write("<a title='click to list only customers' href='smail.aspx?reset=1&type=1' class=o>Customers</a>|");
	Response.Write("<a title='click to list all' href='smail.aspx?reset=1&type=all' class=o>All</a>");
	Response.Write("</td>");//<td colspan><input type=text name=search value=''><input type=submit name=cmd value='Search' "+ Session["button_style"] +">");
	Response.Write("</td></tr>");

	Response.Write("<tr class=tableHeader>");
	
	Response.Write("<th >Company</th>");
	Response.Write("<th >Name</th>");
	Response.Write("<th >E-mail Address</th>");
//	Response.Write("<th>City</th>");
	Response.Write("<th >Credit Term</th>");
	Response.Write("<th >Credit Limit</th>");
	Response.Write("<th >Balance</th>");
	Response.Write("<th >&nbsp;&nbsp;&nbsp;</th></tr>");

	bool bAlterColor = false;
	int iRowPos = 0;
	for(; i < rows && i < end; i++)
	{
		DataRow dr = dsc.Tables["card"].Rows[i];
		//string id = dr["id"].ToString();
		string s_tradeName = dr["trading_name"].ToString();
		string s_name = dr["name"].ToString();
		string s_email = dr["email"].ToString();
//		string s_city = dr["city"].ToString();
		string s_balance = dr["balance"].ToString();
		string s_credit_limit = dr["credit_limit"].ToString();
		string s_credit_terms = dr["credit_terms"].ToString();
		
		CResolver rs = new CResolver();
		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" class=rowColor");
		bAlterColor = !bAlterColor;
		Response.Write(">");
		Response.Write("<td>" + s_tradeName + "</td>");

		Response.Write("<td>" + s_name + "</td>");
		Response.Write("<td>" + s_email + "</td>");
//		Response.Write("<td>" + s_city + "</td>");
		Response.Write("<td>" + s_credit_terms + "</td>");
		Response.Write("<td align=right>" + double.Parse(s_credit_limit).ToString("c") + "</td>");
		Response.Write("<td align=right>" + double.Parse(s_balance).ToString("c")+ "</td>\r\n");
		string sTicked = "sTicked" + iRowPos.ToString();
		Response.Write("<td align=center><input type=checkbox name="+sTicked+" >");
		string sCardID = "sCardID" + iRowPos.ToString();
		Response.Write("<input type=hidden name="+sCardID+" value='" + dr["id"].ToString() + "'></td></tr>\r\n");
		iRowPos = iRowPos + 1;;
	}
	
	Response.Write("</table><input type=hidden name=TotalRows value='" + iRowPos.ToString() + "'><br>");
	Response.Write("<div class=sendMailButtonHolder align=right><input type=submit class=sendStatementButton");
	Response.Write(" name=cmd value=' Send Statement ' onclick=\"if(!confirm('Email Statement...')){return false;}\">");
	Response.Write("<input type=submit class=printStatementButton");
	Response.Write(" name=cmd value=' Print Statement '></div>");

	Response.Write("</from>");
}

void DoPrintStatement()
{

	m_timeOpt = "4";
	string sCardID = "";
	string s_mailbody = "";
	int oldid = 1;
	
//	s_mailbody = "<STYLE TYPE='text/css'> P.breakhere  {page-break-before: always}</STYLE>";
//	s_mailbody = "<STYLE TYPE='text/css'> H2  {page-break-before: always}</STYLE>";
	int nCt = 0;
	bool bFirstPrint = false;
	string PrintPageBreak = "";
	for(int i=0; i < MyIntParse(Request.Form["TotalRows"].ToString()); i++)
	{
		string sRow = "sTicked" + i.ToString();
		string sRowCardID = "sCardID" + i.ToString();
	
		if(Request.Form[sRow] == "on")
		{ 
			nCt++;
			sCardID = Request.Form[sRowCardID];

			m_custID = sCardID;
			GetSelectedCust(sCardID);
			GetInvRecords(sCardID);
						
			s_mailbody = PrintStatmentDetails();
			PrintPageBreak = "<P CLASS='breakhere'>";
			
			if(bFirstPrint)
				Response.Write(PrintPageBreak);	
			Response.Write(s_mailbody);
			bFirstPrint = true;
		}
		
	
	}
	return;

}

void DoMailStatement()
{
	m_timeOpt = "4";
	string sCardID = "";
	string s_mailbody = "";
	
	for(int i=0; i < MyIntParse(Request.Form["TotalRows"].ToString()); i++)
	{
		

		string sRow = "sTicked" + i.ToString();
		string sRowCardID = "sCardID" + i.ToString();
	
		if(Request.Form[sRow] == "on")
		{ 
			sCardID = Request.Form[sRowCardID];

			m_custID = sCardID;
			GetSelectedCust(sCardID);
			GetInvRecords(sCardID);

			s_mailbody = PrintStatmentDetails();
//DEBUG(" smailbody = ", s_mailbody);
			string mFrom = m_sSalesEmail; //Session["email"].ToString();
			
			//sent to account payable email if exists
			string mTo = dst.Tables["cust_gen"].Rows[0]["ap_email"].ToString();
			if(mTo == "")
				mTo = dst.Tables["cust_gen"].Rows[0]["email"].ToString();
			msgMail.Subject = "Statement Notice.";
			msgMail.Body = s_mailbody;
            SendEmail(mFrom, mFrom, mTo, mSubject, strBody);
			
//Response.Write(s_mailbody);
		}
		
		//remember
		string s = "";
		if(Session["smail_already_sent"] != null)
			s = Session["smail_already_sent"].ToString() + ", " + Request.Form[sRowCardID];
		else 
			s = Request.Form[sRowCardID];
		Session["smail_already_sent"] = s;
	}
	return;
}


</script>


