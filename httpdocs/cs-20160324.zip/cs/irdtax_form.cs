<!-- #include file="page_index.cs" -->
<script runat=server>
/*Change gst formula
 *  $ * 3 /23
 */



string m_id = ""; //for restore
string m_type = "0";
string m_datePeriod = "";
string m_dateSql = "";
string m_code = "";
string m_branchID = "1";
string[] m_EachMonth = new string[13];

DataRow[] m_dra = null;

double m_dSales = 0;
double m_dSalesNOGST = 0;
double m_dPurchase = 0;

string m_sdDay = "0";
string m_sdMonth = "0";
string m_sdFrom = "";
string m_sdTo = "";
int m_nPeriod = -1;
double m_ird_rate = 3;
double m_ird_rate2 = 23;

string IRD_TAX_FORM = "";

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck(""))
		return;
	//monthly name
	m_EachMonth[0] = "JAN";
	m_EachMonth[1] = "FEB";
	m_EachMonth[2] = "MAR";
	m_EachMonth[3] = "APR";
	m_EachMonth[4] = "MAY"; 
	m_EachMonth[5] = "JUN";
	m_EachMonth[6] = "JUL";
	m_EachMonth[7] = "AUG";
	m_EachMonth[8] = "SEP";
	m_EachMonth[9] = "OCT";
	m_EachMonth[10] = "NOV";
	m_EachMonth[11] = "DEC";
	//----
	//session control
	IRD_TAX_FORM = ReadSitePage("ird_tax_return_form");	

	m_ird_rate = double.Parse(GetSiteSettings("IRD_Tax_return_rate", "3", false));
    m_ird_rate2 = double.Parse(GetSiteSettings("IRD_Tax_return_rate2", "23", false));
	if(Request.QueryString["plist"] == "1")
	{
		PrintAdminHeader();
		PrintAdminMenu();
		DoQueryTaxForm("", true);
		PrintAdminFooter();
		return;
	}
	if(Request.QueryString["taxid"] != null)
	{
		if(TSIsDigit(Request.QueryString["taxid"].ToString()))
			DoQueryTaxForm(Request.QueryString["taxid"].ToString(), false);
		else
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<p><p><center><h4>Invalid ID!!!");
			Response.Write("<br><br><a href='"+ Request.ServerVariables["URL"] +"?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' class=o> << Back</a>");
			PrintAdminFooter();
		}
		return;
	}
	if(Request.Form["cmd"] == "Save/Print")
	{
//DEBUG("fromatdaet = ", Request.Form["datefrom"].ToString());
		if(DoSaveTaxReturn())
			return;
	}
	if(Session["branch_support"] != null)
	{
		if(Request.Form["branch"] != null)
			m_branchID = Request.Form["branch"];
		else if(Request.QueryString["branch"] != null && Request.QueryString["branch"] != "")
			m_branchID = Request.QueryString["branch"];
		else if(Session["branch_id"] != null)
			m_branchID = Session["branch_id"].ToString();
	}
	if(Request.Form["period"] != null)
		m_nPeriod = MyIntParse(Request.Form["period"]);
	if(Request.Form["Datepicker1_day"] != null)
	{
		string day = Request.Form["Datepicker1_day"];
		string monthYear = Request.Form["Datepicker1_month"] + "-" +Request.Form["Datepicker1_year"];
		m_sdFrom = day + "-" + monthYear;
	
		day = Request.Form["Datepicker2_day"];
		monthYear = Request.Form["Datepicker2_month"] + "-" + Request.Form["Datepicker2_year"];
		m_sdTo = day + "-" + monthYear;
	}
	
	if(Request.Form["cmd"] == null)
	{
		PrintMainPage();
		return;
	}
	switch(m_nPeriod)
	{
	case 0:
		m_datePeriod = "Continue";
		break;
	case 1:
		m_datePeriod = "Current Month";
		break;
	case 2:
		m_datePeriod = "Last Month";
		break;
	case 3:
		m_datePeriod = "Last Three Month";
		break;
	case 4:
		m_datePeriod = "From <font color=green>" + m_sdFrom + "</font>";
		m_datePeriod += " To <font color=red>" + m_sdTo + "</font>";
		break;
	default:
		break;
	}

	PrintAdminHeader();
	PrintAdminMenu();

	PrintStatement();

	PrintAdminFooter();
}

bool DoQueryLastTaxReturn()
{
	string sc = " SELECT TOP 1 date_from, date_to, ISNULL(DATEDIFF(month, date_from, date_to),0) AS month_diff, iSNULL(DATEDIFF(week, date_from, date_to),0) AS week_diff ";
	sc += " FROM ird_tax_return  ";
	sc += " WHERE date_from IS NOT NULL AND date_to IS NOT NULL ";
	sc += " ORDER BY date_to DESC ";
	int rows = 0;
	try
	{
		SqlDataAdapter myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "ird_date");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows == 1)
	{
//		int week_diff = int.Parse(dst.Tables["ird_date"].Rows[0]["week_diff"].ToString());
		int month_diff = int.Parse(dst.Tables["ird_date"].Rows[0]["month_diff"].ToString());
		string sdFrom = dst.Tables["ird_date"].Rows[0]["date_from"].ToString();
		string sdTo = dst.Tables["ird_date"].Rows[0]["date_to"].ToString();
		if(month_diff > 0)
		{
			m_sdMonth = month_diff.ToString();
		}
		
	}
	return true; 
}

void PrintMainPage()
{
	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<form name=f action="+ Request.ServerVariables["URL"] +"?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " method=post>");

	Response.Write("<br><center><h3>Goods and services tax return</h3>");
	
	if(Session["branch_support"] != null)
	{
//		string b_uri = Request.ServerVariables["URL"] +"?r="+ DateTime.UtcNow.AddHours(12).ToOADate();
//		b_uri += "&branch=";
		Response.Write("<b>Branch : </b>");
		PrintBranchNameOptions(m_branchID, "");
	}

	Response.Write("<p><table align=center cellspacing=1 cellpadding=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr class=tableHeader>");
	Response.Write("<td colspan=2 ><b>Date Period</b></td></tr>");

	int i = 1;
	datePicker(); //call date picker function from common.cs
	Response.Write("<tr><td>");
	string s_day = DateTime.UtcNow.AddHours(12).ToString("dd");
	string s_month = DateTime.UtcNow.AddHours(12).ToString("MM");
	string s_year = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	Response.Write("<tr><td>");
	Response.Write(" FROM: ");
	Response.Write("<select name='Datepicker1_day' onChange=\"tg_mm_setdays('document.forms[0].Datepicker1',1);\">");
	for(int d=1; d<32; d++)
	{
		Response.Write("<option value="+ d +">"+d+"</option>");
	}
	Response.Write("</select>");
	Response.Write("<select name='Datepicker1_month' onChange=\"tg_mm_setdays('document.forms[0].Datepicker1',1);\" style=''>");

	for(int m=1; m<13; m++)
	{
		string txtMonth = "";
		txtMonth = m_EachMonth[m-1];
		if(int.Parse(m_sdMonth) > 0)
			s_month = (int.Parse(s_month) - int.Parse(m_sdMonth)).ToString();
		if(int.Parse(s_month) == m)
			Response.Write("<option value="+m+" selected>"+txtMonth+"</option>");
		else
			Response.Write("<option value="+m+">"+txtMonth+"</option>");
	}
	
	Response.Write("</select>");
	Response.Write("<select name='Datepicker1_year' onChange=\"tg_mm_setdays('document.forms[0].Datepicker1',1);\" style=''>");
	for(int y=2000; y<int.Parse(s_year)+1; y++)
	{
		if(int.Parse(s_year) == y)
			Response.Write("<option value="+y+" selected>"+y+"</option>");
		else
			Response.Write("<option value="+y+">"+y+"</option>");
	}
	Response.Write("</select>");
	Response.Write("<input type=hidden name='Datepicker1'>");
	Response.Write("<input type=hidden name='Datepicker1_conv'>");
	Response.Write("<script language=javascpt> tg_mm_setdays('document.forms[0].Datepicker1',1)");
	Response.Write("</script ");
	Response.Write(">");
	//Response.Write("</td>");
		//------ start second display date -----------
	Response.Write(" &nbsp; TO: ");
	Response.Write("<select name='Datepicker2_day' onChange=\"tg_mm_setdays('document.forms[0].Datepicker2',1);\" style=''>");
	for(int d=1; d<32; d++)
	{
		if(int.Parse(s_day) == d)
			Response.Write("<option value="+ d +" selected>"+d+"</option>");
		else
			Response.Write("<option value="+ d +">"+d+"</option>");
	}
	Response.Write("</select>");
	Response.Write("<select name='Datepicker2_month' onChange=\"tg_mm_setdays('document.forms[0].Datepicker2',1);\" style=''>");

	for(int m=1; m<13; m++)
	{
		string txtMonth = "";
		txtMonth = m_EachMonth[m-1];
		if(int.Parse(s_month) == m)
			Response.Write("<option value="+m+" selected>"+txtMonth+"</option>");
		else
			Response.Write("<option value="+m+">"+txtMonth+"</option>");
	}
	
	Response.Write("</select>");
	Response.Write("<select name='Datepicker2_year' onChange=\"tg_mm_setdays('document.forms[0].Datepicker2',1);\" style=''>");
	for(int y=2000; y<int.Parse(s_year)+1; y++)
	{
		if(int.Parse(s_year) == y)
			Response.Write("<option value="+y+" selected>"+y+"</option>");
		else
			Response.Write("<option value="+y+">"+y+"</option>");
	}
	Response.Write("</select>");
	Response.Write("<input type=hidden name='Datepicker2'>");
	Response.Write("<input type=hidden name='Datepicker2_conv'>");
	Response.Write("<script language=javascpt> tg_mm_setdays('document.forms[0].Datepicker2',1)");
	Response.Write("</script ");
	Response.Write(">");
	Response.Write("</td>");
	Response.Write("</tr>");
	
	Response.Write("<td align=right><input type=button value='View List' onclick=\"window.location=('irdtax_form.aspx?plist=1&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"')\" "+ Session["button_style"] +"><input type=submit name=cmd value='Print Form'  "+ Session["button_style"] +" ></td></tr>");

	Response.Write("</table>");
	Response.Write("</form>");
	
}

bool DoQueryTaxForm(string taxid, bool blist)
{
//	string sc = " SELECT record_date, date_from, date_to, total_sales, zero_rate_sales, sales_adjust, total_purchase ";
//	sc += " ,credit_adjust, topaid , ird_rate ";
	string sc = " SELECT ird.* ";
	sc += " ,ird.total_sales - ird.zero_rate_sales AS box7, (ird.total_sales - ird.zero_rate_sales) / ird.ird_rate AS box8 ";
	sc += ", ((ird.total_sales - ird.zero_rate_sales) / ird.ird_rate) + ird.sales_adjust AS box10 ";
	sc += " ,ird.total_purchase / ird.ird_rate AS box12, (ird.total_purchase / ird.ird_rate) + ird.credit_adjust AS box14 ";
	sc += " , c.name AS staff_name ";
	if(Session["branch_support"] != null)
		sc += " , b.name AS branch_name ";
	sc += " FROM ird_tax_return ird ";
	sc += " JOIN card c ON c.id = ird.record_by ";

	if(Session["branch_support"] != null)
		sc += " JOIN branch b ON b.id = ird.branch ";
	if(!blist)
		sc += " WHERE ird.id = "+ taxid;
	if(Session["branch_support"] != null)
		sc += " AND ird.branch = "+ m_branchID;
	sc += " ORDER BY ird.record_date DESC ";
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "taxform");
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	 if(!blist)
	 {
		if(rows == 1)
		{
			DataRow dr = dst.Tables["taxform"].Rows[0];
			double box15 = 0;
			string stoPaid = "GST to pay";
			if(MyBooleanParse(dr["topaid"].ToString()))
	//		if(MyDoubleParse(dr["box10"].ToString()) > MyDoubleParse(dr["box14"].ToString()))
			{
				box15 = MyDoubleParse(dr["box10"].ToString()) - MyDoubleParse(dr["box14"].ToString());
			}
			else
			{
				box15 = MyDoubleParse(dr["box14"].ToString()) - MyDoubleParse(dr["box10"].ToString());
				stoPaid = "Refund";
			}

			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX5", MyDoubleParse(dr["total_sales"].ToString()).ToString("c"));	
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX6", MyDoubleParse(dr["zero_rate_sales"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX7", MyDoubleParse(dr["box7"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX8", MyDoubleParse(dr["box8"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX9", MyDoubleParse(dr["sales_adjust"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX10", MyDoubleParse(dr["box10"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX11", MyDoubleParse(dr["total_purchase"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX12", MyDoubleParse(dr["box12"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX13", MyDoubleParse(dr["credit_adjust"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX14", MyDoubleParse(dr["box14"].ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@BOX15", MyDoubleParse(box15.ToString()).ToString("c"));
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@DATEFROM", dr["date_from"].ToString());
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@DATETO", dr["date_to"].ToString());
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@RECORD_DATE", dr["record_date"].ToString());
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@ISREFUND",  stoPaid);
			IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@IRD_RATE",  dr["ird_rate"].ToString());
            IRD_TAX_FORM = IRD_TAX_FORM.Replace("@@_IRD_RATE",  dr["ird_rate2"].ToString());

			Response.Write(IRD_TAX_FORM);
		}
	}
	else
	{
		
			//paging class
		PageIndex m_cPI = new PageIndex(); //page index class
		if(Request.QueryString["p"] != null)
			m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
		if(Request.QueryString["spb"] != null)
			m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);
		
		m_cPI.PageSize = 40;
		m_cPI.TotalRows = rows;
		int i = m_cPI.GetStartRow();
		m_cPI.URI = "?plist=1";
		int end = i + m_cPI.PageSize;
		
		string sPageIndex = m_cPI.Print();

		Response.Write("<br><center><h3>IRD Tax Return LIST</h3>");
		Response.Write("<p><table align=center width=60% cellspacing=2 cellpadding=2 bordercolor=#EEEEEE bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr><td colspan=6>" + sPageIndex + " | <a href='irdtax_form.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' class=o> Back </td></tr>");
		Response.Write("<tr align=left bgcolor=#EEEEE><th>ID</td><th>RECORDED_BY</td><th>RECORDED_DATE</td><th>TYPE</td>");
		if(Session["branch_support"] != null)
			Response.Write("<th>BRANCH</td>");
		Response.Write("<th></td></tr>");
			string uri = "irdtax_form.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&taxid=";
		bool bAlter = false;
	

		//	for(int i=0; i<rows; i++)
		for(; i < rows && i < end; i++)
		{
			DataRow dr = dst.Tables["taxform"].Rows[i];
			string id = dr["id"].ToString();
			string name = dr["staff_name"].ToString();
			string record_date = dr["record_date"].ToString();
			string istopaid = dr["topaid"].ToString();
			string sMSG = "";
			uri += id;
			if(MyBooleanParse(istopaid))
				sMSG = "Paid GST";
			else
				sMSG = "Refund GST";
			string branch = dr["branch_name"].ToString();
			Response.Write("<tr");
			if(bAlter)
				Response.Write(" bgcolor=#EEEEEE ");
			Response.Write(">");
			bAlter = !bAlter;
			Response.Write("<td>"+ id +"</td>");
			Response.Write("<td>"+ name +"</td>");
			Response.Write("<td>"+ record_date +"</td>");
			Response.Write("<td>"+ sMSG +"</td>");
			if(Session["branch_support"] != null)
				Response.Write("<td>"+ branch +"</td>");
			Response.Write("<td><a title='view ird tax return' href='" + uri +"' class=o target=blank>View</td>");
			Response.Write("</tr>");
				
		}	
		Response.Write("</table>");
	}
	return true;

}

bool DoSaveTaxReturn()
{
	string box9 = Request.Form["sales_adjust"];
	string box13 = Request.Form["purchase_adjust"];
	string box10 = Request.Form["box10"];
	string box14 = Request.Form["box14"];
//	DEBUG("dadt  =", Request.Form["datefrom"].ToString());
int ntopaid = 1;
	if(MyDoubleParse(box10) < MyDoubleParse(box14))
		ntopaid = 0;

	string sc = " BEGIN TRANSACTION ";
	sc += " SET DATEFORMAT dmy INSERT INTO ird_tax_return ( record_date, record_by, date_from, date_to, total_sales ";
	sc += " ,zero_rate_sales, sales_adjust, total_purchase, credit_adjust, topaid, branch , ird_rate, ird_rate2)";
	sc += " values (getdate(), "+ Session["card_id"] +", '"+ Request.Form["datefrom"] +"', '"+ Request.Form["dateto"] +"' ";
	sc += " , "+ Request.Form["boxvalue5"] +", "+ Request.Form["boxvalue6"] +", "+ box9 +", "+ Request.Form["boxvalue10"] +", "+ box13 +", "+ ntopaid +", "+ Request.Form["branch"] +" ";
	sc += ", "+ Request.Form["ird_rate"] +" ";
    sc += ", "+ Request.Form["ird_rate2"] +" ";
	sc += ")";
	sc += " SELECT IDENT_CURRENT('ird_tax_return') AS id ";
	sc += " COMMIT ";
	string taxID = "";	
//DEBUG("s c= ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dst, "taxid") != 1)
		{
			Response.Write("<br><br><center><h3>Error getting poid IDENT");
			return false;
		}
		taxID = dst.Tables["taxid"].Rows[0]["id"].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(taxID != "")
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=irdtax_form.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "&taxid="+ taxID +"\">");

//	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=irdtax_form.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "&taxid="+ taxID +"\">");
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
//IRD tax return 
void PrintStatement()
{

	int i = 0;	
	double dSales = Math.Round(GetCurrenGSTCollect(false),2);
	double dSalesNOGST = Math.Round(GetCurrenGSTCollect(true),2);
	double dPurchase = Math.Round(GetCurrenGSTPaid(),2);
	m_dSales = dSales;
	m_dSalesNOGST = dSalesNOGST;
	m_dPurchase = dPurchase;

	double dBox7 = Math.Round(dSales - dSalesNOGST, 2);
	double dBox8 = Math.Round(dBox7 * m_ird_rate / m_ird_rate2, 2);
	double dBox9 = 0;
	double dBox10 = Math.Round(dBox8 + dBox9,2);
	double dBox11 = Math.Round(dPurchase,2);
	double dBox12 = Math.Round(dBox11 * m_ird_rate / m_ird_rate2,2);
	double dBox13 = 0;
	double dBox14 = Math.Round(dBox12 + dBox13,2);
	double dBox15 = 0;
	bool btoPaid = false;
	if(dBox10 > dBox14)
	{
		dBox15 = Math.Round(dBox10 - dBox14,2);
		btoPaid = true;
	}
	else
	{
		dBox15 = Math.Round(dBox14 - dBox10,2);
	}

	Response.Write("<form name=frm method=post>");
	Response.Write("<br><center><h3>Record and Adjust Tax Return</h3>");

	//call java function;
	vJAVACal();

	if(Session["branch_support"] != null)
	{	
		Response.Write(GetBranchName(m_branchID));
	}
	string keyEnter = " onkeydown=\" if(event.keyCode==13) event.keyCode=9;\" onchange=\"Calstotal(this.value);\" style='text-align: right'";

	Response.Write("<p>Date From: <b>"+ m_sdFrom +"</b> To: <b>"+ m_sdTo +" ");
	Response.Write("<p><table align=center cellspacing=3 cellpadding=4 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	//***hidden values
	Response.Write("<input type=hidden name=boxvalue5 value="+ dSales +">");
	Response.Write("<input type=hidden name=boxvalue6 value="+ dSalesNOGST +">");
	Response.Write("<input type=hidden name=boxvalue7 value="+ dBox7 +">");
	Response.Write("<input type=hidden name=boxvalue8 value="+ dBox8 +">");
	Response.Write("<input type=hidden name=boxvalue10 value="+ dPurchase +">");
	Response.Write("<input type=hidden name=boxvalue11 value="+ dBox11 +">");
	Response.Write("<input type=hidden name=boxvalue12 value="+ dBox12 +">");
	Response.Write("<input type=hidden name=boxvalue14 value="+ dBox14 +">");
	Response.Write("<input type=hidden name=boxvalue15 value="+ dBox15 +">");
	Response.Write("<input type=hidden name=datefrom value='"+ m_sdFrom +"'>");
	Response.Write("<input type=hidden name=dateto value='"+ m_sdTo +"'>");
	Response.Write("<input type=hidden name=branch value='"+ m_branchID +"'>");
	Response.Write("<input type=hidden name=ird_rate value='"+ m_ird_rate +"'>");
    Response.Write("<input type=hidden name=ird_rate2 value='"+ m_ird_rate2 +"'>");
	//*** end here

//	Response.Write("<tr class=tableHeader>");
	Response.Write("<tr><td>Total Sales and Income :</td><th>5</th><td><input type=text "+ keyEnter +" value="+ dSales +"></td></tr>");
	Response.Write("<tr><td>Zero-rated supplies included in Box 5 :</td><th>6</th><td><input type=text  "+ keyEnter +" value="+ dSalesNOGST +"></td></tr>");
	Response.Write("<tr><td>Subtract Box 6 from Box 5 :</td><th>7</th><td><input type=text  "+ keyEnter +" value="+ dBox7 +"></td></tr>");

	Response.Write("<tr><td>Multiply amount in Box 7 by ("+ m_ird_rate2 +") than Divide the amount in Box 7 by ("+ m_ird_rate +")  :</td><th>8</th><td><input type=text  "+ keyEnter +" name=box8 value="+ dBox8 +"></td></tr>");
	Response.Write("<tr><td><font color=red><b>Adjustments from your calculation sheet : *</td><th><font color=red>9</th><td><input type=text  "+ keyEnter +" name=sales_adjust value='0'></td></tr>");

	Response.Write("<tr><td>Add Boxes 8 and 9. Total GST Collect :</td><th>10</th><td><input type=text  "+ keyEnter +"  name=box10 value="+ dBox10 +"></td></tr>");
	Response.Write("<tr><td>Total Purchases and Expense :</td><th>11</th><td><input type=text "+ keyEnter +"  name=box11 value="+ dPurchase +"></td></tr>");

	Response.Write("<tr><td>Divide the amount in Box 11 by ("+ m_ird_rate +") :</td><th>12</th><td><input type=text "+ keyEnter +"  name=box12 value="+ dBox12 +"></td></tr>");
	Response.Write("<tr><td><font color=red><b>Credit adjustments :*</td><th><font color=red>13</th><td><input type=text name=purchase_adjust "+ keyEnter +"  value='0'></td></tr>");
	Response.Write("<tr><td>Add Box 12 and 13. Total GST Credit :</td><th>14</th><td><input type=text "+ keyEnter +"  name=box14 value="+ dBox14 +"></td></tr>");

	Response.Write("<tr><td>Print the Different between Box 10 and 14 ");
/*	if(!btoPaid)
		Response.Write("<i>(Refund)</i>");
	else
		Response.Write("<i>(GST to pay)</i>");
*/
	Response.Write(":</td><th>15</th><td><input type=text "+ keyEnter +"  name=box15 value="+ dBox15 +"></td></tr>");
	Response.Write("<tr><td colspan=3 align=right><input type=button value='Cancel' onclick=\"window.location=('irdtax_form.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"')\" "+ Session["button_style"] +">");
	Response.Write("<input type=button value='View List' onclick=\"window.location=('irdtax_form.aspx?plist=1&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"')\" "+ Session["button_style"] +"><input type=reset name=cmd value='refresh' "+ Session["button_style"] +"><input type=submit name=cmd value='Save/Print'  "+ Session["button_style"] +" ");
	Response.Write(" onclick=\" return confirm('Please check all data are CORRECT before processing...');\" ");
	Response.Write("></td></tr>");
	Response.Write("</table>");
//	Response.Write("</form>");
//DEBUG("dsae = ", dSales);
//DEBUG("dpruchase = ", dPurchase);
//DEBUG("dsae = ", dSalesNOGST);

//	return true;
}

void vJAVACal()
{
	Response.Write("<script language=javascript>");
	string s = @"
		function Calstotal(dvalue)
	{
		var box9 = eval(document.frm.sales_adjust.value);
//	window.alert(box9);
		var box10 = eval(document.frm.box8.value) + eval(box9) ;

		document.frm.box10.value = eval(box10).toFixed(2);

		var box13 = eval(document.frm.purchase_adjust.value);
		var box14 = eval(document.frm.box12.value) + eval(box13);

		document.frm.box14.value = eval(box14).toFixed(2);

		var box15 = 0;
		if(eval(box10) > eval(box14))
			box15 = eval(box10) - eval(box14); 
		else
			box15 = eval(box14) - eval(box10); 
		document.frm.box15.value = eval(box15).toFixed(2);

	}

		";

	Response.Write(s);
	Response.Write("</script");
	Response.Write(">");
	
}

string GetBranchName(string branchid)
{
	string sc = " SELECT name FROM branch WHERE id = "+ branchid;
	int rows = 0;
	string branch_name = "Auckland";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "branch");
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "Auckland";
	}
	if(rows == 1)
		branch_name = dst.Tables["branch"].Rows[0][0].ToString();

	return branch_name;
}

double GetCurrenGSTPaid()
{	
	string sqlLoss = "";
	string sqlExpense = "";
	string sqlTrans = "";
	string sqlPurchase = "";
	string sqlTax = "";
	string sqlOld = "";

	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	double dValue = 0;
	if(dst.Tables["purchase_exp"] != null)
		dst.Tables["purchase_exp"].Clear();

	string sc = " SET DATEFORMAT dmy ";
    sc += "	SELECT isnull(SUM(p.tax / p.exchange_rate),0) ";
	sc += " AS tax, isnull(SUM(p.total / p.exchange_rate),0) AS total, isnull(SUM(p.total_amount / p.exchange_rate),0) AS total_amount ";
    sc += " FROM purchase p LEFT OUTER JOIN ";
	sc += " card c ON c.id = p.supplier_id ";
	sc += " WHERE p.date_received IS NOT NULL "; // AND p.tax_date is NOT NULL ";
//	sc += " AND (p.date_received >= '"+ m_sdFrom +"'AND p.date_received <= '"+ m_sdTo +" 23:59') ";   
	sc += " AND (p.tax_date >= '"+ m_sdFrom +"'AND p.tax_date <= '"+ m_sdTo +" 23:59') ";   
	sc += " AND p.tax > 0 ";
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = "+ m_branchID +"";

	sc += " UNION ";
	sc += " SELECT isnull(SUM(ei.tax),0) , isnull(SUM(ei.total),0)  , isnull(SUM(e.total),0)  ";
	sc += " FROM expense e LEFT OUTER JOIN ";
	sc += " expense_item ei ON ei.id = e.id LEFT OUTER JOIN ";
	sc += " card c ON c.id = e.card_id LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = e.recorded_by INNER JOIN ";
	sc += " account a ON a.id = e.to_account ";
	sc += " WHERE 1 = 1 AND ei.tax > 0 ";
	sc += " AND (e.payment_date >= '"+ m_sdFrom +"'AND e.payment_date < '"+ m_sdTo +" 23:59') ";   
	if(Session["branch_support"] != null)
		sc += " AND e.branch = "+ m_branchID +"";

/*	sc += " UNION ";
	sc += " SELECT ISNULL(SUM(ct.total_gst), 0) AS tax, 0 AS total, ISNULL(SUM(ct.total_gst), 0)  ";
	sc += " AS total_amount ";
	sc += " FROM custom_tax ct LEFT OUTER JOIN ";
	sc += " card c ON c.id = ct.payee LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = ct.recorded_by";
	sc += " WHERE 1 = 1 ";
	sc += " AND (ct.statement_date >= '"+ m_sdFrom +"'AND ct.statement_date < '"+ m_sdTo +" 23:59') ";   
	if(Session["branch_support"] != null)
		sc += " AND ct.branch = "+ m_branchID +"";
*/
	sc += " UNION ";
	sc += " SELECT ISNULL(SUM(a.tax), 0) AS tax, ISNULL(SUM(a.total), 0) AS total,  ";
	sc += " ISNULL(SUM(a.total), 0) AS total_amount ";
	sc += " FROM assets a LEFT OUTER JOIN ";
	sc += " card c ON c.id = a.card_id LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = a.recorded_by";
	sc += " WHERE 1 = 1 ";
	sc += " AND (a.payment_date >= '"+ m_sdFrom +"'AND a.payment_date < '"+ m_sdTo +" 23:59') ";   
	if(Session["branch_support"] != null)
		sc += " AND a.branch = "+ m_branchID +"";

	int rows = 0;
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "purchase_exp");
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	for(int i=0; i<rows; i++)
		dValue += double.Parse(dst.Tables["purchase_exp"].Rows[i][2].ToString());
	

	return dValue;
	
}

double GetCurrenGSTCollect(bool bSalesNoGST)
{

	if(dst.Tables["sales_total"] != null)
		dst.Tables["sales_total"].Clear();
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	double dValue = 0;
	string sc = " SET DATEFORMAT dmy ";
    sc += " SELECT isnull(SUM(i.tax),0) AS gst_collect, isnull(SUM(i.total),0) AS total  ";
    sc += " FROM invoice i LEFT OUTER JOIN ";
    sc += " card c ON c.id = i.card_id ";
	sc += " WHERE 1=1 ";
	if(Session["branch_support"] != null)
		sc += " AND  i.branch = "+ m_branchID +" ";
	sc += " AND i.commit_date >= '"+ m_sdFrom +"'AND i.commit_date < '"+ m_sdTo +"' ";   
	if(bSalesNoGST)
		sc += " AND c.gst_rate = 0 ";
//	else
//		sc += " AND c.gst_rate <> 0 ";
	int rows = 0;
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "sales_total")>0)
			dValue = double.Parse(dst.Tables["sales_total"].Rows[0][1].ToString());
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}

	return dValue;
	
}


</script>
