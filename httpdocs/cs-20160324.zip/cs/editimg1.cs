<script runat=server>

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	
	if(Request.QueryString["t"] == "da")
	{
		DoDelPic();
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=editimg.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
		return;
	}
	PrintAdminHeader();
	PrintAdminMenu();
	Form1.Visible = true;
	ShowImages();
	LFooter.Text = m_sAdminFooter;
}

bool ShowImages()
{
	string imgPath = "../i";
	string strPath = Server.MapPath(imgPath);
strPath = "\\\\192.168.1.1\\c$\\html\\eznz\\nz\\wholesale\\admin\\i";
	if(!Directory.Exists(strPath))
		return false;

	strPath += "\\";

	StringBuilder sb = new StringBuilder();
	sb.Append("<table border=0><tr>");
	DirectoryInfo di = new DirectoryInfo(strPath);
	int n = 0;
	foreach (FileInfo f in di.GetFiles("*.*")) 
	{
		string ext = f.Extension.ToLower();
		if(ext != ".jpg" && ext != ".gif")
			continue;

		string s = f.FullName;
//DEBUG("s=", s);
		System.Drawing.Image im = System.Drawing.Image.FromFile(s);
		string file = s.Substring(strPath.Length, s.Length-strPath.Length);
//DEBUG("file=", file);
		string imgsrc = imgPath + "/" + file;
//		if(n == 0 || n == 3 || n == 6 || n == 9)
		sb.Append("</tr><tr>");
		sb.Append("<td valign=bottom><table><tr><td colspan=2><img src=" + imgsrc);
//		if(im.Width > 250)
//			Response.Write(" width=250");
		sb.Append(" border=0></td></tr>");
		sb.Append("<tr><td>" + f.Name + "</td>");
		sb.Append("<td>" + im.Width.ToString() + "x" + im.Height.ToString() + " " + (f.Length/1000).ToString() + "K ");
		if(f.Length > 20480)
			sb.Append(" <font color=red> * big file * </font>");
		sb.Append("</td>");
		sb.Append("<td align=right><a href=editimg.aspx?t=da&file=" + HttpUtility.UrlEncode(file));
		sb.Append(" class=o>DELETE</a></td></tr>");
		sb.Append("<tr><td>&nbsp;</td></tr></table></td>");
		im.Dispose();
		n++;
	}
	sb.Append("</tr></table>");
	sb.Append("<a href=editimg.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o>Back to View</a>");
	LOldPic.Text = "<b>" + n.ToString() + " Photo</b>";
	LOldPic.Text += sb.ToString();
	if(n > 0)
		return true;
	return false; //no pic
}

void DoDelPic()
{
	string file = Server.MapPath("../i/" + Request.QueryString["file"]);
//DEBUG("file=", file);
	File.Delete(file);
}

// Processes click on our cmdSend button
void cmdSend_Click(object sender, System.EventArgs e)
{
	// Check to see if file was uploaded
	if( filMyFile.PostedFile != null )
	{
		// Get a reference to PostedFile object
		HttpPostedFile myFile = filMyFile.PostedFile;

		string ext = Path.GetExtension(myFile.FileName);
		ext = ext.ToLower();
		if(ext != ".jpg" && ext != ".gif")
		{
			Response.Write("<h3>ERROR Only .jpg, .gif File Allowed</h3>");
			return;
		}

		// Get size of uploaded file
		int nFileLen = myFile.ContentLength; 
//DEBUG("nFileLen=", nFileLen);
		if(nFileLen > 204800)
		{
			Response.Write("<h3>ERROR Max File Size(200 KB) Exceeded. ");
			Response.Write(Path.GetFileName(myFile.FileName) + " " + (int)nFileLen/1000 + " KB </h3>");
			return;
		}

		// make sure the size of the file is > 0
		if( nFileLen > 0 )
		{
			// Allocate a buffer for reading of the file
			byte[] myData = new byte[nFileLen];

			// Read uploaded file from the Stream
			myFile.InputStream.Read(myData, 0, nFileLen);

			// Create a name for the file to store
			string strFileName = Path.GetFileName(myFile.FileName);
			string strPath = Server.MapPath("../i");
//			if(!Directory.Exists(strPath))
//				Directory.CreateDirectory(strPath);
			strPath += "\\";
			string purePath = strPath;
			strPath += strFileName;
			
//DEBUG("pathname=", strPath);

			// Write data into a file, overwrite if exists
			WriteToFile(strPath, ref myData);
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=editimg.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
		}
	}
	return;
}

// Writes file to current folder
void WriteToFile(string strPath, ref byte[] Buffer)
{
	// Create a file
	FileStream newFile = new FileStream(strPath, FileMode.Create);
	// Write data to the file
	newFile.Write(Buffer, 0, Buffer.Length);
	// Close file
	newFile.Close();
}
</script>


<form id="Form1" method="post" runat="server" enctype="multipart/form-data" visible=false>
<br>
<table width=70% align=center cellspacing=1 cellpadding=3 border=1 bgcolor=#FFFFFF bordercolorlight=#44444 bordercolordark=#AAAAAA style=font-family:Verdana;font-size:8pt;fixed>
<tr><td><font size=+1 color=red><b>Attach Images</b></font><br>

<table><tr>
<td><input id="filMyFile" type="file" size=50 runat="server"></td><td>&nbsp;</td>
<td><asp:button id="cmdSend" runat="server" OnClick="cmdSend_Click" Text="Upload"/></td>
</tr></table>

<br>
<asp:Label id=LOldPic runat=server/>
</td></tr></table>


</FORM>
<asp:Label id=LFooter runat=server/>