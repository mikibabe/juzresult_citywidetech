<!-- #include file="card_function.cs" -->

<script runat=server>

const string cols = "11";	//how many columns main table has, used to write colspan=
const string tableTitle = "Process Order";
const string thisurl = "esales.aspx";
bool bItemProcessing = false;
//bool m_bDodiscount = true;	//assess whether update account discount, HG 13.Aug.2002
bool m_bOrder = false;

string m_sDN = ""; //delivery notice sent to customer by email
string m_sInvoiceNumber;
string m_type;
string m_freight = "";
int page = 1;
const int m_nPageSize = 100; //how many rows in oen page
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
DataSet dsf = new DataSet();	//for getting freight

string m_cardID = "";
string m_customerEmail = "";
double m_dOldFreight = 0;
double m_dPrice = 0;
double m_dTotalOld = 0;

string m_shippingMethod = "1";
bool m_bSpecialShipto = false;
string m_specialShiptoAddr = "";
string m_pickupTime = "";

string m_delTicket = "";

bool m_bFreightCharged = false;


void Page_Load(Object Src, EventArgs E) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("manager"))
		return;

	string spage = Request.QueryString["p"];
	if(spage != null)
		page = int.Parse(spage);
	m_type = Request.QueryString["t"];
	m_sInvoiceNumber = Request.QueryString["i"];
	if(!TSIsDigit(m_sInvoiceNumber))
	{
		Response.Write("<h3>Wrong Invoice Number: " + m_sInvoiceNumber + "</h3>");
		return;
	}

	m_delTicket = Request.QueryString["delt"];
	if(m_delTicket != null && m_delTicket != "")
	{
		DoDelTicket();
//DEBUG("58DoDelTicket=", "ok");
        Response.Write("<meta http-equiv=\"refresh\" content=\"0; ");
		Response.Write(" URL=esales.aspx?i=" + m_sInvoiceNumber + "\">");
		return;
	}

	if(Session["shipping_ticket_count"] == null || (m_type != "continue" && Request.Form["cmd"] == null))
		Session["shipping_ticket_count"] = 0;

	if (!GetShipDetails())
		return;

	if(!GetCustomerDetails())
		return;

    
	if(Request.Form["ticket"] != null && Request.Form["ticket"] != "") //scan ticket
	{
		if(DoScanTicket())
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; ");
			Response.Write(" URL=esales.aspx?t=continue&st=y&i=" + m_sInvoiceNumber + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
			return;
		}

	}
	else if(Request.Form["cmd"] != null)
	{
		bool bSuccess = false;
		string cmd = Request.Form["cmd"];
		if(cmd == "Record")
			bSuccess = UpdateStatus();
		else if(cmd == "Delete")
			bSuccess = DoDelete();
		else if(cmd == "Send")
			bSuccess = ReSendInvoice();
		else if(cmd == "Continue")
			bSuccess = UpdateStatus(true);
		if(bSuccess)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			// Response.Write("<br><br><center><h3>done!");
			// Response.Write("<br><br><center><a href=invoice.aspx?" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Credit/Invoice</a>");
			// Response.Write("<br><br><center><a href=pack.aspx?i=" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Packing Slip</a>");
			// Response.Write("<br><br><center><a href=invoice.aspx?n=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
			// Response.Write(" class=blueFont2 target=_blank title='Email Invoice to customer'>EMail Credit/Invoice</a>");
			// Response.Write("<br><br><center><a href=pack.aspx?i=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
			// Response.Write(" target=_blank title='Email Packing Slip to customer' class=blueFont2>EMail Packing Slip</a>");
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; ");
			Response.Write(" URL=epack.aspx?i=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail) + "\">");
			return;
		}

		return;
	}
	else
	{
		if(!GetOrder())
		{
			Response.Write("<h3>Order# " + m_sInvoiceNumber + " not found</h3>");
			return;
		}

		PrintAdminHeader();
		PrintAdminMenu();
		WriteHeaders();
		DrawProcessTable();
		DrawItemTable();
		WriteFooter();
	}

	PrintAdminFooter();
}

bool ReSendInvoice()
{
	string body = BuildInvoice(m_sInvoiceNumber);
	string email = Request.Form["email"];
	


	SendEmail(m_sSalesEmail, m_sSalesEmail, email, "Invoice " + m_sInvoiceNumber, BuildInvoice(m_sInvoiceNumber));
	return true;
}

bool GetCustomerDetails()
{
	int rows = 0;
	string status_deleted = GetEnumID("general_status", "deleted");
	string sc = "SELECT i.*, c.*, o.status AS order_status ";
	sc += ", c.company AS c_company, c.address1 AS c_address1, c.address2 AS c_address2 ";
	sc += ", c.address3 AS c_address3, c.phone AS c_phone, c.city AS c_city, c.country AS c_country ";
	sc += " FROM orders o JOIN invoice i ON o.invoice_number=i.invoice_number LEFT OUTER JOIN card c ON c.id=i.card_id ";
	sc += " WHERE i.invoice_number=" + m_sInvoiceNumber;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "invoice");
		if(rows <= 0)
		{
			Response.Write("<br><center><h3>Invoice Not Found</h3></center>");
			return false;
		}
		else
		{
			string sStatus = dst.Tables["invoice"].Rows[0]["status"].ToString();
			if(sStatus == status_deleted)
			{
				Response.Write("<h3>Invoice Deleted</h3>");
				return false;
			}
			else
			{
				DataRow dr = dst.Tables["invoice"].Rows[0];
				m_freight = dr["freight"].ToString();
				if(m_freight != "0")
					m_bFreightCharged = true;
				m_bSpecialShipto = bool.Parse(dr["special_shipto"].ToString());
				m_shippingMethod = dr["shipping_method"].ToString();
				m_pickupTime = dr["pick_up_time"].ToString();
				m_specialShiptoAddr = dr["shipto"].ToString();
				string company = dr["trading_name"].ToString();
				string address = dr["address1"].ToString();
				string type = dr["type"].ToString();
				m_cardID = dr["card_id"].ToString();
				m_customerEmail  = dr["email"].ToString();

                string ap_email = dr["ap_email"].ToString();
                if(!ap_email.Contains("@")){
                    ap_email = dr["email"].ToString();
                }
                if(String.IsNullOrEmpty(ap_email)){
                    ap_email = dr["email"].ToString();
                }
                m_customerEmail = ap_email;
				m_dPrice = MyDoubleParse(dr["price"].ToString());
				m_dTotalOld = MyDoubleParse(dr["total"].ToString());
				m_dOldFreight = MyDoubleParse(dr["freight"].ToString());
				string status = dr["order_status"].ToString();
				if(type == "6")//GetEnumID("receipt_type", "credit note"))
				{
					PrintAdminHeader();
					PrintAdminMenu();
					Response.Write("<br><br><br><center><h3><a href=invoice.aspx?" + m_sInvoiceNumber + " class=blueFont2  target=_blank>Print Credit/Invoice</a></h3>");
					Response.Write("<br><br><center><h3><a href=pack.aspx?i=" + m_sInvoiceNumber + " class=blueFont2  target=_blank>Print Packing Slip</a></h3>");
					Response.Write("<br><br><center><h3><a href=invoice.aspx?n=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
					Response.Write(" class=blueFont2  target=_blank title='Email Invoice to customer'>EMail Credit/Invoice</a></h3>");
					Response.Write("<br><br><center><h3><a href=pack.aspx?i=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
					Response.Write(" target=_blank title='Email Packing Slip to customer' class=blueFont2 >EMail Packing Slip</a></h3>");
					return false;
				}
				else if(m_shippingMethod == "1") //pickup
				{
                    PrintAdminHeader();
                    PrintAdminMenu();
                    
                    Response.Write("   <link href='../themes/datepicker/public/css/reset.css' rel='stylesheet' type='text/css'> ");
                    Response.Write("   <link href='../themes/datepicker/public/css/zebra_datepicker.css' rel='stylesheet' type='text/css'> ");
                    Response.Write("   <link href='../themes/datepicker/public/css/style.css' rel='stylesheet' type='text/css'> ");
                    Response.Write("   <link href='../themes/datepicker/libraries/syntaxhighlighter/public/css/shCoreDefault.css' rel='stylesheet' type='text/css'> ");


                    Response.Write(" <script src='../themes/datepicker/libraries/syntaxhighlighter/public/javascript/XRegExp.js' type='text/javascript'></");
                    Response.Write("script>");
                    Response.Write(" <script src='../themes/datepicker/libraries/syntaxhighlighter/public/javascript/shCore.js' type='text/javascript'></");
                    Response.Write("script>");
                    Response.Write(" <script src='../themes/datepicker/libraries/syntaxhighlighter/public/javascript/shLegacy.js' type='text/javascript'></");
                    Response.Write("script>");
                    Response.Write(" <script src='../themes/datepicker/libraries/syntaxhighlighter/public/javascript/shBrushJScript.js' type='text/javascript'></");
                    Response.Write("script>");
                    Response.Write(" <script src='../themes/datepicker/public/javascript/zebra_datepicker.js' type='text/javascript'></");
                    Response.Write("script>");
                    Response.Write(" <script src='../themes/datepicker/public/javascript/functions.js' type='text/javascript'></");
                    Response.Write("script>");

                    Response.Write(" <script type='text/javascript'> ");
                    Response.Write("     SyntaxHighlighter.defaults['toolbar'] = false;");
                    Response.Write("     SyntaxHighlighter.all(); ");

                    Response.Write(" $(document).ready(function(){ ");
                    Response.Write("    $('#pickUpDate').Zebra_DatePicker({ ");
                    Response.Write("       format: 'd-m-Y' ");
                    Response.Write("    }); ");
                    Response.Write(" }); ");
                    
                    Response.Write("  ");

                    Response.Write(" </");
                    Response.Write("script>");


                    bool picked = true;
                    if(String.IsNullOrEmpty(Request.QueryString["isp"])){
                        DateTime pickUpDateFromDB = GetPickUpDate();
                        //output form to enter pick up time.
                        string _i = Request.QueryString["i"];
                        string _r = Request.QueryString["r"];
                        Response.Write("    <form name='pickUpTimeForm' action='esales.aspx?isp=y&i="+ _i +"&r="+ _r +"' method='POST'>");
                        Response.Write("        <h3 class='blueFont2' style='text-align: center'>Pick Up Time</h3>");
                        Response.Write("       <hr />");
                        Response.Write("        <br />");
                        Response.Write("        <div style='text-align:center;margin-top:50px'>");
                        //Response.Write("        Day : <input type='text' name='pickDay' value='"+ DateTime.Now.ToString("dd") +"'/>");
                        //Response.Write("        Month : <input type='text' name='pickMonth' value='"+ DateTime.Now.ToString("MM") +"'/>");
                        //Response.Write("        Year: <input type='text' name='pickYear' value='"+ DateTime.Now.ToString("yyyy") +"'/>");
                        Response.Write("        Date: <input type='text' name='pickUpDate' id='pickUpDate' value='"+ pickUpDateFromDB.ToString("dd-MM-yyyy") +"'/>");

                        //Response.Write("        Hour : <input type='text' name='pickHour' value='"+ DateTime.Now.ToString("HH") +"'/>");
//DEBUG("pickUpDateFromDB.Hour =", pickUpDateFromDB.Hour );
                        Response.Write("Hour :  <select name='pickHour'>");
                        if(pickUpDateFromDB.Hour == 1)
                            Response.Write("     <option value='1' selected='selected'>1</option>");
                        else
                            Response.Write("     <option value='1'>1</option>");

                        if(pickUpDateFromDB.Hour == 2)
                            Response.Write("     <option value='2' selected='selected'>2</option>");
                        else
                            Response.Write("     <option value='2'>2</option>");

                        if(pickUpDateFromDB.Hour == 3)
                            Response.Write("     <option value='3' selected='selected'>3</option>");
                        else
                            Response.Write("     <option value='3'>3</option>");

                        if(pickUpDateFromDB.Hour == 4)
                            Response.Write("     <option value='4' selected='selected'>4</option>");
                        else
                            Response.Write("     <option value='4'>4</option>");

                        if(pickUpDateFromDB.Hour == 5)
                            Response.Write("     <option value='5' selected='selected'>5</option>");
                        else
                            Response.Write("     <option value='5'>5</option>");

                        if(pickUpDateFromDB.Hour == 6)
                            Response.Write("     <option value='6' selected='selected'>6</option>");
                        else
                            Response.Write("     <option value='6'>6</option>");

                        if(pickUpDateFromDB.Hour == 7)
                            Response.Write("     <option value='7' selected='selected'>7</option>");
                        else
                            Response.Write("     <option value='7'>7</option>");

                        if(pickUpDateFromDB.Hour == 8)
                            Response.Write("     <option value='8' selected='selected'>8</option>");
                        else
                            Response.Write("     <option value='8'>8</option>");

                        if(pickUpDateFromDB.Hour == 9)
                            Response.Write("     <option value='9' selected='selected'>9</option>");
                        else
                            Response.Write("     <option value='9'>9</option>");

                        if(pickUpDateFromDB.Hour == 10)
                            Response.Write("     <option value='10' selected='selected'>10</option>");
                        else
                            Response.Write("     <option value='10'>10</option>");

                        if(pickUpDateFromDB.Hour == 11)
                            Response.Write("     <option value='11' selected='selected'>11</option>");
                        else
                            Response.Write("     <option value='11'>11</option>");

                        if(pickUpDateFromDB.Hour == 12)
                            Response.Write("     <option value='12' selected='selected'>12</option>");
                        else
                            Response.Write("     <option value='12'>12</option>");

                        if(pickUpDateFromDB.Hour == 13)
                            Response.Write("     <option value='13' selected='selected'>13</option>");
                        else
                            Response.Write("     <option value='13'>13</option>");

                        if(pickUpDateFromDB.Hour == 14)
                            Response.Write("     <option value='14' selected='selected'>14</option>");
                        else
                            Response.Write("     <option value='14'>14</option>");

                        if(pickUpDateFromDB.Hour == 15)
                            Response.Write("     <option value='15' selected='selected'>15</option>");
                        else
                            Response.Write("     <option value='15'>15</option>");

                        if(pickUpDateFromDB.Hour == 16)
                            Response.Write("     <option value='16' selected='selected'>16</option>");
                        else
                            Response.Write("     <option value='16'>16</option>");

                        if(pickUpDateFromDB.Hour == 17)
                            Response.Write("     <option value='17' selected='selected'>17</option>");
                        else
                            Response.Write("     <option value='17'>17</option>");

                        if(pickUpDateFromDB.Hour == 18)
                            Response.Write("     <option value='18' selected='selected'>18</option>");
                        else
                            Response.Write("     <option value='18'>18</option>");

                        if(pickUpDateFromDB.Hour == 19)
                            Response.Write("     <option value='19' selected='selected'>19</option>");
                        else
                            Response.Write("     <option value='19'>19</option>");

                        if(pickUpDateFromDB.Hour == 20)
                            Response.Write("     <option value='20' selected='selected'>20</option>");
                        else
                            Response.Write("     <option value='20'>20</option>");

                        if(pickUpDateFromDB.Hour == 21)
                            Response.Write("     <option value='21' selected='selected'>21</option>");
                        else
                            Response.Write("     <option value='21'>21</option>");

                        if(pickUpDateFromDB.Hour == 22)
                            Response.Write("     <option value='22' selected='selected'>22</option>");
                        else
                            Response.Write("     <option value='22'>22</option>");

                        if(pickUpDateFromDB.Hour == 23)
                            Response.Write("     <option value='23' selected='selected'>23</option>");
                        else
                            Response.Write("     <option value='23'>23</option>");

                        if(pickUpDateFromDB.Hour == 24)
                            Response.Write("     <option value='24' selected='selected'>24</option>");
                        else
                            Response.Write("     <option value='24'>24</option>");


                        Response.Write(" </select>");
                        Response.Write(" ");
                        Response.Write(" Minute : <select name='pickMinute'>");

                        if(pickUpDateFromDB.Minute > 45)
                            Response.Write("     <option value='0' selected='selected'>0</option>");
                        else
                            Response.Write("     <option value='0'>0</option>");


                        if(pickUpDateFromDB.Minute > 0 && pickUpDateFromDB.Minute <= 15)
                            Response.Write("     <option value='15' selected='selected'>15</option>");
                        else
                            Response.Write("     <option value='15'>15</option>");
                        

                        if(pickUpDateFromDB.Minute > 15 && pickUpDateFromDB.Minute <= 30)
                            Response.Write("     <option value='30' selected='selected'>30</option>");
                        else
                            Response.Write("     <option value='30'>30</option>");
                        
                        if(pickUpDateFromDB.Minute > 30 && pickUpDateFromDB.Minute <= 45)
                            Response.Write("     <option value='45' selected='selected'>45</option>");
                        else
                            Response.Write("     <option value='45'>45</option>");

                        Response.Write(" </select>");

                        //Response.Write("        Minute : <input type='text' name='pickMinute' value='"+ DateTime.Now.ToString("mm") +"'/>");
                        Response.Write("        <br /></div>");
                        Response.Write("        <div style='text-align:center;margin-top:50px'><input type='submit' class='saveButton' name='pickType' value='Save'/>");
                        Response.Write("        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' class='continueButton' name='pickType' value='Continue' onclick=\"if(!confirm(' \\r\\n\\r\\nCONTINUE??? \\r\\n\\r\\n\\r\\n*You can always come back to enter the pick up time at the order list menu')){ return false;}\" /> </div>");
                        Response.Write("    </form>");
                        return false;
                    }else{ //save data
                        string status_invoiced = GetEnumID("order_item_status", "Invoiced");
                        DateTime pickUpDate = DateTime.Now;
                        try{

                            String pickUpDateString = Request.Form["pickUpDate"];
                            m_pickupTime = Request.Form["pickUpDate"] + " " + Request.Form["pickHour"] + ":" + Request.Form["pickMinute"];
//DEBUG("pickUpDateString=", pickUpDateString);
                            String[] pickUpDateStringArray = pickUpDateString.Split('-');
                            

                            String pickDayString = pickUpDateStringArray[0];
                            String pickMonthString = pickUpDateStringArray[1];
                            String pickYearString = pickUpDateStringArray[2];
                            String pickHourString = Request.Form["pickHour"];
                            String pickMinuteString = Request.Form["pickMinute"];
                            if(!String.IsNullOrEmpty(pickUpDateString)){
                                int day = int.Parse(pickDayString);
                                int month = int.Parse(pickMonthString);
                                int year = int.Parse(pickYearString);
                                int hour = int.Parse(pickHourString);
                                int minute = int.Parse(pickMinuteString);
                                pickUpDate = new DateTime(year,month,day,hour,minute,0);
                            }
                            String cmdType = Request.Form["pickType"];
                            if(cmdType == "Save"){
                                picked = false;
                            }
                            if(cmdType == "Continue"){
                                picked = true;
                            }
                        }catch(Exception ex){
                           //DEBUG("ex=", ex.Message);
                        }
                        if(status == status_invoiced)
                        {
                            sc = "UPDATE orders SET date_shipped='"+ pickUpDate.ToString("yyyy-MM-dd HH:mm") +"' ";
                            sc += "       , pick_up_time='"+ pickUpDate.ToString("yyyy-MM-dd HH:mm") +"' ";
                            //sc += ", status=" + GetEnumID("order_item_status", "Shipped");
            
                            if(picked)
	                        {	//continue
	                            sc += ", status=" + GetEnumID("order_item_status", "Shipped");	// + ", freight=" + s_freight; 
                            }else{
                                //save
                                sc += ", status=" + GetEnumID("order_item_status", "Invoiced");	// + ", freight=" + s_freight; 
                            }

                            sc += " WHERE invoice_number=" + m_sInvoiceNumber;
                            
                            //update pick up time.
                            sc += "  UPDATE invoice SET pick_up_time='"+ pickUpDate.ToString("yyyy-MM-dd HH:mm") +"' ";
                            sc += " WHERE invoice_number=" + m_sInvoiceNumber;
//DEBUG("270sc=" , sc);
                            try
                            {
                                myCommand = new SqlCommand(sc);
                                myCommand.Connection = myConnection;
                                myCommand.Connection.Open();
                                myCommand.ExecuteNonQuery();
                                myCommand.Connection.Close();
                            }
                            catch(Exception e) 
                            {
                                ShowExp(sc, e);
                                return false;
                            }
                        }
                        
                        Response.Write("<br><br><br><center><h2><b>Pick Up " + m_pickupTime + "<br><br><a href=invoice.aspx?" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Credit/Invoice</a></b></h2>");
                        Response.Write("<br><br><center><h3><a href=pack.aspx?i=" + m_sInvoiceNumber + " class=blueFont2 target=_blank>Print Packing Slip</a></h3>");
                        Response.Write("<br><br><center><h3><a href=invoice.aspx?n=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
                        Response.Write(" class=blueFont2 target=_blank title='Email Invoice to customer'>EMail Credit/Invoice</a></h3>");
                        Response.Write("<br><br><center><h3><a href=pack.aspx?i=" + m_sInvoiceNumber + "&confirm=1&email=" + HttpUtility.UrlEncode(m_customerEmail));
                        Response.Write(" target=_blank title='Email Packing Slip to customer' class=blueFont2>EMail Packing Slip</a></h3>");
                        return false;
                    }//save data end.
				}
			}
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetShipDetails()
{
	int rows = 0;
	StringBuilder sb = new StringBuilder();
	sb.Append("SELECT * FROM ship");
	try
	{
		myAdapter = new SqlDataAdapter(sb.ToString(), myConnection);
		rows = myAdapter.Fill(dst, "ship");

	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}
	return true;
}

bool GetOrder()
{
	int rows = 0;
	string sc = "SELECT * FROM sales WHERE invoice_number=" + m_sInvoiceNumber;
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "product");
		if(rows <= 0)
			return false;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DoDelete()
{
	if(Request.Form["delete"] != "on")
	{
		Response.Write("<h3>Error, please tick the checkbox to confirm deletion</h3>");
		return false;
	}
	string status_deleted = GetEnumID("general_status", "deleted");
	string sc = "UPDATE invoice SET status=" + status_deleted + " WHERE invoice_number=" + m_sInvoiceNumber;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
Boolean UpdateStatus()
{
	return UpdateStatus(false);
}
Boolean UpdateStatus(bool bNoTicketInput)
{
	
	if(!bNoTicketInput)
	{	
		int tickets = (int)Session["shipping_ticket_count"];
		if(tickets <= 0)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error, no freight");
			return false;
		}
	}
	string invoice = Request.Form["invoice0"];
	string s_freight = MyMoneyParse(Request.Form["freight"]).ToString();
	string sc = "";
    
        sc += "UPDATE orders SET date_shipped=GETDATE() "; //shipby=" + shipby + ", ticket='" + ticket + "' ";
        if(bNoTicketInput)
	    {	
	        sc += ", status=" + GetEnumID("order_item_status", "Shipped");	// + ", freight=" + s_freight; 
        }else{
            sc += ", status=" + GetEnumID("order_item_status", "Invoiced");	// + ", freight=" + s_freight; 
        }
        sc += " WHERE invoice_number=" + invoice;
    //DEBUG("sc=", sc);
	    try
	    {
		    myCommand = new SqlCommand(sc);
		    myCommand.Connection = myConnection;
		    myCommand.Connection.Open();
		    myCommand.ExecuteNonQuery();
		    myCommand.Connection.Close();
	    }
	    catch(Exception e) 
	    {
		    ShowExp(sc, e);
		    return false;
	    }
    
    if(!bNoTicketInput)
    {
	   // if(!UpdateInvoiceFreight(s_freight))
		//    return false;
    }else{
        if(m_sDN != "") //send delivery notice
	    {
		    SendEmail(m_sSalesEmail, m_sSalesEmail, dst.Tables["invoice"].Rows[0]["email"].ToString(), 
                                        "Shipment Notice - " + m_sCompanyTitle, m_sDN);
	    }
    }



    int _tickets = (int)Session["shipping_ticket_count"];
    Session["shipping_ticket_count"] = null;
	string _ticket = "";
    string _shippingMethodId = "";  
    string _shipTime = "";
    string shipname = "";
    string shipdesc = "";
    double dShipFreight = 0;
    DataRow dr2;
    sc = "";

    
    sc = " DELETE FROM invoice_freight WHERE invoice_number = "+ invoice +" ";            

            try
            {
                myCommand = new SqlCommand(sc);
                myCommand.Connection = myConnection;
                myCommand.Connection.Open();
                myCommand.ExecuteNonQuery();
                myCommand.Connection.Close();
            }
            catch(Exception e) 
            {
                //ShowExp(sc, e);
                //return false;
            }

     sc = "";

    //if(bNoTicketInput){
        for(int i=0; i<_tickets; i++)
        {
            sc = "";

            _ticket = Session["shipping_ticket" + i].ToString();
            Session["shipping_ticket" + i] = null;
            if(Request.Form["f_time" + i] != null){
                _shipTime = Request.Form["f_time" + i];
            }else{
                _shipTime = DateTime.Now.ToString("dd/MM/yyyy");
            }
            
            _shippingMethodId = Session["shipping_method_Id" + i].ToString();
            Session["shipping_method_Id" + i] = null;
            Session["shipping_time" + i] = null;
            dr2 = GetShipPrice(_shippingMethodId);
            if(dr2 != null)
            {
                shipname = dr2["name"].ToString();
                shipdesc = dr2["description"].ToString();
                dShipFreight = MyDoubleParse(dr2["price"].ToString());
            }else{
                shipname = "";
                shipdesc = "";
                dShipFreight = 0;
            }

            sc += " INSERT INTO invoice_freight ";
            sc += "           ( invoice_number, ship_name ,ship_desc ,ticket ,price ,ship_id, ship_time) ";
            sc += "      VALUES ("+invoice+",  '"+ shipname +"'  ,'"+ shipdesc +"' ,'"+_ticket+"' ,"+ dShipFreight +" ,"+_shippingMethodId+", '"+ _shipTime +"') ";
       // }

        try
        {
            myCommand = new SqlCommand(sc);
            myCommand.Connection = myConnection;
            myCommand.Connection.Open();
            myCommand.ExecuteNonQuery();
            myCommand.Connection.Close();
        }
        catch(Exception e) 
        {
            //ShowExp(sc, e);
            //return false;
        }
    }
    Session["shipping_ticket_count"] = 0;

	return true;
}

bool UpdateInvoiceFreight(string s_freight)
{
	string sc = "";
	int tickets = (int)Session["shipping_ticket_count"];
	if(tickets <= 0)
	{
		PrintAdminHeader();
		PrintAdminMenu();
		Response.Write("<br><br><center><h3>Error, no freight");
		return false;
	}

	string stickets = "";
	string ticket = "";
    string shipTime = "";
    string shippingMethodId = "";
	double dFreight = MyDoubleParse(s_freight);
	for(int i=0; i<tickets; i++)
	{
		string id = ""; //for later use
		
		string shipid = "";
		string shipname = "";
		string shipdesc = "";
		double dShipFreight = 0;
		DataRow dr = null;

		ticket = Session["shipping_ticket" + i].ToString();
        if(Session["shipping_time" + i] != null){
            shipTime = Session["shipping_time" + i].ToString();
        }else{
            shipTime = DateTime.Now.ToString("dd/MM/yyyy");
        }
        
        shippingMethodId = Session["shipping_method_Id" + i].ToString();
//DEBUG("ticket=", ticket);
		dr = GetShipPrice(shippingMethodId);
		if(dr == null)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error, Freight ticke # " + ticket + " undefined");
			return false;
		}
		shipid = dr["id"].ToString();
		shipname = dr["name"].ToString();
		shipdesc = dr["description"].ToString();
		if(Request.Form["already_charged" + i] == "on")
			dShipFreight = 0;
		else
			dShipFreight = MyDoubleParse(dr["price"].ToString());

		sc += " INSERT INTO	invoice_freight (invoice_number, ship_name, ship_desc, ticket, price, ship_id, ship_time) ";
		sc += " VALUES(" + m_sInvoiceNumber;
		sc += ", '" + EncodeQuote(shipname) + "' ";
		sc += ", '" + EncodeQuote(shipdesc) + "' ";
		sc += ", '" + EncodeQuote(ticket) + "' ";
		sc += ", " + dShipFreight;
		sc += ", " + shipid;
        sc += ", '" + shipTime + "'";
		sc += ") ";

		stickets += shipdesc;
		stickets += " : ";
		stickets += ticket;
		stickets += "<br>\r\n";
	}

	double dTaxNew = (m_dPrice + dFreight) * GetGstRate(m_cardID);
	dTaxNew = Math.Round(dTaxNew, 2);
	double dTotalNew = m_dPrice + dFreight + dTaxNew;
	
	double dTotalAdd = dTotalNew - m_dTotalOld;
	UpdateCardBalance(m_cardID, dTotalAdd);

	sc += " Update invoice SET freight=" + dFreight;
	sc += ", tax=" + dTaxNew;
	sc += ", total=" + dTotalNew;
	sc += " WHERE invoice_number=" + m_sInvoiceNumber; 
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(stickets != "")
	{
		m_sDN = ReadSitePage("shipment_notice");
		m_sDN = m_sDN.Replace("@@invoice_number", m_sInvoiceNumber);
		m_sDN = m_sDN.Replace("@@ship_address", WriteCustomerDetails());
		m_sDN = m_sDN.Replace("@@ship_date", DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy HH:mm"));
		m_sDN = m_sDN.Replace("@@ship_tickets", stickets);
		string item_list = BuildInvoiceItemList(m_sInvoiceNumber);
		m_sDN = m_sDN.Replace("@@product_list", item_list);
	}

	return true;
}

void DrawTableHeader()
{
	StringBuilder sb = new StringBuilder();;
	sb.Append("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr class=tableHeader>\r\n");
	sb.Append("<td width=50>INVOICE#</td>\r\n");
	sb.Append("<td>DATE/TIME</td>\r\n");
	sb.Append("<td>CODE</td>");
	sb.Append("<td>M_PN</td>");
	sb.Append("<td>NAME</td>");
	sb.Append("<td>SUPPLIER</td>");
	sb.Append("<td>SUPPLIER_CODE</td>");
	sb.Append("<td>QTY</td>");
	if(bItemProcessing)
	{
		sb.Append("<td>STATUS</td>");
		sb.Append("<td>SHIP BY</td>");
		sb.Append("<td>TICKET#</td>");
//		sb.Append("<td>NOTES</td>");
	}
	sb.Append("</tr>\r\n");
	
	Response.Write(sb.ToString());
	Response.Flush();
}

Boolean DrawRow(DataRow dr, int i, Boolean alterColor)
{
	string invoice = dr["invoice_number"].ToString();
	string code = dr["code"].ToString();
	string supplier_code = dr["supplier_code"].ToString();
	string name = dr["name"].ToString();
	string supplier = dr["supplier"].ToString();
	string quantity = dr["quantity"].ToString();
	string status = dr["status"].ToString();
	string shipby = dr["shipby"].ToString();
	string ticket = dr["ticket"].ToString();
	string note = dr["note"].ToString();
	bool bSystem = (bool)dr["system"];

	string date = dst.Tables["invoice"].Rows[0]["commit_date"].ToString();
	string index = i.ToString();

	StringBuilder sb = new StringBuilder();
	
	sb.Append("<input type=hidden name=invoice" + index + " value='" + invoice + "'>");
	sb.Append("<input type=hidden name=code" + index + " value='" + code + "'>");

	sb.Append("<tr");
	if(bSystem)
		sb.Append(" bgcolor=#FFFFEE");
	else if(alterColor)
		sb.Append(" bgcolor=#EEEEEE");
	sb.Append("><td><a href=invoice.aspx?" + invoice + " target=_blank>");
	sb.Append(invoice);
	sb.Append("</a></td><td>");
	sb.Append(date);
	sb.Append("</td><td>");
	sb.Append(code);
	sb.Append("</td><td>");
	sb.Append(supplier_code);
	sb.Append("</td><td>");
	sb.Append(name);
	sb.Append("</td><td>");
	sb.Append(supplier);
	sb.Append("</td><td>");
	sb.Append(supplier_code);
	sb.Append("</td><td>");
	sb.Append(quantity);
	sb.Append("</td></tr>");

	Response.Write(sb.ToString());
	Response.Flush();
	return true;
}

string AddShips(string id, string sName, string shipby)
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<option value='" + id + "'");
	if(shipby == id)
		sb.Append(" selected");
	sb.Append(">" + sName + "</option>");
	return sb.ToString();
}

bool DoScanTicket()
{
//DEBUG("ticket=", Request.Form["ticket"]);
	if(Request.Form["ticket"] != null && Request.Form["ticket"] != "")
	{
		int tickets = (int)Session["shipping_ticket_count"];
        String shipTime = "";
		for(int i=0; i<tickets; i++)
		{
			if(Request.Form["already_charged" + i] == "on")
				Session["shipping_ticket_already_charged" + i] = "1";
			else
				Session["shipping_ticket_already_charged" + i] = null;
            shipTime = Request.Form["f_time" + i];
            if(shipTime == ""){
                shipTime = DateTime.Now.ToString("dd/MM/yyyy");
            }
            Session["shipping_time" + i] = shipTime;
            string theTicket = Session["shipping_ticket" + i].ToString();
            //update ship time to database
            UpdateShipTime(m_sInvoiceNumber, theTicket, shipTime);

//DEBUG("926 shiptime " + i +"=", shipTime);
		}
		Session["shipping_ticket" + tickets] = Request.Form["ticket"];
        
        Session["shipping_method_Id" + tickets] = Request.Form["shipping_method"];
		if(m_bFreightCharged)
			Session["shipping_ticket_already_charged" + tickets] = "1";
		else
			Session["shipping_ticket_already_charged" + tickets] = null;
		Session["shipping_ticket_count"] = tickets + 1;
    
        //save new data to database
        SaveShippingTicketToDB(m_sInvoiceNumber, Request.Form["ticket"],  Request.Form["shipping_method"], DateTime.Now.ToString("dd/MM/yyyy"));

	}
	return true;
}

void SaveShippingTicketToDB(String invoice, String _ticket,  String _shippingMethodId, String  _shipTime){

		    String sc = "";
            String shipname = "";
            String shipdesc = "";
            double dShipFreight = 0;
            
            DataRow dr2 = GetShipPrice(_shippingMethodId);
		    if(dr2 != null)
		    {
			    shipname = dr2["name"].ToString();
			    shipdesc = dr2["description"].ToString();
			    dShipFreight = MyDoubleParse(dr2["price"].ToString());
		    }else{
                shipname = "";
			    shipdesc = "";
			    dShipFreight = 0;
            }

            sc += " INSERT INTO invoice_freight ";
            sc += "           ( invoice_number, ship_name ,ship_desc ,ticket ,price ,ship_id, ship_time) ";
            sc += "      VALUES ("+invoice+",  '"+ shipname +"'  ,'"+ shipdesc +"' ,'"+_ticket+"' ,"+ dShipFreight +" ,"+_shippingMethodId+", '"+ _shipTime +"') ";
       // }
        try
        {
//DEBUG("975 sc=", sc);
            myCommand = new SqlCommand(sc);
            myCommand.Connection = myConnection;
            myCommand.Connection.Open();
            myCommand.ExecuteNonQuery();
            myCommand.Connection.Close();
       }
        catch(Exception e) 
        {
            //ShowExp(sc, e);
            //return false;
            myCommand.Connection.Close();
       }
}


void UpdateShipTime(String invoiceNo, String ticket, String shipTime){
        string sc = "UPDATE invoice_freight SET ship_time='"+ shipTime +"' ";

        sc += " WHERE invoice_number=" + invoiceNo + " and ticket='" + ticket + "'";

        try
        {
            myCommand = new SqlCommand(sc);
            myCommand.Connection = myConnection;
            myCommand.Connection.Open();
            myCommand.ExecuteNonQuery();
            myCommand.Connection.Close();
        }
        catch(Exception e) 
        {
            //ShowExp(sc, e);
            //return false;
            myCommand.Connection.Close();
        }

}

bool DoDelTicket()
{

    //int _t = 0;
    //if(!int.TryParse(m_delTicket, out _t)){
        //call delete ticket from db
        //return DeleteShippingTicketFromDB();  
        DeleteShippingTicketFromDB();
    //}

	if(Session["shipping_ticket_count"] == null)
		return true;

//DEBUG("947session=", Session["shipping_ticket_count"] .ToString());
	int tickets = (int)Session["shipping_ticket_count"];
    System.Collections.Generic.List<String> shippingTicketList = new System.Collections.Generic.List<String>();
	tickets--;
	for(int i=0; i<tickets; i++)
	{
        //add session to tmp list
        shippingTicketList.Add(Session["shipping_ticket" + i].ToString());
        //clear current shipping_ticket
        Session.Remove("shipping_ticket" + i.ToString());
		//Session["shipping_ticket" + i] = Session["shipping_ticket" + (i+1).ToString()].ToString();
//DEBUG("948=", "new session");
	}
    int h = 0;
//DEBUG("shippingTicketList.Count=", shippingTicketList.Count);
    for(int j = shippingTicketList.Count; j > 0; j--){
//DEBUG("962 j=", j);
        Session["shipping_ticket" + h] = shippingTicketList[j-1];
//DEBUG("962shippingTicketList[j]=", shippingTicketList[j-1]);
        h++;
    }

	Session["shipping_ticket_count"] = tickets;
//DEBUG("967session=", Session["shipping_ticket_count"] .ToString());
	return true;
}

DataRow GetShipPrice(string ticket)
{
	DataRow dr = null;

	if(dsf.Tables["scan"] != null)
		dsf.Tables["scan"].Clear();

	string sc = "SELECT * FROM ship where id = "+ ticket +"  ORDER BY prefix";
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dsf, "scan");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
	}
	bool bsuffixMatch = false;
	bool bPrefixMatch = false;

	string pm = "";
	string sm = "";
	string prefix = "";
	string suffix = "";
	for(int i=0; i<dsf.Tables["scan"].Rows.Count; i++)
	{
		dr = dsf.Tables["scan"].Rows[i];
        break;
//        prefix = dr["prefix"].ToString();
//        suffix = dr["suffix"].ToString();
//        Trim(ref prefix);
//        Trim(ref suffix);
//        if(prefix == "")
//        {
//            if(suffix == "")
//                continue;
//            if(suffix.Length > ticket.Length)
//                continue;
////DEBUG("check suffix ", suffix);
//            //now check suffix
//            if(ticket.Substring(ticket.Length - suffix.Length, suffix.Length).ToLower() == suffix.ToLower())
//            {
//            //	return dr;
//                bsuffixMatch = true;
////DEBUG("suffixMatch=", suffix);
//                sm = suffix;
//                break;
//            }
//            continue;
//        }
////DEBUG("pl="+prefix.Length.ToString(), " tl="+ticket.Length.ToString());
//        if(prefix.Length > ticket.Length)
//            continue;
////DEBUG("check prefix ", prefix);
////DEBUG("t="+ticket.Substring(0, prefix.Length).ToLower(), " pf="+prefix.ToLower());
//        if(ticket.Substring(0, prefix.Length).ToLower() == prefix.ToLower())
//        {
//            bPrefixMatch = true;
////DEBUG("prefixMatch=", prefix);
//            pm = prefix;
//            break;
//        }
	}
//DEBUG("bsuffixMatch=", bsuffixMatch.ToString());
//DEBUG("bprefixMatch=", bPrefixMatch.ToString());
    //if(!bsuffixMatch && !bPrefixMatch)
    //    return null;

    //bool bDoubleMatch = false;
    ////check double matches
    //for(int i=0; i<dsf.Tables["scan"].Rows.Count; i++)
    //{
    //    DataRow drd = dsf.Tables["scan"].Rows[i];
    //    prefix = drd["prefix"].ToString();
    //    suffix = drd["suffix"].ToString();
    //    Trim(ref prefix);
    //    Trim(ref suffix);
    //    if(prefix == "")
    //    {
    //        if(suffix == "")
    //            continue;
    //        if(suffix.Length > ticket.Length)
    //            continue;
    //        if(bsuffixMatch)
    //            continue;

    //        //now check suffix
    //        if(ticket.Substring(ticket.Length - suffix.Length, suffix.Length).ToLower() == suffix.ToLower())
    //        {
    //            bDoubleMatch = true;
    //            sm = suffix;
    //            break;
    //        }
    //    }
    //    if(prefix.Length > ticket.Length)
    //        continue;
    //    if(ticket.Substring(0, prefix.Length).ToLower() == prefix.ToLower())
    //    {
    //        if(bPrefixMatch)
    //            continue;
    //        bDoubleMatch = true;
    //        pm = prefix;
    //        break;
    //    }
    //}
    //if(bDoubleMatch)
    //{
    //    Response.Write("<br><br><center><h1><font color=red>Double Match Detected, ");
    //    Response.Write("ticket scanned match both prefix '</font>" + pm + "<font color=red>' ");
    //    Response.Write("and suffix '</font>" + sm + "<font color=red>', please check ticket settings");
    //}
	return dr;
}


bool DeleteShippingTicketFromDB(){
    string ticketNo = Request.QueryString["ticNu"];
    string ticket = Session["shipping_ticket" + ticketNo].ToString();
    string sc = " DELETE FROM invoice_freight WHERE ticket='"+ ticket +"' and invoice_number="+ m_sInvoiceNumber ;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
    return true;
}

string PrintShippingTicketFromDB()
{
	DataRow dr = null;
    string _value = "";
	if(dsf.Tables["scan2"] != null)
		dsf.Tables["scan2"].Clear();

	string sc = "SELECT * FROM invoice_freight WHERE invoice_number=" + m_sInvoiceNumber;
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dsf, "scan2");
    
        if(dsf.Tables["scan2"].Rows.Count <= 0){
            return "";
        }


        string id = ""; //for later use
	    string shipid = "";
	    string shipname = "";
	    string shipdesc = "";
	    double dShipFreight = 0;
        string ticket = "";
        string shippingMethodId = "";
        string fTime = DateTime.Now.ToString("dd/MM/yyyy");        
        int count = 0;
	    for(int i=0; i<dsf.Tables["scan2"].Rows.Count; i++)
	    {

		    dr = dsf.Tables["scan2"].Rows[i];
        

		    ticket = dr["ticket"].ToString();
            shippingMethodId = dr["ship_id"].ToString();
		    DataRow dr2 = GetShipPrice(shippingMethodId);

		    shipid = dr2["id"].ToString();
		    shipname = dr2["name"].ToString();
		    shipdesc = dr2["description"].ToString();
		    dShipFreight = MyDoubleParse(dr2["price"].ToString());
		    fTime = dr["ship_time"].ToString();

		    _value += "<tr><td>" + ticket;
		    
		    _value += "</td><td>";
		    _value += shipname;
		    _value += "</td><td>";
		    _value += shipdesc;
		    _value += "</td><td align=center>";
            _value += "<input type='text' name='f_time" + i + "' value='" + fTime + "' />";
            _value += "</td><td align=center>";
            _value += " <a href=esales.aspx?t=continue&i=" + m_sInvoiceNumber + "&ticNu="+ i +"&delt=xxxxx";
		    _value += "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o title=Delete><b>X</b></a>";
		    _value += "</td></tr>";

            Session["shipping_ticket" + i] = ticket;
            Session["shipping_method_Id" + i] = shipid;
            Session["shipping_time" + i] = fTime;
            count++;
        }   
        Session["shipping_ticket_count"] = count;
	}
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}

    return _value;
}


void DrawProcessTable()
{
	Response.Write("<table width=100% cellspacing=3 cellpadding=0 border=1 ");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-style:Solid;border-collapse:collapse;fixed\">");
	
	Response.Write("<tr><td valign=top>");

	Response.Write("<table>");
	Response.Write("<tr><td></td>");
	Response.Write("<td valign=top>&nbsp&nbsp;");

    Response.Write(" <font color=green>Shipping Method : </font>");//<font color=red><b>" + GetShipCompany(m_shippingMethod) + "</b></font>");
    Response.Write("<select name=shipping_method >");
    Response.Write(ShowShipingOption());
    Response.Write("</select>");
    Response.Write("<font color=green>&nbsp;&nbsp;TICKETS: </font>");
	Response.Write("<input type=text name=ticket autocomplete=off>");
	Response.Write("<script");
	Response.Write(">");
	Response.Write("document.f.ticket.focus();");
	Response.Write("</script");
	Response.Write(">");

	Response.Write("<input type=submit class=linkButton title='Enter' name=cmd value='Enter'>");

	

	if(m_bFreightCharged)
		Response.Write(" <b>(Freight Already Charged)</b>");
	Response.Write("</td></tr>");
	Response.Write("</table>");

	Response.Write("</td></tr>");
	Response.Write("<tr><td>");

	//ticket list
	Response.Write("<table style='width: 50%;'>");
	Response.Write("<tr class=tableHeader>\r\n");
	Response.Write("<td width=70>Ticket#</td>");
	Response.Write("<td width=90>Ship By</td>");
	Response.Write("<th width=90>Description</th>");
	Response.Write("<th>Time</th>");
	Response.Write("<th>Delete</th>");
	Response.Write("</tr>");

	int tickets = (int)Session["shipping_ticket_count"];
//DEBUG("tickets=", tickets);
//	if(tickets <= 0)
//		Response.Write("<tr><td colspan=2><b>There's no tickets</b></td></tr>");
	string ticket = "";
    string shippingMethodId = "";
	double dFreight = 0;
	if(m_freight != "")
		dFreight = MyDoubleParse(m_freight);
//DEBUG("1233tickets=", tickets);
//    for(int i=0; i<tickets; i++)
//    {
//        string id = ""; //for later use
		
//        string shipid = "";
//        string shipname = "";
//        string shipdesc = "";
//        double dShipFreight = 0;
//        string fTime = DateTime.Now.ToString("dd/MM/yyyy");
//        DataRow dr = null;
        
////DEBUG("1244=", i);
//        ticket = Session["shipping_ticket" + i].ToString();
//        if(Session["shipping_time" + i] != null){
//            fTime = Session["shipping_time" + i].ToString();
//        }else{
//            fTime = DateTime.Now.ToString("dd/MM/yyyy");
//        }
//        shippingMethodId = Session["shipping_method_Id" + i].ToString();
//        dr = GetShipPrice(shippingMethodId);
//        if(dr != null)
//        {
//            shipid = dr["id"].ToString();
//            shipname = dr["name"].ToString();
//            shipdesc = dr["description"].ToString();
//            dShipFreight = MyDoubleParse(dr["price"].ToString());
//        }

//        Response.Write("<tr><td>" + ticket);
		
//        Response.Write("</td><td>");
//        Response.Write(shipname);
//        Response.Write("</td><td>");
//        Response.Write(shipdesc);
//        Response.Write("</td><td align=right>");
//        //Response.Write("<a href=newship.aspx?t=m&i=" + shipid + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
//        //Response.Write(" target=_blank title=Edit>" + dShipFreight.ToString("c") + "</a>");
//        Response.Write("<input type='text' name='f_time" + i + "' value='" + fTime + "' />");
//        Response.Write("</td><td align=center>");
//        //Response.Write("<input type=checkbox name=already_charged" + i + " onclick=\"UpdateFreight();\" ");
//        //Response.Write("<input type=checkbox name=already_charged" + i );
//        //if(Session["shipping_ticket_already_charged" + i] != null)
//        //{
//        //    Response.Write(" checked");
//        //}
//        //else
//        //{
//        //    dFreight += dShipFreight;
//        //}

//        Response.Write(" <a href=esales.aspx?t=continue&i=" + m_sInvoiceNumber + "&delt=" + i);
//        Response.Write("&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + " class=o title=Delete><b>X</b></a>");

//        Response.Write("</td></tr>");
//    }

    //if(Request.QueryString["st"] == null){
        Response.Write(PrintShippingTicketFromDB());
   // }
    

	//javascript function
	//Response.Write("<script TYPE=text/javascript");
	//Response.Write(">");
	//Response.Write("function UpdateFreight()");
	//Response.Write("{ var total = 0;");
	//for(int i=0; i<tickets; i++)
	//{
	//	Response.Write("	if(!document.f.already_charged" + i.ToString() + ".checked)");
	//	Response.Write("	total += Number(document.f.freight" + i.ToString() + ".value);\r\n");
	//}
	//Response.Write("	document.f.freight.value = Number(document.f.freight_charged.value) + total;\r\n");
	//Response.Write("}");
	//Response.Write("</script");
	//Response.Write(">");

	Response.Write("<input type=hidden name=freight_charged value=" + m_freight + ">");
	m_freight = dFreight.ToString();
	Response.Write("<tr></td><td colspan=4 align=right>");
	Response.Write("<b>Total Freight : </b><input type=text size=8 readonly=true style=text-align:right; name=freight value='");
	if(m_freight != "")
		Response.Write(dFreight.ToString("c"));
	Response.Write("'></td></tr>");

	Response.Write("<tr></td>");
    Response.Write("<td  align=right><input type=submit  class=saveButton title='Record' name=cmd value=Record></td>");
	Response.Write("<td colspan=3 align=right><input type=submit class=continueButton title='Continue' name=cmd value=Continue onclick=\"if(!confirm(' \\r\\n\\r\\nCONTINUE??? \\r\\n\\r\\n\\r\\n*You can always come back to enter the Shipping tickets at the order list menu')){ return false;}\">");
	//Response.Write("<input type=submit class=continueButton title='Continue' name=cmd value=Continue >");
	Response.Write("</td></tr></table>");
	Response.Write("</td></tr></table>");
	Response.Write("</td></tr></table>");
}

void WriteHeaders()
{
	Response.Write("\r\n<form name=f action=esales.aspx?i=");
	Response.Write(m_sInvoiceNumber);
	Response.Write("&t=update&p=");
	Response.Write(page);
	if(bItemProcessing)
		Response.Write("&jt=i");
	else
		Response.Write("&jt=a");
	Response.Write(" method=post>\r\n");
	Response.Write("\r\n\r\n<table width=100% bgcolor=white align=center>");
	Response.Write("\r\n<tr><td valign=top>");
	Response.Write("<br><center><font class=blueFont2>Shipping</font></center></td></tr><tr><td>");
}

void WriteFooter()
{
	DataRow dr = dst.Tables["invoice"].Rows[0];
	Response.Write("<tr valign=top><td>");
	Response.Write(WriteCustomerDetails());
	Response.Write("</td></tr>");
	Response.Write("<tr><td>");
	
	// add button for Packing Order
	//added resent email button, 15 Aug 2002 DW.
	Response.Write("<table width=100% align=right><tr>");
	Response.Write("</td>");
	
	Response.Write("</tr>");
	Response.Write("</table>\r\n");

	Response.Write("</td></tr>");
	Response.Write("</table>");
	Response.Write("</form>");
}

string WriteCustomerDetails()
{
	DataRow dr = dst.Tables["invoice"].Rows[0];
	StringBuilder sb = new StringBuilder();
	sb.Append("<table valign=top colspan=4><tr><td>");
	if(m_bSpecialShipto)
		sb.Append("<font size=+1 color=red><b>Special Shipping Address</b></font>");
	else
		sb.Append("<font size=+1><b>Shipping Address</b></font>");
	sb.Append("</td></tr>");
	sb.Append("<tr><td>");
	if(m_bSpecialShipto)
	{
		sb.Append("<h4>");
		sb.Append(m_specialShiptoAddr.Replace("\r\n", "\r\n<br>"));
		sb.Append("</h4>");
	}
	else
	{
		sb.Append(dr["trading_name"].ToString() + "<br>");
		sb.Append(dr["c_address1"].ToString() + "<br>");
		sb.Append(dr["c_address2"].ToString() + "<br>");
		if(dr["c_address3"].ToString() != "")
			sb.Append(dr["c_address3"].ToString() + "<br>");
		else if(dr["c_city"].ToString() != "")
			sb.Append(dr["c_city"].ToString() + "<br>");
		sb.Append(dr["c_country"].ToString() + "<br>");
		sb.Append("Ph : " + dr["c_phone"].ToString() + "<br>");
	}

	sb.Append("</td></tr></table><br>\r\n");
	return sb.ToString();
}

Boolean DrawItemTable()
{
	Boolean bRet = true;

	DataRow dr = dst.Tables["product"].Rows[0];
//	string status = dr["status"].ToString();
	string shipby = dr["shipby"].ToString();
	string ticket = dr["ticket"].ToString();
	string note = dr["note"].ToString();

//	Response.Write("</td></tr><tr><td>");

	DrawTableHeader();
	string s = "";
	Boolean alterColor = true;
	int startPage = (page-1) * m_nPageSize;
	for(int i=startPage; i<dst.Tables["product"].Rows.Count; i++)
	{
		if(i-startPage >= m_nPageSize)
			break;
		dr = dst.Tables["product"].Rows[i];
		alterColor = !alterColor;
		if(!DrawRow(dr, i, alterColor))
		{
			bRet = false;
			break;
		}
	}

	int pages = dst.Tables["product"].Rows.Count / m_nPageSize + 1;
	if(pages > 1)
	{
		Response.Write("<tr><td colspan=" + cols + " align=right>Page: ");
		for(int i=1; i<=pages; i++)
		{
			if(i != page)
			{
				Response.Write("<a href=esales.aspx?i=");
				Response.Write(m_sInvoiceNumber);
				Response.Write("&p=");
				Response.Write(i.ToString());
				Response.Write(">");
				Response.Write(i.ToString());
				Response.Write("</a> ");
			}
			else
			{
				Response.Write(i.ToString());
				Response.Write(" ");
			}
		}
		Response.Write("</td></tr>");
	}

	Response.Write("</table>\r\n");

	return bRet;
}

bool DoCheckEnterSN()
{
	for(int i=0; i<dst.Tables["product"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["product"].Rows[i];
		string sc = "SELECT COUNT(sn) AS num FROM sales_serial WHERE invoice_number='" + m_sInvoiceNumber;
			sc += "' AND code=" + dr["code"].ToString();
		try
		{
			myAdapter = new SqlDataAdapter(sc, myConnection);
			myAdapter.Fill(dst, "NumOfSn");
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
		if(int.Parse(dr["quantity"].ToString()) > int.Parse(dst.Tables["NumOfSn"].Rows[0]["num"].ToString()))
		{
			return false;
		}
	}

	return true;
}

string BuildInvoiceItemList(string sInvoiceNumber)
{
	string m_sKitTerm = GetSiteSettings("package_bundle_kit_name", "Kit", true);

	string CheckDigit = check_IsNumber(sInvoiceNumber);
	if(CheckDigit == "False")
		return "";

	DataSet dsi = new DataSet();
	string sc = "SELECT i.invoice_number, i.type, i.payment_type, i.commit_date, i.price ";
	sc += ", i.tax, i.total, i.sales, i.cust_ponumber, ";
	sc += " i.freight, i.sales_note, c.*, s.code, s.supplier_code, s.quantity, s.name as item_name ";
	sc += ", s.commit_price, i.type, i.special_shipto, i.shipto, shipping_method, ";
	sc += " s.status AS si_status, s.note, s.shipby, s.ship_date, s.ticket, s.processed_by ";
	sc += ", s.system AS bSystem, i.system AS iSystem, cr.is_service, i.no_individual_price AS iNoIndividual ";
	sc += ", s.kit, s.krid, k.kit_id, k.qty AS kit_qty, k.name AS kit_name, k.commit_price AS kit_price ";
	sc += " FROM sales s JOIN invoice i ON s.invoice_number=i.invoice_number LEFT OUTER JOIN card c ON c.id=i.card_id ";
	sc += " JOIN code_relations cr ON cr.code = s.code ";
	sc += " LEFT OUTER JOIN sales_kit k ON k.invoice_number=i.invoice_number AND k.krid = s.krid ";
	sc += " WHERE i.invoice_number=";
	sc += sInvoiceNumber;
	if(!SecurityCheck("sales", false))
		sc += " AND i.card_id=" + Session["card_id"];
	sc += " ORDER BY s.id ";

	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsi);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	if(rows <= 0)
		return "";

	DataRow dr = dsi.Tables[0].Rows[0];
	m_account_number = dr["id"].ToString();
	m_account_name = dr["trading_name"].ToString();
	string sDate = dr["commit_date"].ToString();
	DateTime tDate = DateTime.Parse(sDate);
	m_sDN = m_sDN.Replace("@@order_date", tDate.ToString("dd-MM-yyyy"));
	m_sDN = m_sDN.Replace("@@po_number", dr["cust_ponumber"].ToString());

	return BuildItemTable(dsi.Tables[0], false);
}


DateTime GetPickUpDate()
{
	DataRow dr = null;
    DateTime pickUpDate = DateTime.Now;
	if(dsf.Tables["_scan"] != null)
		dsf.Tables["_scan"].Clear();

	string sc = "SELECT * FROM orders where invoice_number=" + m_sInvoiceNumber;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dsf, "_scan");
	

	    for(int i=0; i<dsf.Tables["_scan"].Rows.Count; i++)
	    {
		    dr = dsf.Tables["_scan"].Rows[i];
            break;
	    }

    
        String pick_up_time = dr["pick_up_time"].ToString();
        //DEBUG("pick_up_time=", pick_up_time);


        String[] pickUpDateTimeStringArray = pick_up_time.Split(' ');
        String[] pickUpDateStringArray = pickUpDateTimeStringArray[0].Split('-');     
        String[] pickUpTimeStringArray = pickUpDateTimeStringArray[1].Split(':');              

        String pickDayString = pickUpDateStringArray[2];
        String pickMonthString = pickUpDateStringArray[1];
        String pickYearString = pickUpDateStringArray[0];
        String pickHourString = pickUpTimeStringArray[0];
        String pickMinuteString = pickUpTimeStringArray[1];

        if(!String.IsNullOrEmpty(pick_up_time)){
            int day = int.Parse(pickDayString);
            int month = int.Parse(pickMonthString);
            int year = int.Parse(pickYearString);
            int hour = int.Parse(pickHourString);
            int minute = int.Parse(pickMinuteString);
            pickUpDate = new DateTime(year,month,day,hour,minute,0);
        }


    }
	catch(Exception e) 
	{
		//ShowExp(sc, e);
	}
    if(pickUpDate.Minute > 45){
        pickUpDate = pickUpDate.AddHours(1);
    }
    return pickUpDate;
}



</script>