<!-- #include file="kit_fun.cs" -->
<!-- #include file="catalog.cs" -->
<!-- #include file="price.cs" -->

<script runat=server>

string m_sql = "";//"SELECT p.code, p.id, p.name, p.brand, p.cat, p.s_cat, p.ss_cat, p.hot, c.skip FROM product p JOIN code_relations c ON p.id=c.id WHERE p.cat='hardware' AND p.'s_cat'='case' ORDER BY p.cat, p.s_cat, p.ss_cat, p.name, p.brand";
string m_code = "";
string m_c = "hardware";
string m_s = "case";
string m_co = "-1"; //cat for options
string m_so = "-1"; //s_cat for options
string m_ck = "-1"; //cat for options
string m_sk = "-1"; //s_cat for options
string m_action = "";
bool m_bUpdateCatalogTable = false;
//bool m_bSkipped = false; //indictate this is a skipped item

DataSet dsc = new DataSet();	//DataSet cache for code_relations and product_drop
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
DataRow[] dracr;	//for sorting code_relations

string copy_supplier = "";
string copy_supplier_code = "";
string copy_id = "";

string m_sCurrencyName = "NZD";

bool m_bSimpleInterface = false;
bool m_bFixedPrices = false;
bool m_bSecurityCheckAccessAllow = false;
bool m_bRoundItemPrice = false;
void Page_Load(Object Src, EventArgs E ) 
{



	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("manager"))
		return;
	m_bSecurityCheckAccessAllow = bSecurityAccess(Session["card_id"].ToString());
	if(MyBooleanParse(GetSiteSettings("simple_liveedit", "1", true)))
		m_bSimpleInterface = true;
	if(MyBooleanParse(GetSiteSettings("use_fixed_level_prices", "0", true)))
		m_bFixedPrices = true;
	m_bRoundItemPrice = MyBooleanParse(GetSiteSettings("round_price_no_cent", "0"));

	m_sCurrencyName = GetSiteSettings("default_currency_name", "NZD");
	InitKit();
	GetQueryStrings();

	if(m_action == "copy")
	{
		if(Request.Form["cmd"] == "Copy")
		{
			m_code = Request.QueryString["code"];
			if(DoCopyProduct())
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=liveedit.aspx?code=" + m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
		}
		else
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Copy Item</h3>");
			Response.Write("<form action=liveedit.aspx?action=copy&code=" + m_code + " method=post>");
			Response.Write("<table><tr><td>Supplier : </td><td>" + PrintSupplierOptionsWithShortName() + "</td></tr>");
			Response.Write("<tr><td>Supplier Code : </td><td><input type=text name=supplier_code></td></tr>");
			Response.Write("<tr><td colspan=2 align=right><input type=submit name=cmd value=Copy class=copyButton></td></tr>");
			Response.Write("</table></form>");
			PrintAdminFooter();
		}
		return;
	}

	PrintAdminHeader();
	PrintAdminMenu();
	WriteHeaders();
//DEBUG("action=", m_action);	
	Boolean bRet = true;
	if(m_action == "update")
	{

		string update = Request.Form["update"];
		if(update != null)
		{
			m_bUpdateCatalogTable = false;
			if(String.Compare(update, "update", true) == 0)
			{
				bRet = UpdateAllRows();
			}
//			if(m_bUpdateCatalogTable)
//				bRet = UpdateCatalogTable();
		}
//		else
//		{
//			bRet = DoSqlCmd(Request.Form["sSqlCmd"]);
//		}
		if(bRet)
		{
			TSRemoveCache(m_sCompanyName + "_" + m_sHeaderCacheName);
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=liveedit.aspx?code=" + m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\"></body></html>");
		}
	}
	else if(m_action == "add")
	{
		if(AddCross())
		{
			string s = "<br><br>done! wait a moment......... <br>\r\n";
			s += "<meta http-equiv=\"refresh\" content=\"1; URL=liveedit.aspx?code=";
			s += m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate();
			s += "\"></body></html>";
			Response.Write(s);
			TSRemoveCache(m_sCompanyName + "_" + m_sHeaderCacheName);
		}
	}
	else if(m_action == "delete")
	{
		if(DeleteCross())
		{
			string s = "<br><br>done! wait a moment......... <br>\r\n";
			s += "<meta http-equiv=\"refresh\" content=\"1; URL=liveedit.aspx?code=";
			s += m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate();
			s += "\"></body></html>";
			Response.Write(s);
			TSRemoveCache(m_sCompanyName + "_" + m_sHeaderCacheName);
		}
	}
	else
	{
		if(DoSearch())
		{	
			PrintJavaFunction();
			MyDrawTable();
		}
	}
	WriteFooter();
	PrintAdminFooter();
}

void GetQueryStrings()
{
	if(Request.Form["m_sql"] != null && Request.Form["m_sql"] != "")
		m_sql = Request.Form["m_sql"];

	m_code = Request.QueryString["code"];
	m_c = Request.QueryString["c"];
	m_s = Request.QueryString["s"];
	if(Request.QueryString["co"] != null)
		m_co = Request.QueryString["co"];
	if(Request.QueryString["so"] != null)
		m_so = Request.QueryString["so"];
	if(Request.QueryString["ck"] != null)
		m_ck = Request.QueryString["ck"];
	if(Request.QueryString["sk"] != null)
		m_sk = Request.QueryString["sk"];
	m_action = Request.QueryString["action"];
}

Boolean DoSearch()
{
	if(m_code == null || m_code == "")
	{
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=c.aspx\">");
		return false;
	}

	if(dst.Tables["product"] != null)
		dst.Tables["product"].Clear();

	int rows = 0;
	string id = "";
//	string sc = "SELECT supplier+supplier_code AS id FROM product WHERE code=" + m_code;
	string sc = "SELECT id, skip FROM code_relations WHERE code=" + m_code;
	if(m_supplierString != "")
		sc += " AND supplier IN" + m_supplierString + " ";
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "id");
		if(rows > 0)
			id = dst.Tables["id"].Rows[0]["id"].ToString();
//DEBUG("rows="+rows, " id="+id);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(id == "")
	{
		Response.Write("<h3>Product Not Found</h3>");
		return false;
	}
//DEBUG("id=", id);
	
	bool bSkipped = bool.Parse(dst.Tables["id"].Rows[0]["skip"].ToString());
	if(bSkipped)
	{
/*		sc = "SELECT c.code, c.supplier, c.supplier_code, c.id, c.name, c.brand, c.cat, c.s_cat, c.ss_cat, c.rate, ";
		sc += " c.clearance, c.currency, c.exchange_rate, c.foreign_supplier_price, c.nzd_freight, ";
		sc += " c.supplier_price, k.price, k.stock, k.eta, c.hot, c.skip, 0 AS special, c.is_service ";
		sc += ", c.level_rate1, c.level_rate2, c.qty_break1, c.qty_break2, c.qty_break3, c.qty_break4, c.average_cost "; 
		sc += ", c.level_rate3, c.level_rate4, c.level_rate5, c.level_rate6, c.level_rate7, c.level_rate8, c.level_rate9 ";
		sc += ", c.qty_break5, c.qty_break6, c.qty_break7, c.qty_break8, c.qty_break9 ";
		sc += ", c.qty_break_discount1, c.qty_break_discount2, c.qty_break_discount3, c.qty_break_discount4 ";
		sc += ", c.qty_break_discount5, c.qty_break_discount6, c.qty_break_discount7, c.qty_break_discount8 ";
		sc += ", c.qty_break_discount9, c.rrp, c.weight, c.stock_location ";
		sc += ", c.qty_break_price1, c.qty_break_price2, c.qty_break_price3, c.qty_break_price4 ";
		sc += ", c.qty_break_price5, c.qty_break_price6, c.qty_break_price7, c.qty_break_price8 ";
		sc += ", c.qty_break_price9, c.qty_break_price10 ";
		sc += ", manual_cost_frd, c.manual_exchange_rate, c.manual_cost_nzd ";
*/
		sc = " SELECT c.*, k.price, k.stock, k.eta, 0 AS special ";
		sc += " FROM product_skip k JOIN code_relations c ON k.id=c.id WHERE c.id='" + id + "'";
	}
	else
	{
/*		sc = "SELECT c.code, c.supplier, c.supplier_code, c.id, p.name, p.brand, p.cat, p.s_cat, p.ss_cat, c.rate, ";
		sc += " c.clearance, c.currency, c.exchange_rate, c.foreign_supplier_price, c.nzd_freight, ";
		sc += " c.supplier_price, p.price, p.stock, p.eta, p.hot, c.skip, isnull(s.code, 0) AS special, c.is_service ";
		sc += ", c.level_rate1, c.level_rate2, c.qty_break1, c.qty_break2, c.qty_break3, c.qty_break4, c.average_cost "; 
		sc += ", c.level_rate3, c.level_rate4, c.level_rate5, c.level_rate6, c.level_rate7, c.level_rate8, c.level_rate9 ";
		sc += ", c.qty_break5, c.qty_break6, c.qty_break7, c.qty_break8, c.qty_break9 ";
		sc += ", c.qty_break_discount1, c.qty_break_discount2, c.qty_break_discount3, c.qty_break_discount4 ";
		sc += ", c.qty_break_discount5, c.qty_break_discount6, c.qty_break_discount7, c.qty_break_discount8 ";
		sc += ", c.qty_break_discount9, c.rrp, c.weight, c.stock_location ";
		sc += ", c.qty_break_price1, c.qty_break_price2, c.qty_break_price3, c.qty_break_price4 ";
		sc += ", c.qty_break_price5, c.qty_break_price6, c.qty_break_price7, c.qty_break_price8 ";
		sc += ", c.qty_break_price9, c.qty_break_price10 ";
		sc += ", manual_cost_frd, c.manual_exchange_rate, c.manual_cost_nzd ";
*/
		
		sc = " SELECT c.*, p.price ";
		sc += " , ISNULL((select sum(qty) FROM stock_qty WHERE code = p.code AND code = c.code AND branch_id = "+ Session["branch_id"] +"), 0) AS  stock ";
		sc += " , ISNULL((select sum(allocated_stock) FROM stock_qty WHERE code = p.code AND code = c.code AND branch_id = "+ Session["branch_id"] +"), 0) AS  allocated_stock ";
		//sc += ", p.stock ";
		sc += ", p.eta, p.hot, isnull(s.code, 0) AS special ";
		sc += " FROM product p JOIN code_relations c ON p.code=c.code LEFT OUTER JOIN specials s on p.code=s.code ";
		sc += " WHERE c.id='" + id + "'";
	}
	if(m_supplierString != "")
		sc += " AND c.supplier IN" + m_supplierString + " ";
//DEBUG("sc=", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows > 0)
	{
		string code = dst.Tables["product"].Rows[0]["code"].ToString();
//DEBUG("code=" + code, " m_code="+m_code);
		if(code != m_code)
		{
			sc = "UPDATE product SET code=" + code + " WHERE code=" + m_code;
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
			Response.Write("<font color=red><b>&nbsp;&nbsp;&nbsp;Notice: Wrong Product Code Corrected</b></font>");
		}
	}
	return true;
/*
	StringBuilder sb = new StringBuilder();
	sb.Append("SELECT p.code, c.id, p.name, p.brand, p.cat, p.s_cat, p.ss_cat, p.supplier_price, p.price, p.stock, p.hot, c.skip FROM product p JOIN code_relations c ON p.code=c.code WHERE ");
//DEBUG("m_code=", m_code);
	if(m_code != "")
	{
		sb.Append(" p.code='");
		sb.Append(m_code);
	}
	else
	{
		sb.Append(" p.cat='");
		sb.Append(m_c);
		sb.Append("' AND p.s_cat='");
		sb.Append(m_s);
	}
	sb.Append("' ORDER BY p.cat, p.s_cat, p.ss_cat, p.name, p.brand");

	m_sql = sb.ToString();
//DEBUG("sc=", m_sql);
	if(!DoSqlCmd(sb.ToString()))
		return false;
	return true;
*/
}

Boolean UpdateAllRows()
{
	int i = 0;
	string id = Request.Form["id"+i.ToString()];
//	while(id != null && id != "")
//	{
	//DEBUG("311 level_rate1=", Request.Form["level_rate1"]);
		if(!UpdateOneRow(i.ToString())){
			//DEBUG("313 level_rate1=", Request.Form["level_rate1"]);
			return false;
		}
			
//		i++;
//		id = Request.Form["id"+i.ToString()];
//	}
	return true;
}

Boolean UpdateOneRow(string sRow)
{
	Boolean bRet = true;

	string code		= Request.Form["code"+sRow];
	string id		= Request.Form["id"+sRow];
	string supplier	= Request.Form["supplier"+sRow];
	string supplier_code = Request.Form["supplier_code"+sRow];
	string name		= EncodeQuote(Request.Form["name"+sRow]);
	string brand	= EncodeQuote(Request.Form["brand"+sRow]);
	string cat		= EncodeQuote(Request.Form["cat"+sRow]);
	string s_cat	= EncodeQuote(Request.Form["s_cat"+sRow]);
	string ss_cat	= EncodeQuote(Request.Form["ss_cat"+sRow]);
	string supplier_price = Request.Form["supplier_price"+sRow];
	string supplier_price_old = Request.Form["supplier_price_old"+sRow];
	string price	= Request.Form["price"+sRow];
	string average_cost	= Request.Form["average_cost"];
	if(average_cost == "")
		average_cost = supplier_price;
	string stock	= Request.Form["stock"+sRow];
	string eta		= EncodeQuote(Request.Form["eta"+sRow]);
	string hot		= Request.Form["hot"+sRow];
	string skip		= Request.Form["skip"+sRow];
	string clearance = Request.Form["clearance"+sRow];
	string rate		= Request.Form["rate"+sRow];
	if(rate == "NaN")
		rate = "1.01";
	string currency	= Request.Form["currency_name"];
	currency = GetEnumID("currency", currency);
	string exchange_rate	= Request.Form["exrate"];
	string freight	= Request.Form["freight"];
	string foreign_supplier_price	= Request.Form["raw_supplier_price"];
	string weight = Request.Form["weight"+sRow];
	double dWeight = MyDoubleParse(weight);
	string stock_location = Request.Form["stock_location"];
	stock_location = EncodeQuote(stock_location);

	string barcode = Request.Form["barcode"];
	string expire_date = Request.Form["expire_date"];
	
	string is_service = Request.Form["is_service"];
	if(is_service == "on")
		is_service = "1";
	else
		is_service = "0";

	if(is_service == "1") //enforce
	{
		brand = "ServiceItem";
		cat = "ServiceItem";
	}

	//****account*******
	string sales_income = Request.Form["sales_income"].ToString();
	string sales_cost = Request.Form["costofsales"].ToString();
	string inventory = Request.Form["inventory"].ToString();
//******* end here *******

	string rrp		= Request.Form["rrp"+sRow];
	

    string show_price = Request.Form["show_price"];

    bool bSpecial = (Request.Form["special"+sRow] == "on");

    string t = "";

    if(bSpecial){
       
        t = rrp;
        rrp = show_price;
        show_price = t;
    }else{
        show_price = "0";
    }



    double drrp = MyDoubleParse(rrp);

	string manual_cost_frd = Request.Form["manual_cost_frd"];
	string manual_exchange_rate = Request.Form["manual_exrate"];
	string manual_cost_nzd = Request.Form["manual_cost_nzd"];
    string _supplier = Request.Form["supplier"];
    
    string forRetail = Request.Form["forRetail"];
    string forDealer = Request.Form["forDealer"];
    int show_level = 1; //1: retial 2: dealer 3: both 4: not show for anyone.
    if(forRetail == "on"){
        if(forDealer == "on" ){
            show_level = 3;
        }else{
            show_level = 1;
        }
    }else{
        if(forDealer == "on"){
            show_level = 2;
        }else{
            show_level = 4;
        }
    }
//DEBUG("show_proce", show_price);
	double[] level_rate = new double[9];
	double[] qty_discount = new double[9];
	double[] qty_price = new double[16];
	int[] qb = new int[9];

	int dls = MyIntParse(Request.Form["dls"]);
	int qbs = MyIntParse(Request.Form["qbs"]);

	int i = 0;
	for(i=0; i<dls; i++)
	{
		string ii = (i+1).ToString();
		level_rate[i] = MyDoubleParse(Request.Form["level_rate" + ii]);
		//DEBUG("438 level_rate[i]=", level_rate[i]);
	}
	for(i=0; i<qbs; i++)
	{
		string ii = (i+1).ToString();
		qb[i] = MyIntParse(Request.Form["qty_break" + ii]);
		qty_discount[i] = MyIntParse(Request.Form["qty_break_discount" + ii]);
		qty_price[i] = MyMoneyParse(Request.Form["qty_price" + ii]);
		//DEBUG("446 qty_price[i]=", qty_price[i]);
	}

	//update exchange rate if changed
	string rate_usd = Request.Form["rate_usd"];
	string rate_aud = Request.Form["rate_aud"];
	string rate_usd_old = Request.Form["rate_usd_old"];
	string rate_aud_old = Request.Form["rate_aud_old"];
	if(rate_usd != rate_usd_old)
		SetSiteSettings("exchange_rate_usd", rate_usd);
	if(rate_aud != rate_aud_old)
		SetSiteSettings("exchange_rate_aud", rate_aud);
	
	
	bool bSpecial_old = (Request.Form["special_old"+sRow] == "on");

	string price_old = Request.Form["price_old"+sRow];
	double dPrice_old = MyMoneyParse(price_old);
	double dsupplier_price_old = MyMoneyParse(supplier_price_old);
	double dRate = MyDoubleParse(rate);

	if(Request.Form["brand_new"+sRow] != "")
		brand = EncodeQuote(Request.Form["brand_new"+sRow]);
	if(Request.Form["cat_new"+sRow] != "")
		cat = EncodeQuote(Request.Form["cat_new"+sRow]);
	if(Request.Form["s_cat_new"+sRow] != "")
		s_cat = EncodeQuote(Request.Form["s_cat_new"+sRow]);
	if(Request.Form["ss_cat_new"+sRow] != "")
		ss_cat = EncodeQuote(Request.Form["ss_cat_new"+sRow]);

	string old_code		= EncodeQuote(Request.Form["old_code"+sRow]);
	string old_brand	= EncodeQuote(Request.Form["old_brand"+sRow]);
	string old_cat		= EncodeQuote(Request.Form["old_cat"+sRow]);
	string old_s_cat	= EncodeQuote(Request.Form["old_s_cat"+sRow]);
	string old_ss_cat	= EncodeQuote(Request.Form["old_ss_cat"+sRow]);
	string old_hot		= EncodeQuote(Request.Form["old_hot"+sRow]);
	string old_skip		= EncodeQuote(Request.Form["old_skip"+sRow]);

	if(String.Compare(brand, old_brand, true) != 0)
	{
		m_bUpdateCatalogTable = true;
	}
	else
	{
		if(String.Compare(cat, old_cat, true) != 0)
			m_bUpdateCatalogTable = true;
		else
		{
			if(String.Compare(s_cat, old_s_cat, true) != 0)
				m_bUpdateCatalogTable = true;
			else
			{
				if(String.Compare(ss_cat, old_ss_cat, true) != 0)
					m_bUpdateCatalogTable = true;
				else
				{
					if(String.Compare(hot, old_hot, true) != 0)
						m_bUpdateCatalogTable = true;
				}
			}
		}
	}
	
	if(hot == null)
		hot = "0";
	else
		hot = "1";

	if(skip == null)
		skip = "0";
	else
		skip = "1";

	if(clearance == "on")
		clearance = "1";
	else
		clearance = "0";

	double dsupplier_price = MyMoneyParse(supplier_price);
	double dPrice = MyMoneyParse(price);
	if(dsupplier_price.ToString().ToLower() == "infinity" || dsupplier_price.ToString().ToLower() == "nan")
		supplier_price = "0";


	if(supplier_price == "0")
	{
		dRate = 1;
		Response.Write("<font color=red><h3>Error, supplier_price is 0, please skip this product.</h3></font>");
		return false;
	}

	if(dsupplier_price != dsupplier_price_old) //supplier price change
	{
		if(!WritePriceHistory(code, dPrice * level_rate[0], dPrice_old * level_rate[0])) //use level 1 price as retail price
			return false;
	}
	
	if(stock == "")
		stock = "null";
	StringBuilder sb = new StringBuilder();

	//check kit needs
	if(skip == "1")
	{
		if(Kit_NeedThisItem(code, "phased out"))
		{
			return false;
		}
	}

	string sc = "";
	if(m_bSimpleInterface)
	{

		sc = " UPDATE code_relations SET ";
		sc += " name = '" + name + "' ";
		sc += ", brand = '" + brand + "' ";
		sc += ", cat = '" + cat + "' ";
		sc += ", s_cat = '" + s_cat + "' ";
		sc += ", ss_cat = '" + ss_cat + "' ";
        sc += ", supplier = '" + _supplier + "' ";
//		sc += ", price = " + dPrice;
		for(i=0; i<qbs; i++)
		{
			string ii = (i+1).ToString();
			sc += ", qty_break" + ii + " = " + qb[i];
			sc += ", qty_break_price" + ii + " = " + qty_price[i];
		}
		for(int iii = 0; iii<dls; iii++){
			string ss = (iii + 1).ToString();
			sc += ", level_rate" + ss + " = " + level_rate[iii];
		}
		sc += " WHERE code=" + code;
		sc += " UPDATE product SET ";
		sc += " name = '" + name + "' ";
		sc += ", brand = '" + brand + "' ";
		sc += ", cat = '" + cat + "' ";
		sc += ", s_cat = '" + s_cat + "' ";
		sc += ", ss_cat = '" + ss_cat + "' ";
//		sc += "', hot=" + hot;
//		sc += ", skip=" + skip + ", clearance=" + clearance;
        sc += "', show_price=" + show_price;
        sc += "', show_level=" + show_level;
		sc += ", price = " + dPrice;
        sc += ", supplier = '" + _supplier + "' ";		

		sc += " WHERE code=" + code;

		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception esc) 
		{
			ShowExp(sc, esc);
			return false;
		}
		if(bSpecial != bSpecial_old)
		{
			if(bSpecial) //do insert
				bRet = AddSpecial(code);
			else //do delete
				bRet = RemoveSpecial(code);
		}
		return true;
	}
	else if(m_bFixedPrices)
	{

		string price1	= Request.Form["price1"];
		string price2	= Request.Form["price2"];
		string price3	= Request.Form["price3"];
		string price4	= Request.Form["price4"];
		string price5	= Request.Form["price5"];
		string price6	= Request.Form["price6"];
		string price7	= Request.Form["price7"];
		string price8	= Request.Form["price8"];
		string price9	= Request.Form["price9"];
		double dPrice1 = MyMoneyParse(price1);
		double dPrice2 = MyMoneyParse(price2);
		double dPrice3 = MyMoneyParse(price3);
		double dPrice4 = MyMoneyParse(price4);
		double dPrice5 = MyMoneyParse(price5);
		double dPrice6 = MyMoneyParse(price6);
		double dPrice7 = MyMoneyParse(price7);
		double dPrice8 = MyMoneyParse(price8);
		double dPrice9 = MyMoneyParse(price9);

		sc = " UPDATE code_relations SET ";
		sc += " name = '" + name + "' ";
		sc += ", brand = '" + brand + "' ";
		sc += ", cat = '" + cat + "' ";
		sc += ", s_cat = '" + s_cat + "' ";
		sc += ", ss_cat = '" + ss_cat + "' ";
		sc += ", price1 = " + dPrice1;
		sc += ", price2 = " + dPrice2;
		sc += ", price3 = " + dPrice3;
		sc += ", price4 = " + dPrice4;
		sc += ", price5 = " + dPrice5;
		sc += ", price6 = " + dPrice6;
		sc += ", price7 = " + dPrice7;
		sc += ", price8 = " + dPrice8;
		sc += ", price9 = " + dPrice9;
/*		for(i=0; i<qbs; i++)
		{
			string ii = (i+1).ToString();
			sc += ", qty_break" + ii + " = " + qb[i];
			sc += ", qty_break_price" + ii + " = " + qty_price[i];
		}
*/
		for(int iii = 0; iii<dls; iii++){
			string ss = (iii + 1).ToString();
			sc += ", level_rate" + ss + " = " + level_rate[iii];
		}

		sc += " WHERE code=" + code;
		sc += " UPDATE product SET ";
		sc += " name = '" + name + "' ";
		sc += ", brand = '" + brand + "' ";
		sc += ", cat = '" + cat + "' ";
		sc += ", s_cat = '" + s_cat + "' ";
		sc += ", ss_cat = '" + ss_cat + "' ";
        sc += ", supplier = '" + _supplier + "' ";		
//		sc += "', hot=" + hot;
//		sc += ", skip=" + skip + ", clearance=" + clearance;
//		sc += ", price = " + dPrice;
		sc += " WHERE code=" + code;
		//DEBUG("668 sc=", sc);
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception esc) 
		{
			ShowExp(sc, esc);
			return false;
		}
		if(bSpecial != bSpecial_old)
		{
			if(bSpecial) //do insert
				bRet = AddSpecial(code);
			else //do delete
				bRet = RemoveSpecial(code);
		}
		return true;
	}
	
	//update code_relations
	sb.Append(" BEGIN TRANSACTION ");
	sb.Append(" SET DATEFORMAT dmy ");
	sb.Append(" UPDATE code_relations SET code=");
	sb.Append(code);
	sb.Append(", name='");
	sb.Append(name);
	sb.Append("', brand='");
	sb.Append(brand);
	sb.Append("', cat='");
	sb.Append(cat);
	sb.Append("', s_cat='");
	sb.Append(s_cat);
	sb.Append("', ss_cat='");
	sb.Append(ss_cat);
	sb.Append("', hot=");
	sb.Append(hot);
	sb.Append(", skip=" + skip + ", clearance=" + clearance);
	sb.Append(", supplier_price=");
	sb.Append(dsupplier_price);
//	sb.Append(", average_cost=");
//	sb.Append(average_cost);
	sb.Append(", rate=");
	sb.Append(dRate);
	if(currency != "")
		sb.Append(", currency='" + currency + "'");
	if(exchange_rate != "")
		sb.Append(", exchange_rate=" + exchange_rate);
	if(foreign_supplier_price != "")
		sb.Append(", foreign_supplier_price=" + foreign_supplier_price);
	if(freight != "")
		sb.Append(", nzd_freight=" + freight);

	sb.Append(", is_service=" + is_service);
    sb.Append(", supplier = '" + _supplier + "' ");
    	
	for(i=0; i<dls; i++)
	{
		string ii = (i+1).ToString();
		string slevel_rate = level_rate[i].ToString();
		if(slevel_rate == "" || slevel_rate == null || slevel_rate == "NaN" || slevel_rate == "Infinity")
			slevel_rate = "1";
		//sb.Append(", level_rate" + ii + " = " + level_rate[i]);
		sb.Append(", level_rate" + ii + " = " + slevel_rate);
	}
	for(i= 0; i<qbs; i++)
	{
		string ii = (i+1).ToString();
		sb.Append(", qty_break" + ii + " = " + qb[i]);
		sb.Append(", qty_break_discount" + ii + " = " + qty_discount[i]);
	}
	sb.Append(", manual_cost_frd=" + manual_cost_frd + ", manual_exchange_rate=" + manual_exchange_rate);
	sb.Append(", manual_cost_nzd=" + manual_cost_nzd);
	sb.Append(", rrp=" + drrp);
	sb.Append(", weight=" + dWeight);
	sb.Append(", stock_location='" + stock_location + "' ");
	sb.Append(", barcode='" + EncodeQuote(barcode) + "' ");
	if(expire_date != "")
		sb.Append(", expire_date='" + EncodeQuote(expire_date) + "' ");
	sb.Append(", inventory_account = "+ inventory +"");
	sb.Append(", income_account = "+ sales_income +"");
	sb.Append(", costofsales_account = "+ sales_cost +"");
    sb.Append(", show_price = "+ show_price +"");
    sb.Append(", show_level = "+ show_level +"");
	sb.Append(" WHERE id='");
	sb.Append(id);
	sb.Append("'");
	sb.Append(" COMMIT ");
	try
	{
		myCommand = new SqlCommand(sb.ToString());
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}

	sb.Remove(0, sb.Length);
	if(skip != old_skip)
	{
		if(skip=="1")
		{
			//add to to product_skip table
			sc = " IF NOT EXISTS (SELECT id FROM product_skip WHERE id = '"+ id +"' ) ";
			sc += " INSERT INTO product_skip (id, stock, eta, supplier_price, price) VALUES('";
			sc += id + "', " + stock + ", '" + eta + "', " + supplier_price + ", " + price + ")";
			sc += " ELSE ";
			sc += " UPDATE product_skip set stock = "+ stock +" ";		
			sc += " , eta = '"+ eta +"' ";
			sc += " , supplier_price = "+ supplier_price +" ";
			sc += " , price = "+ price +"";
			sc += " WHERE id = '"+ id +"' ";
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
			
			//delete from product table
			sb.Append("DELETE FROM product WHERE code=" + old_code);
		}
		else
		{
			//can we insert it back to product table at this time?  maybe this one was 
			//discontinued a long time ago so simply update code_relations talbe, or better
			//wait it comes back at next autoupdate? DW 27.Jun.2002
			sc = " IF NOT EXISTS (SELECT code FROM product WHERE code=" + code + " ) ";
			sc += " INSERT INTO product (supplier, supplier_code, code, name, brand, cat, s_cat, ss_cat, supplier_price, ";
			sc += "price, stock, eta, hot, price_age) ";
			sc += "VALUES('" + supplier + "', '" + supplier_code + "', " + code + ", '" + name;
			sc += "', '" + brand + "', '" + cat + "', '" + s_cat + "', '" + ss_cat;
			sc += "', " + supplier_price + ", " + price + ", " + stock + ", '" + eta + "', ";
			sc += hot + ", GETDATE())";
			sc += " IF NOT EXISTS (SELECT code FROM stock_qty WHERE code=" + code + " ) ";
			sc += " INSERT INTO stock_qty (code, qty, supplier_price, allocated_stock) ";
			sc += "VALUES(" + code + ", 0, " + supplier_price + ", 0)";

			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}

			//remove form product_skip
			sb.Append("DELETE FROM product_skip WHERE id='" + id + "'");
		}
	}
	else
	{
		if(skip == "0")
		{
			//update product (live update)
			sb.Append("UPDATE product SET code='");
			sb.Append(code);
			sb.Append("', name='");
			sb.Append(name);
			sb.Append("', brand='");
			sb.Append(brand);
			sb.Append("', cat='");
			sb.Append(cat);
			sb.Append("', s_cat='");
			sb.Append(s_cat);
			sb.Append("', ss_cat='");
			sb.Append(ss_cat);
			sb.Append("', supplier_price=");
			sb.Append(dsupplier_price);
			sb.Append(", price=");
			sb.Append(dPrice);
			sb.Append(", stock=");
			sb.Append(stock);
			sb.Append(", eta='");
			sb.Append(eta);
			sb.Append("', hot=");
			sb.Append(hot);
            sb.Append(", supplier = '" + _supplier + "' ");
			sb.Append(" WHERE code=");
			sb.Append(old_code);
            
		}
		else
		{
			//update product_skip (live update)
			sb.Append("UPDATE product_skip SET stock=");
			sb.Append(stock);
			sb.Append(", eta='");
			sb.Append(eta);
			sb.Append("', supplier_price=");
			sb.Append(supplier_price);
			sb.Append(", price=");
			sb.Append(price);
			sb.Append(" WHERE id='");
			sb.Append(id);
			sb.Append("'");
		}
	}
//DEBUG("sc=", sb.ToString());
	try
	{
		myCommand = new SqlCommand(sb.ToString());
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}

	//DO singleout check
	if(code != old_code)
	{
		bRet = SingleOut(code);
		m_code = code;
	}
	else if(skip != "1")
	{
		//check kit
		Kit_AutoUpdatePrice(code);
	}

	if(bSpecial != bSpecial_old)
	{
		if(bSpecial) //do insert
			bRet = AddSpecial(code);
		else //do delete
			bRet = RemoveSpecial(code);
	}
	
	return bRet;
}

bool CrossExists(string cat, string s_cat, string ss_cat)
{
	StringBuilder sb = new StringBuilder();
	sb.Append("SELECT * FROM cat_cross WHERE cat='");
	sb.Append(cat);
	sb.Append("' AND s_cat='");
	sb.Append(s_cat);
	sb.Append("' AND ss_cat='");
	sb.Append(ss_cat);
	sb.Append("' AND code=");
	sb.Append(m_code);
	try
	{
		DataSet dsex = new DataSet();
		myAdapter = new SqlDataAdapter(sb.ToString(), myConnection);
		if(myAdapter.Fill(dsex) > 0)
			return true;

	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return true; //return true to stop adding
	}
	return false;
}

bool AddCross()
{
	string cat = EncodeQuote(Request.Form["cat"]);
	string s_cat = EncodeQuote(Request.Form["s_cat"]);
	string ss_cat = EncodeQuote(Request.Form["ss_cat"]);
	if(CrossExists(cat, s_cat, ss_cat))
		return true;
	StringBuilder sb = new StringBuilder();
	sb.Append("INSERT INTO cat_cross (cat, s_cat, ss_cat, code) VALUES('");
	sb.Append(cat);
	sb.Append("', '");
	sb.Append(s_cat);
	sb.Append("', '");
	sb.Append(ss_cat);
	sb.Append("', ");
	sb.Append(m_code);
	sb.Append(")");
	try
	{
		myCommand = new SqlCommand(sb.ToString());
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}
	return true;
}

bool DeleteCross()
{
	string cat = EncodeQuote(Request.QueryString["c"]);
	string s_cat = EncodeQuote(Request.QueryString["s"]);
	string ss_cat = EncodeQuote(Request.QueryString["ss"]);
	StringBuilder sb = new StringBuilder();
	sb.Append("DELETE FROM cat_cross WHERE code=" + m_code + " AND cat='");
	sb.Append(cat);
	sb.Append("' AND s_cat='");
	sb.Append(s_cat);
	sb.Append("' AND ss_cat='");
	sb.Append(ss_cat);
	sb.Append("'");
	try
	{
		myCommand = new SqlCommand(sb.ToString());
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}
	return true;
}

void WriteHeaders()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<br><center><h3>Edit Product</h3></center>");
	Response.Write(sb.ToString());
	Response.Flush();
}

void WriteFooter()
{
	StringBuilder sb = new StringBuilder();
//	sb.Append("</form>");
	Response.Write(sb.ToString());
}

bool GetCrossReferences()
{
	int rows = 0;
	string sc = "SELECT cat, s_cat, ss_cat FROM cat_cross WHERE code=" + m_code + " ORDER BY cat, s_cat, ss_cat";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "cross");
//DEBUG("sc=", sc);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
//	if(rows <= 0)
//		return true;
	if(dsAEV.Tables["cat"].Rows.Count <= 0)
		return true;

	if(m_co == "-1")
		m_co = dsAEV.Tables["cat"].Rows[0][0].ToString(); 
	sc = "cat='" +  m_co + "' ORDER BY s_cat";
//DEBUG("sc=", sc);
	if(!ECATGetAllExistsValues("s_cat", sc, false))
		return false;

	if(m_so == "-1")
		m_so = dsAEV.Tables["s_cat"].Rows[0][0].ToString();
	sc = "cat='" + m_co + "' AND s_cat='" + m_so + "' ORDER BY ss_cat";
	if(!ECATGetAllExistsValues("ss_cat", sc, false))
		return false;

	return true;
}

string PrintCrossReferences()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<a name=cross>");
	sb.Append("<form name=form2 action=liveedit.aspx?action=add&code=" + m_code + " method=post>");
	sb.Append("<table width=100%  cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	sb.Append("<tr class=tableHeader><td>CAT</td><td>S_CAT</td><td>SS_CAT</td><td>ACTION</td></tr>");
	bool alterColor = true;
	for(int i=0; i<dst.Tables["cross"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["cross"].Rows[i];
		string cat = dr["cat"].ToString();
		string s_cat = dr["s_cat"].ToString();
		string ss_cat = dr["ss_cat"].ToString();
		alterColor = !alterColor;
		sb.Append("<tr");
		if(alterColor)
			sb.Append(" bgcolor=#EEEEEE");
		sb.Append("><td>");
		sb.Append(cat);
		sb.Append("</td><td>");
		sb.Append(s_cat);
		sb.Append("</td><td>");
		sb.Append(ss_cat);
		sb.Append("</td><td align=right><a class=linkButton href=liveedit.aspx?action=delete&code=" + m_code + "&c=");
		sb.Append(HttpUtility.UrlEncode(cat));
		sb.Append("&s=");
		sb.Append(HttpUtility.UrlEncode(s_cat));
		sb.Append("&ss=");
		sb.Append(HttpUtility.UrlEncode(ss_cat));
		sb.Append(">DELETE</a></td></tr>");
	}
	sb.Append("<tr><td>&nbsp;</td></tr><tr><td>");
	sb.Append(PrintSelectionRowForCross("cat", m_co));
	sb.Append("</td><td>");
	sb.Append(PrintSelectionRowForCross("s_cat", m_so));
	sb.Append("</td><td>");
	sb.Append(PrintSelectionRowForCross("ss_cat", ""));
	sb.Append("</td><td align=right><input type=submit value=' Add ' class=linkButton title='Add'></td></tr>");
	sb.Append("</table</form>");
	return sb.ToString();
}

bool MyDrawTable()
{
	if(dst.Tables["product"].Rows.Count <=0 )
	{
		Response.Write("<h3>Product Not Found</h3>");
		return true;
	}

	bool bRet = true;
	Response.Write("<table width=70%  align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td>");
	
	//print edit table
	Response.Write("<form name=form1 action=liveedit.aspx?action=update&code=");
	Response.Write(m_code);
	Response.Write(" method=post>\r\n");
	Response.Write("<input type=hidden name=m_sql value='");
	Response.Write(m_sql);
	Response.Write("'>\r\n");
	
	Response.Write("<table id=editProductTable>");
	Response.Write("<tr class=rowColor><td><font class=bigFont>NAME</font></td><td colspan=2><font class=bigFont>VALUE</font></td></tr>");
	string s = "";
	DataRow dr;
//DEBUG("dst.Tables[product].Rows.Count=", dst.Tables["product"].Rows.Count);
	for(int i=0; i<dst.Tables["product"].Rows.Count; i++)
	{
		dr = dst.Tables["product"].Rows[i];
		if(!DrawRow(dr, i))
		{
			bRet = false;
			break;
		}
	}

    //Response.Write("<a href=ep.aspx?code=" + m_code + " class=x>Edit Details</a> ");
    //Response.Write("<a href=addpic.aspx?code=" + m_code + " class=x>Edit Photo</a> "); //</td></tr>");
    //if(m_bSecurityCheckAccessAllow)
    //{		
    //    Response.Write("<input type=submit name=update title= 'Update All' value='Update' " + Session["button_style"] + ">");
    //    if(!bool.Parse(dst.Tables["product"].Rows[0]["skip"].ToString()))
    //        Response.Write("<input type=button value='Copy Item' onclick=window.location=('liveedit.aspx?action=copy&code=" + m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') " + Session["button_style"] + ">");
    //}
	Response.Write("</td></tr>");
	Response.Write("</table></form>");

	if(m_bSimpleInterface || m_bFixedPrices)
		return true;

	Response.Write("</td></tr><tr class=rowColor><td><b>CATEGORY CROSS REFERENCES</b></td></tr>");
	Response.Write("<tr><td>");

	if(!GetCrossReferences())
	{
		Response.Write("</td></tr></table>");
		return false;
	}

	Response.Write(PrintCrossReferences());
	Response.Write("</td></tr>");
	
	Response.Write("</table>\r\n");

	return bRet;
}
void ShowAccountList(string sales_income, string sales_cost, string inventory)
{
		//*** this section is for account setting... *****

	Response.Write("<tr><td colspan=5><br>");
	Response.Write("<table width=100%>");
	Response.Write("<tr><td  width=25%><b>COST OF SALES</b><br /><br /><b>SALES INCOME<br /></b><br /><b>INVENTORY</b></td>");
	Response.Write("<td  width=25%>");
	Response.Write("<select name=costofsales>");
	Response.Write(ShowAccountName(sales_cost, "5111"));
	Response.Write("</select>");
	Response.Write("<br /><br />");
	Response.Write("<select name=sales_income>");
	Response.Write(ShowAccountName(sales_income, "4111"));
	Response.Write("</select>");
	Response.Write("<br /><br />");
	Response.Write("<select name=inventory>");
	Response.Write(ShowAccountName(inventory, "1121"));
	Response.Write("</select>");
    Response.Write("</td>");
    Response.Write("<td align=right  width=50%>");

    Response.Write("<a href='ep.aspx?code=" + m_code + "' class=linkButton title='Edit Details'>Edit Details</a> <br /><br />");
	Response.Write("<a href='addpic.aspx?code=" + m_code + "' class=linkButton title='Edit Photo'>Edit Photo</a> <br /><br />"); //</td></tr>");
    Response.Write("<a href='addpdf.aspx?code=" + m_code + "' class=linkButton title='Edit PDF'>Edit PDF</a> <br /><br />"); 

	if(m_bSecurityCheckAccessAllow)
	{		
		if(!bool.Parse(dst.Tables["product"].Rows[0]["skip"].ToString()))
			Response.Write("<input type=button title='Copy Item' value='Copy Item' onclick=window.location=('liveedit.aspx?action=copy&code=" + m_code + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') class=linkButton><br /><br />");
        
        //output js function to check RRP price is lower than manual price.
        Response.Write("<script>");
        Response.Write(" function CheckRRPPrice(){");
        Response.Write("    var manualCost = $('#manual_cost_frd').val();");
        Response.Write("    var rrpPrice = $('#RRP_TXT_EXGST').val();");
        Response.Write("    var specialPrice = $('#ShowPriceExcGST').val();");
        Response.Write("    manualCost = Number(manualCost);");
        Response.Write("    rrpPrice = Number(rrpPrice);");
        Response.Write("    if(rrpPrice > 0){");
        Response.Write("        if(manualCost > rrpPrice){");
        Response.Write("            alert('The Manual cost must lower than RRP');");
        Response.Write("            return false;");
        Response.Write("        }");

        Response.Write("    }");
        Response.Write("    if(specialPrice > 0){");
        Response.Write("        if(manualCost > specialPrice){");
        Response.Write("            alert('The Manual cost must lower than Special price');");
        Response.Write("            return false;");
        Response.Write("        }");
        Response.Write("    }");

        Response.Write("    return true;");
        Response.Write("}");
        Response.Write("</");
        Response.Write("script>");


        Response.Write("<input type=submit name=update title= 'Update All' value='Update' class=updateAdjustmentButton onclick='return CheckRRPPrice();'><br /><br />");
	}

    Response.Write("</td>");
    Response.Write("</tr>");
	Response.Write("</table>");

    Response.Write("</td>");
    Response.Write("<td>");

	Response.Write("</td></tr>");
	//******* end here **********************//
}
string ShowAccountName(string accid, string sdefault)
{
	if(accid == "" || accid == null)
		accid = sdefault;
	string sc = " SELECT * FROM account order by class1 ";
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "acct");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string stext = "";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["acct"].Rows[i];
		string cname = (dr["name1"].ToString()).ToUpper() +" - "+ dr["name4"].ToString();
		string class_id = dr["class1"].ToString() + dr["class2"].ToString() + dr["class3"].ToString() + dr["class4"].ToString();
		stext += "<option value="+ class_id +" ";
		if(accid == class_id)
			stext += " selected ";
		stext += ">"+ cname +"</option>";
	}
	return stext;
}
void DrawTableHeader()
{
	StringBuilder sb = new StringBuilder();
	Response.Write(sb.ToString());
	Response.Flush();
}

bool DrawRow(DataRow dr, int row)
{
	string code = dr["code"].ToString();
	string id = dr["id"].ToString();
	string supplier = dr["supplier"].ToString();
	string supplier_code = dr["supplier_code"].ToString();
	string name = dr["name"].ToString();
	string brand = dr["brand"].ToString();
	string cat = dr["cat"].ToString();
	string s_cat = dr["s_cat"].ToString();
	string ss_cat = dr["ss_cat"].ToString();
	string supplier_price = dr["supplier_price"].ToString();
	string rate = dr["rate"].ToString();
//	string price = Math.Round(MyDoubleParse(dr["price"].ToString()), 2).ToString();
	string stock = GetStock(dr["code"].ToString()).ToString();//dr["stock"].ToString();
	string eta = dr["eta"].ToString();
	string hot = dr["hot"].ToString();
	string skip = dr["skip"].ToString();
	
	
	string clearance = dr["clearance"].ToString();
	string index = row.ToString();
	string currency = dr["currency"].ToString();
	string weight = dr["weight"].ToString();
	string stock_location = dr["stock_location"].ToString();
	string barcode = dr["barcode"].ToString();
	string sexpire = dr["expire_date"].ToString();
	string sales_income = dr["income_account"].ToString();
	string inventory = dr["inventory_account"].ToString();
	string sales_cost = dr["costofsales_account"].ToString();
	string allocated_stock = GetAllocatedStock(dr["code"].ToString()).ToString();//dr["allocated_stock"].ToString();
    string _supplier = dr["supplier"].ToString();
	System.IFormatProvider format =	new System.Globalization.CultureInfo("en-NZ", false);
	string expire_date = "";
	if(sexpire != ""){
        //DEBUG("sexpire=", sexpire);
        expire_date = DateTime.Parse(sexpire).ToString("dd-MM-yyyy");
    }
		
//DEBUG("currency==", currency);
	currency = GetEnumValue("currency", currency);

	bool bis_service = bool.Parse(dr["is_service"].ToString());

	supplier_price = Math.Round(MyDoubleParse(supplier_price), 2).ToString();
	string average_cost = dr["average_cost"].ToString();
	if(average_cost == "" || average_cost == "0")
		average_cost = supplier_price;
	average_cost = Math.Round(MyDoubleParse(average_cost), 2).ToString();
	
	string manual_exchange_rate = dr["manual_exchange_rate"].ToString();
	if(manual_exchange_rate == "")
		manual_exchange_rate = "1";
	string manual_cost_frd = Math.Round(MyDoubleParse(dr["manual_cost_frd"].ToString()), 2).ToString();
	string manual_cost_nzd = Math.Round(MyDoubleParse(dr["manual_cost_nzd"].ToString()), 2).ToString();

	string exchange_rate = dr["exchange_rate"].ToString();
	string foreign_supplier_price = Math.Round(MyDoubleParse(dr["foreign_supplier_price"].ToString()), 2).ToString();
	string nzd_freight = dr["nzd_freight"].ToString();

    string showPriceString = dr["show_price"].ToString(); 
    string rrp = dr["rrp"].ToString();
    string special = dr["special"].ToString();

    if(special != "0"){
        string t = "";
        t = rrp;
        rrp = showPriceString;
        showPriceString = t;
    }else{
        showPriceString = "";
    }



    double show_price = 0;
    try{
        
        double.TryParse(showPriceString, out show_price);
    }catch(Exception ex){
        show_price = 0;
    }   

    int show_level = 0;
    try{
        string showLevelString = dr["show_level"].ToString();
//DEBUG("1314showLevelString=", showLevelString);
       if(! int.TryParse(showLevelString, out show_level)){
            show_level = -1;
        }
    }catch(Exception ex){
        show_level = -1;
    }

	double dmcn = MyDoubleParse(manual_cost_nzd);
	double dmer = MyDoubleParse(manual_exchange_rate);
	double dbr = MyDoubleParse(rate);
//	string price = Math.Round( dmcn / dmer * dbr + MyDoubleParse(nzd_freight), 2).ToString();
	string price = Math.Round( dmcn * dbr + MyDoubleParse(nzd_freight), 2).ToString();

	string sSkip = "0";
	if(String.Compare(skip, "true", true) == 0)
		sSkip = "1";
	string sClearance = "0";
	if(String.Compare(clearance, "true", true) == 0)
		sClearance = "1";

//DEBUG("supplier_code=", supplier_code);
	Trim(ref name);
	Trim(ref brand);
	Trim(ref cat);
	Trim(ref s_cat);
	Trim(ref ss_cat);

	if(!ECATGetAllExistsValues("brand", "brand<>'-1' ORDER BY brand", false))
		return false ;
	if(!ECATGetAllExistsValues("cat", "cat<>'Brands' ORDER BY cat", false))
		return false;

	string sc = "";
	if(m_ck == "-1")
		sc = "cat='" + cat + "' ORDER BY s_cat";
	else
		sc = "cat='" + m_ck + "' ORDER BY s_cat";
	if(!ECATGetAllExistsValues("s_cat", sc, false))
		return false;

	if(m_ck == "-1")
	{
		if(m_sk == "-1")
			sc = "cat='" + cat + "' AND s_cat='" + s_cat + "' ORDER BY ss_cat";
		else
			sc = "cat='" + cat + "' AND s_cat='" + m_sk + "' ORDER BY ss_cat";
	}
	else
	{
		if(m_sk == "-1")
			sc = "cat='" + m_ck + "' AND s_cat='" + s_cat + "' ORDER BY ss_cat";
		else
			sc = "cat='" + m_ck + "' AND s_cat='" + m_sk + "' ORDER BY ss_cat";
	}
//DEBUG("sc=", sc);
	if(!ECATGetAllExistsValues("ss_cat", sc, false))
		return false;
	
	Response.Write("<input type=hidden name=old_code");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(code);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=old_cat");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(cat);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=old_s_cat");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(s_cat);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=old_ss_cat");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(ss_cat);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=old_hot");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(hot);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=supplier");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(supplier);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=supplier_code");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(supplier_code);
	Response.Write("'>\r\n");

	Response.Write("<input type=hidden name=price_old");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(price);
	Response.Write("'>\r\n");

//	Response.Write("<input type=hidden name=rate" + index + " value=" + dr["rate"].ToString() + ">");
	Response.Write("<input type=hidden name=supplier_price_old" + index + " value=" + dr["supplier_price"].ToString() + ">");

	Response.Write("<tr class=rowColor><td ><b>Code / ID</b></td><td colspan=2>" + code);
	Response.Write("<input type=hidden name=code");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(code);

	Response.Write("'> / " + id);
	Response.Write("<input type=hidden name=id");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(id);
	Response.Write("'>");
//*** change supplier code for product in the entire database, include code_relations, product, product_skip, sales, purchase_item table
	if(Session["email"].ToString() == "tee@ezsoft.com" || Session["email"].ToString() == "darcy@ezsoft.com" || Session["email"].ToString() == "neo@ezsoft.com" )
		Response.Write(" &nbsp;&nbsp;<a title='change supplier code in the entire database' href='chsupcd.aspx?e=new&cd="+ code +"' class=o>MPN CHANGES</a> " );
	Response.Write("</td>");
	Response.Write("</tr><tr><td><b>Description</b></td><td colspan=2>");
	/*Response.Write("<input type=text size=75  name=name");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(name);
	Response.Write("'>");
	*/
	Response.Write("<textarea cols=65 width=2 name=name");
	Response.Write(index);
	Response.Write(">");
	Response.Write(name);
	Response.Write("</textarea>");
	Response.Write("</td></tr><tr><td><b>Brand</b></td><td>");

	Response.Write(PrintSelectionRow("brand", brand, index));

	Response.Write("</td></tr><tr><td><b>Cat</b></td><td>");
	Response.Write(PrintSelectionRow("cat", cat, index));

	Response.Write("</td></tr><tr><td><b>S_Cat</b></td><td>");
	Response.Write(PrintSelectionRow("s_cat", s_cat, index));

	Response.Write("</td></tr><tr><td><b>SS_Cat</b></td><td>");
	Response.Write(PrintSelectionRow("ss_cat", ss_cat, index));

	if(m_bSimpleInterface)
	{
		PrintSimpleInterface(dr, row);
		return true;
	}
	else if(m_bFixedPrices)
	{
		PrintFixedPricesInterface(dr, row);
		return true;
	}

	Response.Write("<tr><td><b>Stock</b></td><td><input type=text size=3 readonly=true style=text-align:right name=stock");
	Response.Write(index);
	Response.Write(" value='");
	Response.Write(stock);
	Response.Write("'> &nbsp&nbsp; <b>Allocated Stock: </b></td><td><input type=text  name=allocated_stock");
	Response.Write(index + " value='" + allocated_stock + "'></td></tr>");
	
	Response.Write("<tr><td><b>ETA</b></td><td colspan=2><input type=text size=55 name=eta"+index + " value='" + eta + "'>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td><b>Barcode</b></td><td colspan=2><input type=text size=50 name=barcode ");
	Response.Write(" value='" + barcode + "'></td></tr>");
	Response.Write("<tr><td><b>ExpireDate</b></td><td colspan=2><input type=text size=10 name=expire_date ");
	Response.Write(" value='" + expire_date + "'>(dd-mm-yyyy)</td></tr>");

    Response.Write("<tr><td><b>Supplier</b></td><td colspan=2>");
    //Response.Write(_supplier);
    Response.Write(PrintSupplierOptionsWithShortName_Addp(true, _supplier));
	Response.Write("</td></tr>");

	Response.Write("<tr><td><b>Status</b></td><td colspan=2>");
//	Response.Write("<table border=1 width=100%><tr><td>");
//	Response.Write("<b>Status : &nbsp&nbsp&nbsp&nbsp; </b>");
	Response.Write("<input type=checkbox name=hot" + index + " value=");
	if(String.Compare(hot, "true", true) == 0)
		Response.Write("1 checked");
	else
		Response.Write("0 unchecked");
	Response.Write(">New &nbsp&nbsp&nbsp&nbsp; <input type=checkbox name=skip" + index + " value=" + sSkip);
	if(sSkip == "1")
		Response.Write(" checked");
	else
		Response.Write(" unchecked");
	Response.Write(">Phased Out &nbsp&nbsp&nbsp&nbsp; <input type=hidden name=old_skip" + index.ToString() + " value=" + sSkip + ">");

	Response.Write("<input id='isSpecial' type=checkbox name=special" + index);
	if(special != "0")
		Response.Write(" checked");
	Response.Write(">Special &nbsp&nbsp&nbsp&nbsp; <input type=hidden name=special_old" + index + " value=");
	if(special != "0")
		Response.Write("on");
	Response.Write("><input type=checkbox name=clearance" + index);
	if(sClearance == "1")
		Response.Write(" checked");
	else
		Response.Write(" unchecked");
	Response.Write(">Clearance &nbsp&nbsp&nbsp&nbsp; ");
	
	Response.Write("<input type=checkbox name=is_service ");
	if(bis_service)
		Response.Write(" checked");
	Response.Write("><font color=red><b>Service</b></font>");

	Response.Write("</td></tr>\r\n");

	
	//currency selection
	string rate_usd = GetSiteSettings("exchange_rate_usd", "0.49");
	string rate_aud = GetSiteSettings("exchange_rate_aud", "0.87");
    string rate_euro = GetSiteSettings("exchange_rate_euro", "0.75");

	Response.Write("<input type=hidden name=rate_nzd value=1>");
	Response.Write("<input type=hidden name=rate_usd value=" + rate_usd + ">");
	Response.Write("<input type=hidden name=rate_aud value=" + rate_aud + ">");
    Response.Write("<input type=hidden name=rate_euro value=" + rate_euro + ">");
	Response.Write("<input type=hidden name=rate_usd_old value=" + rate_usd + ">");
	Response.Write("<input type=hidden name=rate_aud_old value=" + rate_aud + ">");
    Response.Write("<input type=hidden name=rate_euro_old value=" + rate_euro + ">");
	Response.Write("<input type=hidden name=currency_name value='" + currency + "'>");
//DEBUG("currency_name==", currency);
	Response.Write("<tr><td colspan=3>");
	Response.Write("<table class=editNewProductTable>");
	Response.Write("<tr><td>");
	Response.Write("<table >");

	if(m_bSecurityCheckAccessAllow)
	{
	    //Currency & Exchange-Rate
	    Response.Write("<tr><td><b>Last Cost(FRD)</b></td><td>");
	    Response.Write("<input type=text size=5 style=text-align:right name=raw_supplier_price value='" + foreign_supplier_price + "' onchange=\"CalcCost()\">");
    //DEBUG("currentName=", currency);
        Response.Write("</td><td><b>Currency</b></td><td><select name=currency onchange=\"UpdateCurrency()\">");
	    Response.Write("<option value=1>NZD</option>");
	    Response.Write("<option value=" + rate_usd);
	    if(currency == "usd")
		    Response.Write(" selected");
	    Response.Write(">USD</option>");
	    Response.Write("<option value=" + rate_aud);
	    if(currency == "aud")
		    Response.Write(" selected");
	    Response.Write(">AUD</option>");
        Response.Write("<option value=" + rate_euro );
	    if(currency == "euro")
		    Response.Write(" selected");
	    Response.Write(">EURO</option>");
	    Response.Write("</select>");

	    Response.Write("</td><td><b>Exchange Rate</b></td><td><input type=text size=5 style=text-align:right name=exrate value='" + exchange_rate + "' onchange=\"UpdateExRate()\"></td>");
	    Response.Write("</tr>");

	    Response.Write("<tr><td><b>Last Cost"+"("+m_sCurrencyName+")"+"</b></td><td>");
	    Response.Write("<input type=text size=5 readonly=true style=text-align:right;background-color:#EEEEEE name=supplier_price" + index);
	    Response.Write(" onchange=\"CalcPrice()\" value=" + supplier_price + "></td>");
    //	Response.Write("<td><b>Average Cost : </b></td><td><font color=red><b>NZD" + MyMoneyParse(average_cost).ToString("c") + "</b></font></td>");
    /*	Response.Write("<td><b>Average Cost"+"("+m_sCurrencyName+")"+" : </b></td>");
	    Response.Write("<td><input type=text size=5 ");
	    if(sSkip == "0")
		    Response.Write("style=text-align:right;background-color:#EEEEEE readonly=true ");
	    else
		    Response.Write("style=text-align:right;");
	    Response.Write(" name=average_cost value='" + average_cost + "'></td>");
    */
	    Response.Write("<td><b>Freight"+"("+m_sCurrencyName+")"+"</b></td><td><input type=text size=5 style=text-align:right name=freight value='" + nzd_freight + "' onchange=\"CalcManualCost()\"></td>");
    //	Response.Write("<td><b>Stock Location</b></td><td><input type=text size=5 name=stock_location style=text-align:right maxlength=48 value='" + stock_location + "'></td>");
	    Response.Write("</tr>");

	    //manual
	    Response.Write("<tr><td><b>Manual Cost(FRD)</b></td><td>");
	    Response.Write("<input type=text size=5 style=text-align:right id='manual_cost_frd' name=manual_cost_frd");
	    Response.Write(" onchange=\"CalcManualCost()\" value=" + manual_cost_frd + "></td>");
	    Response.Write("<td><b>Manual Ex-Rate</b></td><td>");
	    Response.Write("<input type=text size=5 style=text-align:right name=manual_exrate");
	    Response.Write(" onchange=\"CalcManualCost()\" value=" + manual_exchange_rate + "></td>");
	    Response.Write("<td><b>Manual COST"+"("+m_sCurrencyName+")"+"</b></td><td>");
	    Response.Write("<input type=text size=5 style=text-align:right;background-color:#EEEEEE readonly=true name=manual_cost_nzd");
	    Response.Write(" value=" + manual_cost_nzd + "></td>");
	    Response.Write("</tr>");
	
	    //bottom rate and price
	    Response.Write("<tr>");
	    Response.Write("<td><b>Bottom Rate</b></td><td><input type=text size=5 style=text-align:right name=rate" + index);
	    Response.Write(" onchange=\"CalcPrice()\" value=" + rate + "></td>");
	    Response.Write("<td><b>Bottom Price</b></td><td><input id=price0 type=text size=5 style=text-align:right ");
	    if(sClearance != "1")
		    Response.Write(" readonly=true ");
	    Response.Write("  name=price" + index + " value=" + price + "></td>");
	
   
	    Response.Write("<td><b>RRP</b></td><td><input id='RRP_TXT' size=5  name=rrp" + index + " value=" + rrp + "  />Inc. GST<input id='RRP_TXT_EXGST' style='text-align:right;background-color:#EEEEEE;text-align:right;' readonly=readonly type=text size=5  ");
	    Response.Write(" >Exc. GST</td>");

	    Response.Write("</tr>");
	}
	//weight, stock location
	Response.Write("<tr>");
	Response.Write("<td><b>Item Weight(kg)</b></td><td><input type=text size=5 style=text-align:right name=weight" + index);
	Response.Write(" value='"+ weight +"' ></td>");
	Response.Write("<td><b>Stock Location</b></td><td><input type=text size=5 name=stock_location style=text-align:right maxlength=48 value='" + stock_location + "'></td>");
	Response.Write("<td class='isShowPrice'><b style='color:red'>Special Price</b></td><td class='isShowPrice'><input id='ShowPriceIncGST' size=5  name=show_price value='"+show_price+"'  /> Inc. GST<input id='ShowPriceExcGST' size=5% style='text-align:right;background-color:#EEEEEE' readonly=readonly type=text >Exc. GST</td>");
    Response.Write("</tr>");

	Response.Write("</table>");

    Response.Write("<script type='text/javascript'>");
    Response.Write("$(document).ready(function () {");
    Response.Write("    checkShowPrice();");
    Response.Write("	$('#isSpecial').click(function(){");
    Response.Write("		checkShowPrice();");
    Response.Write("	});");
    Response.Write("});");
    Response.Write("function checkShowPrice(){");
    Response.Write("	if($('#isSpecial').is(':checked')) {");
    Response.Write("		$('.isShowPrice').css('display', 'table-cell');");
    Response.Write("	}else{");
    Response.Write("		$('.isShowPrice').css('display', 'none');");
    Response.Write("		autoCal3();");
    Response.Write("	}");
    Response.Write("}");
    Response.Write("</");
    Response.Write("script>");

	Response.Write("</td></tr></table>");

	Response.Write("</td></tr>");

//	double level_rate3 = Math.Round(GetLevelRate(3, level_rate1, level_rate2), 4);
//	double level_rate4 = Math.Round(GetLevelRate(4, level_rate1, level_rate2), 4);
//	double level_rate5 = Math.Round(GetLevelRate(5, level_rate1, level_rate2), 4);
//	double level_rate6 = 1;

	double dPrice = MyDoubleParse(price);

	int i = 0;
	int[] qb = new int[9]; //qty breaks;
	double[] dQPrice = new double[9];
	double[] dLPrice = new double[9];
	double[] level_rate = new double[9];
	double[] dQDiscount = new double[9];

	for(i=0; i<9; i++)
	{
		string ii = (i+1).ToString();
		
		string si = dr["level_rate" + ii].ToString();
		if(si == "")
			level_rate[i] = 2;
		else
			level_rate[i] = MyDoubleParse(dr["level_rate" + ii].ToString());
//DEBUG("1713level_rate=", "i=" + i + "  rate=" + level_rate[i]);
		si = dr["qty_break" + ii].ToString();
		if(si == "")
			qb[i] = 1;
		else
			qb[i] = MyIntParse(dr["qty_break" + ii].ToString());

		si = dr["qty_break_discount" + ii].ToString();
		if(si == "")
			dQDiscount[i] = 0;
		else
			dQDiscount[i] = MyIntParse(dr["qty_break_discount" + ii].ToString());
		
		dLPrice[i] = Math.Round(dPrice * level_rate[i], 2);
		dQPrice[i] = Math.Round(dLPrice[0] * (1 - dQDiscount[i]/100), 2);
	}

	int dls = MyIntParse(GetSiteSettings("dealer_levels", "3")); // how many dealer levels
	if(dls > 9)
		dls = 9;
	int qbs = MyIntParse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
	if(qbs > 9)
		qbs = 9;

	Response.Write("<input type=hidden name=dls value=" + dls + ">");
	Response.Write("<input type=hidden name=qbs value=" + qbs + ">");

/*	double dQDiscount1 = GetQuantityDiscount(qb[0], qb, level_rate2);
	double dQDiscount2 = GetQuantityDiscount(qb[1], qb, level_rate2);
	double dQDiscount3 = GetQuantityDiscount(qb[2], qb, level_rate2);
	double dQDiscount4 = GetQuantityDiscount(qb[3], qb, level_rate2);
*/

//	dQDiscount1 = Math.Round(1 - dQDiscount1, 4);

//calculate dealer level by given selling price
	//javascript start here
	Response.Write("<script language=javascript>");
	string s = @"
		function autoCal()
		{
			var SellingPrice, descreased, level1, level2, level3, level4, level5, level6, BottomPrice;
			SellingPrice = document.form1.sellingprice.value;
			BottomPrice = document.form1.price0.value;
			if(SellingPrice == '')
				return false;
			if(eval(SellingPrice) < eval(BottomPrice))
				return false;
			level1 = SellingPrice / BottomPrice;
			descreased = (level1 - 1) / 6;
			level2 = level1 - (2 * descreased);
			level3 = level1 - (3 * descreased);
			level4 = level1 - (4 * descreased);
			level5 = level1 - (5 * descreased);
			level6 = level1 - (6 * descreased);
            if(document.form1.level_rate1)
			    document.form1.level_rate1.value = level1;
            if(document.form1.level_price1)
                document.form1.level_price1.value = document.form1.price0.value * document.form1.level_rate1.value
			if(document.form1.level_rate2)
                document.form1.level_rate2.value = level2.toFixed(2);
            if(document.form1.level_price2)
                document.form1.level_price2.value = document.form1.price0.value * document.form1.level_rate2.value
			if(document.form1.level_rate3)
                document.form1.level_rate3.value = level3.toFixed(2);
            if(document.form1.level_price3)
                document.form1.level_price3.value = document.form1.price0.value * document.form1.level_rate3.value
			if(document.form1.level_rate4)
                document.form1.level_rate4.value = level4.toFixed(2);
            if(document.form1.level_price4)
                document.form1.level_price4.value = document.form1.price0.value * document.form1.level_rate4.value
			if(document.form1.level_rate5)
                document.form1.level_rate5.value = level5.toFixed(2);
            if(document.form1.level_price5)            
                document.form1.level_price5.value = document.form1.price0.value * document.form1.level_rate5.value
			if(document.form1.level_rate6)
                document.form1.level_rate6.value = level6.toFixed(2);
            if(document.form1.level_price6)
                document.form1.level_price6.value = document.form1.price0.value * document.form1.level_rate6.value
			return true;
		}
		";

    	s += @"
		function autoCal2()
		{
			var SellingPrice, descreased, level1, level2, level3, level4, level5, level6, BottomPrice;
			SellingPrice = Number($('#ShowPriceExcGST').val());
			BottomPrice = Number(document.form1.price0.value);
			if(SellingPrice == '')
				return false;
			if(eval(SellingPrice) < eval(BottomPrice))
				return false;
			level1 = SellingPrice / BottomPrice;
			descreased = (level1 - 1) / 6;
			level2 = level1 - (2 * descreased);
			level3 = level1 - (3 * descreased);
			level4 = level1 - (4 * descreased);
			level5 = level1 - (5 * descreased);
			level6 = level1 - (6 * descreased);
            if(document.form1.level_rate1)
			    document.form1.level_rate1.value = level1;
            if(document.form1.level_price1)
                document.form1.level_price1.value = document.form1.price0.value * document.form1.level_rate1.value
            if(document.form1.level_rate2)
			    document.form1.level_rate2.value = level2.toFixed(2);
            if(document.form1.level_price2)
                document.form1.level_price2.value = document.form1.price0.value * document.form1.level_rate2.value
            if(document.form1.level_rate3)
			    document.form1.level_rate3.value = level3.toFixed(2);
            if(document.form1.level_price3)
                document.form1.level_price3.value = document.form1.price0.value * document.form1.level_rate3.value
            if(document.form1.level_rate4)
			    document.form1.level_rate4.value = level4.toFixed(2);
            if(document.form1.level_price4)
                document.form1.level_price4.value = document.form1.price0.value * document.form1.level_rate4.value
            if(document.form1.level_rate5)
			    document.form1.level_rate5.value = level5.toFixed(2);
            if(document.form1.level_price5)
                document.form1.level_price5.value = document.form1.price0.value * document.form1.level_rate5.value
            if(document.form1.level_rate6)
			    document.form1.level_rate6.value = level6.toFixed(2);
            if(document.form1.level_price6)
                document.form1.level_price6.value = document.form1.price0.value * document.form1.level_rate6.value
			return true;
		}
		";

    	s += @"
		function autoCal3()
		{
			//document.form1.level_rate1.value = 1.08;
            if(document.form1.level_price1)
                document.form1.level_price1.value = document.form1.price0.value * document.form1.level_rate1.value
			//document.form1.level_rate2.value = 1.04;
            if(document.form1.level_price2)
                document.form1.level_price2.value = document.form1.price0.value * document.form1.level_rate2.value
			//document.form1.level_rate3.value = 1.03;
            if(document.form1.level_price3)
                document.form1.level_price3.value = document.form1.price0.value * document.form1.level_rate3.value
			//document.form1.level_rate4.value = 1.02;
            if(document.form1.level_price4)
                document.form1.level_price4.value = document.form1.price0.value * document.form1.level_rate4.value
			//document.form1.level_rate5.value = 1.01;
            if(document.form1.level_price5)
                document.form1.level_price5.value = document.form1.price0.value * document.form1.level_rate5.value
			//document.form1.level_rate6.value = 1;
            if(document.form1.level_price6)
                document.form1.level_price6.value = document.form1.price0.value * document.form1.level_rate6.value
			return true;
		}
		";
		
	Response.Write(s);
	Response.Write("</script");
	Response.Write(">");
	if(g_bRetailVersion)
	{
		Response.Write("<tr><td colspan=7>");
		Response.Write("<b>Selling Price: </b><input size=5% style=text-align:right type=text name=sellingprice>");
		Response.Write("<input type=button name='calme' value='Calculate Dealer Rate' title='Calculate Dealer Rate' class=linkButton");
		Response.Write(" Onclick='autoCal(); Calculate();' >");
		Response.Write("</td></tr>");
        Response.Write("<tr><td colspan=7>");
        string forRetailCheckBox = "checked='checked'";
        string forDealerCheckBox = "checked='checked'";
//DEBUG("1736show_level=", show_level);
        if(show_level == -1){
            forRetailCheckBox = "";
            forDealerCheckBox = "";
        }
        if(show_level == 0){
            forDealerCheckBox = "";
        }
        if(show_level == 1){
            forDealerCheckBox = "";
        }
        if(show_level == 2){
            forRetailCheckBox = "";
            forDealerCheckBox = "checked='checked'";
        }
        if(show_level == 3){
            forRetailCheckBox = "checked='checked'";
            forDealerCheckBox = "checked='checked'";
        }
        if(show_level == 4){
            forRetailCheckBox = "";
            forDealerCheckBox = "";
        }
    
        string checkRRPJS = @"
            <script language=javascript>
            function checkRRP(){
                var rrp = Number($('#RRP_TXT').val());
                if(rrp <= 0){
                    alert('Please ENTER RRP');
                    $('#forRetail').attr('checked', false);
                }
            }
        ";
        Response.Write(checkRRPJS);
        Response.Write("</");
        Response.Write("script>");
        Response.Write("<input id='forRetail' type='checkbox' onclick='checkRRP()' name='forRetail' "+forRetailCheckBox+" />For Retail  &nbsp;&nbsp;&nbsp;");
        Response.Write("<input type='checkbox' id='forDealer' name='forDealer' "+forDealerCheckBox+" />For Dealer");
        Response.Write("</td></tr>");
	}


	Response.Write("<tr><td colspan=3>");
	Response.Write("<table width=100%>");
	Response.Write("<tr><td valign=top>");
    Response.Write(OuputJsFunction());
	Response.Write("<table class=editNewProductTable>");
	Response.Write("<tr><td><b>Level</b></td><td><b>Rate <input id='ChangeRateRD' name='ModifyRate' type='radio' checked=checked onclick='EnableRate()' /></b></td><td><b>Price <input id='ChangePriceRD' name='ModifyRate' type='radio' onclick='EnablePrice()' /></b></td></tr>");
	Response.Write("<tr><td colspan=3><hr></td></tr>");

	for(i=0; i<dls; i++)
	{
		string ii = (i + 1).ToString();
		if(m_bRoundItemPrice)
			dLPrice[i] = Math.Round(dLPrice[i], 0);
		string lname = GetEnumValue("dealer_level_name", ii);
		if(lname == "")
			lname = "Level " + ii;
		Response.Write("<tr><td><b>" + lname + "<b></td>");
		Response.Write("<td><input type=text class='level_rate' size=5 data-value=level_price" + ii + " name=level_rate" + ii + " id=level_rate" + ii + " value=" + level_rate[i] + "></td>");
		Response.Write("<td><input type=text class='level_peice' size=5 data-value=level_rate" + ii + " id=level_price" + ii +" name=level_price" + ii);
		Response.Write(" style=text-align:right;background-color:#EEEEEE readonly=true ");
		Response.Write(" value=" + dLPrice[i].ToString() + "></td></tr>");
	}

	Response.Write("</table>");

	Response.Write("</td><td valign=top>");

	Response.Write("<table class=editNewProductTable>");
	Response.Write("<tr><td><b>Break</b></td><td><b>Quantity</b></td><td><b>Discount</b></td><td><b>Example(Level 1)</b></td></tr>");
	Response.Write("<tr><td colspan=4><hr></td></tr>");

//	Response.Write("<tr><td>0</td><td>1</td>");
//	Response.Write("<td>0.00</td><td>" + dLPrice[0].ToString("c") + "</td></tr>");
	for(i=0; i<qbs; i++)
	{
		string ii = (i + 1).ToString();
		if(m_bRoundItemPrice)
			dQPrice[i] = Math.Round(dQPrice[i], 0);
		Response.Write("<tr><td>" + ii + "</td><td>");
		Response.Write("<input type=text size=5 name=qty_break" + ii + " value=" + qb[i] + "></td>");
		Response.Write("<td><input type=text size=3 name=qty_break_discount" + ii + " value=" + dQDiscount[i] + ">%</td>");
		Response.Write("<td><input type=text size=5 name=qty_price" + ii);
		Response.Write(" style=text-align:right;background-color:#EEEEEE readonly=true ");
		Response.Write(" value=" + dQPrice[i].ToString() + "></td></tr>");
	}
	Response.Write("</table>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=3 align=right><input type=button class=linkButton value='Calculate' title=Calculate ");
	Response.Write(" onclick=\"Calculate();\">");
	Response.Write("</td></tr>");
	ShowAccountList(sales_income, sales_cost, inventory);
	Response.Write("</table>");
	
	return true;
}

bool PrintSimpleInterface(DataRow dr, int row)
{
	string index = row.ToString();

	string price = dr["price"].ToString();
	double dPrice = MyDoubleParse(price);
	string special = dr["special"].ToString();

	//bottom rate and price
	Response.Write("</table>");

	Response.Write("</td></tr>");
//	Response.Write("</table>");

//	Response.Write("</td></tr>");

	int i = 0;
	int[] qb = new int[16]; //qty breaks;
	double[] dQPrice = new double[16];
	double[] dLPrice = new double[16];
	double[] dQDiscount = new double[16];

	int qbs = MyIntParse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
	for(i=0; i<qbs; i++)
	{
		string ii = (i+1).ToString();
		qb[i] = MyIntParse(dr["qty_break" + ii].ToString());
		dQPrice[i] = MyDoubleParse(dr["qty_break_price" + ii].ToString());
		if(dQPrice[i] == 0)
		{
			if(i > 0)
				dQPrice[i] = dQPrice[i-1];
			else
				dQPrice[i] = dPrice;
		}
	}

	if(qbs > 15)
		qbs = 15;

	Response.Write("<input type=hidden name=qbs value=" + qbs + ">");

	Response.Write("<tr><td><b>Status</b> : ");
	Response.Write("<input type=checkbox name=special" + index);
	if(special != "0")
		Response.Write(" checked");
	Response.Write(">Special &nbsp&nbsp&nbsp&nbsp; <input type=hidden name=special_old" + index + " value=");
	if(special != "0")
		Response.Write("on");
	Response.Write(">");
	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=2>");
	Response.Write("<table width=100% align=center cellspacing=0 cellpadding=0>");
	Response.Write("<tr><td><b>Break</b></td><td><b>Quantity</b></td><td><b>Price</b></td></tr>");
	Response.Write("<tr><td colspan=4><hr></td></tr>");

	Response.Write("<tr bgcolor=#EEEEEE><td>0</td><td>1</td>");
	Response.Write("<td><input type=text size=5 style=text-align:right ");
	Response.Write("  name=price" + index + " value=" + price + "></td>");
	Response.Write("</td></tr>");

	bool bAlterColor = false;
	for(i=0; i<qbs; i++)
	{
		string ii = (i + 1).ToString();
		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=#EEEEEE");
		bAlterColor = !bAlterColor;
		Response.Write("><td>" + ii + "</td><td>");
		Response.Write("<input type=text size=5 name=qty_break" + ii + " value=" + qb[i] + "></td>");
//		Response.Write("<td><input type=text size=3 name=qty_break_discount" + ii + " value=" + dQDiscount[i] + ">%</td>");
		Response.Write("<td><input type=text size=5 name=qty_price" + ii);
		Response.Write(" style=text-align:right;");
		Response.Write(" value=" + dQPrice[i].ToString() + "></td></tr>");
	}
	Response.Write("</table>");

	Response.Write("</td></tr>");
//	Response.Write("</table>");
	return true;
}

bool PrintFixedPricesInterface(DataRow dr, int row)
{
	int dls = MyIntParse(GetSiteSettings("dealer_levels", "3")); // how many dealer levels

	int i = 0;
	string index = row.ToString();

	string[] price = new string[9];
	double[] dPrice = new double[9];
	for(i=0; i<dls; i++)
	{
		price[i] = dr["price" + (i+1).ToString()].ToString();
		dPrice[i] = MyMoneyParse(price[i]);
	}
	string special = dr["special"].ToString();

	//bottom rate and price
	Response.Write("</table>");

	Response.Write("</td></tr>");
//	Response.Write("</table>");

//	Response.Write("</td></tr>");

/*	int[] qb = new int[16]; //qty breaks;
	double[] dQPrice = new double[16];
	double[] dLPrice = new double[16];
	double[] dQDiscount = new double[16];

	int qbs = MyIntParse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
	for(i=0; i<qbs; i++)
	{
		string ii = (i+1).ToString();
		qb[i] = MyIntParse(dr["qty_break" + ii].ToString());
		dQPrice[i] = MyDoubleParse(dr["qty_break_price" + ii].ToString());
		if(dQPrice[i] == 0)
		{
			if(i > 0)
				dQPrice[i] = dQPrice[i-1];
			else
				dQPrice[i] = dPrice;
		}
	}

	if(qbs > 15)
		qbs = 15;

	Response.Write("<input type=hidden name=qbs value=" + qbs + ">");
*/
	Response.Write("<tr><td><b>Status</b> : ");
	Response.Write("<input type=checkbox name=special" + index);
	if(special != "0")
		Response.Write(" checked");
	Response.Write(">Special &nbsp&nbsp&nbsp&nbsp; <input type=hidden name=special_old" + index + " value=");
	if(special != "0")
		Response.Write("on");
	Response.Write(">");
	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=2>");
	Response.Write("<table width=100% align=center cellspacing=0 cellpadding=0>");
	Response.Write("<tr><td><b>Level</b></td><td><b>Price</b></td></tr>");
	Response.Write("<tr><td colspan=2><hr></td></tr>");

/*	Response.Write("<tr bgcolor=#EEEEEE><td>0</td><td>1</td>");
	Response.Write("<td><input type=text size=5 style=text-align:right ");
	Response.Write("  name=price" + index + " value=" + price + "></td>");
	Response.Write("</td></tr>");
*/
	bool bAlterColor = false;
	for(i=0; i<dls; i++)
	{
		string ii = (i + 1).ToString();
		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=#EEEEEE");
		bAlterColor = !bAlterColor;
		Response.Write("><td>" + ii + "</td><td>");
		Response.Write("<input type=text size=5 name=price" + ii + " value=" + dPrice[i] + " style=text-align:right;>");
//		Response.Write("<td><input type=text size=3 name=qty_break_discount" + ii + " value=" + dQDiscount[i] + ">%</td>");
//		Response.Write("<td><input type=text size=5 name=qty_price" + ii);
		Response.Write("</td></tr>");
	}
	Response.Write("</table>");

	Response.Write("</td></tr>");
//	Response.Write("</table>");
	return true;
}

Boolean UpdateCatalogTable()
{
	if(DoUpdateCatalogTable())
		return true;
	return false;
}

string PrintSelectionRow(string sName, string sValue, string index)
{
	bool bMatch = false;
	string str = "";
	StringBuilder sb = new StringBuilder();
	sb.Append("\r\n<select name=" + sName + index);
	if(sName != "brand" && sName != "ss_cat")
	{
		sb.Append(" onchange=\"window.location=('liveedit.aspx?code=" + m_code);
		sb.Append("&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
		if(sName == "cat")
			sb.Append("&sk=-1&ck='");
		else if(sName == "s_cat")
			sb.Append("&ck="+HttpUtility.UrlEncode(m_ck) + "&sk='");
		sb.Append("+this.options[this.selectedIndex].value)\"");
	}
	sb.Append(">");
	sb.Append("<option value=''></option>");
	for(int j=0; j<dsAEV.Tables[sName].Rows.Count; j++)
	{
		str = dsAEV.Tables[sName].Rows[j][0].ToString();
		str = str.TrimStart(null);
		str = str.TrimEnd(null);
		sb.Append("<option value='" + str + "'");
		if(!bMatch)
		{
			if(sName == "brand")
			{
				if(str == sValue)
				{
					bMatch = true;
					sb.Append(" selected");
				}
			}
			else if(sName == "cat")
			{
				if(m_ck == "-1")
				{
//DEBUG("s_value=", sValue);
					if(str == sValue)
					{
						bMatch = true;
						sb.Append(" selected");
					}
				}
				else
				{
					if(str == m_ck)
					{
						bMatch = true;
						sb.Append(" selected");
					}
				}
			}
			else if(sName == "s_cat")
			{
				if(m_sk == "-1")
				{
					if(str == sValue)
					{
						bMatch = true;
						sb.Append(" selected");
					}
				}
				else
				{
//DEBUG("m_sk="+m_sk, " str="+str);
					if(str == m_sk)
					{
						bMatch = true;
						sb.Append(" selected");
					}
				}
			}
			else if(sName == "ss_cat")
			{
				if(str == sValue)
				{
					bMatch = true;
					sb.Append(" selected");
				}
			}
		}

		sb.Append(">" + str + "</option>");
	}
	if(!bMatch && m_ck == "-1" && m_sk == "-1")
		sb.Append("<option value='" + sValue + "' selected>" + sValue + "</option>");
	sb.Append("</select>");
	sb.Append("</td><td><input type=text size=52 name=" + sName + "_new" + index + ">");
	return sb.ToString();
}

string PrintSelectionRowForCross(string sName, string sValue)
{
	bool bMatch = false;
	string str = "";
	StringBuilder sb = new StringBuilder();
	sb.Append("\r\n<select name=" + sName);
	if(sName != "ss_cat")
	{
		sb.Append(" onchange=\"window.location=('liveedit.aspx?code=" + m_code);
		if(sName == "cat")
			sb.Append("&so=-1&co='");
		else if(sName == "s_cat")
			sb.Append("&co="+HttpUtility.UrlEncode(m_co) + "&so='");
		sb.Append("+this.options[this.selectedIndex].value) + '#cross'\"");
	}
	sb.Append(">");
	for(int j=0; j<dsAEV.Tables[sName].Rows.Count; j++)
	{
		str = dsAEV.Tables[sName].Rows[j][0].ToString();
		sb.Append("<option value='" + str + "'");
		if(str == sValue)
		{
			bMatch = true;
			sb.Append(" selected");
		}
		if(!bMatch)
		{
			if(sName == "cat" && m_co == "-1")
			{
				bMatch = true;
				sb.Append(" selected");
			}
			else if(sName == "s_cat" && m_so == "-1")
			{
				if(str != "")
				{
					bMatch = true;
					sb.Append(" selected");
				}
			}
			else if(sName == "ss_cat")
			{
				if(str != "")
				{
					bMatch = true;
					sb.Append(" selected");
				}
			}
		}
		sb.Append(">"+str+"</option>");
	}
	if(!bMatch)
		sb.Append("<option value='" + sValue + "' selected>" + sValue + "</option></select>");
//	if(sName == "ss_cat")
//		sb.Append("<input type=text size=10 name=" + sName + "_new>");
	return sb.ToString();
}

bool DoCopyProduct()
{
	//m_code = GetNextCode();
	copy_supplier = Request.Form["supplier"];
	copy_supplier_code = Request.Form["supplier_code"];
	if(copy_supplier_code == "")
	{
		Response.Write("<br><br><h3>Error, no supplier code");
		return false;
	}
	copy_id = copy_supplier + copy_supplier_code;
	
	//check id vialation
	string sc = "SELECT * FROM code_relations WHERE id='" + copy_id + "'";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(dst, "id_check") > 0)
		{
			PrintAdminHeader();
			PrintAdminMenu();
			Response.Write("<br><br><center><h3>Error, dupplicate supplier code found</h3><br>");
			DataRow dr = dst.Tables["id_check"].Rows[0];
			string code = dr["code"].ToString();
			Response.Write("<table>");
			Response.Write("<tr><td>code : </td><td><a href=p.aspx?" + code + " class=o>" + code + "</a></td></tr>");
			Response.Write("<tr><td>supplier : </td><td>" + dr["supplier"].ToString() + "</td></tr>");
			Response.Write("<tr><td>Supplier Code : </td><td>" + dr["supplier_code"].ToString() + "</td></tr>");
			Response.Write("<tr><td>Description : </td><td>" + dr["name"].ToString() + "</td></tr>");
			Response.Write("</table>");
			PrintAdminFooter();
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	DataRow drpd = null;
	DataRow drp = null;
	DataRow dr_cr = null;
	DataRow dr_cc = null;

	if(!GetNewProdDetails("product_details", ref drpd))
		return false;
	if(!GetNewProdDetails("product", ref drp))
		return false;
	if(!GetNewProdDetails("code_relations", ref dr_cr))
		return false;
	if(!GetNewProdDetails("cat_cross", ref dr_cc))
		return false;

	string code_old = m_code;
	m_code = GetNextCode().ToString();

	if(drpd != null)
	{
		if(!InsertProdDetails(drpd))
			return false;
	}
	if(drp != null)
	{
		if(!InsertProd(drp))
			return false;
	}
	if(dr_cr != null)
	{
		if(!InsertCodeRelation(dr_cr))
			return false;
	}
	if(dr_cc != null)
	{
		if(!InsertCat_Cross(dr_cc)) 
			return false;
	}
	
	string sPicFile = "";
	string vpath = GetRootPath();
	vpath += "/pi/";
	string path = vpath;
	sPicFile = path + code_old + ".gif";
	string newfile = path + m_code;
	bool bHasLocal = File.Exists(Server.MapPath(sPicFile));
	if(!bHasLocal)
	{
		sPicFile = path + code_old + ".jpg";
		bHasLocal = File.Exists(Server.MapPath(sPicFile));
		newfile += ".jpg";
	}
	else
		newfile += ".gif";

	if(bHasLocal)
	{
		if(!File.Exists(Server.MapPath(newfile)))
			File.Copy(Server.MapPath(sPicFile), Server.MapPath(newfile)); //copy image
	}

	return true;
}

bool GetNewProdDetails(string s_table, ref DataRow dr)
{
	string s_filltable = "";
	if(s_table == "product_details")
		s_filltable = "pspec";
	else if(s_table == "product")
		s_filltable = "pdetails";
	else if(s_table == "code_relations")
		s_filltable = "p_code_relations";
	else if(s_table == "cat_cross")
		s_filltable = "p_cat_cross";
	else
	{
		Response.Write("<br><br><center><h3>Error, no table defined, s_table=" + s_table);
		return false;
	}

//	if(dst.Tables["details"] != null)
//		dst.Tables["details"].Clear();

	string sc = "SELECT * FROM " + s_table + " WHERE code = " + m_code;
//DEBUG("sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, s_filltable);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(dst.Tables[s_filltable].Rows.Count > 0 )
		dr = dst.Tables[s_filltable].Rows[0];
	else
		dr = null;
	return true;
}

bool InsertProdDetails(DataRow dr)
{
	string sc = "INSERT INTO product_details (code, highlight, spec, manufacture, pic, rev, warranty)";
	sc += "VALUES (" + m_code + ", '";
	sc += EncodeQuote(dr["highlight"].ToString()) + "', '";
	sc += EncodeQuote(dr["spec"].ToString()) + "', '";
	sc += EncodeQuote(dr["manufacture"].ToString()) + "', '";
	sc += EncodeQuote(dr["pic"].ToString()) + "', '";
	sc += EncodeQuote(dr["rev"].ToString()) + "', '";
	sc += EncodeQuote(dr["warranty"].ToString()) + "')";
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}		

	return true;
}

bool InsertProd(DataRow dr)
{
	string sc = "INSERT INTO product_skip (id, stock, eta, supplier_price, price) ";
	sc += " VALUES ('";
	sc += copy_id + "', 0, '"; //no stock copying
	sc += dr["eta"].ToString() + "', ";
	sc += dr["supplier_price"].ToString() + ", ";
	sc += dr["price"].ToString() + ")";
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}		

	return true;
}

bool InsertCodeRelation(DataRow dr)
{
	string[] lr = new string[10];
	string[] qb = new string[10];
	string[] qbd = new string[10];

	int i = 1;
	for(i=1; i<=9; i++)
	{
		if(dr["level_rate" + i].ToString() != "")
			lr[i] = dr["level_rate" + i].ToString();
		else
			lr[i] = "null";
		if(dr["qty_break" + i].ToString() != "")
			qb[i] = dr["qty_break" + i].ToString();
		else
			qb[i] = "null";
		if(dr["qty_break_discount" + i].ToString() != "")
			qbd[i] = dr["qty_break_discount" + i].ToString();
		else
			qbd[i] = "null";
	}

	string sc = "INSERT INTO code_relations (code, id, supplier, supplier_code, supplier_price, rate ";
	sc += ", name, brand, cat, s_cat, ss_cat, hot, skip, inventory_account, costofsales_account, income_account ";
	sc += ", foreign_supplier_price, currency, exchange_rate, nzd_freight ";
	sc += ", level_rate1, level_rate2, level_rate3, level_rate4, level_rate5, level_rate6, level_rate7, level_rate8, level_rate9 ";
	sc += ", qty_break1, qty_break2, qty_break3, qty_break4, qty_break5, qty_break6, qty_break7, qty_break8, qty_break9 ";
	sc += ", qty_break_discount1, qty_break_discount2, qty_break_discount3, qty_break_discount4, qty_break_discount5, qty_break_discount6, qty_break_discount7, qty_break_discount8, qty_break_discount9 ";
	sc += ", average_cost ";
	sc += ", manual_cost_frd, manual_exchange_rate, manual_cost_nzd, show_price , show_level";

	sc += ") VALUES (";
	sc += m_code + ", '" + copy_id + "', '";
	sc += copy_supplier + "', '";
	sc += copy_supplier_code + "', ";
	sc += dr["supplier_price"].ToString() + ", ";
	sc += dr["rate"].ToString() + ", '";
	sc += EncodeQuote(dr["name"].ToString()) + "', '";
	sc += EncodeQuote(dr["brand"].ToString()) + "', '";
	sc += EncodeQuote(dr["cat"].ToString()) + "', '";
	sc += EncodeQuote(dr["s_cat"].ToString()) + "', '";
	sc += EncodeQuote(dr["ss_cat"].ToString()) + "', ";
	//"hot" field;
	if(dr["hot"].ToString().ToLower() == "true")
	{
		sc += "1, ";
	}
	else if(dr["hot"].ToString().ToLower() == "false")
	{
		sc += "0, ";
	}
	//"skip" field;
	sc += "1, ";
	string iva = dr["inventory_account"].ToString();
	if(iva == "")
		iva = "null";
	sc +=  iva + ", ";
	string ca = dr["costofsales_account"].ToString();
	if(ca == "")
		ca = "null";
	sc +=  ca + ", ";
	string ia = dr["income_account"].ToString();
	if(ia == "")
		ia = "null";
	sc +=  ia + ", " + dr["foreign_supplier_price"].ToString() + ", '" + dr["currency"].ToString();
	sc += "', " + dr["exchange_rate"].ToString() + ", " + dr["nzd_freight"].ToString();
	for(i=1; i<=9; i++){
		sc += ", " + lr[i];
        if(lr[i] == ""){
          sc += "''";
        }
    }
	for(i=1; i<=9; i++){
		sc += ", " + qb[i];

        if(qb[i] == ""){
          sc += "''";
        }
    }
	for(i=1; i<=9; i++){
		sc += ", " + qbd[i];
        if(qbd[i] == ""){
          sc += "''";
        }
    }
	sc += ", " + dr["supplier_price"].ToString();
	sc += ", " + dr["manual_cost_frd"].ToString();
	sc += ", " + dr["manual_exchange_rate"].ToString();
	sc += ", " + dr["manual_cost_nzd"].ToString();
    sc += ", " + dr["show_price"].ToString();
    sc += ", " + dr["show_level"].ToString();
	sc += ")";
	//sc += dr["cost_account"].ToString() + ", ";
	//sc += dr["income_account"].ToString() + ")";

//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}		

	return true;
}

bool InsertCat_Cross(DataRow dr)
{
	string sc = "INSERT INTO cat_cross (code, cat, s_cat, ss_cat) VALUES (";
		sc += m_code + ", '";
		sc += dr["cat"].ToString() + "', '";
		sc += dr["s_cat"].ToString() + "', '";
		sc += dr["ss_cat"].ToString() + "')";
//DEBUG("sc = ", sc);
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void PrintJavaFunction()
{
	Response.Write("<script TYPE=text/javascript");
	Response.Write(">");
	Response.Write("function CalcCost()");
	Response.Write("{ var d = 0;\r\n");
	Response.Write("	if(Number(document.form1.raw_supplier_price.value) <= 0){return;}\r\n");
	Response.Write("	d = Number(document.form1.raw_supplier_price.value) / Number(document.form1.exrate.value) + Number(document.form1.freight.value);\r\n");
	Response.Write("	d = Math.round(d * 100) / 100;\r\n");
	Response.Write("	document.form1.supplier_price0.value=d;\r\n");
	Response.Write("}\r\n");
	Response.Write("function UpdateCurrency()");
	Response.Write("{\r\n");
	Response.Write("	var rate = Number(document.form1.currency.value);\r\n");
	Response.Write("	document.form1.exrate.value = rate;\r\n");
	Response.Write("	if(rate == Number(document.form1.rate_nzd.value)){document.form1.currency_name.value='nzd';\r\n}");
	Response.Write("	else if(rate == Number(document.form1.rate_usd.value))document.form1.currency_name.value='usd';\r\n");
	Response.Write("	else if(rate == Number(document.form1.rate_aud.value))document.form1.currency_name.value='aud';\r\n");
    Response.Write("	else if(rate == Number(document.form1.rate_euro.value))document.form1.currency_name.value='euro';\r\n");
	Response.Write("	CalcCost();\r\n");
	Response.Write("}\r\n");
	Response.Write("function UpdateExRate()");
	Response.Write("{\r\n");
	Response.Write("	if(document.form1.currency_name.value == 'nzd')document.form1.exrate.value=1;\r\n"); //fix NZD exchange rate to 1.00
	Response.Write("	else if(document.form1.currency_name.value == 'usd')document.form1.rate_usd.value=document.form1.exrate.value;\r\n");
	Response.Write("	else if(document.form1.currency_name.value == 'aud')document.form1.rate_aud.value=document.form1.exrate.value;\r\n");
	Response.Write("	else if(document.form1.currency_name.value == 'euro')document.form1.rate_euro.value=document.form1.exrate.value;\r\n");
    Response.Write("	CalcCost();");
	Response.Write("};");
	Response.Write("function CalcManualCost()");
	Response.Write("{ var d = 0;\r\n");
	Response.Write("	if(Number(document.form1.manual_cost_frd.value) <= 0){return;}\r\n");
//	Response.Write("	d = Number(document.form1.manual_cost_frd.value) / Number(document.form1.manual_exrate.value) + Number(document.form1.freight.value);\r\n");
	Response.Write("	d = Number(document.form1.manual_cost_frd.value) / Number(document.form1.manual_exrate.value);\r\n");
	Response.Write("	d = Math.round(d * 100) / 100;\r\n");
	Response.Write("	document.form1.manual_cost_nzd.value=d;\r\n");
	Response.Write("	CalcPrice();\r\n");
	Response.Write("}\r\n");
	Response.Write("function CalcPrice()");
	Response.Write("{ var d = 0;\r\n");
	Response.Write("	var rate = Number(document.form1.rate0.value);\r\n");
//	Response.Write("	if(rate <= 1){rate = 1.01;window.alert('Error, Bottom Rate cannot less than 1.00 !\\r\\nI will reset it to 1.01');}\r\n");
//	Response.Write("	d = rate * Number(document.form1.manual_cost_nzd.value);\r\n");
	Response.Write("	d = (rate * Number(document.form1.manual_cost_nzd.value)) + Number(document.form1.freight.value);\r\n");
	Response.Write("	d = Math.round(d * 100) / 100;\r\n");
	Response.Write("	document.form1.rate0.value=rate;\r\n");
	Response.Write("	document.form1.price0.value=d;\r\n");
    Response.Write("    $('#level_price1').val(d * Number($('#level_rate1').val()));");
    Response.Write("    $('#level_price2').val(d * Number($('#level_rate2').val()));");
    Response.Write("    $('#level_price3').val(d * Number($('#level_rate3').val()));");
    Response.Write("    $('#level_price4').val(d * Number($('#level_rate4').val()));");
    Response.Write("    $('#level_price5').val(d * Number($('#level_rate5').val()));");
    Response.Write("    $('#level_price6').val(d * Number($('#level_rate6').val()));");


	Response.Write("}\r\n");
	Response.Write("function Calculate()");
	Response.Write("{						");
    Response.Write("  if($('#ChangeRateRD').attr('checked') === true){					");
	Response.Write("	var dls = Number(document.form1.dls.value);	\r\n");
	Response.Write("	for(var i=1; i<=dls; i++) ");
	Response.Write("	{	eval( \"document.form1.level_price\" + i + \".value = Math.round(Number(document.form1.level_rate\" + i + \".value) * Number(document.form1.price0.value) * 100) / 100; \" ); } \r\n");
	Response.Write("	var qbs = Number(document.form1.qbs.value);	\r\n");
	Response.Write("	for(var i=1; i<=qbs; i++) ");
	Response.Write("	{	eval( \"document.form1.qty_price\" + i + \".value = Math.round( (1 - Number(document.form1.qty_break_discount\" + i + \".value)/100) * Number(document.form1.level_price1.value) * 100) / 100; \" ); } \r\n");
	Response.Write("  }else{");
    
    Response.Write("  }");
    Response.Write("}\r\n");
	Response.Write("</script");
	Response.Write(">");
}

string PrintSupplierOptionsWithShortName_Addp(bool onlyShowSupplierShortName, string supplierShortName)
{
	DataSet dssup = new DataSet();
	string type_supplier = GetEnumID("card_type", "supplier");
	int rows = 0;
	string sc = "SELECT id, short_name, name, email, company ";
	sc += " FROM card WHERE type=" + type_supplier + " ORDER BY company ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dssup, "suppliers");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	string s = "\r\n<select name=supplier>";
	
	for(int i=0; i<rows; i++)
	{
        try{
            string shortName = dssup.Tables["suppliers"].Rows[i]["short_name"].ToString();
            string company = dssup.Tables["suppliers"].Rows[i]["company"].ToString();
            if(!String.IsNullOrEmpty(shortName)){
                if(supplierShortName == shortName || supplierShortName == company){
                    s += "<option selected value=" + shortName + ">";
		            s += company + "</option>";
                }else{
                    s += "<option value=" + shortName + ">";
		            s += company + "</option>";
                }
            }
        }catch(Exception ex){
            
        }
	}
	s += "\r\n</select>";
	return s;
}

string OuputJsFunction(){
   string s = "";
   s += "<script>";
   s += "     function EnableRate(){";
   s += "        $('.level_rate').removeAttr('readonly');";
   s += "        $('.level_rate').css('background-color','#FFFFFF');";

   s += "        $('.level_peice').attr('readonly','readonly');";
   s += "        $('.level_peice').css('background-color','#EEEEEE');";
   s += "     }";
   s += "     function EnablePrice (){";
   s += "        $('.level_peice').removeAttr('readonly');";
   s += "        $('.level_peice').css('background-color','#FFFFFF');";

   s += "        $('.level_rate').attr('readonly','readonly');";
   s += "        $('.level_rate').css('background-color','#EEEEEE');";
   s += "     }";


   s += "        $(document).ready(function(){";
   s += "            $('.level_peice').keyup(function(event){";
   s += "                var tag = $(event.currentTarget);";
   s += "                var bprice = $('#price0').val();";
   s += "                bprice = Number(bprice);";
   s += "                var pId = tag.attr('data-value');";
   s += "                var lprice = tag.val();";
   s += "                lprice = Number(lprice);";
   s += "                var p = lprice / bprice;";
   s += "                $('#'+pId).val(p);";
   s += "            });";

   s += "            $('.level_rate').keyup(function(event){";
   s += "                var tag = $(event.currentTarget);";
   s += "                var bprice = $('#price0').val();";
   s += "                bprice = Number(bprice);";
   s += "                var pId = tag.attr('data-value');";
   s += "                var lprice = tag.val();";
   s += "                lprice = Number(lprice);";
   s += "                var p = lprice * bprice;";
   s += "                $('#'+pId).val(p);";
   s += "            });";

   s += "            $('#RRP_TXT').keyup(function(event){";
   s += "                var value = $('#RRP_TXT').val();";
   s += "                if(isNaN(value)){";
   s += "                   $('#RRP_TXT').val(0);";
   s += "                   return;";
   s += "                }";
   s += "                var rrpGst = Number(value) - Number(value) * 3 / 23;";
   s += "                $('#RRP_TXT_EXGST').val(rrpGst);";
   s += "            });";

   s += "                var RRP_TXT = $('#RRP_TXT').val();";
   s += "                if(isNaN(RRP_TXT)){";
   s += "                   $('#RRP_TXT').val(0);";
   s += "                   return;";
   s += "                }";
   s += "                var rrpGst = Number(RRP_TXT) - Number(RRP_TXT) * 3 / 23;";
   s += "                $('#RRP_TXT_EXGST').val(rrpGst);";


   s += "            $('#ShowPriceIncGST').keyup(function(event){";
   s += "                var value = $('#ShowPriceIncGST').val();";
   s += "                if(isNaN(value)){";
   s += "                   $('#ShowPriceIncGST').val(0);";
   s += "                   return;";
   s += "                }";
   s += "                var incGst = Number(value) - Number(value) * 3 / 23;";
   s += "                $('#ShowPriceExcGST').val(incGst);";
   s += "                autoCal2();";
   s += "            });";

   s += "                var ShowPriceIncGST = $('#ShowPriceIncGST').val();";
   s += "                if(isNaN(ShowPriceIncGST)){";
   s += "                   $('#ShowPriceIncGST').val(0);";
   s += "                   return;";
   s += "                }";
   s += "                var incGst = Number(ShowPriceIncGST) -  Number(ShowPriceIncGST) * 3 / 23;";
   s += "                $('#ShowPriceExcGST').val(incGst);";

   s += "         });";

   s += " </";
   s += "script>";
   return s;
}
</script>
