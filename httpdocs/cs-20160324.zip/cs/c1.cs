<!-- #include file="kit_fun.cs" -->

<script runat=server>

DataSet ds = new DataSet();
string mainTitleIndex = "s_cat";
string subTableIndex = "brand";
int rows_return = 0;

string brand = null;
string cat = null;
string s_cat = null;
string ss_cat = null;

//decode "zzzOthers"
string dbrand = null;
string dcat = null;
string ds_cat = null;
string dss_cat = null;

//encoded space
string ebrand = null;
string ecat = null;
string es_cat = null;
string ess_cat = null;

string m_sort = "brand";

//bool m_bCacheEnabled = true; //debug
bool m_bCacheEnabled = false; //debug
bool bShowSpecial = false;
bool m_bAdmin = false;
bool m_bPaging = false;
bool bSayHot = true;
bool m_bAddToCart = false;

bool bAlterTableRowColor = false;  //table row color
bool bEnable_Allocated_Stock = false;
string scn = "";

int m_nPage = 1;
const int m_nPageSize = 100;

bool bIncludeGST = true;
bool bShowAllStock = true;
bool bOrder = false;

string m_sBuyType = "";

double m_levelDiscount = 0;
double m_ld1 = 1.08;
double m_ld2 = 1.04;
int m_qb1 = 2;
int m_qb2 = 5;
int m_qb3 = 10;
int m_qb4 = 50;

int m_nDealerLevel = 1;

bool m_bClearance = false;
bool m_bDiscontinued = false;
bool m_bShowLogo = false;
bool m_bDoAction = false;
string m_action = "";

bool m_bKit = false;
int m_nItemsPerRow = 1;

bool m_bNoPrice = false;

//for search
bool m_bSearching = false;
string keyword = "";
string kw = "";
string kw1 = ""; //first search step;
string kw2 = ""; //2nd search step;
string kw3 = ""; //3rd search step;
string ss = ""; //current search string;

int words = 0; //how many keywords, not include in quotation marks
int uwords = 0; //how many unwanted keywords, not include in quotation marks
string[] kws = new string[64];	//wanted keywords
string[] ukws = new string[64]; //un wanted keywords

bool m_bSimpleInterface = false; //liveedit settings, if true then ignore price rate and qty breaks, go for p.price
bool m_bFixedPrices = false;
bool m_bStockSayYesNo = false;
string m_sStockYesString = "YES";
string m_sStockNoString = "NO";

bool CatalogInitPage()
{
//DEBUG("begin:", DateTime.UtcNow.AddHours(12).ToString());
//	if(g_bRetailVersion)
		TS_PageLoad(); //this is dealer area, check login
//	else
//		TS_Init();

	InitKit();

	if(MyBooleanParse(GetSiteSettings("use_fixed_level_prices", "0", true)))
		m_bFixedPrices = true;
	if(g_bRetailVersion)
	{
		if(MyBooleanParse(GetSiteSettings("allocated_stock_public_enabled", "1", true)))
			bEnable_Allocated_Stock = true;
	}
	if(MyBooleanParse(GetSiteSettings("simple_liveedit", "1", true)))
		m_bSimpleInterface = true;

	if(!g_bRetailVersion && m_sSite == "www")
		m_bNoPrice = true;

	if(MyBooleanParse(GetSiteSettings("stock_say_yes_no", "0", false)))
		m_bStockSayYesNo = true;

	if(m_bStockSayYesNo)
	{
		m_sStockYesString = GetSiteSettings("stock_yes_string", "YES");
		m_sStockNoString = GetSiteSettings("stock_no_string", "NO");
	}

	if(Session[m_sCompanyName + "dealer_level"] == null)
		Session[m_sCompanyName + "dealer_level"] = "1";

	if(TS_UserLoggedIn())
		m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "dealer_level"].ToString());

	//stop ordering status, back to normal
	if(Request.QueryString["endorder"] == "1")
	{
		Session[m_sCompanyName + "_ordering"] = null;
		Session[m_sCompanyName + "_salestype"] = null;
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?\">");
		return true;
	}
	else if(Request.QueryString["startorder"] == "1")
	{
		Session[m_sCompanyName + "_ordering"] = true;	
	}

	//sales session control
	if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
		m_ssid = Request.QueryString["ssid"];

	if(Request.QueryString["t"] == "clearance")
		m_bClearance = true;
	else if (Request.QueryString["t"] == "discontinued")
		m_bDiscontinued = true;

	string cmd = "";
	if(Request.Form["cmd"] != null)
		cmd = Request.Form["cmd"];

	if(cmd == "Action")
	{
		m_bDoAction = true;
		m_action = Request.Form["action"];
	}
	else if(cmd == "Update Price")
	{
	}
	else if(cmd == "Add To Cart")
	{
		m_bAddToCart = true;
	}

	RememberLastPage();
	PrintHeaderAndMenu("");

	if(Request.QueryString["gst"] == "e")
	{
		Session["display_include_gst"] = "false";
	}
	else if(Request.QueryString["gst"] == "i")
		Session["display_include_gst"] = "true";

	if(Session["display_include_gst"] != null)
	{
		if(Session["display_include_gst"].ToString() == "false")
			bIncludeGST = false;
	}
	else
		Session["display_include_gst"] = "true";

	//sort options
	if(Request.QueryString["sort"] != null)
		m_bCacheEnabled = false; //refresh cache
	if(Request.QueryString["sort"] == "price")
		Session[m_sCompanyName + "_sort"] = "price";
	else if(Request.QueryString["sort"] == "brand")
		Session[m_sCompanyName + "_sort"] = "brand";

	if(Session[m_sCompanyName + "_sort"] != null)
		m_sort = Session[m_sCompanyName + "_sort"].ToString();

	Session["display_show_all_stock"] = "true";
	
	if(Request.QueryString["sas"] == "1")
		Session["display_show_all_stock"] = "true";
	else if(Request.QueryString["sas"] == "0")
		Session["display_show_all_stock"] = null;

	if(Session["display_show_all_stock"] == null)
		bShowAllStock = false;
	else if(Session["display_show_all_stock"].ToString() == "true")
		bShowAllStock = true;

//	if(bShowAllStock)
//		DEBUG("bShowAllStock=true", "");
//	else
//		DEBUG("bShowAllStock=false", "");

	if(Request.QueryString["p"] != null)
	{
		string sPage = Request.QueryString["p"];
		if(TSIsDigit(sPage))
			m_nPage = int.Parse(sPage);
	}

	string cn = m_sCompanyName + m_sSite + "_b_" + Request.QueryString["b"] + "_c_" + Request.QueryString["c"] + "_s_" + Request.QueryString["s"] + "_ss_" + Request.QueryString["ss"];
	if(bIncludeGST)
		cn += "_igst";
	if(bShowAllStock)
		cn += "_sas";
	if(Request.QueryString["p"] != null)
	{
		cn += "_p" + m_nPage.ToString();
	}
	scn = cn;

	if(m_bCacheEnabled && m_supplierString == "")
	{
		if(Cache[cn] != null)
		{
			Response.Write(Cache[cn]);
			PrintFooter();
			return true; //cache wrote, should not draw table again
		}
	}

	if(Request.QueryString["b"] == null && Request.QueryString["c"] == null 
		&& Request.QueryString["s"] == null && Request.QueryString["ss"] == null)
	{
		bShowSpecial = true;
	}
	else
	{
		brand = Request.QueryString["b"];
		cat = Request.QueryString["c"];
		s_cat = Request.QueryString["s"];
		ss_cat = Request.QueryString["ss"];

		dbrand = brand;
		dcat = cat;
		ds_cat = s_cat;
		dss_cat = ss_cat;
		if(brand == "zzzOthers")
			dbrand = "";
		if(cat == "zzzOthers")
			dcat = "";
		if(s_cat == "zzzOthers")
			ds_cat = "";
		if(ss_cat == "zzzOthers")
			dss_cat = "";

		ebrand = HttpUtility.UrlEncode(dbrand);
		ecat = HttpUtility.UrlEncode(dcat);
		es_cat = HttpUtility.UrlEncode(ds_cat);
		ess_cat = HttpUtility.UrlEncode(dss_cat);
	}
	
//	if(s_cat != null && ss_cat == null && m_sSite == "admin")
	if(brand == null && s_cat != null && ss_cat == null && m_sSite != "admin")
	{
		m_bShowLogo = true;
	}

	if(cat == m_sKitTerm) //package
	{
		m_bKit = true;
		GetKit();
		return false;
	}

	string sca = "12345"; //try again if no hot product later
	string scb = "12345"; //cut "select " and " hot=1" from sc
	string sWhere = "";
	string sc = "";
	bool bHotOnly = false;
	if(m_bClearance)
	{
		sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.125 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += ", p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		sc += ", c.currency, c.foreign_supplier_price ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
	//	sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
		sc += " FROM product p JOIN code_relations c ON c.id=p.supplier+p.supplier_code ";
		sc += " WHERE c.clearance=1 ";
		if(m_sSite != "admin")
			sc += " AND c.is_service = 0 ";
		if(m_supplierString != "")
			sc += " AND p.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY p.brand, p.cat, p.s_cat, p.ss_cat";
	}
	else if(m_bDiscontinued)
	{
		sc = "SELECT c.code, c.name, c.brand, p.price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = c.code), 0) AS  stock ";
		}
		else
			sc += ", p.stock AS stock ";
		sc += ", c.cat, c.s_cat, c.ss_cat, ";
		sc += " c.supplier, c.supplier_code, c.supplier_price, c.clearance, '' AS eta, 0 AS price_dropped ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
//		sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
		sc += " FROM code_relations c JOIN product_skip p ON c.id=p.id ";
		if(m_sSite != "admin")
			sc += " WHERE c.is_service = 0 ";
		else if(m_supplierString != "")
			sc += " WHERE c.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY c.brand, c.cat, c.s_cat, c.ss_cat";
	}
	else if(bShowSpecial)
	{
		sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.125 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += " , p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
		//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
		sc += " FROM product p JOIN specials s ON p.code=s.code ";
		sc += " JOIN code_relations c ON c.id=p.supplier+p.supplier_code ";
		if(m_sSite != "admin")
			sc += " WHERE c.is_service = 0 ";
		else if(m_supplierString != "")
			sc += " WHERE p.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND p.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND p.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY p.brand, p.cat, p.s_cat, p.ss_cat";
	}
	else
	{
		sc = "p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.125 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += " ) FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += " , p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
		//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
		sc += " FROM product p";
		sc += " JOIN code_relations c ON c.id=p.supplier+p.supplier_code ";
		if(m_sSite != "admin")
			sc += " WHERE c.is_service = 0 AND ";
		else
			sc += " WHERE ";
		if(!bShowAllStock)
			sc += " (p.stock>0 OR p.stock IS NULL) AND ";
		if(brand != null)
		{
			sWhere += " p.brand='";
			sWhere += dbrand;
			sWhere += "'";
			mainTitleIndex = "brand";
			subTableIndex = "ss_cat";
		}
		
		if(cat != null)
		{
			if(sWhere != "")
				sWhere += " AND";
			sWhere += " p.cat='";
			sWhere += dcat;
			sWhere += "'";
		}

		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				string limit = Session["cat_access_sql"].ToString();
				sWhere += " AND (p.brand " + limit;
				if(limit.ToLower().IndexOf("not") >= 0)
					sWhere += " AND ";
				else
					sWhere += " OR ";
				sWhere += " p.s_cat " + limit + " AND p.ss_cat " + limit + ") ";
			}
		}
		
		if(s_cat != null)
		{
			if(sWhere != "")
				sWhere += " AND";
			sWhere += " p.s_cat='";
			sWhere += ds_cat;
			sWhere += "'";
		}
		if(ss_cat != null)
		{
			if(sWhere != "")
				sWhere += " AND";
			sWhere += " p.ss_cat='";
			sWhere += dss_cat;
			sWhere += "'";
		}
//		sWhere += " AND p.cat NOT IN('networking') ";

		scb = sc + sWhere;

		if((ss_cat == null && brand == null && ss_cat != "zzzOthers" && brand != "zzzOthers") 
			|| (s_cat == null && brand != null && s_cat != "zzzOthers" && brand != "zzzOthers"))
		{
			bHotOnly = true;
			if(sWhere != "")
				sWhere += " AND";
			sWhere += " p.hot=1";
		}
		sc += sWhere;
		sc = "SELECT " + sc;
		sca = sc;

		if(m_supplierString != "")
		{
			sc += " AND p.supplier IN" + m_supplierString + " ";
		}
		sc += " ORDER BY p.brand, p.s_cat, p.ss_cat, p.name, p.code";
	}
//DEBUG(" sc =", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return true;
	}

	string scWhere = "";
	int cross = 0;
	if(!bShowSpecial && brand == null)// && ss_cat != null)
	{
		sc = "SELECT code FROM cat_cross WHERE";
		if(cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " cat='";
			scWhere += dcat;
			scWhere += "'";
		}
		if(s_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " s_cat='";
			scWhere += ds_cat;
			scWhere += "'";
		}
		if(ss_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " ss_cat='";
			scWhere += dss_cat;
			scWhere += "'";
		}
		sc += scWhere;
		if(scWhere != "")
		{
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				cross = myCommand.Fill(ds, "cross");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}
			if(cross > 0)
			{
				for(int c=0; c<cross; c++)
				{
					string ccode = ds.Tables["cross"].Rows[c]["code"].ToString();
					sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
					if(bIncludeGST)
						sc += "*1.125 AS price";
					if(m_bStockSayYesNo)
						sc += ", p.stock AS stock ";
					else 
						sc += ", p.stock-p.allocated_stock AS stock ";
					sc += ", p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
					for(int j=1; j<=9; j++)
						sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
					sc += ", c.currency, c.foreign_supplier_price ";
					//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
					sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
					sc += " FROM product p JOIN code_relations c ON c.id=p.supplier+p.supplier_code WHERE p.code=" + ccode;
					if(m_sSite != "admin")
						sc += " AND c.is_service = 0 ";
					if(bHotOnly)
						sc += " AND p.hot=1";
					if(m_supplierString != "")
						sc += " AND p.supplier IN" + m_supplierString + " ";
					if(Session["cat_access_sql"] != null)
					{
						if(Session["cat_access_sql"].ToString() != "all")
						{
							sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
							sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
						}
					}
					try
					{
						SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
						rows_return += myCommand.Fill(ds, "product");
					}
					catch(Exception e) 
					{
						ShowExp(sc, e);
						return true;
					}
				}
			}
		}
		
		//kit cross
		sc = "SELECT code FROM cat_cross_kit WHERE";
		if(cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " cat='";
			scWhere += dcat;
			scWhere += "'";
		}
		if(s_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " s_cat='";
			scWhere += ds_cat;
			scWhere += "'";
		}
		if(ss_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " ss_cat='";
			scWhere += dss_cat;
			scWhere += "'";
		}
		sc += scWhere;
		if(scWhere != "")
		{
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				cross = myCommand.Fill(ds, "cross_kit");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}
			if(cross > 0)
			{
				for(int c=0; c<cross; c++)
				{
					string ccode = ds.Tables["cross_kit"].Rows[c]["code"].ToString();
					sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
					sc += ", id AS code, '' AS brand, 0 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
					sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
					for(int j=1; j<=9; j++)
						sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
					sc += ", price AS bottom_price ";
					sc += ", * FROM kit ";
					sc += " WHERE id = " + ccode;
					if(Session["cat_access_sql"] != null)
					{
						if(Session["cat_access_sql"].ToString() != "all")
						{
							sc += " AND s_cat " + Session["cat_access_sql"].ToString();
							sc += " AND ss_cat " + Session["cat_access_sql"].ToString();
						}
					}

					try
					{
						SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
						rows_return += myCommand.Fill(ds, "product");
					}
					catch(Exception e) 
					{
						ShowExp(sc, e);
						return true;
					}
				}
			}
		}
	
	}		

	if(rows_return <= 0)
	{
		if(bHotOnly) //try display all
		{
			sc = "SELECT TOP 10 ";
			sc += scb; //sca.Substring(7, sca.Length-17);
			if(m_supplierString != "")
				sc += " AND supplier IN" + m_supplierString + " ";
			sc += " ORDER BY p.brand, p.s_cat, p.ss_cat, p.name, p.code";
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				rows_return = myCommand.Fill(ds, "product");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}
			if(rows_return <= 0)
			{
				//for corporate
				if(m_supplierString == "")
					return true;
			}
			bSayHot = false; //don't display word " - hot product"
		}
		else
		{
			//for corporate
			if(m_supplierString == "")
				return false;
			sc = "SELECT TOP 7 ";
			sc += " p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
			if(bIncludeGST)
				sc += "*1.125 AS price";
			sc += ", p.stock-p.allocated_stock AS stock, p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
			for(int j=1; j<=9; j++)
				sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
			sc += ", c.currency, c.foreign_supplier_price ";
			//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
			sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight AS bottom_price ";
			sc += " FROM product p JOIN code_relations c ON c.id=p.supplier+p.supplier_code WHERE p.supplier IN " + m_supplierString;
			if(m_sSite != "admin")
				sc += " c.is_service = 0 ";
			if(Session["cat_access_sql"] != null)
			{
				if(Session["cat_access_sql"].ToString() != "all")
				{
					sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
					sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
				}
			}
			sc += " ORDER BY price DESC";
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				rows_return = myCommand.Fill(ds, "product");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}

			if(rows_return <= 0)
				return true;
			bSayHot = false; //don't display word " - hot product"
		}
	}

	if(bShowSpecial)
	{
		GetSpecialKits();
	}

	return false;
}

string PrintURI()
{
	StringBuilder sb = new StringBuilder();
	if(brand != null)
		sb.Append("b=" + ebrand + "&");
	if(cat != null)
		sb.Append("c="+ ecat);
	if(s_cat != null)
		sb.Append("&s=" + es_cat);
	if(ss_cat != null)
		sb.Append("&ss=" + ess_cat);
	if(m_ssid != "")
		sb.Append("&ssid=" + m_ssid);
	return sb.ToString();
}

void CatalogDrawList(bool bAdmin) //if bAdmin then draw adminstratrion menu
{
	m_bAdmin = bAdmin;
	StringBuilder sb = new StringBuilder();

	//for search result print
	if(m_bSearching)
	{
		m_bShowLogo = false;
	}
//DEBUG("mbshowlogo =", m_bShowLogo.ToString());
	if(m_bShowLogo)
	{
		string sl = ShowLogo();
		if(sl != "")
		{
			sb.Append("&nbsp;");
			sb.Append(sl);

			sb.Append("</td><tr><tr><td alin=right>");
			sb.Append("<font color=red><i><b>This sub catageory default page layout is patented</b></i></font> &nbsp&nbsp; ");
			//sb.Append("<a href=/admin/catlogo.aspx?s=" + es_cat + " class=o>Edit Images</a>");
			sb.Append("<a href=catlogo.aspx?s=" + es_cat + " class=o>Edit Images</a>");

			sb.Append("</td></tr></table>");
			sb.Append("</td></tr></table>");
			Response.Write(sb.ToString());
			return;
		}
	}
	if(Session[m_sCompanyName + "_ordering"] != null)
		bOrder = true;
	if(Session[m_sCompanyName + "_salestype"] != null)
		m_sBuyType = Session[m_sCompanyName + "_salestype"].ToString();
	if(bOrder)
	{
		//use current customer level for POS
		if(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid] != null)
			m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString());
	}
	if(Request.QueryString.Count <= 0)
	{
		Session[m_sCompanyName + "_ordering"] = null;
		bOrder = false;
	}

	//left side menu
	string sMId = m_sCompanyName + m_sSite + "cache_leftmenu_";
	if(brand != null)
	{
		sMId += "brands_";
		sMId += brand;
	}
	else
	{
		sMId += cat;
		sMId += "_";
		sMId += s_cat;
	}
	sMId = sMId.ToLower();

	string lsm_id = "left_side_menu";
	if(m_sSite == "www")
		lsm_id = "public_left_side_menu";
	string lsm = ReadSitePage(lsm_id);
	if(lsm != "")
	{
		lsm = BlockSysQuote(lsm);
		string kw = "";
		if(Session["search_keyword"] != null)
			kw = Session["search_keyword"].ToString();
		lsm = lsm.Replace("@@search_keyword", kw);
	}

	string tp = ReadSitePage("public_body_item_list");
	if(g_bOrderOnlyVersion)
		tp = ReadSitePage("public_body_item_list_orderonly");
	if(m_bDealerArea || m_sSite == "admin")
		tp = ReadSitePage("body_item_list");

	//print page index
	if(ds.Tables["product"] == null || ds.Tables["product"].Rows.Count <= 0)
		return;

	int rows = ds.Tables["product"].Rows.Count;
	string slPageFirst = "";
	string slPagePrev = "";
	string slPage = "";
	string slPageNext = "";
	string slPageLast = "";
	if(rows > 100)
	{
		m_bPaging = true;
		int pages = rows / m_nPageSize + 1;
		if(m_nPage > 1)
		{
			slPagePrev = WriteURLWithoutPageNumber() + "&p=1";
			slPageNext = WriteURLWithoutPageNumber() + "&p=" + (m_nPage-1).ToString();
		}
		for(int p=1; p<=pages; p++)
		{
			if(p != m_nPage)
			{
				slPage += "<a href=";
				slPage += WriteURLWithoutPageNumber() + "&p=" + p.ToString();
				slPage += "> ";
			}
			else
				slPage += "<font size=+1><b>";
			slPage += p.ToString();
			if(p != m_nPage)
				slPage += " </a>";
			else
				slPage += "</b></font>";
			slPage += " ";
		}
		if(m_nPage < pages)
		{
			slPageNext = WriteURLWithoutPageNumber() + "&p=" + (m_nPage+1).ToString();
			slPageLast = WriteURLWithoutPageNumber() + "&p=" + pages.ToString();
		}
		tp = tp.Replace("@@PAGE_LINK_FIRST", slPageFirst);
		tp = tp.Replace("@@PAGE_LINK_PREV", slPagePrev);
		tp = tp.Replace("@@PAGE_LINK_PAGES", slPage);
		tp = tp.Replace("@@PAGE_LINK_NEXT", slPageNext);
		tp = tp.Replace("@@PAGE_LINK_LAST", slPageLast);
	}

	//parse conditions, IF_SPECIAL, IF_PURCHAE etc.
	tp = TemplateParseCommand(tp);

	bool bHasGroup = true;
	string tp_group = GetRowTemplate(ref tp, "itemgroup");
	string tp_row = GetRowTemplate(ref tp_group, "itemrow");
	if(tp_group == "")
	{
		bHasGroup = false;
		tp_group = GetRowTemplate(ref tp, "itemrow");
		tp_row = tp_group;
	}
	string tp_item = GetRowTemplate(ref tp_row, "rowitem");
//	if(tp.IndexOf("@@SUB_SUB_MENU") >= 0)
//		tp = tp.Replace("@@LEFT_SIDE_MENU", lsm);
	string ssmenu = "";
	if(Cache[sMId] != null)
	{
		ssmenu = Cache[sMId].ToString();
		ssmenu = ssmenu.Replace("@@ssid", m_ssid);
	}

	if(m_bSearching)
		ssmenu = "";

	ssmenu += lsm;

	if(tp.IndexOf("@@SUB_SUB_MENU") >= 0)
		tp = tp.Replace("@@SUB_SUB_MENU", ssmenu);
	else
		tp = tp.Replace("@@LEFT_SIDE_MENU", ssmenu);
	string sout = tp;
	if(Cache["item_categories"] != null)
		sout = sout.Replace("@@HEADER_MENU_TOP_CAT", Cache["item_categories"].ToString());
	else
		sout = sout.Replace("@@HEADER_MENU_TOP_CAT", "");
	
	// title and title_desc
	string title = "";
	if(bShowSpecial)
	{
		if(m_supplierString == "")
		{
			if(m_bClearance)
				title = "Clearance Center";
			else if(m_bDiscontinued)
				title = "Discontinued Items";
			else
				title = "Today's Specials";
		}
		else
			title = m_sCompanyTitle;
	}
	else
	{
		if(ds.Tables["product"].Rows.Count > 0)
			title = ds.Tables["product"].Rows[0][mainTitleIndex].ToString();
	}

	string title_desc = "";
	if(!bShowSpecial && ds.Tables["product"].Rows.Count > 0)
	{
		if(brand != null)
		{
			if(s_cat == null)
			{
//				if(bSayHot)
//					title_desc = " - New Products";
			}
//			else if(s_cat == "zzzOthers")
//				title_desc = " - All Others";
			else
				title_desc = " - " + s_cat;
		}
		else
		{
			if(s_cat == "zzzOthers")
			{
				title = " + cat + ";
				title_desc = " - All Others";
			}
			else
			{
				if(ss_cat == null)
				{
//					if(bSayHot)
//						title_desc = " - New Products";
				}
//				else if(ss_cat == "zzzOthers")
//					title_desc = " - All Others";
				else
					title_desc = " - " + ss_cat + "";
			}
		}
	}

	if(m_bSearching)
	{
		title = "<b>Search Result for : " + keyword + "</b>";
		title_desc = "";
	}

	sout = sout.Replace("@@ITEM_LIST_TITLE_DESC", title_desc);
	sout = sout.Replace("@@ITEM_LIST_TITLE", title);

	string form_action = "?" + Request.ServerVariables["QUERY_STRING"];
	sout = sout.Replace("@@ITEM_LIST_FORM_ACTION", form_action);

	//function buttons

	string fun_buttons = "";
	if(m_sSite == "admin" && !m_bDiscontinued && bOrder)
	{
		fun_buttons = PrintFunctionButtons();
	}
	sout = sout.Replace("@@ITEM_LIST_FUNCTION_BUTTONS", fun_buttons);

	//start group
	string groups = "";

	Boolean bAlterColor = false;
	DataRow dr = null;
	string sti = "";
	string stiOld = "-1"; //in case there's a blank subTableIndex
	string code = "";
	int i = 0;
	string bgColor = "white";
	
	string sSel = "brand, s_cat, ss_cat, name, code"; 
	if(m_sort != "brand")
		sSel = m_sort + ", brand, s_cat, ss_cat, name, code"; 
	DataRow[] drs = ds.Tables["product"].Select("", sSel);

	string sFontColor = "red";
	string slSort = "";
	string sSortName = "";
	string slShowRoom = "";

//	if(!bShowSpecial && brand == null)
	{
		sSortName = "brand";
		if(m_sort == "brand")
			sSortName = "price";
		slSort = "?r" + PrintURI() + "&sort=" + sSortName; // + ">Click here to sort by " + sort + "</a>");
	}
	slShowRoom = "sroom.aspx?" + PrintURI();

	if(m_bSearching)
		slShowRoom = "";

	bool bFixLevel6 = MyBooleanParse(GetSiteSettings("level_6_no_qty_discount", "0"));
	bool bAddBookMark = true;
	bool bAddSort = true;
	bool bClearance = false;
	int	nBookMarkCount = 0;
	int nStart = (m_nPage - 1) * m_nPageSize;
	int nEnd = nStart + m_nPageSize;
	i = nStart;
	
	//finals
	StringBuilder sbGroups = new StringBuilder();
	StringBuilder sbRows = new StringBuilder();
	StringBuilder sbItems = new StringBuilder();

	//template
	string sgroup = tp_group;
	string srow = tp_row;
	string sitem = tp_item;

	//count
	int items_added = 0; //if greater than m_nItemsPerRow than add the row and reset this counter to zero

	bool bGroupEmpty = true;
	bool bFirstGroup = true;
	
	while(i<rows && i < nEnd)
	{
		sti = drs[i][subTableIndex].ToString(); //sti: subTableIndex
		Trim(ref sti);
		
		if(bHasGroup && stiOld.ToLower() != sti.ToLower() && !bShowSpecial && !m_bSearching)
		{
			if(!bGroupEmpty) //add group
			{
				if(items_added > 0) //finish current row if any item already added
				{
					srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
					sbRows.Append(srow); //add row to rows
					srow = tp_row; //reset row template, prepare next row
				
					sbItems.Remove(0, sbItems.Length); //empty items content
					items_added = 0; //reset counter
				}

				sgroup = sgroup.Replace("@@template_itemrow", sbRows.ToString()); //add group
				sgroup = RowParseCommand(sgroup, bFirstGroup); //remove show room link if not first group
				if(bFirstGroup)
				{
					sgroup = sgroup.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
					sgroup = sgroup.Replace("@@ITEM_LIST_SORT_LINK", slSort);
					sgroup = sgroup.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
					bFirstGroup = false;
				}

				string bookMark = "";
				if(bAddBookMark)
					bookMark = stiOld + "_a";

				sgroup = sgroup.Replace("@@ITEM_GROUP_TAG", bookMark);
				sgroup = sgroup.Replace("@@ITEM_GROUP_TITLE", stiOld);

				sbGroups.Append(sgroup); //add group
				sbRows.Remove(0, sbRows.Length); //reset rows content, prepare next row
				sgroup = tp_group; //reset group template
			}

			//begin a new group
			bGroupEmpty = false;

			bAlterColor = false;
		}
		
		if(!bAddBookMark)
		{
			nBookMarkCount++;
			if(nBookMarkCount > 10)
			{
				nBookMarkCount = 0;
				bAddBookMark = true;
			}
		}

		stiOld = sti;
		dr = drs[i];
		code = dr["code"].ToString();
		bool bKit = false;
		if(dr["cat"].ToString() == m_sKitTerm) //package
			bKit = true;

		if(m_bDoAction)
		{
			if(Request.Form["sel" + code] == "on")
			{
				if(DoAction(code))
				{
					if(m_action == "Phase Out")
					{
						i++;
						continue; //already phased out, don't display
					}
				}
			}
		}

//		if(!bShowSpecial)
		{
//			if(bAlterColor && TS_UserLoggedIn())
//				bgColor = "@@color_12";
//			else
			if(bAlterColor)
				bgColor = "@@color_12";
			else
				bgColor = "@@color_11";
			bAlterColor = !bAlterColor;
//		DEBUG("alter color =", bAlterColor.ToString());
		}
		srow = srow.Replace("@@ITEM_ROW_BGCOLOR", bgColor);

		bClearance = MyBooleanParse(dr["clearance"].ToString());

		//first column is blank, show product pic for special page
		string src = GetProductImgSrc(code);
		if(bShowSpecial)
		{
			if(m_bKit || bKit)
				src = GetKitImgSrc(code);
		}
src = src.Replace("na.gif", "0.gif");
		sitem = sitem.Replace("@@ITEM_PIC_LINK", src);
		
		string sdcode = code;
		string m_pn = dr["supplier_code"].ToString();
		string sItemName = dr["name"].ToString();

		if(m_bKit || bKit)
			sdcode = m_sKitTerm + " " + code;
		if(m_bSearching)
		{
			sdcode = ShowKeywords(sdcode);
			m_pn = ShowKeywords(m_pn);
			sItemName = ShowKeywords(sItemName);
		}
	//	bAlterTableRowColor = !bAlterTableRowColor;

		sitem = sitem.Replace("@@ITEM_CODE", sdcode);
		sitem = sitem.Replace("@@ITEM_MPN", m_pn);

		//recently price dropped
		string sRPD = "";
		sb.Append("<td>");
		if(dr["price_dropped"].ToString() != "0")
		{
			if(CheckPriceDate(code, dr["price_age"].ToString()))
			{
				if(dr["price_dropped"].ToString() == "1")
					sRPD = "<img src=pd.gif title='Recently Price Dropped'>";
				else
					sRPD = "<img src=pu.gif title='Recently Price Raise'>";
			}
		}
		sitem = sitem.Replace("@@RECENT_PRICE_CHANGE_IMG", sRPD);
	
		//Description
		string sItemLink = "p.aspx?" + code;
		if(m_bKit || bKit) //kit
		{
			sItemLink = "pk.aspx?" + code + "&ssid=" + m_ssid;
			if(MyBooleanParse(dr["inactive"].ToString()))
				sItemName += "<font color=red><b><i>( * Inactive. Edit Only)<i></b></font>";
		}

		if(bClearance)
			sItemName += " <font color=" + sFontColor + ">(*Clearance*) </font>";

		sitem = sitem.Replace("@@ITEM_LINK", sItemLink);
		sitem = sitem.Replace("@@ITEM_NAME", sItemName);

//		if(srow.IndexOf("@@ITEM_HIGHLIGHT") >= 0)
		{
			string highlight = "";
			double dRRP = 0;
			DataRow drp = null;
			if(GetProduct(code, ref drp))
			{
				highlight = drp["highlight"].ToString();
				if(highlight.Length > 255)
					highlight = highlight.Substring(0, 255);
				dRRP = MyDoubleParse(drp["rrp"].ToString());
				if(dRRP == 0)
					dRRP = MyDoubleParse(drp["manual_cost_nzd"].ToString()) * MyDoubleParse(drp["rate"].ToString()) * MyDoubleParse(drp["level_rate1"].ToString()) * 1.1;
			}
			sitem = sitem.Replace("@@ITEM_HIGHLIGHT", highlight);
			sitem = sitem.Replace("@@ITEM_PRICE_RRP", dRRP.ToString("c"));

		}

		string item_supplier = "";
		string item_supplier_price = "";
//		if(TS_UserLoggedIn() && !m_bDiscontinued)
//		if(!m_bDiscontinued)
		{
			//supplier info
			string supplier = dr["supplier"].ToString();
			string supplier_code = dr["supplier_code"].ToString();
			string foreignCost = dr["foreign_supplier_price"].ToString();
			double dForeignCost = MyDoubleParse(dr["supplier_price"].ToString());
			if(foreignCost != "")
				dForeignCost = MyDoubleParse(foreignCost);

//			if(bOrder && m_sBuyType == "purchase")
			{
				item_supplier = supplier;
				string cur = GetEnumValue("currency", dr["currency"].ToString()).ToUpper();
				if(cur.Length > 2)
					cur = cur.Substring(0, 2);
				item_supplier_price = cur + dForeignCost.ToString("c");
			}

			int dls = int.Parse(GetSiteSettings("dealer_levels", "6")); // how many quantity breaks
			if(dls > 9)
				dls = 9;
			int qbs = int.Parse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
			if(qbs > 9)
				qbs = 9;

			double[] lr = new double[9];
			int[] qb = new int[9]; //qty breaks;
			double[] qbd = new double[9];
			double[] dprice = new double[9];

			int j = 0;
			for(j=0; j<dls; j++)
			{
				string jj = (j+1).ToString();
				lr[j] = 2;
				if(dr["level_rate" + jj].ToString() != "")
					lr[j] = double.Parse(dr["level_rate" + jj].ToString());
			}
			for(j=0; j<qbs; j++)
			{
				string jj = (j+1).ToString();
				qb[j] = 1;
				if(dr["qty_break" + jj].ToString() != "")
					qb[j] = int.Parse(dr["qty_break" + jj].ToString());

				qbd[j] = 1;
				if(dr["qty_break_discount" + jj].ToString() != "")
					qbd[j] = double.Parse(dr["qty_break_discount" + jj].ToString());
			}

			double dQtyDiscount = 0;
			double dDiscount = 0;

			string card_id = "";
			int nLevel = 1;
			if(Session["card_id"] != null)
				card_id = Session["card_id"].ToString();
			if(bOrder)
			{
				card_id = "0";
				//use current customer level for POS
				if(Session[m_sCompanyName + "_dealer_card_id" + m_ssid] != null)
					card_id = Session[m_sCompanyName + "_dealer_card_id" + m_ssid].ToString();
			}
//DEBUG("card_id=", card_id);
			if(card_id != "" && card_id != "0")
			{
				string sBrand = brand;
				if(sBrand == null || sBrand == "")
					sBrand = dr["brand"].ToString();
				nLevel = GetDealerLevelForCat(card_id, sBrand, cat + " - " + s_cat, m_nDealerLevel);
			}
//DEBUG("nLevel=", nLevel);
//			double level_rate = lr[m_nDealerLevel - 1];
			double level_rate = lr[nLevel - 1];
//			double dPrice = double.Parse(dr["price"].ToString());
			double dPrice = MyDoubleParse(dr["bottom_price"].ToString());
			double dNormalPrice = dPrice * lr[0];
			if(!bClearance)
				dPrice *= level_rate;

if(m_bSimpleInterface)
	dPrice = MyDoubleParse(dr["price"].ToString()); //this is p.price

if(m_bFixedPrices)
	dPrice = MyDoubleParse(dr["price" + nLevel].ToString());
//	dPrice = MyDoubleParse(dr["price" + m_nDealerLevel].ToString());
			double dPriceOnePiece = dPrice; //price without qty discount

			//calculate price and discount on qty
			string qty = "0";
			if(Request.Form["qty" + i] != null)
				qty = Request.Form["qty" + i];
			int dqty = MyIntParse(qty);
			dDiscount = 0;
			if(dqty != 0)
			{
				if(dqty < 0 && !bAdmin)
				{
					//negative qty is not allowed to public user!
					Response.Write("<script Language=javascript");
					Response.Write(">");
					Response.Write("window.alert ('Error. Quantity cannot be negative !')");
					Response.Write("</script");
					Response.Write(">");
					qty = "0";
				}
				else
				{
					//get qty discount
					dQtyDiscount = GetQtyDiscount(dqty, qb, qbd);
					if(bFixLevel6 && m_nDealerLevel >= 6)
						dQtyDiscount = 0;
					if(!bClearance)
					{
						dPrice *= (1 - dQtyDiscount);
						dDiscount = dQtyDiscount;
					}
					if(m_bAddToCart)
					{
						if(m_bKit || bKit)
						{
							if(bAdmin)
							{
								DoAddKit(code, dqty);
								dPrice = dPriceOnePiece;
								dDiscount = 0;
								dqty = 0;
								qty = "0";
							}
							else
							{
								DoAddKit(code, dqty);
								dPrice = dPriceOnePiece;
								dDiscount = 0;
								dqty = 0;
								qty = "0";		
								if(Session["c_editing_order" + m_ssid] != null)
								{
									Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=corder.aspx?ssid=" + m_ssid + "\">");
									return;
								}
							}
						}
						else
						{
							if(bAdmin)
							{
								//admin edit
								if(m_sBuyType == "purchase")
									AddToCart(code, supplier, supplier_code, qty, dForeignCost.ToString());
								else
									AddToCart(code, qty, dPrice.ToString());
								dPrice = dPriceOnePiece;
								dDiscount = 0;
								dqty = 0;
								qty = "0";
							}
							else
							{
								AddToCart(code, qty, dPrice.ToString());
								dPrice = dPriceOnePiece;
								dDiscount = 0;
								dqty = 0;
								qty = "0";		
								if(Session["c_editing_order" + m_ssid] != null)
								{
									Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=corder.aspx?ssid=" + m_ssid + "\">");
									return;
								}
							}
						}
					}
				}
			}

			dDiscount = Math.Round((dNormalPrice - dPrice)/dNormalPrice, 4);

//			if(bOrder && m_sBuyType == "purchase")
			{
				sitem = sitem.Replace("@@ITEM_SUPPLIER", item_supplier);
				sitem = sitem.Replace("@@ITEM_COST", item_supplier_price);
			}

			string sstock = dr["stock"].ToString();

			if(m_bStockSayYesNo && m_sSite.ToLower() != "admin" )
			{
				if(MyIntParse(sstock) == 0)
					sstock = m_sStockNoString;
				else
					sstock = m_sStockYesString;
			}
			string seta = dr["eta"].ToString();
			string sDiscountInfo = "";
			string sprice = "";

			if(m_bDiscontinued)
			{
				sstock = "&nbsp;";
				seta = "&nbsp;";
				sDiscountInfo = "&nbsp;";
			}

			//Stock
			sitem = sitem.Replace("@@ITEM_STOCK", sstock);

			//ETA
			sitem = sitem.Replace("@@ITEM_ETA", seta);

			//discount
//			if(m_sBuyType != "purchase")
			{
				sDiscountInfo += dDiscount.ToString("p");
				if(qbs > 0)
				{
					sDiscountInfo += " (";
					for(j=0; j<qbs; j++)
					{
						if(j != 0)
							sDiscountInfo += ",";
						sDiscountInfo += qb[j]; 
					}
					sDiscountInfo += ") ";
				}
			}
			if(m_bDiscontinued)
			{
				sDiscountInfo = "&nbsp;";
				qty = "0";
			}

			sitem = sitem.Replace("@@ITEM_DISCOUNT", sDiscountInfo);

			//qty
			sitem = sitem.Replace("@@ITEM_FIELD_NAME_QTY", "qty" + i.ToString());
			sitem = sitem.Replace("@@ITEM_FIELD_VALUE_QTY", qty);

//			if(m_sBuyType != "purchase")
			{
				//price
//				if(m_sSite == "admin")
				{
					sb.Append("<td align=right>");
					if(dqty > 1 && !bClearance)
						sprice = "<font color=" + sFontColor + "><b>";
					sprice += dPrice.ToString("c");
					if(dqty > 1 && !bClearance)
						sprice += "</b></font>";
				}
			}

			if(m_bNoPrice || m_bDiscontinued)
				sprice = "&nbsp;";
//DEBUG(" spric e= ", sprice);
			sitem = sitem.Replace("@@ITEM_PRICE", sprice);

			string slEdit = "";
			string slActionSel = "";
			string slBuyButton = "";

			if(bAdmin && !bOrder)
			{
				//admin edit
				if(m_bKit || bKit) //kit
					slEdit += "kit.aspx?id=";
				else
					slEdit += "liveedit.aspx?code=";
				slEdit += code;
				slActionSel += "<input type=checkbox name=sel" + code + ">";
			}
			else
			{
				slEdit = "\"javascript:alert_window=window.alert('Product Edit Not Allow While in Sale Mode');window.close();\"";
			}
			if(m_sSite.ToLower() != "admin")
			{
				if(m_bKit || bKit)
					slBuyButton = "<a title='view to buy this kit' href=pk.aspx?"+ code +"&ssid=" + m_ssid + " class=o><img title='view package details to purchase' border=0 src='i/view.gif'></a>";
				else
					slBuyButton = "<a href=cart.aspx?t=b&c="+ code +"><img title='buy this item' border=0 src='i/cart3.gif'></a>";
			}
			sitem = sitem.Replace("@@PUBLIC_BUY_LINK", slBuyButton);

			sitem = sitem.Replace("@@ITEM_EDIT_LINK", slEdit);
			sitem = sitem.Replace("@@ACTION_SELECT", slActionSel);
		}
		sb.Append("</tr>\r\n");

		//one item added
		items_added++;
		sbItems.Append(sitem); //add to row
		sitem = tp_item; //reset item template, prepare next item
		if(items_added >= m_nItemsPerRow) //row ready
		{
			srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
			sbRows.Append(srow); //add row to rows
			srow = tp_row; //reset row template, prepare next row
			
			sbItems.Remove(0, sbItems.Length); //empty items content
			items_added = 0; //reset counter
		}

		i++;
		sitem = tp_item; //new item
		//end subTable
	}

	if(items_added > 0) //item left behind
	{
		srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
		sbRows.Append(srow); //add row to rows
	}

	if(bHasGroup && sbRows.Length > 0) //row behinde
	{
		sgroup = sgroup.Replace("@@template_itemrow", sbRows.ToString()); //add group
		sgroup = RowParseCommand(sgroup, bFirstGroup); //remove show room link if not first group
		if(bFirstGroup)
		{
			sgroup = sgroup.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
			sgroup = sgroup.Replace("@@ITEM_LIST_SORT_LINK", slSort);
			sgroup = sgroup.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
			bFirstGroup = false;
		}

		string bookMark = sti + "_a";

		if(bAddBookMark)
			bookMark = sti + "_a";

		sgroup = sgroup.Replace("@@ITEM_GROUP_TAG", bookMark);
		sgroup = sgroup.Replace("@@ITEM_GROUP_TITLE", sti);

		sbGroups.Append(sgroup); //add group
	}

	if(bHasGroup)
		sout = sout.Replace("@@template_itemgroup", sbGroups.ToString());
	else
		sout = sout.Replace("@@template_itemrow", sbRows.ToString());

	sout = sout.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
	sout = sout.Replace("@@ITEM_LIST_SORT_LINK", slSort);
	sout = sout.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
	sout = sout.Replace("@@ssid_value", m_ssid);

//	if(m_bSearching)
//		sout = sout.Replace("Show Room", "");
	sout = ApplyColor(sout);
	Response.Write(sout);
	return;

	//end product list
	TSAddCache(scn, sb.ToString());
	Response.Write(sb.ToString());
}

string WriteURLWithoutPageNumber()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("?");
	if(brand != null)
		sb.Append("b=" + ebrand + "&");
	if(cat != null)
		sb.Append("c="+ ecat);
	if(s_cat != null)
		sb.Append("&s=" + es_cat);
	if(ss_cat != null)
		sb.Append("&ss=" + ess_cat);
	if(m_ssid != "")
		sb.Append("&ssid=" + m_ssid);
	return sb.ToString();
}

string AppendParameter(string brand, string s_cat, string ss_cat, 
					   string ebrand, string ecat, string es_cat, string ess_cat, string text)
{
	StringBuilder sb = new StringBuilder();
	if(brand != null)
	{
		sb.Append("b=");
		sb.Append(ebrand);
	}
	else
	{
		sb.Append("c=");
		sb.Append(ecat);
	}
	if(s_cat != null)
	{
		sb.Append("&s=");
		sb.Append(es_cat);
	}
	if(ss_cat != null)
	{
		sb.Append("&ss=");
		sb.Append(ess_cat);
	}
	sb.Append("&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
	sb.Append(" target=_blank>");
	sb.Append(text);
	sb.Append("</a>");
	return sb.ToString();
}

bool CheckPriceDate(string code, string age)
{
	DateTime dAge = DateTime.Parse(age);
	if( (DateTime.UtcNow.AddHours(12) - dAge).Days > 7)
		return false;
	return true;
}

string ShowLogo()
{
	string sc = " SELECT * FROM cat_logo ";
	sc += " WHERE s_cat = '" + EncodeQuote(s_cat) + "' ";
	sc += " ORDER by seq ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(ds, "logo") <= 0)
			return "";
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	StringBuilder sb = new StringBuilder();

	int columns = MyIntParse(GetSiteSettings("sub_cat_image_table_columns", "3"));
	if(columns > 30)
		columns = 30; //for protection

	int n = 0;
	sb.Append("<table cellspacing=10 cellpadding=10 border=0>");
	for(int i=0; i<ds.Tables["logo"].Rows.Count; i++)
	{
		DataRow dr = ds.Tables["logo"].Rows[i];
		string pic_name = dr["pic_name"].ToString();
		string uri = dr["uri"].ToString();
		int nColspan = MyIntParse(dr["colspan"].ToString());
		string title = dr["title"].ToString();
		if(n == 0)
		{
			if(i > 0)
				sb.Append("</tr>");
			sb.Append("<tr>");
		}

		if(nColspan > columns - n) //no enough columns
		{
			for(int m=columns-n; m>0; m--)
				sb.Append("<td>&nbsp;</td>");
			sb.Append("</tr><tr>");
			n = 0;
		}

		n++;
		if(n >= columns)
			n = 0;

		sb.Append("<td valign=bottom");
		if(nColspan > 1)
		{
			sb.Append(" colspan=" + nColspan);
			n += nColspan - 1;
			if(n >= columns)
				n = 0;
		}
		sb.Append(">");

		sb.Append("<table cellspacing=0 cellpadding=0 border=0 ");
		sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
		sb.Append("<tr><td>");
//	DEBUG("uri = ", uri);
		if(uri != "")
		{
			sb.Append("<a href=" + uri + "");
			if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
				sb.Append("&ssid="+ Request.QueryString["ssid"]+"");
			sb.Append(">");
		}
		sb.Append("<img src='/i/" + pic_name + "' border=0>");
		if(uri != "")
			sb.Append("</a>");
		sb.Append("</td></tr>");
		sb.Append("<tr><td><b>");
		sb.Append(title);
		sb.Append("</b></td></tr></table>");

		sb.Append("</td>");
	}
	sb.Append("</tr>");
	sb.Append("</table>");
	return sb.ToString();
}

bool DoAction(string code)
{
	if(m_action == "Phase Out")
	{
		//add to to product_skip table
		string sc = " IF EXISTS (SELECT code FROM product WHERE code=" + code + ") ";
		sc += " BEGIN ";
		sc += " INSERT INTO product_skip ";
		sc += " SELECT c.id, p.stock, p.eta, c.supplier_price, p.price, '' AS details ";
		sc += " FROM product p join code_relations c on c.code=p.code where c.code = " + code;
		sc += " UPDATE code_relations SET skip=1 WHERE code=" + code;
		sc += " DELETE FROM product WHERE code = " + code;
		sc += " END ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

string PrintFunctionButtons()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<input type=button " + Session["button_style"] + " value='View ");
	if(m_sBuyType == "purchase")
		sb.Append("Purchase Order");
	else if(m_sBuyType == "quote")
		sb.Append("Quote");
	else
		sb.Append(m_sBuyType);
	sb.Append("' onclick=window.location=('");
	if(m_sBuyType == "purchase")
		sb.Append("purchase.aspx");
	else if(m_sBuyType == "quote")
		sb.Append("q.aspx");
	else if(m_sBuyType == "sales")
		sb.Append("pos.aspx");
	else if(m_sBuyType == "quick_sales")
		sb.Append("pos_retail.aspx");
	else
		sb.Append(Session[m_sCompanyName + "_salesurl"]);
	if(m_ssid != "" && sb.ToString().IndexOf("ssid=") < 0)
		sb.Append("?ssid=" + m_ssid);
	sb.Append("') >");
	return sb.ToString();
}

bool GetKit()
{
	string sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
	sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
	sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
	for(int j=1; j<=9; j++)
		sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
	sc += ", price AS bottom_price ";
	sc += ", * FROM kit ";
	sc += " WHERE ";
	if(m_sSite != "admin")
		sc += " inactive=0 AND ";
	sc += " s_cat = '" + EncodeQuote(ds_cat) + "' ";
	if(dss_cat != null && dss_cat != "")
		sc += " AND ss_cat = '" + EncodeQuote(dss_cat) + "' ";
	if(Request.QueryString["ss"] == null || Request.QueryString["ss"] == "")
		sc += " AND hot = 1 ";
	sc += " ORDER BY s_cat, ss_cat, name, id";
//DEBUG("sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetSpecialKits()
{
	string sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
	sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
	sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
	for(int j=1; j<=9; j++)
		sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
	sc += ", k.price AS bottom_price ";
	sc += ", * FROM kit k ";
	sc += " JOIN specials_kit s ON k.id = s.code "; 
	sc += " WHERE 1=1 ";
	if(m_sSite != "admin")
		sc += " AND k.inactive=0 ";
	sc += " ORDER BY k.s_cat, k.ss_cat, k.name, k.id";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string TemplateParseCommand(string tp)
{
	StringBuilder sb = new StringBuilder();

	int line = 0;
	string sline = "";
	bool bRead = ReadLine(tp, line, ref sline);
	int protect = 999;
	while(bRead && protect-- > 0)
	{
		if(sline.IndexOf("IF_SPECIAL") >= 0)
		{
			sline = sline.Replace("IF_SPECIAL", "");
			if(bShowSpecial)
			{
				if(sline.IndexOf("@@DEFINE") >= 0)
				{
					string snItems = GetDefineValue("ITEMS_PER_ROW", sline);
					if(snItems != "")
						m_nItemsPerRow = MyIntParse(snItems);
				}
				else
					sb.Append(sline);
			}
		}
		else if(sline.IndexOf("IF_NOT_SPECIAL") >= 0)
		{
			sline = sline.Replace("IF_NOT_SPECIAL", "");
			if(!bShowSpecial && !m_bSearching)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_DISCONTINUED") >= 0)
		{
			sline = sline.Replace("IF_NOT_DISCONTINUED", "");
			if(!m_bDiscontinued)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_PURCHASE") >= 0)
		{
			sline = sline.Replace("IF_PURCHASE", "");
			if(m_sBuyType == "purchase")
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_PURCHASE") >= 0)
		{
			sline = sline.Replace("IF_NOT_PURCHASE", "");
			if(m_sBuyType != "purchase")
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_ADMIN") >= 0)
		{
			sline = sline.Replace("IF_ADMIN", "");
			if(m_bAdmin)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_ADMIN") >= 0)
		{
			sline = sline.Replace("IF_NOT_ADMIN", "");
			if(!m_bAdmin)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_PAGING") >= 0)
		{
			sline = sline.Replace("IF_PAGING", "");
			if(m_bPaging)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_LOGGEDIN") >= 0)
		{
			sline = sline.Replace("IF_LOGGEDIN", "");
			if(TS_UserLoggedIn())
				sb.Append(sline);
		}
		else if(sline.IndexOf("@@DEFINE") >= 0)
		{
			string snItems = GetDefineValue("ITEMS_PER_ROW", sline);
			if(snItems != "")
				m_nItemsPerRow = MyIntParse(snItems);
		}
		else if(sline.IndexOf("IF_SEARCHING") >= 0)
		{
			sline = sline.Replace("IF_SEARCHING", "");
			if(m_bSearching)
				sb.Append(sline);
		}
		else
		{
			sb.Append(sline);
		}
		line++;
		bRead = ReadLine(tp, line, ref sline);
	}
	return sb.ToString();
}

string GetDefineValue(string sDef, string sline)
{
	int p = sline.IndexOf(sDef);
	string sValue = "";
	if(p > 0)
	{
		p += sDef.Length + 1;
		for(; p<sline.Length; p++)
		{
			if(sline[p] == ' ' || sline[p] == '\r' || sline[p] == '\n')
				break;
			sValue += sline[p];
		}
	}
	return sValue;
}

string RowParseCommand(string s, bool bFirstGroup)
{
	StringBuilder sb = new StringBuilder();

	int line = 0;
	string sline = "";
	bool bRead = ReadLine(s, line, ref sline);
	int protect = 999;
	while(bRead && protect-- > 0)
	{
		if(sline.IndexOf("IF_FIRST_GROUP") >= 0)
		{
			sline = sline.Replace("IF_FIRST_GROUP", "");
			if(bFirstGroup)
				sb.Append(sline);
		}
		else
		{
			sb.Append(sline);
		}
		line++;
		bRead = ReadLine(s, line, ref sline);
	}
	return sb.ToString();
}

//for search options
string ShowKeywords(string sIn)
{
	string s = sIn;
	for(int i=0; i<words; i++)
	{
		s = showkw(s, kws[i]);
	}
	return s;
}

string showkw(string sIn, string kw)
{
	if(kw.Length <= 0)
	{
		return sIn;
	}

	string s = "";
	string slow = sIn.ToLower();
	kw = kw.ToLower();
	int p = slow.IndexOf(kw);
//DEBUG("keyword="+keyword, " p=" + p.ToString());
	int start = 0;

	while(p >= 0)
	{
		s += sIn.Substring(start, p - start) + "<b>";
		s += sIn.Substring(p, kw.Length);
		s += "</b>";
		start = p + kw.Length;
//		int pp = p;
		p = sIn.IndexOf(kw, p + kw.Length);
//		if(p
	}
	if(start < sIn.Length)
	{
		s += sIn.Substring(start, sIn.Length - start);
	}
	if(s == "")
		return sIn;

	return s;
}

</script>

