<script runat=server>

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

string m_JOBRA = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("technician"))
		return;
	//InitializeData(); //init functions

	if(!getRAStatus())
		return;
	//BindCustomer();
	//LFooter.Text = m_sAdminFooter;
}

bool getRAStatus()
{
	int rows = 0;
	string sc = "";
	
	if(Request.QueryString["job"] != "" && Request.QueryString["job"] != null)
		m_JOBRA = Request.QueryString["job"].ToString();
	bool isNum = true;
	int ptr = 0;
	while (ptr < m_JOBRA.Length)
	{
		if (!char.IsDigit(m_JOBRA, ptr++))
		{
			isNum = false;
			break;
		}
	}
	if(Request.QueryString["job"] != "" && Request.QueryString["job"] != null)
	{
		sc = "SELECT r.status, r.charge_detail, r.serial_number, r.invoice_number, r.charge, r.charge_detail, r.invoice_number,  c.id AS card_id,  e.name AS job_status, c.email, c.address1, c.address2, ";
		sc += " c.contact, c.name, c.trading_name, c.contact, c.company, c.phone, c.email, ";
		sc += " c.city, c.address1, c.address2, r.fault_desc, r.note, r.ram, ";
		sc += " r.cpu, r.os, r.other, r.motherboard, r.vga, r.prod_desc ";
		sc += " FROM  repair r JOIN enum e ON r.status = e.id  ";
		sc += " JOIN card c ON c.id = r.customer_id ";
		if(isNum)
			sc += " WHERE r.id = "+ m_JOBRA +" ";
		else
			sc += " WHERE r.id = 0 ";
		sc += " AND e.class = 'rma_status' ";
		//sc += " ORDER BY id ";
	}
	if(Request.QueryString["ra"] == "supplier")
	{
		sc = " SELECT * FROM rma ";
		sc += " WHERE ra_id = "+ Request.QueryString["id"].ToString() +" ";

	}
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "repair");

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows <= 0)
	{
		Response.Write("<center><h5><font color=Red>NO Customer Details</h5></font></center>");
		return false;
	}
	Response.Write("<table align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#83CCF6 bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:11pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	if(Request.QueryString["job"] != "" && Request.QueryString["job"] != null)
	{
		DataRow dr = dst.Tables["repair"].Rows[0];
		string id = dr["card_id"].ToString();
		string name = dr["name"].ToString();
		string company = dr["company"].ToString();
		string email = dr["email"].ToString();
		string trading_name = dr["trading_name"].ToString();
		string contact = dr["contact"].ToString();
		string phone = dr["phone"].ToString();
		string addr1 = dr["address1"].ToString();
		string addr2 = dr["address2"].ToString();
		string city = dr["city"].ToString();
		string sn = dr["serial_number"].ToString();
		string fault = dr["fault_desc"].ToString();
		string note = dr["note"].ToString();
		string charge = dr["charge"].ToString();
		string status = dr["job_status"].ToString();
		string inv = dr["invoice_number"].ToString();
		string charge_det = dr["charge_detail"].ToString();
		int ra_status = int.Parse(dr["status"].ToString());
		string ram = dr["ram"].ToString();
		string os = dr["os"].ToString();
		string vga = dr["vga"].ToString();
		string motherboard = dr["motherboard"].ToString();
		string other = dr["other"].ToString();
		string prod_desc = dr["prod_desc"].ToString();
		//Response.Write("<center><h5>Customer Details</h5></center>");
		Response.Write("<tr><td valign=top >");
		Response.Write("<table align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#83CCF6 bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr bgcolor=#6DE2A7><th colspan=2>Customer Details</th></tr>");
		Response.Write("<tr><td colspan=2>&nbsp;</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Customer ID:</th><td> "+ id +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Name:</th><td> "+ name +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Trading Name:</th><td> "+ trading_name +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Company:</th><td> "+ company +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Address:</th><td> "+ addr1 +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>&nbsp;</th><td> "+ addr2 +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>&nbsp;</th><td> "+ city +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Email:</th><td> <a title='email to customer' href=mailto:"+ email +">"+ email +"</a></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Phone:</th><td> "+ phone +"</td></tr>");
		//Response.Write("<tr><th align=right bgcolor=#83CCF6>Fax:</th><td> "+ fax +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Contact:</th><td> "+ contact +"</td></tr>");
		Response.Write("</table>");
		Response.Write("</td><td>&nbsp;</td>");
		Response.Write("<td valign=top>");
		Response.Write("<table align=center valign=center cellspacing=0 cellpadding=0 border=1 bordercolor=#83CCF6 bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr bgcolor=#6DE2A7><th colspan=2>Repair Details</th></tr>");
		Response.Write("<tr><td colspan=3><br size=1; color=black></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair Status:</th><th> "+ status.ToUpper() +"</th></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>SN#:</th><td><a title='check SN#' href='snsearch.aspx?sn="+ sn +"' class=o target=_blank>"+ sn +"</a></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>INV#:</th><td><a title='view invoic number' href='invoice.aspx?"+ inv +"' class=o target=_blank>"+ inv +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Product Des:</th><td>"+ prod_desc +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Environment:</th><td>&nbsp;</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>OS:</th><td>"+ os +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>RAM:</th><td>"+ ram +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>VGA:</th><td>"+ vga +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>MoBo:</th><td>"+ motherboard +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Other:</th><td>"+ other +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Fault Descriptions:</th><td> <textarea col=10 rows=5 readonly>"+ fault +"</textarea></td></tr>");
		if(ra_status >= 3)
		{
			if((charge != "" && charge != null))
			{
				if(double.Parse(charge) > 0)
				{
					Response.Write("<tr><th align=right bgcolor=#83CCF6>Charge Detail:</th><td> "+ charge_det +"</td></tr>");
					Response.Write("<tr><th align=right bgcolor=#83CCF6>Total Charge:</th><td> "+ charge +"</td></tr>");
				}
			}
			Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair Note:</th><td><textarea col=10 rows=5 readonly>"+ note +"</textarea></td></tr>");
		}
		Response.Write("</table>");
		Response.Write("</td></tr>");
	}
	if(Request.QueryString["ra"] == "supplier")
	{
		for(int i=0; i<dst.Tables["repair"].Rows.Count; i++)
		{
		DataRow dr = dst.Tables["repair"].Rows[i];
		string id = dr["ra_id"].ToString();
		string supplier = dr["supplier"].ToString();
		//string supplier_id = dr["supplier_id"].ToString();
		string technician = dr["technician"].ToString();
		string repair_date = dr["repair_date"].ToString();
		string check_status	= dr["check_status"].ToString();
		string sn = dr["serial_number"].ToString();
		string fault = dr["fault_desc"].ToString();
		string pack_no = dr["pack_no"].ToString();
		string inv = dr["invoice_number"].ToString();
		string authorize = dr["authorize"].ToString();
		string supp_rma_no = dr["supp_rmano"].ToString();
		string purchase_date = dr["purchase_date"].ToString();
		string prod_desc = dr["product_desc"].ToString();
		string stock_check = dr["stock_check"].ToString();
		string repair_id = dr["repair_jobno"].ToString();
		string pcode = dr["p_code"].ToString();
		string return_date = dr["return_date"].ToString();

		Response.Write("<tr bgcolor=#6DE2A7><th colspan=3>RMA Status</th></tr>");
		Response.Write("<tr><td colspan=3><br size=1; color=black></td></tr>");
		if(check_status == "2")
			Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair Status:</th><td>&nbsp;</td><th> Faulty Product Has Been Sent</th></tr>");
		else if(check_status == "1")
			Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair Status:</th><td>&nbsp;</td><th> Waiting for Supplier's RMA#</th></tr>");
		else
			Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair Status:</th><td>&nbsp;</td><th> Product Returned</th></tr>");
//<a title='view invoic number' href='invoice.aspx?"+ inv +"' class=o target=_blank>
		Response.Write("<tr><th align=right bgcolor=#83CCF6>ID:</th><td>&nbsp;</td><td><a title='Click me to Process RMA' href='rma.aspx?rma="+ id +"&data=recorded' class=o target=_blank onclick='window.close()'>"+ id +"</a></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>RMA Date:</th><td>&nbsp;</td><td>"+ repair_date +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Supplier RA#:</th><td>&nbsp;</td><td>"+ supp_rma_no +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Supplier:</th><td>&nbsp;</td><td>"+ supplier +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>SN#:</th><td>&nbsp;</td><td><a title='click to view invoice detail' href='snsearch.aspx?sn="+ sn +"' onclick='window.close()' class=o target=_blank>"+ sn +"</a></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>INV#:</th><td>&nbsp;</td><td><a title='click to view invoice detail' href='invoice.aspx?"+ inv +"' class=o target=_blank>"+ inv +"</a></td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Product Desc:</th><td>&nbsp;</td><td>"+ prod_desc +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Purchase Date:</th><td>&nbsp;</td><td>"+ purchase_date +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Supp Code:</th><td>&nbsp;</td><td>"+ pcode +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Return Date:</th><td>&nbsp;</td><td>"+ return_date +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Supplier Authorize Person:</th><td>&nbsp;</td><td>"+ authorize +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Delivery#:</th><td>&nbsp;</td><td>"+ pack_no +"</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Faulty Desc:</th><td>&nbsp;</td><td>"+ fault +"</td></tr>");
		if(stock_check == "1")
			Response.Write("<tr><th align=right bgcolor=#83CCF6>For Stock:</th><td>&nbsp;</td><td>Yes, for stock</td></tr>");
		else
			Response.Write("<tr><th align=right bgcolor=#83CCF6>For Stock:</th><td>&nbsp;</td><td>This Product is for Customer</td></tr>");
		Response.Write("<tr><th align=right bgcolor=#83CCF6>Repair JOB#:</th><td>&nbsp;</td><td><a title='click to view repair job' href='view_ra.aspx?job="+ repair_id +"' class=o >"+ repair_id +"</td></tr>");
		}
	}
	Response.Write("<tr><td colspan=3 align=right><input type=button value='    close   ' "+Session["button_style"]+" onclick='window.close()'>");
	Response.Write("</table>");
	
	return true;
}


</script>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html>
<head>
    <title>--- Repair Status ---</title> 
</head>
