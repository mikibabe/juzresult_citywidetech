<!-- #include file="resolver.cs" -->
<!-- #include file="kit_fun.cs" -->
<!-- #include file="card_function.cs" -->

<script runat=server>

string err = "";
Boolean alterColor = false;

int invoiceNumber = -1;
string sCheckoutType = "";
string sPaymentType = "cash";
string m_orderNumber = "";
string m_branchID = "1";

DataSet ds = new DataSet();

protected void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	string sc = "";
	CheckShoppingCart();
	CheckUserTable();	//get user details if logged on

    string isPublicRegister = Request.Form["public-register"];
    bool isNewUserRegister = false;
    if(String.IsNullOrEmpty(isPublicRegister)){
        if(IsCartEmpty())
	    {
		    PrintHeaderAndMenu("Confirm Order");
		    Response.Write("<center><h3>Your shopping cart is empty.. <br></h3>");
		    Response.Write("<a href=cart.aspx class=d><font size=+1><b>View Cart</b></font></a></center><br><br><br>\r\n");
		    return;
	    }
    }else{
         isNewUserRegister = true;
    }

	if(!ValidateUserDetails())
	{

        if(isNewUserRegister && err == ""){
            //go to login
            string u =  Request.Form["email"];
            string p = Request.Form["pass"] ;
            string outputForm = "";
             outputForm += "<script type='text/javascript' src='themes/js/jquery-1.8.0.min.js'></";
             outputForm += "script>";
             outputForm += "<form action='login.aspx' method='post'  id='loginForm-inner'>";
             outputForm += "    <input type='hidden'  name='name' value='"+u+"'>";
             outputForm += "    <input type='hidden'  name='pass' value='"+p+"'>";
             outputForm += "    <input type='hidden' name='cmd'  value='Login'  >";
             outputForm += "</form>";
             outputForm += "<script type='text/javascript'>";
             outputForm += "   $(document).ready(function () {";
             outputForm += "       $('#loginForm-inner').submit();";
             outputForm += "   });";
             outputForm += "</";
             outputForm += "script>";
             Response.Write(outputForm);
             return;
        }

		PrintHeaderAndMenu("Confirm Order");
		sc = "<br><center><h3>";
		sc += err;
		sc += "</h3><br><br><input type=button onclick=history.go(-1) value=Back class=b></center>\r\n";
		Response.Write(sc);
		return;
	}

	PrintHeaderAndMenu("Confirm Order");

	//security check, block suspicious transactions
	if(!CheckTranHistory())
	{
		PrintFooter();
		return;
	}

	sc = "<br>";
	sc += PrintCart(false, false, false);	//print shoppingcart, false: no buttons

	if(!CreateOrder())
		return;

	sc += PrintConfirmTable();

	sc += "<tr><td  align=center>";
	if(sPaymentType == "credit card"){
		sc += "<script>";
        sc += "function DoPaypalPayment(){$('#PaypalForm').submit();}";
        sc += "</";
        sc += "script>";
        sc += "<div style='text-align: center;'><input type=button value='Continue with Credit Card' onclick='DoPaypalPayment();' class=\"red_btn\"></div>";
	}
	else
		sc += "<br /><input type=submit value=&nbsp;&nbsp;Continue&nbsp;&nbsp; class=\"button button_large\">";
	sc += "</td></tr><tr><td colspan=2 align=center>";
	if(sPaymentType == "Credit Card")
		sc += "<font color=red size=-2>please only press this button once, this will invoke secured credit card transaction.</font>";
	sc += "</td></tr></table></td></tr></table>";
//confirm table end
    
    sc += "</form>";

	Response.Write(sc);
	PrintFooter();
}

Boolean ValidateUserDetails()
{

    string isPublicRegister = Request.Form["public-register"];
    string returnUrl = Request.Url.ToString();
    bool isNewUserRegister = false;
    if(!String.IsNullOrEmpty(isPublicRegister)){
       // Response.Redirect(returnUrl);
        Session[m_sCompanyName + "loggedin"] = null;
       isNewUserRegister = true; 
    }

	if(dtUser.Rows.Count <= 0)
	{
//DEBUG("error, user table empty", "");
		err = "internal error";
		return false;
	}

	sCheckoutType = Request.Form["CheckoutType"];
	if(sCheckoutType == "Continue With Credit Card >>")
	{
		sPaymentType = "credit card";
	}
	else if(sCheckoutType == "Continue With BankDeposit >>")
	{
		sPaymentType = "deposit";
	}
	else if(sCheckoutType == "Continue With PayPal >>")
	{
		sPaymentType = "paypal";
//DEBUG("paypal=", sPaymentType);
	}else if(sCheckoutType == "Continue With Pay By Cash >>")
	{
		sPaymentType = "cash";
//DEBUG("paypal=", sPaymentType);
	}
	
	string email = Request.Form["email"];




	string email_confirm = Request.Form["email_confirm"];

	string name = EncodeQuote(Request.Form["Name"]);
	string company = EncodeQuote(Request.Form["Company"]);
	string address1 = EncodeQuote(Request.Form["Address1"]);
	string address2 = EncodeQuote(Request.Form["Address2"]);
	string address3 = EncodeQuote(Request.Form["City"]);
	string city = EncodeQuote(Request.Form["City"]);
	string country = EncodeQuote(Request.Form["Country"]);
	string phone = EncodeQuote(Request.Form["Phone"]);

	string nameB = EncodeQuote(Request.Form["NameB"]);
	string companyB = EncodeQuote(Request.Form["CompanyB"]);
	string address1B = EncodeQuote(Request.Form["Address1B"]);
	string address2B = EncodeQuote(Request.Form["Address2B"]);
	string cityB = EncodeQuote(Request.Form["CityB"]);
	string countryB = EncodeQuote(Request.Form["CountryB"]);

	Trim(ref email);
	Trim(ref email_confirm);
	Trim(ref name);
	Trim(ref company);
	Trim(ref address1);
	Trim(ref address2);
	Trim(ref address3);
	Trim(ref city);
	Trim(ref country);
	Trim(ref phone);
	Trim(ref nameB);
	Trim(ref companyB);
	Trim(ref address1B);
	Trim(ref address2B);
	Trim(ref cityB);
	Trim(ref countryB);

    if(String.IsNullOrEmpty(nameB)){
        nameB = name;
    }

    if(String.IsNullOrEmpty(companyB)){
        companyB = company;
    }

    if(String.IsNullOrEmpty(address1B)){
        address1B = address1;
    }

    if(String.IsNullOrEmpty(address2B)){
        address2B = address2;
    }

    if(String.IsNullOrEmpty(cityB)){
        cityB = city;
    }

    if(String.IsNullOrEmpty(countryB)){
        countryB = country;
    }

	bool bChanged = false;
	string nd = ""; //new data, used to compare to old data to detect changes
	nd += name;
	nd += company;
	nd += address1;
	nd += address2;
	nd += city;
	nd += country;
	nd += phone;

	nd += nameB;
	nd += companyB;
	nd += address1B;
	nd += address2B;
	nd += cityB;
	nd += countryB;

	if(nd != Request.Form["old_data"]){
      //  if(isNewUserRegister){
      //      bChanged = false;
      //  }else{
            bChanged = true;
      //  }
    }
		
	DataRow dr = dtUser.Rows[0];
	
	dtUser.AcceptChanges();
	dr.BeginEdit();

	if(bChanged)
	{
		dr["Name"] = name;
		dr["Company"] = company;
		dr["Address1"] = address1;
		dr["Address2"] = address2;
		dr["Address3"] = city;
		dr["City"] = city;
		dr["Country"] = country;
		dr["Phone"] = phone;
		dr["Email"] = email;
		
		dr["NameB"] = nameB;
		dr["CompanyB"] = companyB;
		dr["Address1B"] = address1B;
		dr["Address2B"] = address2B;
		dr["CityB"] = cityB;
		dr["CountryB"] = countryB;
		if(Session["ShippingFee"] != null)
			dr["shipping_fee"] = Session["ShippingFee"].ToString();
	}

	dr["CardType"] = Request.Form["CardType"];
	dr["NameOnCard"] = Request.Form["NameOnCard"];
	dr["CardNumber"] = Request.Form["CardNumber"];
	dr["ExpireMonth"] = Request.Form["ExpireMonth"];
	dr["ExpireYear"] = Request.Form["ExpireYear"];

	dr.EndEdit();

	dtUser.AcceptChanges();

//	if(Session["TotalPrice"] == null || Session["TotalGST"] == null || Session["Amount"] == null)
	if(dr["name"].ToString() == "")
		err = "Error, Name can't be blank.";
	else if(dr["Address1"].ToString() == "")
		err = "Error, Address can't be blank.";
	else if(dr["Phone"].ToString() == "")
		err = "Error, Phone Number can't be blank.";
	else if(dr["Email"].ToString() == "")
		err = "Error, Email can't be blank.";
	else if(email != email_confirm)
		err = "Error, Confirming Email address not identical to Email Address.";

	string pass = Request.Form["pass"] ;
	string ads = "0";

    //if(err == "" && Request.Form["remember"] == "on")
    //{
    //    if(Request.Form["pass"] == "")
    //        err = "Error, password can't be blank.";
		if(Request.Form["accept_mass_email"] == "on")
			ads = "1";
    //}

	bool bRet = (err == "");
	if(bRet)
	{
//DEBUG("bChanged", bChanged.ToString());
		if(bChanged && TS_UserLoggedIn())
			bRet = UpdateAccount();
		else
		{
			string registered = "0";
			if(Request.Form["remember"] == "on")
				registered = "1";
//DEBUG("userLoginIn=", TS_UserLoggedIn().ToString());
			if(!TS_UserLoggedIn())
			{
//DEBUG("pass", pass);
                    //check email used or not.
                    if(!CheckEmailRegister(email)){
                        err = "Email already uesed please change other one.";  
                        return false;
                    }
				bRet = NewCard(email, pass, "customer", name, "", company, address1, address2, city, country,
					nameB, companyB, address1B, address2B, cityB, countryB, phone, "", nameB,address1B , address2B, cityB, //postal1, 2, 3
					ads, dr["shipping_fee"].ToString(), "0", "0", 1, true, registered);
//DEBUG("GOHERE", "244OK");
//DEBUG("bRet", bRet.ToString());
				if(bRet)
				{
//					Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=checkout.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "\">");
//					Response.End();
					//return true;
				}
			}
		}
	}
    
    if(isNewUserRegister){
        err = "";
        return false;
    }

	if(bRet && GetCartItemForThisSite() <= 0)
	{
		err = "Your Shopping Cart is empty<br><br>";
		err += "<a href=c.aspx class=d><font size=+1><b>Home Page</b></font></a>";
		return false;
	}
	return bRet;
}

Boolean UpdateAccount()
{
	DataRow dr = dtUser.Rows[0];
//DEBUG("shipping_fee=", dr["shipping_fee"].ToString());
	StringBuilder sb = new StringBuilder();

	sb.Append("UPDATE card SET Name='");
	sb.Append(dr["Name"].ToString());
	sb.Append("', Company='");
	sb.Append(dr["Company"].ToString());
	sb.Append("', Address1='");
	sb.Append(dr["Address1"].ToString());
	sb.Append("', Address2='");
	sb.Append(dr["Address2"].ToString());
	sb.Append("', Address3='");
	sb.Append(dr["Address3"].ToString());
	sb.Append("', City='");
	sb.Append(dr["City"].ToString());
	sb.Append("', Country='");
	sb.Append(dr["Country"].ToString());
	sb.Append("', Phone='");
	sb.Append(dr["Phone"].ToString());
	sb.Append("', NameB='");
	sb.Append(dr["NameB"].ToString());
	sb.Append("', CompanyB='");
	sb.Append(dr["CompanyB"].ToString());
	sb.Append("', Address1B='");
	sb.Append(dr["Address1B"].ToString());
	sb.Append("', Address2B='");
	sb.Append(dr["Address2B"].ToString());
	sb.Append("', CityB='");
	sb.Append(dr["CityB"].ToString());
	sb.Append("', CountryB='");
	sb.Append(dr["CountryB"].ToString());
	sb.Append("', shipping_fee=");
	sb.Append(dr["shipping_fee"].ToString());
	sb.Append(" WHERE email='");
	sb.Append(dr["Email"].ToString());
	sb.Append("'");

	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft" + m_sDataSource + m_sSecurityString);
		myCommand = new SqlCommand(sb.ToString());
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sb.ToString(), e);
		return false;
	}
	return true;
}

string PrintConfirmTable()
{
	DataRow dr = dtUser.Rows[0];
	
	StringBuilder sb = new StringBuilder();

	sb.Append("<form action=");
	if(sPaymentType == "credit card")
	{
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
// for testing
	//	bool bTest = false;
	//	if(Session["email"] != null && Session["email"].ToString().IndexOf("@ezsoft.com") > 0)
	//		bTest = true;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
        sb.Append("'Payment.aspx' method=post class=\"std\" id=\"PaypalForm\">");
        //fill data for kiwibank
        double _orderAmount = 0;
	    try{
	       _orderAmount = double.Parse(Session["Amount"].ToString());
	    }catch(Exception){

	    }
        //sb.Append("<input type='hidden' name='cmd' value='_xclick' />");
       // sb.Append("<input type='hidden' name='account_id' value='11216' />");
       // sb.Append("<input type='hidden' name='return_url' value='http://"+ HttpContext.Current.Request.Url.Host +"/paypalback.aspx' />");
       // sb.Append("<input type='hidden' name='amount' value='"+ Math.Round(_orderAmount, 2) +"' />");
       // sb.Append("<input type='hidden' name='item_name' value='Online order' />");
        //sb.Append("<input type='hidden' name='store_card' value='1' />");
       // sb.Append("<input type='hidden' name='csc_required' value='1' />");
       // sb.Append("<input type='hidden' name='reference' value='Surmanti Online Order' />");
       // sb.Append("<input type='hidden' name='particular' value='Order ID "+ Session["OrderNumber"] +"'  /> ");


        sb.Append("<input type='hidden' name='OrderNumber' value='"+ m_orderNumber  +"' />");
        sb.Append("<input type='hidden' name='PayAmount' value='"+ Math.Round(_orderAmount, 2) +"' />");
	}
	else
	{
		sb.Append("result.aspx method=post class=\"std\" id=\"loginForm\">");
	}
	//sb.Append(" method=post class=\"std\" id=\"loginForm\">");

	if(Session["host_name"] == null)
		Session["host_name"] = "";
	string host_name = Session["host_name"].ToString();
	
	if(Session["rip"] == null)
		Session["rip"] = "";
	sb.Append("<input type=hidden name=card_id value=" + Session["card_id"].ToString() + ">");
	sb.Append("<input type=hidden name=ip value=" + Session["rip"].ToString() + ">"); //show card details form
	sb.Append("<input type=hidden name=host_name value='" + host_name + "'>"); //show card details form
	sb.Append("<input type=hidden name=po_id value='" + m_orderNumber + "'>");

	string url = "";
	string servername = Request.ServerVariables["SERVER_NAME"];
	string s = Request.ServerVariables["URL"];
//DEBUG("s=", s);
	int i = s.Length - 1;
	for(; i>=0; i--)
	{
		if(s[i] == '/')
			break;
	}
	
	s = s.Substring(0, i);
	url = "http://" + servername + s + "/result.aspx?t=cc&oid=" + Session["OrderNumber"];
//DEBUG("url=", url);

	sb.Append("<input type=hidden name=result_url value='");
	sb.Append(url + "'>");

//confirm table start






	sb.Append("<br style='clear: both;' /><br /><fieldset class=\"account_creation\" >");
//	sb.Append("<tr><td colspan=2>&nbsp;</td></tr>\r\n");
	sb.Append("<h2 class='entry-title'>Shipping Address</h2>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Name</label>");
     sb.Append(dr["Name"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Company</label>");
     sb.Append(dr["Company"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Address</label>");
     sb.Append(dr["Address1"].ToString());
	 sb.Append("&nbsp;");
	 sb.Append(dr["Address2"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           City</label>");
     sb.Append(dr["City"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Phone</label>");
     sb.Append(dr["Phone"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Email</label>");
     sb.Append(dr["Email"].ToString());
     sb.Append("   </p>");
     sb.Append("</fieldset>");
	    

	//billing table
	sb.Append(" <hr /><fieldset class=\"account_creation\" >");
	sb.Append("<h2 class='entry-title'>Billing Address</h2>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Name</label>");
	if(dr["NameB"].ToString() != "")
		sb.Append(dr["NameB"].ToString());
	else
		sb.Append(dr["Name"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Company</label>");
	if(dr["CompanyB"].ToString() != "")
		sb.Append(dr["CompanyB"].ToString());
	else
		sb.Append(dr["Company"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Address</label>");
	if(dr["Address1B"].ToString() != "")
		sb.Append(dr["Address1B"].ToString());
	else
		sb.Append(dr["Address1"].ToString());

	sb.Append("&nbsp;");
	if(dr["Address2B"].ToString() != "")
		sb.Append(dr["Address2B"].ToString());
	else
		sb.Append(dr["Address2"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           City</label>");
	if(dr["CityB"].ToString() != "")
		sb.Append(dr["CityB"].ToString());
	else
		sb.Append(dr["City"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Phone</label>");
     sb.Append(dr["Phone"].ToString());
     sb.Append("   </p>");

     sb.Append("   <p class=\"required text\">");
      sb.Append("      <label for=\"customer_firstname\">");
     sb.Append("           Email</label>");
     sb.Append(dr["Email"].ToString());
     sb.Append("   </p>");
     sb.Append("</fieldset>");
	//end of billing table
	if(sPaymentType != "credit card"){
		sb.Append("<input type=hidden name=Amount value='");
		sb.Append(Session["Amount"].ToString());
		sb.Append("'>\r\n");
	}
	
//DEBUG("amout=", Session["Amount"].ToString());
	sb.Append("<input type=hidden name=InvoiceNumber value='");
	sb.Append(Session["OrderNumber"]);
	sb.Append("'>\r\n");
	
	sb.Append("<input type=hidden name=PaymentType value='");
	sb.Append(sPaymentType);
	sb.Append("'>\r\n");

	sb.Append("</td></tr>");

	return sb.ToString();
}

bool UpdateOrder()
{
	string temp_paymenttype = GetEnumID("payment_method", sPaymentType.ToLower());

	string sc = " UPDATE orders SET payment_type='" + temp_paymenttype + "'";
	sc += " WHERE id=" + m_orderNumber;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

Boolean CreateOrder()
{
	if(Session["OrderCreated"] != null)
	{
		if(Session["OrderCreated"] == "true")
		{
			m_orderNumber = Session["OrderNumber"].ToString();
			return UpdateOrder(); //update payment type
		}
	}

	string payment_method = GetEnumID("payment_method", sPaymentType.ToLower());
//DEBUG("506payment_method=", sPaymentType);
	string sc = "BEGIN TRANSACTION ";
	sc += " INSERT INTO orders ( number, card_id, po_number) VALUES(0, " + Session["card_id"].ToString() + ", '";
	sc += EncodeQuote(Request.Form["po_number"]) + "') SELECT IDENT_CURRENT('orders') AS id";
	sc += " COMMIT ";

    int shippingMethodId = 4;
    double shww = 0;
    try{
        string shw = Session["ShippingFee"].ToString();
        shww = double.Parse(shw);
        if(shww > 0){
            shippingMethodId = 4;
            shww = shww / 1.15;
        }else{
            shippingMethodId = 1;
        }

    }catch(Exception){

    }

	try
	{
		SqlDataAdapter myCommand1 = new SqlDataAdapter(sc, myConnection);
		if(myCommand1.Fill(ds, "id") == 1)
		{
			m_orderNumber = ds.Tables["id"].Rows[0]["id"].ToString();
			Session["OrderNumber"] = m_orderNumber;
			//assign ordernumber same as id
			sc = "UPDATE orders SET number=" + m_orderNumber;
			sc += ", shipping_method="+shippingMethodId;// 4: 2 day courier + Request.Form["shipping_method"];
			sc += ", freight=" + shww.ToString();
//			sc += ", pick_up_time='" + pickup_time + "'";
//			if(Request.Form["special_shipto"] == "1" || (bool)Session["login_is_branch"] )
//				sc += ", special_shipto=1, shipto='" + EncodeQuote(Request.Form["ssta"]) + "' ";
//			sc += ", contact='" + EncodeQuote(Request.Form["contact"]) + "' ";
			sc += ", sales_note='Online Retail Order - ";
			if(Session["CouponName"] != null)
				sc += " Coupon: " + Session["CouponName"].ToString() +" Original Price: "+ Session["BeforeCoupon"].ToString() +" Total Discount: "+ Session["CouponTotal"].ToString() ;				
			
            if(Session["PickUpBranchName"] != null && shippingMethodId == 1)
				 sc += " pickup from " + EncodeQuote(Session["PickUpBranchName"].ToString());
            else
                 sc += "  2 day courier " + shww.ToString("C");
			sc += "', payment_type=" + payment_method; 
			sc += " WHERE id=" + m_orderNumber;
			try
			{
				myCommand = new SqlCommand(sc);
				myCommand.Connection = myConnection;
				myCommand.Connection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();

				if(Session["CouponId"] != null && Session["CouponType"] != null){
					//insert into coupon to user coupon table
			        sc = "INSERT INTO UserCoupons (CardId, CouponId, UsedDatetime, OrderId) VALUES ("+ Session["card_id"].ToString() +", "+ Session["CouponId"].ToString() +", '"+ DateTime.Now +"', "+ m_orderNumber +")";
			        myCommand = new SqlCommand(sc);
					myCommand.Connection = myConnection;
					myCommand.Connection.Open();
					myCommand.ExecuteNonQuery();
					myCommand.Connection.Close();
				}


				
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
		}
		else
		{
			Response.Write("<br><br><center><h3>Create Order failed, error getting new order number</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	if(!RecordOrderItems())
		return false;

	Session["OrderCreated"] = "true";
	Session["CouponValue"] = null;
	Session["CouponName"] = null;
	Session["CouponId"] = null;
	Session["CouponType"] = null;
	Session["PickUpBranchName"] = null;
/*
	

	msgMail.To = m_sAdminEmail;
	msgMail.From = m_sSalesEmail;
	msgMail.Subject = "Online Checking Out - " + m_sCompanyName;
//	msgMail.BodyFormat = MailFormat.Html;
	msgMail.Body = "Order Number : " + m_orderNumber + " \r\n";
	msgMail.Body += "Payment Method : " + sPaymentType;

	
*/
    
	return true;
}

bool RecordOrderItems()
{
	for(int i=0; i<dtCart.Rows.Count; i++)
	{
		DataRow dr = dtCart.Rows[i];
		if(dr["site"].ToString() != m_sCompanyName)
			continue;

		string kit = dr["kit"].ToString();
		double dPrice = MyDoubleParse(dr["salesPrice"].ToString());

		string name = EncodeQuote(dr["name"].ToString());
		if(name.Length > 255)
			name = name.Substring(0, 255);

		if(kit == "1")
		{
			RecordKitToOrder(m_orderNumber, dr["code"].ToString(), name, dr["quantity"].ToString(), dPrice, "1");
			continue;
		}

        double salePrice = Math.Round(MyDoubleParse(dr["salesPrice"].ToString()), 4);

        
		if(Session["CouponValue"] != null){
			double couponValue = double.Parse(Session["CouponValue"].ToString());
			salePrice = salePrice * (1- couponValue);
		}

        if(g_bRetailVersion && m_sSite == "www" && !m_bDealerArea){
            salePrice = salePrice - salePrice * 3 / 23;        
            salePrice = Math.Round(salePrice, 3);
        }
        


		string sc = "INSERT INTO order_item (id, code, quantity, item_name, supplier, supplier_code, supplier_price ";
		sc += ", commit_price) VALUES(" + m_orderNumber + ", " + dr["code"].ToString() + ", ";
		sc += dr["quantity"].ToString() + ", '" + name + "', '" + dr["supplier"].ToString();
		sc += "', '" + dr["supplier_code"].ToString() + "', " + Math.Round(MyDoubleParse(dr["supplierPrice"].ToString()), 2);
		sc += ", " + salePrice + ") "; 

		sc += " IF NOT EXISTS (SELECT code FROM stock_qty WHERE code=" + dr["code"].ToString();
		sc += " AND branch_id = " + m_branchID;
		sc += ")";
		sc += " INSERT INTO stock_qty (code, branch_id, qty, allocated_stock) ";
		sc += " VALUES (" + dr["code"].ToString() + ", " + m_branchID + ", 0, " + dr["quantity"].ToString() + ")"; 
		sc += " ELSE Update stock_qty SET ";
		sc += " allocated_stock = allocated_stock + " + dr["quantity"].ToString();
		sc += " WHERE code=" + dr["code"].ToString() + " AND branch_id = " + m_branchID;

		sc += " UPDATE product SET allocated_stock=allocated_stock+" + dr["quantity"].ToString();
		sc += " WHERE code=" + dr["code"].ToString();
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myCommand.Connection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e)
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

bool CheckTranHistory()
{
//trans log checking is only for eden
return true;

	string host_name = "";
	if(Session["host_name"] == null)
	{
		CResolver rs = new CResolver();
		if(Session["rip"] != null)
			host_name = rs.Resolve(Session["rip"].ToString());
		Session["host_name"] = host_name;
	}
	else
		host_name = Session["host_name"].ToString();

	string country = "nz";
//host_name = "p321-ipadla.saitma.ocn.ne.jp";
	if(host_name.Length >= 3)
	{
		country = host_name.Substring(host_name.Length - 3, 3);
	}
	country = country.ToLower();
	if(country == ".jp" || country == ".id" || country == ".ph")
	{
		
		
		string mFrom  = GetSiteSettings("postmaster_email", "postmaster@ezsoft.com");
		string mSubject = "IP rejected for checkout";
		string mBody = "IP:" + Session["rip"].ToString() + "\r\n";
		mBody += "host:" + Session["host_name"].ToString() + "\r\n";

		
        SendEmail(mFrom, mFrom, m_emailAlertTo, mSubject,mBody);
		Response.Write("<br><br><center><font color=red><h3>Stop !</h3></font>");
		Response.Write("<h3>Sorry, we only sell within New Zealand</h3>");
		Response.Write("<h5>Call us if you are right in New Zealand now, there maybe an IP confusion</h5><br>");
		Response.Write("<b>Your IP : </b>" + Session["rip"].ToString() + "<br>");
		Response.Write("<b>Your Host Name : </b>" + Session["host_name"].ToString() + "<br>");
		Response.Write("<br><br><br><br><br><br><br>");
		return false;
	}

	DataSet dsctl = new DataSet();
	int rows = 0;
	string sc = "SELECT DISTINCT card_number FROM cctrans_log WHERE ip='" + Session["rip"] + "' ";
	sc += " AND success=0 AND DATEDIFF(hour, LogTime, GETDATE())<=24";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dsctl, "cctrans_log");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows > 2)
	{
		
		
		string mTo = m_emailAlertTo;
		string mFrom = GetSiteSettings("postmaster_email", "postmaster@ezsoft.com");
		string mSubject  = "Suspicious Transaction Stopped";
		string mBody = "IP:" + Session["rip"].ToString() + "\r\n";
		mBody += "host:" + Session["host_name"].ToString() + "\r\n";

		
        SendEmail(mFrom, mFrom, mTo, mSubject,mBody);
		Response.Write("<br><br><center><font color=red><h3>Stop !</h3></font>");
		Response.Write("<h5>Suspicious transaction, call us if you are using your won credit card</b><br><br><br><br><br><br>");
		return false;
	}
	return true;
}

bool CheckEmailRegister(string email){
    string sc = "select email from card where email = '"+email+"'";
    DataSet dddssss = new DataSet();
    bool returnValue = false;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		int rows = myCommand.Fill(dddssss, "what");
        if(rows > 0){
            returnValue =  false;
        }else{
            returnValue = true;
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		returnValue = false;
	}

    return returnValue;
}
</script>