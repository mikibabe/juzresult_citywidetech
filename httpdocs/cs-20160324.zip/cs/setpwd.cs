<script runat=server>


string m_old_pwd = "";

DataSet dst = new DataSet();

void SPage_Load()//Object Src, EventArgs E ) 
{
	if(Request.QueryString["t"] != null && Request.QueryString["t"] == "c")
	{

		if(Session["email"] != null){
    		
	    }else{
	    	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=c.aspx\">");
	    }

		Response.Write("<center>");
		if(!GetUserOldPwd())
		{
			Response.Write("<br><br><br><h3><b>&nbsp;&nbsp;Error! Wrong Old Password!</b></h3>");
			Response.Write("<a class='red_btn' href=setpwd.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + ">");
			Response.Write(" Try Again! </a> ");
		}
		else if(!CheckNewPwd())
		{
			Response.Write("<br><br><br><h3><b>&nbsp;&nbsp;Invalid New Password!</b></h3>");
			Response.Write("<a class='red_btn' href=setpwd.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + ">");
			Response.Write(" Try Again! </a> ");
		}
		else if(UpdatePwd())
		{
			//Response.Write("<br><br><br><h3><b>&nbsp;&nbsp;New password saved!</b></h3>");
			//Response.Write("<input type=button onclick=window.location=('default.aspx') value='Home'>");
			Response.Write("<script>alert('New Password Saved.');</");
			Response.Write("script>");
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=sp.aspx?account\">");
		}
		else
		{
			Response.Write("<br><br><br><g2> &nbsp;&nbsp;Updating Password Error, Please </h2>");
			Response.Write("<a class='red_btn' href=setpwd.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + ">");
			Response.Write(" Try Again! </a> ");
		}

		
	}
	else
	{
		MyPwdTalbe();
	}
}

bool UpdatePwd()
{
	string newpwd = Request.Form["new_pwd"];
	newpwd = FormsAuthentication.HashPasswordForStoringInConfigFile(newpwd, "md5");
	
	string sc = "UPDATE card SET password='" + newpwd + "' WHERE email='" + Session["email"].ToString() + "'";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}


bool CheckNewPwd()
{
	string s_pwd1 = Request.Form["new_pwd"];
	string s_pwd2 = Request.Form["confirm_pwd"];

	return s_pwd1 == s_pwd2;
}

bool GetUserOldPwd()
{



	string s_login = Session["email"].ToString();
	string s_oldpwd = "";
	if(Request.Form["old_pwd"] != null)
		s_oldpwd = Request.Form["old_pwd"];
	else
		return false;

	s_oldpwd = FormsAuthentication.HashPasswordForStoringInConfigFile(s_oldpwd, "md5");
	int rows = 0;

	string sc = "SELECT password FROM card WHERE email='" + s_login + "'";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "pwd");

		if(rows == 1 && dst.Tables["pwd"].Rows[0]["password"].ToString() == s_oldpwd)
		{
			return true;
		}
		else
			return false;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}

void MyPwdTalbe()
{
    string public_change_password_page = ReadSitePage("public_change_password");
    
    //Response.Write("<form action=setpwd.aspx?t=c method=post>");
    //Response.Write("<table width=35% align=center cellspacing=0 cellpadding=1 border=1 bgcolor=#FFFFFF");
    //Response.Write(" bordercolorlight=#888888 bordercolor=#FFFFFF style=\"font-family:Verdana;font-size:8pt;fixed\">\r\n");
    //Response.Write("<tr bgcolor=#EEEEEE><td colspan=2><font color=red><b>Password Change:</b></font></td></tr>\r\n");
    //Response.Write("<tr><td align=right>Your Old Password:&nbsp;&nbsp;&nbsp;</td>");
    //Response.Write("<td>&nbsp;&nbsp;<input type=password name=old_pwd value=''></td></tr>\r\n");
    //Response.Write("<tr><td align=right>New Password:&nbsp;&nbsp;&nbsp;</td>");
    //Response.Write("<td>&nbsp;&nbsp;<input type=password name=new_pwd value=''></td></tr>\r\n");
    //Response.Write("<tr><td align=right>Type New Password again:&nbsp;&nbsp;&nbsp;</td>");
    //Response.Write("<td>&nbsp;&nbsp;<input type=password name=confirm_pwd value=''></td></tr>\r\n");

    //Response.Write("<td colspan=2 align=center><br><br><input type=submit value=Change class=updateAdjustmentButton>&nbsp;&nbsp;");
    //Response.Write("<button onclick=window.location=('Default.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() +"') class=cancelButton2>");
    //Response.Write("Cancel</button><br><br></td></tr>\r\n");


    if(Session["email"] != null){
    	Response.Write(public_change_password_page);
    }else{
    	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=c.aspx\">");
    }
	

	return;
}

</script>

<asp:Label id=LFooter runat=server/>