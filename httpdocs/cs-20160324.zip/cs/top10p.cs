<script runat=server>

DataSet dst = new DataSet();
bool m_bShowTopSeller = false;

/*
void ShowTopProduct() 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	m_bShowTopSeller = MyBooleanParse(GetSiteSettings("show_top_seller_item", "false"));

	string sParse = doQueryTopProduct();

	if(m_bShowTopSeller)
		sParse = sParse.Replace("@@SHOW_TOP_SELLER_ITEM", sParse);
*/
/*	Response.Write("<br><br><center><h3>ezsoft Customer Service</h3>");

	Response.Write("<form action=http://www.eznz.com/ticket.aspx method=post traget=_new>");
	Response.Write("<input type=hidden name=customer value='" + m_sCompanyName + "'>");
//	Response.Write("<input type=hidden name=password value=473987C3D573D88BBF94D16BD4149180>");
	Response.Write("<input type=hidden name=name value='" + Session["name"] + "'>");
	Response.Write("<input type=hidden name=email value='" + Session["email"] + "'>");
	Response.Write("<input type=hidden name=access_level value=" + Session[m_sCompanyName + "access_level"] + ">");

	Response.Write("<input type=submit name=cmd value='View Tickets' " + Session["button_style"] + ">");
	Response.Write("<br><br>");
	Response.Write("<input type=submit name=cmd value='Bug Report' " + Session["button_style"] + ">");
	Response.Write("<br><br>");
	Response.Write("<input type=submit name=cmd value='New Feature Request' " + Session["button_style"] + ">");
	Response.Write("<br><br>");

	Response.Write("</form>");
	PrintAdminFooter();

}
*/
string doQueryTopProduct()
{
	string sc = " SELECT top 10 sum(s.quantity) AS qty, s.code, s.name, s.supplier_code , i.commit_date ";
	
	sc += "FROM sales s JOIN invoice i ON i.invoice_Number = s.invoice_number ";
	sc += " WHERE DATEDIFF(month, i.commit_date, GETDATE()) = 0 ";
	sc += " GROUP BY s.code, s.name, s.supplier_code, i.commit_date ";
	sc += " ORDER BY qty DESC ";
	int rows = 0; 
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst,"top10");
	}
	catch (Exception e) 
	{
		ShowExp(sc,e);
		return "0";
	}

	string s = "";
	s += "<table cellspacing=0 cellpadding=1 border=0 bordercolor=gray bgcolor=transparent";
	s += " style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">";
	for(int i=0; i<rows; i++)
	{
		DataRow dr = dst.Tables["top10"].Rows[i];
		string name = dr["name"].ToString();
		string supplier_code = dr["supplier_code"].ToString();
		string code = dr["code"].ToString();
		string qty = dr["qty"].ToString();
		string uri = "p.aspx?code="+ code +"&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";

	string sname = "";
	if(name.Length >30)
	{
		for(int j=0; j<30; j++)
			sname += name[j].ToString();
		sname += "...";
	}
	
		/*Response.Write("<table cellspacing=0 cellpadding=1 border=1 bordercolor=gray bgcolor=white");
		Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
		Response.Write("<tr><td>");
		Response.Write(""+ (i + 1) +".</td><td><a title='View product "+ name +"' class=o href='" + uri +"'> "+ name +"</a>");
		Response.Write("</td></tr>");
		Response.Write("</table>");
		*/
	
		s += "<tr valign=top><td>";
		s += ""+ (i + 1) +".</td><td><a title='View product "+ name +"' class=o href='" + uri +"'>";
		if(sname != "")
			s += sname; 
		else
			s += name;
		s += "</a>";
		s += "</td></tr>";

	}
	s += "</table>";
//	DEBUG("s =", s);
	return s;


}
</script>
