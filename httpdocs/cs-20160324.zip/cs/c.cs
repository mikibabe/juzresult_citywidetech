<!-- #include file="kit_fun.cs" -->
<!-- #include file="top10p.cs" -->
<!-- #include file="wholemenu.cs" -->

<script runat=server>
//change public site meun and layout 
//22-02-2011
//By LY
//line 1052
//line 1364



DataSet ds = new DataSet();
string mainTitleIndex = "s_cat";
string subTableIndex = "brand";
int rows_return = 0;

string brand = null;
string cat = null;
string s_cat = null;
string ss_cat = null;

//decode "zzzOthers"
string dbrand = null;
string dcat = null;
string ds_cat = null;
string dss_cat = null;

//encoded space
string ebrand = null;
string ecat = null;
string es_cat = null;
string ess_cat = null;

string m_sort = "brand";

//bool m_bCacheEnabled = true; //debug
bool m_bCacheEnabled = false; //debug
bool bShowSpecial = false;
bool m_bAdmin = false;
bool m_bPaging = false;
bool bSayHot = true;
bool m_bAddToCart = false;
bool m_bShowBestSelling = false;
bool m_bShowAddedCartItemOnMain = false;
bool bAlterTableRowColor = false;  //table row color
bool bEnable_Allocated_Stock = false;
bool m_bRoundItemPrice = false;
string scn = "";

int m_nPage = 1;
const int m_nPageSize = 16;

bool bIncludeGST = true;
bool bShowAllStock = true;
bool bOrder = false;

string m_sTopQTY = "10";
string m_sBuyType = "";

double m_levelDiscount = 0;
double m_ld1 = 1.08;
double m_ld2 = 1.04;
int m_qb1 = 2;
int m_qb2 = 5;
int m_qb3 = 10;
int m_qb4 = 50;

int m_nDealerLevel = 1;

bool m_bClearance = false;
bool m_bDiscontinued = false;
bool m_bShowLogo = false;
bool m_bDoAction = false;
string m_action = "";

bool m_bKit = false;
int m_nItemsPerRow = 1;

bool m_bNoPrice = false;

//for search
bool m_bSearching = false;
string keyword = "";
string kw = "";
string kw1 = ""; //first search step;
string kw2 = ""; //2nd search step;
string kw3 = ""; //3rd search step;
string ss = ""; //current search string;

int words = 0; //how many keywords, not include in quotation marks
int uwords = 0; //how many unwanted keywords, not include in quotation marks
string[] kws = new string[64];	//wanted keywords
string[] ukws = new string[64]; //un wanted keywords

bool m_bShowTopCatOnLeftSide = true;
bool m_bSimpleInterface = false; //liveedit settings, if true then ignore price rate and qty breaks, go for p.price
bool m_bFixedPrices = false;
bool m_bStockSayYesNo = false;
bool m_bStockQTYControl = false;
string m_sStockYesString = "YES";
string m_sStockNoString = "NO";
string m_sStockLevelString = "LOW STK";
string m_sAddtoCartString = "Add To Cart";
string[] m_sQTYLevel = new string[3];
int m_nItemListRows = 16;
int siteType = 1;

//siteType = 1 : public site
//siteType = 2 : dealer site
//siteType = 3 : admin site.
bool CatalogInitPage(int st)
{
    siteType = st;
////DEBUG("begin:", DateTime.UtcNow.AddHours(12).ToString());
//	if(g_bRetailVersion)
		TS_PageLoad(); //this is dealer area, check login
//	else
//		TS_Init();

	m_nItemListRows = int.Parse(GetSiteSettings("item_rows_paging", "9"));
	if(m_sSite.ToLower() != "www")
		m_nItemListRows = 9;
	InitKit();
	m_bRoundItemPrice = MyBooleanParse(GetSiteSettings("round_price_no_cent", "0"));

	if(MyBooleanParse(GetSiteSettings("use_fixed_level_prices", "0", true)))
		m_bFixedPrices = true;
//	m_bShowBestSelling = MyBooleanParse(GetSiteSettings("show_top_seller_item", "false"));
	m_bShowAddedCartItemOnMain = MyBooleanParse(GetSiteSettings("show_added_item_on_main", "true"));
	m_sAddtoCartString = GetSiteSettings("site_add_to_cart_string", "Add To Cart", true);
	
	if(g_bRetailVersion)
	{
		if(MyBooleanParse(GetSiteSettings("allocated_stock_public_enabled", "1", true)))
			bEnable_Allocated_Stock = true;
	}
	if(MyBooleanParse(GetSiteSettings("simple_liveedit", "1", true)))
		m_bSimpleInterface = true;

	if(!g_bRetailVersion && m_sSite == "www")
		m_bNoPrice = true;

	if(MyBooleanParse(GetSiteSettings("stock_say_yes_no", "0", false)))
		m_bStockSayYesNo = true;
	if(MyBooleanParse(GetSiteSettings("stock_qty_control_level", "0", false)))
		m_bStockQTYControl = true;

	if(m_bStockQTYControl)
	{	
		m_sQTYLevel[0] = GetSiteSettings("stock_qty_control_low_in_stock", "5", false);
		m_sStockLevelString = GetSiteSettings("stock_qty_control_low_in_stock_string", "LOW STOCK", false);
	}
	if(m_bStockSayYesNo)
	{
		m_sStockYesString = GetSiteSettings("stock_yes_string", "YES");
		m_sStockNoString = GetSiteSettings("stock_no_string", "NO");
	}

	if(Session[m_sCompanyName + "dealer_level"] == null)
		Session[m_sCompanyName + "dealer_level"] = "1";

	if(TS_UserLoggedIn())
		m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "dealer_level"].ToString());

	//stop ordering status, back to normal
	if(Request.QueryString["endorder"] == "1")
	{
		Session[m_sCompanyName + "_ordering"] = null;
		Session[m_sCompanyName + "_salestype"] = null;
		Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?\">");
		return true;
	}
	else if(Request.QueryString["startorder"] == "1")
	{
		Session[m_sCompanyName + "_ordering"] = true;	 
	}
	
	//sales session control
	if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
		m_ssid = Request.QueryString["ssid"];

////DEBUG("m_ssid =", m_ssid);
	if(Request.QueryString["t"] == "clearance")
		m_bClearance = true;
	else if (Request.QueryString["t"] == "discontinued")
		m_bDiscontinued = true;
	else if(Request.QueryString["t"] == "topsales")
		m_bShowBestSelling = true;
////DEBUG("m_bShowBestSelling = ", m_bShowBestSelling);
////DEBUG("m_bShowspecial = ", bShowSpecial);

	string cmd = "";
	if(Request.Form["cmd"] != null)
		cmd = Request.Form["cmd"];

	if(cmd == "Action")
	{
		m_bDoAction = true;
		m_action = Request.Form["action"];
	}
	else if(cmd == "Update Price")
	{
	}
	//else if(cmd == "Add To Cart") m_sAddtoCartString
	else if(cmd.ToLower() == m_sAddtoCartString.ToLower())
	{
		m_bAddToCart = true;
	}

	RememberLastPage();
	PrintHeaderAndMenu("");

	if(Request.QueryString["gst"] == "e")
	{
		Session["display_include_gst"] = "false";
	}
	else if(Request.QueryString["gst"] == "i")
		Session["display_include_gst"] = "true";

	if(Session["display_include_gst"] != null)
	{
		if(Session["display_include_gst"].ToString() == "false")
			bIncludeGST = false;
	}
	else
		Session["display_include_gst"] = "true";

	//sort options
	if(Request.QueryString["sort"] != null)
		m_bCacheEnabled = false; //refresh cache
	if(Request.QueryString["sort"] == "price")
		Session[m_sCompanyName + "_sort"] = "price";
	else if(Request.QueryString["sort"] == "brand")
		Session[m_sCompanyName + "_sort"] = "brand";

	if(Session[m_sCompanyName + "_sort"] != null)
		m_sort = Session[m_sCompanyName + "_sort"].ToString();

	Session["display_show_all_stock"] = "true";
	
	if(Request.QueryString["sas"] == "1")
		Session["display_show_all_stock"] = "true";
	else if(Request.QueryString["sas"] == "0")
		Session["display_show_all_stock"] = null;

	if(Session["display_show_all_stock"] == null)
		bShowAllStock = false;
	else if(Session["display_show_all_stock"].ToString() == "true")
		bShowAllStock = true;

//	if(bShowAllStock)
//		//DEBUG("bShowAllStock=true", "");
//	else
//		//DEBUG("bShowAllStock=false", "");

	if(Request.QueryString["p"] != null)
	{
		string sPage = Request.QueryString["p"];
		if(TSIsDigit(sPage))
			m_nPage = int.Parse(sPage);
	}

	string cn = m_sCompanyName + m_sSite + "_b_" + Request.QueryString["b"] + "_c_" + Request.QueryString["c"] + "_s_" + Request.QueryString["s"] + "_ss_" + Request.QueryString["ss"];
	if(bIncludeGST)
		cn += "_igst";
	if(bShowAllStock)
		cn += "_sas";
	if(Request.QueryString["p"] != null)
	{
		cn += "_p" + m_nPage.ToString();
	}
	scn = cn;

	if(m_bCacheEnabled && m_supplierString == "")
	{
		if(Cache[cn] != null)
		{
			Response.Write(Cache[cn]);
			PrintFooter();
			return true; //cache wrote, should not draw table again
		}
	}

	if(Request.QueryString["b"] == null && Request.QueryString["c"] == null 
		&& Request.QueryString["s"] == null && Request.QueryString["ss"] == null)
	{
		bShowSpecial = true;
	}
	else
	{
		brand = Request.QueryString["b"];
		cat = Request.QueryString["c"];
		s_cat = Request.QueryString["s"];
		ss_cat = Request.QueryString["ss"];

		dbrand = brand;
		dcat = cat;
		ds_cat = s_cat;
		dss_cat = ss_cat;
		if(brand == "zzzOthers")
			dbrand = "";
		if(cat == "zzzOthers")
			dcat = "";
		if(s_cat == "zzzOthers")
			ds_cat = "";
		if(ss_cat == "zzzOthers")
			dss_cat = "";

		ebrand = HttpUtility.UrlEncode(dbrand);
		ecat = HttpUtility.UrlEncode(dcat);
		es_cat = HttpUtility.UrlEncode(ds_cat);
		ess_cat = HttpUtility.UrlEncode(dss_cat);
	}
	
//	if(s_cat != null && ss_cat == null && m_sSite == "admin")
	if(brand == null && s_cat != null && ss_cat == null && m_sSite != "admin")
	{
		m_bShowLogo = true;
	}

	if(cat == m_sKitTerm) //package
	{
		m_bKit = true;
		GetKit();
		return false;
	}

	string sca = "12345"; //try again if no hot product later
	string scb = "12345"; //cut "select " and " hot=1" from sc
	string sWhere = "";
	string sc = "";
	bool bHotOnly = false;

	if(m_bClearance)
	{
		sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.10 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += ", p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		sc += ", c.currency, c.foreign_supplier_price ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
	//	sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
		sc += " FROM product p JOIN code_relations c ON c.code = p.code ";
		sc += " WHERE c.clearance=1 ";
		if(m_sSite != "admin")
			sc += " AND c.is_service = 0 ";
		if(m_supplierString != "")
			sc += " AND p.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY p.brand, p.cat, p.s_cat, p.ss_cat";
		//DEBUG("373=", sc);
	}
	else if(m_bDiscontinued)
	{
		sc = "SELECT c.code, c.name, c.brand, p.price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = c.code), 0) AS  stock ";
		}
		else
			sc += ", p.stock AS stock ";
		sc += ", c.cat, c.s_cat, c.ss_cat, ";
		sc += " c.supplier, c.supplier_code, c.supplier_price, c.clearance, '' AS eta, 0 AS price_dropped ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
//		sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
		sc += " FROM code_relations c JOIN product_skip p ON c.id=p.id ";
		if(m_sSite != "admin")
			sc += " WHERE c.is_service = 0 ";
		else if(m_supplierString != "")
			sc += " WHERE c.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
			}

		}
		sc += "ORDER BY c.brand, c.cat, c.s_cat, c.ss_cat";
		//DEBUG("409=", sc);
	}
	else if(bShowSpecial)
	{
		sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.10 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += " , p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
		//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
		sc += " FROM product p right JOIN specials s ON p.code=s.code ";
		sc += " left JOIN code_relations c ON c.code = p.code ";
		if(m_sSite != "admin")
			sc += " WHERE c.is_service = 0 or c.is_service is null and p.code is not null ";
		else if(m_supplierString != "")
			sc += " WHERE p.supplier IN" + m_supplierString + " ";
        else if(m_sSite == "admin")
            sc += " WHERE p.code is not null ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND p.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND p.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY p.brand, p.cat, p.s_cat, p.ss_cat";
//DEBUG("446=", sc);
	}
	else if(m_bShowBestSelling)
	{
		sc = "SELECT DISTINCT top "+ m_sTopQTY +" p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.10 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += " , p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
		sc += ", (SELECT ISNULL(SUM(quantity), 0)  FROM sales  WHERE code = s.code) AS salesQTY ";
		sc += " FROM product p  ";
		sc += " JOIN code_relations c ON c.code = p.code ";
		sc += " JOIN sales s ON s.code = p.code AND s.code = c.code ";
		sc += " JOIN invoice i ON i.invoice_number = s.invoice_number ";
		sc += " WHERE 1=1 AND (DATEDIFF([month], i.commit_date, GETDATE()) = 0) ";
		if(m_sSite != "admin")
			sc += " AND c.is_service = 0 ";
		else if(m_supplierString != "")
			sc += " AND p.supplier IN" + m_supplierString + " ";
		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				sc += " AND p.s_cat " + Session["cat_access_sql"].ToString();
				sc += " AND p.ss_cat " + Session["cat_access_sql"].ToString();
			}
		}
		sc += "ORDER BY salesQTY DESC ";
	}
	else 
	{
		sc = " TOP 160 p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
		if(bIncludeGST)
			sc += "*1.10 AS price";
		if(g_bRetailVersion)
		{
			sc += ", ISNULL((select sum(qty";
			if(bEnable_Allocated_Stock)
				sc += "-allocated_stock";
			sc += " ) FROM stock_qty WHERE code = p.code), 0) AS  stock ";
		}
		else if(m_bStockSayYesNo)
			sc += ", p.stock AS stock ";
		else
			sc += ", p.stock-p.allocated_stock AS stock ";
		sc += " , p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
		for(int j=1; j<=9; j++)
			sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
		sc += ", c.currency, c.foreign_supplier_price ";
		//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
		sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
		sc += " FROM product p";
		sc += " JOIN code_relations c ON c.code = p.code ";
		sc += " WHERE 1=1 ";
		if(m_sSite != "admin")
			sc += " AND c.is_service = 0 ";
//		else
//			sc += " WHERE ";
		if(!bShowAllStock)
			sc += " AND (p.stock>0 OR p.stock IS NULL) AND ";
		if(brand != null)
		{
			sWhere += " AND p.brand='";
			sWhere += dbrand;
			sWhere += "'";
			mainTitleIndex = "brand";
			subTableIndex = "ss_cat";
		}
		
		if(cat != null)
		{
			//if(sWhere != "")
			//	sWhere += " AND";
			sWhere += " AND p.cat='";
			sWhere += dcat;
			sWhere += "'";
		}

		if(Session["cat_access_sql"] != null)
		{
			if(Session["cat_access_sql"].ToString() != "all")
			{
				string limit = Session["cat_access_sql"].ToString();
				sWhere += " AND (p.brand " + limit;
				if(limit.ToLower().IndexOf("not") >= 0)
					sWhere += " AND ";
				else
					sWhere += " OR ";
				sWhere += " p.s_cat " + limit + " AND p.ss_cat " + limit + ") ";
			}
		}
		
		if(s_cat != null)
		{
		//	if(sWhere != "")
		//		sWhere += " AND";
			sWhere += " AND p.s_cat='";
			sWhere += ds_cat;
			sWhere += "'";
		}
		if(ss_cat != null)
		{
		//	if(sWhere != "")
		//		sWhere += " AND";
			sWhere += " AND p.ss_cat='";
			sWhere += dss_cat;
			sWhere += "'";
		}
//		sWhere += " AND p.cat NOT IN('networking') ";

		scb = sc + sWhere;

		if((ss_cat == null && brand == null && ss_cat != "zzzOthers" && brand != "zzzOthers") 
			|| (s_cat == null && brand != null && s_cat != "zzzOthers" && brand != "zzzOthers"))
		{
			bHotOnly = true;
		//	if(sWhere != "")
		//		sWhere += " AND";
			sWhere += " AND p.hot=1";
		}
		sc += sWhere;
		sc = "SELECT " + sc;
		sca = sc;

		if(m_supplierString != "")
		{
			sc += " AND p.supplier IN" + m_supplierString + " ";
		}
		sc += " ORDER BY p.brand, p.s_cat, p.ss_cat, p.name, p.code";
		//DEBUG(" 593 =", sc);
	}
//DEBUG(" 592sc =", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return true;
	}

	string scWhere = "";
	int cross = 0;

	if(!bShowSpecial && brand == null)// && ss_cat != null)
	{
		sc = "SELECT code FROM cat_cross WHERE";
		if(cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " cat='";
			scWhere += dcat;
			scWhere += "'";
		}
		if(s_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " s_cat='";
			scWhere += ds_cat;
			scWhere += "'";
		}
		if(ss_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " ss_cat='";
			scWhere += dss_cat;
			scWhere += "'";
		}
		sc += scWhere;
		if(scWhere != "")
		{
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				cross = myCommand.Fill(ds, "cross");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}
			if(cross > 0)
			{
				for(int c=0; c<cross; c++)
				{
					string ccode = ds.Tables["cross"].Rows[c]["code"].ToString();
					sc = "SELECT p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
					if(bIncludeGST)
						sc += "*1.10 AS price";
					/*if(m_bStockSayYesNo)
						sc += ", p.stock AS stock ";
					else 
						sc += ", p.stock-p.allocated_stock AS stock ";*/
					if(g_bRetailVersion)
					{
						sc += ", ISNULL((select sum(qty";
						if(bEnable_Allocated_Stock)
							sc += "-allocated_stock";
						sc += ") FROM stock_qty WHERE code = p.code), 0) AS  stock ";
					}
					else if(m_bStockSayYesNo)
						sc += ", p.stock AS stock ";
					else
						sc += ", p.stock-p.allocated_stock AS stock ";
					sc += ", p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
					for(int j=1; j<=9; j++)
						sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
					sc += ", c.currency, c.foreign_supplier_price ";
					//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
					sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight  AS bottom_price ";
					sc += " FROM product p JOIN code_relations c ON c.code = p.code WHERE p.code=" + ccode;
					if(m_sSite != "admin")
						sc += " AND c.is_service = 0 ";
					if(bHotOnly)
						sc += " AND p.hot=1";
					if(m_supplierString != "")
						sc += " AND p.supplier IN" + m_supplierString + " ";
					if(Session["cat_access_sql"] != null)
					{
						if(Session["cat_access_sql"].ToString() != "all")
						{
							sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
							sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
						}
					}
					try
					{
//DEBUG("693sc=", sc);
						SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
						rows_return += myCommand.Fill(ds, "product");
					}
					catch(Exception e) 
					{
						ShowExp(sc, e);
						return true;
					}
				}
			}
		}
		
		//kit cross
		sc = "SELECT code FROM cat_cross_kit WHERE";
		if(cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " cat='";
			scWhere += dcat;
			scWhere += "'";
		}
		if(s_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " s_cat='";
			scWhere += ds_cat;
			scWhere += "'";
		}
		if(ss_cat != null)
		{
			if(scWhere != "")
				scWhere += " AND";
			scWhere += " ss_cat='";
			scWhere += dss_cat;
			scWhere += "'";
		}
		sc += scWhere;

		if(scWhere != "")
		{
			try
			{

				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				cross = myCommand.Fill(ds, "cross_kit");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}

			if(cross > 0)
			{
				for(int c=0; c<cross; c++)
				{
					string ccode = ds.Tables["cross_kit"].Rows[c]["code"].ToString();
					sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
					sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
					sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
					for(int j=1; j<=9; j++)
						sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
					sc += ", price AS bottom_price ";
					sc += ", * FROM kit ";
					sc += " WHERE id = " + ccode;
                    if(Session["cat_access_sql"] != null)
                    {
                        if(Session["cat_access_sql"].ToString() != "all")
                        {
                            sc += " AND s_cat " + Session["cat_access_sql"].ToString();
                            sc += " AND ss_cat " + Session["cat_access_sql"].ToString();
                        }
                    //}else{
                       // sc += " AND s_cat = '"+s_cat+"' " ;
						//sc += " AND ss_cat = '"+ss_cat+"' ";
                    }
					try
					{
//DEBUG("774sc=", sc);
						SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
						rows_return += myCommand.Fill(ds, "product");
					}
					catch(Exception e) 
					{
						ShowExp(sc, e);
						return true;
					}
				}
			}
		}
	
	}
	
	if(rows_return <= 0)
	{

		if(bHotOnly) //try display all
		{
			sc = "SELECT  ";
			sc += scb; //sca.Substring(7, sca.Length-17);
			if(m_supplierString != "")
				sc += " AND supplier IN" + m_supplierString + " ";
			sc += " ORDER BY p.brand, p.s_cat, p.ss_cat, p.name, p.code";
			try
			{
//DEBUG("801sc=", sc);
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				rows_return = myCommand.Fill(ds, "product");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}
			if(rows_return <= 0)
			{
				//for corporate
				if(m_supplierString == "")
					return true;
			}
			bSayHot = false; //don't display word " - hot product"

		}
		else
		{
			//for corporate
			if(m_supplierString == "")
				return false;
			sc = "SELECT TOP 7 ";
			sc += " p.price_age, p.supplier, p.supplier_code, p.supplier_price, p.code, p.name, p.brand, p.price";
			if(bIncludeGST)
				sc += "*1.10 AS price";
			sc += ", p.stock-p.allocated_stock AS stock, p.cat, p.s_cat, p.ss_cat, p.eta, p.price_dropped, c.clearance ";
			for(int j=1; j<=9; j++)
				sc += ", c.level_rate" + j + ", c.qty_break" + j + ", c.qty_break_discount" + j + ", c.price" + j;
			sc += ", c.currency, c.foreign_supplier_price ";
			//sc += ", c.manual_cost_nzd * c.rate AS bottom_price ";
			sc += ", (c.manual_cost_nzd * c.rate) + c.nzd_freight   AS bottom_price ";
			sc += " FROM product p JOIN code_relations c ON c.code = p.code WHERE p.supplier IN " + m_supplierString;
			if(m_sSite != "admin")
				sc += " c.is_service = 0 ";
			if(Session["cat_access_sql"] != null)
			{
				if(Session["cat_access_sql"].ToString() != "all")
				{
					sc += " AND c.s_cat " + Session["cat_access_sql"].ToString();
					sc += " AND c.ss_cat " + Session["cat_access_sql"].ToString();
				}
			}
			sc += " ORDER BY price DESC";
//DEBUG("846sc=", sc);
			try
			{
				SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
				rows_return = myCommand.Fill(ds, "product");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return true;
			}

			if(rows_return <= 0)
				return true;
			bSayHot = false; //don't display word " - hot product"
		}
	}

	if(bShowSpecial)
	{
        GetSpecialKits();
		//GetSpecialKits(s_cat, ss_cat);
	}

	return false;
}

string PrintURI()
{
	StringBuilder sb = new StringBuilder();
	if(brand != null)
		sb.Append("b=" + ebrand + "&");
	if(cat != null)
		sb.Append("c="+ ecat);
	if(s_cat != null)
		sb.Append("&s=" + es_cat);
	if(ss_cat != null)
		sb.Append("&ss=" + ess_cat);
	if(m_ssid != "")
		sb.Append("&ssid=" + m_ssid);
	return sb.ToString();
}

void CatalogDrawList(bool bAdmin) //if bAdmin then draw adminstratrion menu
{

	m_bAdmin = bAdmin;
	StringBuilder sb = new StringBuilder();

	//for search result print
	if(m_bSearching)
	{
		m_bShowLogo = false;
	}
////DEBUG("mbshowlogo =", m_bShowLogo.ToString());
	if(m_bShowLogo)
	{
		string sl = ShowLogo();
		if(sl != "")
		{
			sb.Append("&nbsp;");
			sb.Append(sl);

			sb.Append("</td><tr><tr><td alin=right>");
			sb.Append("<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /> ");
			//sb.Append("<a href=/admin/catlogo.aspx?s=" + es_cat + " class=o>Edit Images</a>");
			//sb.Append("<a href=catlogo.aspx?s=" + es_cat + " class=o>Edit Images</a>");

			sb.Append("</td></tr></table>");
			sb.Append("</td></tr></table>");
			Response.Write(sb.ToString());
			return;
		}
	}
	if(Session[m_sCompanyName + "_ordering"] != null)
		bOrder = true;
	if(Session[m_sCompanyName + "_salestype"] != null)
		m_sBuyType = Session[m_sCompanyName + "_salestype"].ToString();
	if(bOrder)
	{
		//use current customer level for POS
		if(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid] != null)
			m_nDealerLevel = MyIntParse(Session[m_sCompanyName + "sales_dealer_level_for_pos" + m_ssid].ToString());
	}
	if(Request.QueryString.Count <= 0)
	{
		Session[m_sCompanyName + "_ordering"] = null;
		bOrder = false;
	}

	//left side menu
	string sMId = m_sCompanyName + m_sSite + "cache_leftmenu_";
	if(brand != null)
	{
		sMId += "brands_";
		sMId += brand;
	}
	else
	{
		sMId += cat;
		sMId += "_";
		sMId += s_cat;
	}
	sMId = sMId.ToLower();

	string lsm_id = "left_side_menu";
	if(m_sSite == "www")
		lsm_id = "public_left_side_menu";
	string lsm = ReadSitePage(lsm_id);
	if(lsm != "")
	{
		lsm = BlockSysQuote(lsm);
		string kw = "";
		if(Session["search_keyword"] != null)
			kw = Session["search_keyword"].ToString();
		lsm = lsm.Replace("@@search_keyword", kw);
		
		//*** add show best seller items here #12-12-04 tee
		if(m_bShowAddedCartItemOnMain)
			lsm = lsm.Replace("@@SHOW_ITEM_IN_CART", doShowIteminCart());
		else
			lsm = lsm.Replace("@@SHOW_ITEM_IN_CART", "");
		//if(m_bShowBestSelling)
			//lsm = lsm.Replace("@@SHOW_TOP_SELLER_ITEM", doQueryTopProduct());
		//else
			//lsm = lsm.Replace("@@SHOW_TOP_SELLER_ITEM", "");
	
		if(m_bShowTopCatOnLeftSide)
		{
			//lsm = lsm.Replace("@@TOP_CAT_MENU", doQueryCatalog());
		}
		else
			//lsm = lsm.Replace("@@TOP_CAT_MENU", "");

		if(Cache["item_categories"] != null)
			lsm = lsm.Replace("@@HEADER_MENU_TOP_CAT", Cache["item_categories"].ToString());
		else
			lsm = lsm.Replace("@@HEADER_MENU_TOP_CAT", "");

	}

	string tp = ReadSitePage("public_body_item_list");
	if(g_bOrderOnlyVersion)
		tp = ReadSitePage("public_body_item_list_orderonly");
	if(m_bDealerArea || m_sSite == "admin")
		tp = ReadSitePage("body_item_list");
	
    //set navigation bar
    string navigationBar = "<div class='navigationBarHolder' ><a href='default.aspx' > Home </a>";
    string cString = Request.QueryString["c"];
    string bString = Request.QueryString["b"];
    string sString = Request.QueryString["s"];
    string ssString = Request.QueryString["ss"];
    if(cString != null){
        navigationBar += "&nbsp;>>&nbsp; <a href='c.aspx?L=1&c="+cString+"'>"+cString+" </a>";
        if(sString != null){
            navigationBar += "&nbsp;>>&nbsp; <a href='c.aspx?L=2&c="+cString+"&s="+sString+"'>"+sString+"</a>";
            if(ssString != null){
                navigationBar += "&nbsp;>>&nbsp; <a href='c.aspx?L=2&c="+cString+"&s="+sString+"&ss="+ssString+"'>"+ssString+"</a>";
            }
        }
    }else if(bString != null){
        navigationBar += " &nbsp; >> &nbsp; " + bString;
    }else{
        navigationBar += " &nbsp; >> &nbsp; Special";
    }


    navigationBar += "</div>";

    tp = tp.Replace("@@page_nacigation", navigationBar);    

    //delete product when this product not using for current user.
    ProductFilter(ref ds);
    
	//print page index
	//if(ds.Tables["product"] == null || ds.Tables["product"].Rows.Count <= 0)
	//	return;

	int rows = ds.Tables["product"].Rows.Count;

	string slPageFirst = "";
	string slPagePrev = "";
	string slPage = "";
	string slPageNext = "";
	string slPageLast = "";

    string currentPageString = "1";
    int currentPage = 1;
    currentPageString = Request.QueryString["p"];
    int.TryParse(currentPageString, out currentPage);
    if(currentPage < 1){
            currentPage = 1;
    }
	if(rows > m_nItemListRows)
	{
		m_bPaging = true;
		int pages = rows / m_nPageSize + 1;
		if(m_nPage > 1)
		{
			slPageFirst = "<a href='" + WriteURLWithoutPageNumber() + "&p=1' >First</a>";
			slPagePrev = "<a href='" + WriteURLWithoutPageNumber() + "&p=" + (m_nPage-1).ToString() + "' >Prev</a>";
		}
        int pageLoop = 10;
        if(pages < 10){
            pageLoop = pages;
        }
        int p = 1;

        if(currentPage > pageLoop){
            p = currentPage - 5;
            slPage += "...";
        }

		for(;p<=pages; p++)
		{
            if(pageLoop == 0){
                break;
            }
            pageLoop--;
			if(p != m_nPage)
			{
				slPage += "<a href='";
				slPage += WriteURLWithoutPageNumber() + "&p=" + p.ToString();
				slPage += "' > ";
			}
			else{
                slPage += "<font size=+1><b>";
            }
			slPage += p.ToString();
			if(p != m_nPage){
                slPage += " </a>";
            }
			else{
                slPage += "</b></font>";
            }
			slPage += " ";
		}
        if(pages > p){
            slPage += " ...";
        }
		if(m_nPage < pages)
		{
			slPageNext = "<a href='" + WriteURLWithoutPageNumber() + "&p=" + (m_nPage+1).ToString() + "'>Next</a> ";
			slPageLast = "<a href='" + WriteURLWithoutPageNumber() + "&p=" + pages.ToString() +"'>Last</a> ";
		}

		tp = tp.Replace("@@PAGE_LINK_FIRST", slPageFirst);
		tp = tp.Replace("@@PAGE_LINK_PREV", slPagePrev);
		tp = tp.Replace("@@PAGE_LINK_PAGES", slPage);
		tp = tp.Replace("@@PAGE_LINK_NEXT", slPageNext);
		tp = tp.Replace("@@PAGE_LINK_LAST", slPageLast);
	}else {
        tp = tp.Replace("@@PAGE_LINK_FIRST", "");
		tp = tp.Replace("@@PAGE_LINK_PREV", "");
		tp = tp.Replace("@@PAGE_LINK_PAGES", "");
		tp = tp.Replace("@@PAGE_LINK_NEXT", "");
		tp = tp.Replace("@@PAGE_LINK_LAST", "");
	}

	//parse conditions, IF_SPECIAL, IF_PURCHASE etc.
	tp = TemplateParseCommand(tp);
	if(m_bShowAddedCartItemOnMain)
		tp = tp.Replace("@@SHOW_ITEM_IN_CART", doShowIteminCart());
	else
		tp = tp.Replace("@@SHOW_ITEM_IN_CART", "");
	bool bHasGroup = true;
	string tp_group = GetRowTemplate(ref tp, "itemgroup");
	string tp_row = GetRowTemplate(ref tp_group, "itemrow");
	if(tp_group == "")
	{
		bHasGroup = false;
		tp_group = GetRowTemplate(ref tp, "itemrow");
		tp_row = tp_group;
	}
	string tp_item = GetRowTemplate(ref tp_row, "rowitem");
//	if(tp.IndexOf("@@SUB_SUB_MENU") >= 0)
//		tp = tp.Replace("@@LEFT_SIDE_MENU", lsm);
	string ssmenu = "";
	if(Cache[sMId] != null)
	{
		ssmenu = Cache[sMId].ToString();
		ssmenu = ssmenu.Replace("@@ssid", m_ssid);
	}

	if(m_bSearching)
		ssmenu = "";

	ssmenu += lsm;
	
	if(tp.IndexOf("@@SUB_SUB_MENU") >= 0)
		tp = tp.Replace("@@SUB_SUB_MENU", ssmenu);
	else
		tp = tp.Replace("@@LEFT_SIDE_MENU", ssmenu);

	string sout = tp;
	
    //if(Cache["item_categories"] != null)
		
    //    //--show public new menu
    //    //sout = sout.Replace("@@HEADER_MENU_TOP_CAT", Cache["item_categories"].ToString());
    //else
        //--show public new menu
		//sout = sout.Replace("@@HEADER_MENU_TOP_CAT", "");
	
	// title and title_desc
	string title = "";
	if(bShowSpecial)
	{
		if(m_supplierString == "")
		{
			if(m_bClearance)
				title = "Clearance Center";
			else if(m_bDiscontinued)
				title = "Discontinued Items";
			else
				title = "Today's Specials";
		}
		else
			title = m_sCompanyTitle;
	}
	else
	{

		if(ds.Tables["product"].Rows.Count > 0){
            title = ds.Tables["product"].Rows[0][mainTitleIndex].ToString();
        }
			
	}

	string title_desc = "";
	if(!bShowSpecial && ds.Tables["product"].Rows.Count > 0)
	{
		if(brand != null)
		{
			if(s_cat == null)
			{
//				if(bSayHot)
//					title_desc = " - New Products";
			}
//			else if(s_cat == "zzzOthers")
//				title_desc = " - All Others";
			else
				title_desc = " - " + s_cat;
		}
		else
		{
			if(s_cat == "zzzOthers")
			{
				title = " + cat + ";
				title_desc = " - All Others";
			}
			else
			{
				if(ss_cat == null)
				{
//					if(bSayHot)
//						title_desc = " - New Products";
				}
//				else if(ss_cat == "zzzOthers")
//					title_desc = " - All Others";
				else
					title_desc = " - " + ss_cat + "";
			}
		}
	}

	if(m_bSearching)
	{
		title = "<b>Search Result for : " + keyword + "</b>";
		title_desc = "";
	}

	sout = sout.Replace("@@ITEM_LIST_TITLE_DESC", title_desc);
	sout = sout.Replace("@@ITEM_LIST_TITLE", title);

	string form_action = "?" + Request.ServerVariables["QUERY_STRING"];
	sout = sout.Replace("@@ITEM_LIST_FORM_ACTION", form_action);

	//function buttons

	string fun_buttons = "";
	if(m_sSite == "admin" && !m_bDiscontinued && bOrder)
	{
		fun_buttons = PrintFunctionButtons();
	}
	sout = sout.Replace("@@ITEM_LIST_FUNCTION_BUTTONS", fun_buttons);

	//start group
	string groups = "";

	Boolean bAlterColor = false;
	DataRow dr = null;
	string sti = "";
	string stiOld = "-1"; //in case there's a blank subTableIndex
	string code = "";
	int i = 0;
	string bgColor = "white";
	
	string sSel = "brand, s_cat, ss_cat, name, code"; 
	if(m_sort != "brand")
		sSel = m_sort + ", brand, s_cat, ss_cat, name, code"; 
	DataRow[] drs = ds.Tables["product"].Select("", sSel);

	string sFontColor = "red";
	string slSort = "";
	string sSortName = "";
	string slShowRoom = "";

//	if(!bShowSpecial && brand == null)
	{
		sSortName = "brand";
		if(m_sort == "brand")
			sSortName = "price";
		//slSort = "?r=" + PrintURI() + "&sort=" + sSortName; // + ">Click here to sort by " + sort + "</a>");
		slSort = "?" + PrintURI() + "&sort=" + sSortName; // + ">Click here to sort by " + sort + "</a>");
	}
	slShowRoom = "sroom.aspx?" + PrintURI();

	if(m_bSearching)
		slShowRoom = "";

	bool bFixLevel6 = MyBooleanParse(GetSiteSettings("level_6_no_qty_discount", "0"));
	bool bAddBookMark = true;
	bool bAddSort = true;
	bool bClearance = false;
	int	nBookMarkCount = 0;
	int nStart = (m_nPage - 1) * m_nPageSize;
	int nEnd = nStart + m_nPageSize;
	i = nStart;
	
	//finals
	StringBuilder sbGroups = new StringBuilder();
	StringBuilder sbRows = new StringBuilder();
	StringBuilder sbItems = new StringBuilder();

	//template
	string sgroup = tp_group;
	string srow = tp_row;
	string sitem = tp_item;

	//count
	int items_added = 0; //if greater than m_nItemsPerRow than add the row and reset this counter to zero

	bool bGroupEmpty = true;
	bool bFirstGroup = true;
//DEBUG("1301CcurrentPage=", currentPage);
//DEBUG("1301Cm_nItemListRows=", m_nItemListRows);
//DEBUG("1301Crows=", rows);
    int showRowStart = (currentPage * m_nItemListRows) - m_nItemListRows;
    int showRowEnd = (currentPage * m_nItemListRows) - 1;
    if(rows < showRowEnd){
        showRowEnd = rows - 1;
    }
    i = showRowStart;


	//while(i<rows && i < nEnd)
//DEBUG("1301CshowRowStart=", showRowStart);
//DEBUG("1301CshowRowEnd=", showRowEnd);
    while(showRowStart <= i && i <= showRowEnd)
	{//end 1851
//DEBUG("1305C=", subTableIndex);
		try{
            sti = drs[i][subTableIndex].ToString(); //sti: subTableIndex
        }catch(Exception ex){
            break;
        }
		Trim(ref sti);
		
		if(bHasGroup && stiOld.ToLower() != sti.ToLower() && !bShowSpecial && !m_bSearching)
		{
			if(!bGroupEmpty) //add group
			{
				if(items_added > 0) //finish current row if any item already added
				{
					srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
					sbRows.Append(srow); //add row to rows
					srow = tp_row; //reset row template, prepare next row
				
					sbItems.Remove(0, sbItems.Length); //empty items content
					items_added = 0; //reset counter
				}

				sgroup = sgroup.Replace("@@template_itemrow", sbRows.ToString()); //add group
				sgroup = RowParseCommand(sgroup, bFirstGroup); //remove show room link if not first group
				if(bFirstGroup)
				{
					sgroup = sgroup.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
					sgroup = sgroup.Replace("@@ITEM_LIST_SORT_LINK", slSort);
					sgroup = sgroup.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
					bFirstGroup = false;
				}

				string bookMark = "";
				if(bAddBookMark)
					bookMark = stiOld + "_a";

				sgroup = sgroup.Replace("@@ITEM_GROUP_TAG", bookMark);
				sgroup = sgroup.Replace("@@ITEM_GROUP_TITLE", stiOld);

				sbGroups.Append(sgroup); //add group
				sbRows.Remove(0, sbRows.Length); //reset rows content, prepare next row
				sgroup = tp_group; //reset group template
			}

			//begin a new group
			bGroupEmpty = false;

			bAlterColor = false;
		}
		
		if(!bAddBookMark)
		{
			nBookMarkCount++;
			if(nBookMarkCount > 10)
			{
				nBookMarkCount = 0;
				bAddBookMark = true;
			}
		}

		stiOld = sti;
		dr = drs[i];
		code = dr["code"].ToString();

		bool bKit = false;
		if(dr["cat"].ToString() == GetSiteSettings("package_bundle_kit_name", "Kit", true)){
            m_bKit = true;
        }else{
            m_bKit = false;
        }
////DEBUG("1267Cat=", m_sKitTerm );
		if(m_bDoAction)
		{
			if(Request.Form["sel" + code] == "on")
			{
				if(DoAction(code))
				{
					if(m_action == "Phase Out")
					{
						i++;
						continue; //already phased out, don't display
					}
				}
			}
		}

//		if(!bShowSpecial)
		{
//			if(bAlterColor && TS_UserLoggedIn())
//				bgColor = "@@color_12";
//			else
			if(bAlterColor)
				bgColor = "@@color_12";
			else
				bgColor = "@@color_11";
			bAlterColor = !bAlterColor;
//		//DEBUG("alter color =", bAlterColor.ToString());
		}

		srow = srow.Replace("@@ITEM_ROW_BGCOLOR", bgColor);

		bClearance = MyBooleanParse(dr["clearance"].ToString());

		//first column is blank, show product pic for special page
		string src = GetProductImgSrc(code);
		if(m_bKit)
		{
			src = GetKitImgSrc(code);
		}
        //src = src.Replace("na.gif", "0.gif");

		sitem = sitem.Replace("@@ITEM_PIC_LINK", src);
		
		string sdcode = code;
        
		if(m_bKit || bKit)
			sitem = sitem.Replace("@@ADDTOCART_LINK", "cart.aspx?id="+sdcode +"&t=b");
		else
			sitem = sitem.Replace("@@ADDTOCART_LINK", "cart.aspx?c="+sdcode +"&t=b");
		string m_pn = dr["supplier_code"].ToString();
		string sItemName = dr["name"].ToString();

		if(m_bKit || bKit)
			sdcode = m_sKitTerm + " " + code;
		if(m_bSearching)
		{
			sdcode = ShowKeywords(sdcode);
			m_pn = ShowKeywords(m_pn);
			sItemName = ShowKeywords(sItemName);
		}
	//	bAlterTableRowColor = !bAlterTableRowColor;

		sitem = sitem.Replace("@@ITEM_CODE", sdcode);
		sitem = sitem.Replace("@@ITEM_MPN", m_pn);
	//product detail pages
        string blurb = sDoGetProductHightLight(ref code, "highlight");
        if(blurb.Length > 30){
            blurb = blurb.Substring(0, 30) + "...";
        }
        
        sitem = sitem.Replace("@@ITEM_BLURB", blurb);

		//recently price dropped
		string sRPD = "";
		sb.Append("<td>");
		if(dr["price_dropped"].ToString() != "0")
		{
			if(CheckPriceDate(code, dr["price_age"].ToString()))
			{
				if(dr["price_dropped"].ToString() == "1")
					sRPD = "<img src=pd.gif title='Recently Price Dropped'>";
				else
					sRPD = "<img src=pu.gif title='Recently Price Raise'>";
			}
		}
		sitem = sitem.Replace("@@RECENT_PRICE_CHANGE_IMG", sRPD);
	
		//Description
		string sItemLink = "p.aspx?" + code;

		sitem = sitem.Replace("@@ITEM_LINK", sItemLink);
        //change number of chart of product name..
        string sItemName2 = "";
        if(sItemName.Length > 20){
                sItemName2 = sItemName;
                sItemName = sItemName.Substring(0, 20) + "..";
        }
       //if(m_bKit || bKit) //kit
       // {
       //     sItemLink = "pk.aspx?" + code + "&ssid=" + m_ssid;
       //     if(MyBooleanParse(dr["inactive"].ToString()))
       //         sItemName += "<font color=red><b><i>( * Inactive. Edit Only)</i></b></font>";
       // }

		if(bClearance)
			sItemName += " <font color=" + sFontColor + ">(*Clearance*) </font>";

        //sItemName2 = HttpUtility.HtmlEncode(sItemName);
        //sItemName2 = HttpUtility.HtmlEncode(sItemName2);
         sItemName = sItemName.Replace("<b>", "");
         sItemName = sItemName.Replace("</b>", "");
        // sItemName = sItemName.Replace("/", "%2F");
		sitem = sitem.Replace("@@ITEM_NAME", Server.HtmlEncode(sItemName));
        sItemName2 = sItemName2.Replace("<b>", "");
        sItemName2 = sItemName2.Replace("</b>", "");
        // sItemName2 = sItemName2.Replace("/", "%2F");
        sitem = sitem.Replace("@@ITEM2_NAME", sItemName2);
        
        sitem = sitem.Replace("@@ITEM2_DESC@@", sItemName);
//		if(srow.IndexOf("@@ITEM_HIGHLIGHT") >= 0)
		{
			string highlight = "";
			double dRRP = 0;
			DataRow drp = null;
            double show_price = 0;
            int show_level = 1;
			if(GetProduct(code, ref drp))
			{
				highlight = drp["highlight"].ToString();
				if(highlight.Length > 255)
					highlight = highlight.Substring(0, 255);
				dRRP = MyDoubleParse(drp["rrp"].ToString());
				if(dRRP == 0)
					dRRP = MyDoubleParse(drp["manual_cost_nzd"].ToString()) * MyDoubleParse(drp["rate"].ToString()) * MyDoubleParse(drp["level_rate1"].ToString()) * 1.1;
		        
                try{
                    string showPriceString = drp["show_price"].ToString();
                    double.TryParse(showPriceString, out show_price);
                }catch(Exception ex){
                    show_price = 0;
                }
                try{
                    string showLevelString = drp["show_level"].ToString();
                    int.TryParse(showLevelString, out show_level);
                }catch(Exception ex){
                    show_level = 1;
                }
            }else{
                    //may kit
                dRRP = MyDoubleParse(dr["bottom_price"].ToString()) ; //this is p.price
            }
            
            if(siteType == 1){
                //dRRP = dRRP * ( 1 + MyDoubleParse(GetSiteSettings("gst_rate_percent", "10")) / 100);
            }else if(siteType == 2){

            }else if(siteType == 3){
                
            }
            
			sitem = sitem.Replace("@@ITEM_HIGHLIGHT", highlight);

		//if(m_bKit || bKit){
        //       dRRP = MyDoubleParse(dr["price"].ToString()) * ( 1 + MyDoubleParse(GetSiteSettings("gst_rate_percent", "15")) / 100); //this is p.price

       // } //kit price
////DEBUG("price=", dr["price"].ToString());			
        ////DEBUG("1394drrp =", (m_bKit || bKit) .ToString());	
        if(show_price == 0){
            sitem = sitem.Replace("@@show_price", "");
            sitem = sitem.Replace("@@CSS_SHOW_SPECIAL_IMAGE", "home-product-list-show-special-image-none");
            sitem = sitem.Replace("@@CSS_RRP_PRICE", "home-product-list-rrp");
        }else{
            sitem = sitem.Replace("@@show_price", show_price.ToString("c"));
            sitem = sitem.Replace("@@CSS_SHOW_SPECIAL_IMAGE", "home-product-list-show-special-image");
            sitem = sitem.Replace("@@CSS_RRP_PRICE", "home-product-list-rrp-right");
        }
        
		sitem = sitem.Replace("@@ITEM_PRICE_RRP", dRRP.ToString("c"));

		if(m_bRoundItemPrice)
			dRRP = Math.Round(dRRP, 0);
		}

		string item_supplier = "";
		string item_supplier_price = "";
//		if(TS_UserLoggedIn() && !m_bDiscontinued)
//		if(!m_bDiscontinued)
		{
			//supplier info
			string supplier = dr["supplier"].ToString();
			string supplier_code = dr["supplier_code"].ToString();
			string foreignCost = dr["foreign_supplier_price"].ToString();
			double dForeignCost = MyDoubleParse(dr["supplier_price"].ToString());
			if(foreignCost != "")
				dForeignCost = MyDoubleParse(foreignCost);

//			if(bOrder && m_sBuyType == "purchase")
			{
				item_supplier = supplier;
				string cur = GetEnumValue("currency", dr["currency"].ToString()).ToUpper();
				if(cur.Length > 2)
					cur = cur.Substring(0, 2);
				item_supplier_price = cur + dForeignCost.ToString("c");
			}

			int dls = int.Parse(GetSiteSettings("dealer_levels", "6")); // how many quantity breaks
			if(dls > 9)
				dls = 9;
			int qbs = int.Parse(GetSiteSettings("quantity_breaks", "3")); // how many quantity breaks
			if(qbs > 9)
				qbs = 9;

			double[] lr = new double[9];
			int[] qb = new int[9]; //qty breaks;
			double[] qbd = new double[9];
			double[] dprice = new double[9];

			int j = 0;
			for(j=0; j<dls; j++)
			{
				string jj = (j+1).ToString();
				lr[j] = 2;
				if(dr["level_rate" + jj].ToString() != "")
					lr[j] = double.Parse(dr["level_rate" + jj].ToString());
			}
			for(j=0; j<qbs; j++)
			{
				string jj = (j+1).ToString();
				qb[j] = 1;
				if(dr["qty_break" + jj].ToString() != "")
					qb[j] = int.Parse(dr["qty_break" + jj].ToString());

				qbd[j] = 1;
				if(dr["qty_break_discount" + jj].ToString() != "")
					qbd[j] = double.Parse(dr["qty_break_discount" + jj].ToString());
			}

			double dQtyDiscount = 0;
			double dDiscount = 0;

			string card_id = "";
			int nLevel = 1;
			if(Session["card_id"] != null)
				card_id = Session["card_id"].ToString();
			if(bOrder)
			{
				card_id = "0";
				//use current customer level for POS
				if(Session[m_sCompanyName + "_dealer_card_id" + m_ssid] != null)
					card_id = Session[m_sCompanyName + "_dealer_card_id" + m_ssid].ToString();
			}
////DEBUG("card_id=", card_id);
			if(card_id != "" && card_id != "0")
			{
				string sBrand = brand;
				if(sBrand == null || sBrand == "")
					sBrand = dr["brand"].ToString();
				nLevel = GetDealerLevelForCat(card_id, sBrand, cat + " - " + s_cat, m_nDealerLevel);
	//	//DEBUG("nsle = ", nLevel);
			}
			
////DEBUG("nLevel=", nLevel);
//			double level_rate = lr[m_nDealerLevel - 1];
			double level_rate = lr[nLevel - 1];
//			double dPrice = double.Parse(dr["price"].ToString());
			double dPrice = MyDoubleParse(dr["bottom_price"].ToString());
//DEBUG("=========code=", code);
//DEBUG("1629 dPrice=", dPrice);
			double dNormalPrice = dPrice * lr[0];
			if(!bClearance)
				dPrice *= level_rate;
//DEBUG("1663 dPrice=", dPrice);
            if(m_bSimpleInterface)
	            dPrice = MyDoubleParse(dr["price"].ToString()); //this is p.price

            if(m_bFixedPrices)
	            dPrice = MyDoubleParse(dr["price" + nLevel].ToString());
//DEBUG("1639 dPrice=", dPrice);
//	dPrice = MyDoubleParse(dr["price" + m_nDealerLevel].ToString());
			double dPriceOnePiece = dPrice; //price without qty discount
////DEBUG("dpric e= ", dPrice);
////DEBUG("normalspri c= ", dNormalPrice);
			//calculate price and discount on qty
			string qty = "0";
			if(Request.Form["qty" + i] != null)
				qty = Request.Form["qty" + i];
			int dqty = MyIntParse(qty);
			dDiscount = 0;
			if(dqty != 0)
			{
				if(dqty < 0 && !bAdmin)
				{
					//negative qty is not allowed to public user!
					Response.Write("<script Language=javascript");
					Response.Write(">");
					Response.Write("window.alert ('Error. Quantity cannot be negative !')");
					Response.Write("</script");
					Response.Write(">");
					qty = "0";
				}
				else
				{
					//get qty discount
					dQtyDiscount = GetQtyDiscount(dqty, qb, qbd);
					if(bFixLevel6 && m_nDealerLevel >= 6)
						dQtyDiscount = 0;
					if(!bClearance)
					{
						dPrice *= (1 - dQtyDiscount);
//DEBUG("1671 dPrice=", dPrice);
						dDiscount = dQtyDiscount;
					}
					if(m_bAddToCart)
					{
						if(m_bKit || bKit)
						{
							if(bAdmin)
							{
								DoAddKit(code, dqty, "", bAdmin);
								dPrice = dPriceOnePiece;
//DEBUG("1681 dPrice=", dPrice);
                                dDiscount = 0;
                                dqty = 0;
                                qty = "0";
							}
							else
							{
								DoAddKit(code, dqty);
								dPrice = dPriceOnePiece;
//DEBUG("1691 dPrice=", dPrice);
                                dDiscount = 0;
                                dqty = 0;
                                qty = "0";		
								if(Session["c_editing_order" + m_ssid] != null)
								{
									Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=corder.aspx?ssid=" + m_ssid + "\">");
									return;
								}
							}
						}
						else
						{
							if(bAdmin)
							{
								//admin edit
								if(m_sBuyType == "purchase")
									AddToCart(code, supplier, supplier_code, qty, dForeignCost.ToString());
								else
									AddToCart(code, qty, dPrice.ToString());
								dPrice = dPriceOnePiece;
//DEBUG("1712 dPrice=", dPrice);
								dDiscount = 0;
								dqty = 0;
								qty = "0";
							}
							else
							{
								AddToCart(code, qty, dPrice.ToString());
								dPrice = dPriceOnePiece;
//DEBUG("1721 dPrice=", dPrice);
                                dDiscount = 0;
                                dqty = 0;
                                qty = "0";		
								if(Session["c_editing_order" + m_ssid] != null)
								{
									Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=corder.aspx?ssid=" + m_ssid + "\">");
									return;
								}
							}
						}
					}
				}
			}

			if(m_bRoundItemPrice)
					dPrice = Math.Round(dPrice,0);
//DEBUG("1738 dPrice=", dPrice);
            if(dNormalPrice != 0)     //dive by 0 got error
			    dDiscount = Math.Round((dNormalPrice - dPrice)/dNormalPrice, 4);

            if(m_bKit || bKit){
            //if(m_bKit || bKit && Session["card_id"] != null){
                if(Session["card_id"] != null){
                        dPrice = GetSalesKitPriceForDealer(code,"1",m_nDealerLevel.ToString(),Session["card_id"].ToString());
                        dForeignCost = GetSalesKitPriceForDealer(code,"1",m_nDealerLevel.ToString(),Session["card_id"].ToString());
//DEBUG("1747 dPrice=", dPrice);
                }
            }

//			if(bOrder && m_sBuyType == "purchase")
			{
				sitem = sitem.Replace("@@ITEM_SUPPLIER", item_supplier);
				//sitem = sitem.Replace("@@ITEM_COST", item_supplier_price);
                if(m_sBuyType == "purchase"){
                    if(dForeignCost == 0){
                        sitem = sitem.Replace("@@ITEM_COST", dPrice.ToString("c"));
                    }else{
                        sitem = sitem.Replace("@@ITEM_COST", dForeignCost.ToString("c"));
                    }
                }else{
                        sitem = sitem.Replace("@@ITEM_COST",  dPrice.ToString("c"));
                }
                
			}

			string sstock = dr["stock"].ToString();

			if(m_bStockSayYesNo && m_sSite.ToLower() != "admin" )
			{
				if(m_bStockQTYControl)
				{
					if(MyIntParse(sstock) <= 0 )
						sstock = m_sStockNoString;
					else if(MyIntParse(sstock) > MyIntParse(m_sQTYLevel[0]))
						sstock = m_sStockYesString;
					else if(MyIntParse(sstock)> 0 || MyIntParse(sstock) <= MyIntParse(m_sQTYLevel[0]))
						sstock = m_sStockLevelString;
				}
				else
				{
					if(MyIntParse(sstock) <= 0)
						sstock = m_sStockNoString;
					else 
						sstock = m_sStockYesString;
				}
			}
			string seta = dr["eta"].ToString();
			string sDiscountInfo = "";
			string sprice = "";

			if(m_bDiscontinued)
			{
				sstock = "&nbsp;";
				seta = "&nbsp;";
				sDiscountInfo = "&nbsp;";
			}

			//Stock
			sitem = sitem.Replace("@@ITEM_STOCK", sstock);

			//ETA
			sitem = sitem.Replace("@@ITEM_ETA", seta);

			//discount
//			if(m_sBuyType != "purchase")
			{
				sDiscountInfo += dDiscount.ToString("p");
				if(qbs > 0)
				{
					sDiscountInfo += " (";
					for(j=0; j<qbs; j++)
					{
						if(j != 0)
							sDiscountInfo += ",";
						sDiscountInfo += qb[j]; 
					}
					sDiscountInfo += ") ";
				}
			}
			if(m_bDiscontinued)
			{
				sDiscountInfo = "&nbsp;";
				qty = "0";
			}

			sitem = sitem.Replace("@@ITEM_DISCOUNT", sDiscountInfo );

			//qty
			sitem = sitem.Replace("@@ITEM_FIELD_NAME_QTY", "qty" + i.ToString());
			sitem = sitem.Replace("@@ITEM_FIELD_VALUE_QTY", qty);

//			if(m_sBuyType != "purchase")
			{
				//price
//				if(m_sSite == "admin")
				{
					sb.Append("<td align=right>");
					if(dqty > 1 && !bClearance)
						sprice = "<font color=" + sFontColor + "><b>";
					sprice += dPrice.ToString("c");
					if(dqty > 1 && !bClearance)
						sprice += "</b></font>";
				}
			}

			if(m_bNoPrice || m_bDiscontinued)
				sprice = "&nbsp;";
		
////DEBUG(" spric e= ", sprice);
            if(m_bKit || bKit){
                //if(m_bKit || bKit && Session["card_id"] != null){
                if(Session["card_id"] != null){
                        sprice = GetSalesKitPriceForDealer(code,"1",m_nDealerLevel.ToString(),Session["card_id"].ToString()).ToString("c");
                }
               //sprice = m_nDealerLevel.ToString();
            }
			sitem = sitem.Replace("@@ITEM_PRICE", sprice );

			string slEdit = "";
			string slActionSel = "";
			string slBuyButton = "";
            string hiddenButton = "";
			if(bAdmin && !bOrder)
			{
				//admin edit
				if(m_bKit || bKit) //kit
					slEdit += "kit.aspx?id=";
				else
					slEdit += "liveedit.aspx?code=";
				slEdit += code;
				slActionSel += "<input type=checkbox name=sel" + code + ">";
			}
			else
			{
				slEdit = "javascript:alert_window=window.alert('Product Edit Not Allow While in Sale Mode');window.close();";
                hiddenButton = "display:none;";
			}
			if(m_sSite.ToLower() != "admin")
			{
				if(m_bKit || bKit)
					slBuyButton = "<a title='view to buy this kit' href=pk.aspx?"+ code +"&ssid=" + m_ssid + " class=o><img title='view package details to purchase' border=0 src='i/view.gif'></a>";
				else
					slBuyButton = "<a href=cart.aspx?t=b&c="+ code +"><img title='buy this item' border=0 src='i/cart3.gif'></a>";
			}
			sitem = sitem.Replace("@@PUBLIC_BUY_LINK", slBuyButton);

			sitem = sitem.Replace("@@ITEM_EDIT_LINK", slEdit);
            sitem = sitem.Replace("@@hiddenButton@@", hiddenButton);
			sitem = sitem.Replace("@@ACTION_SELECT", slActionSel);
		}
		sb.Append("</tr>\r\n");

		//one item added
		items_added++;
		sbItems.Append(sitem); //add to row
		sitem = tp_item; //reset item template, prepare next item
		if(items_added >= m_nItemsPerRow) //row ready
		{
			srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
			sbRows.Append(srow); //add row to rows
			srow = tp_row; //reset row template, prepare next row
			
			sbItems.Remove(0, sbItems.Length); //empty items content
			items_added = 0; //reset counter
		}

		i++;
		sitem = tp_item; //new item
		//end subTable
	}

	if(items_added > 0) //item left behind
	{
		srow = srow.Replace("@@template_rowitem", sbItems.ToString()); //finalize this row
		sbRows.Append(srow); //add row to rows
	}

	if(bHasGroup && sbRows.Length > 0) //row behinde
	{
		sgroup = sgroup.Replace("@@template_itemrow", sbRows.ToString()); //add group
		sgroup = RowParseCommand(sgroup, bFirstGroup); //remove show room link if not first group
		if(bFirstGroup)
		{
			sgroup = sgroup.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
			sgroup = sgroup.Replace("@@ITEM_LIST_SORT_LINK", slSort);
			sgroup = sgroup.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
			bFirstGroup = false;
		}

		string bookMark = sti + "_a";

		if(bAddBookMark)
			bookMark = sti + "_a";

		sgroup = sgroup.Replace("@@ITEM_GROUP_TAG", bookMark);
		sgroup = sgroup.Replace("@@ITEM_GROUP_TITLE", sti);

		sbGroups.Append(sgroup); //add group
	}

	if(bHasGroup)
		sout = sout.Replace("@@template_itemgroup", sbGroups.ToString());
	else
		sout = sout.Replace("@@template_itemrow", sbRows.ToString());

	sout = sout.Replace("@@ITEM_LIST_SHOWROOM_LINK", slShowRoom);
	sout = sout.Replace("@@ITEM_LIST_SORT_LINK", slSort);
	sout = sout.Replace("@@ITEM_LIST_SORT_NAME", sSortName);
	sout = sout.Replace("@@ssid_value", m_ssid);
	sout = sout.Replace("@@date_now", DateTime.UtcNow.AddHours(12).ToString("D"));

//	if(m_bSearching)
//		sout = sout.Replace("Show Room", "");
	sout = ApplyColor(sout);
	Response.Write(sout);
	return;

	//end product list
	TSAddCache(scn, sb.ToString());
	Response.Write(sb.ToString());
}

string WriteURLWithoutPageNumber()
{
	StringBuilder sb = new StringBuilder();
	sb.Append(Request.Url.AbsolutePath);
	sb.Append("?");
	if(brand != null)
		sb.Append("b=" + ebrand + "&");
	if(cat != null)
		sb.Append("c="+ ecat);
	if(s_cat != null)
		sb.Append("&s=" + es_cat);
	if(ss_cat != null)
		sb.Append("&ss=" + ess_cat);
	if(m_ssid != "")
		sb.Append("&ssid=" + m_ssid);
    if(Request.QueryString["kw"] != null)
        sb.Append("&kw=" + Request.QueryString["kw"]);
    if(Request.QueryString["search"] != null)
        sb.Append("&search=" + Request.QueryString["search"]);
	return sb.ToString();
}

string AppendParameter(string brand, string s_cat, string ss_cat, 
					   string ebrand, string ecat, string es_cat, string ess_cat, string text)
{
	StringBuilder sb = new StringBuilder();
	if(brand != null)
	{
		sb.Append("b=");
		sb.Append(ebrand);
	}
	else
	{
		sb.Append("c=");
		sb.Append(ecat);
	}
	if(s_cat != null)
	{
		sb.Append("&s=");
		sb.Append(es_cat);
	}
	if(ss_cat != null)
	{
		sb.Append("&ss=");
		sb.Append(ess_cat);
	}
	sb.Append("&r=" + DateTime.UtcNow.AddHours(12).ToOADate());
	sb.Append(" target=_blank>");
	sb.Append(text);
	sb.Append("</a>");
	return sb.ToString();
}

bool CheckPriceDate(string code, string age)
{
////DEBUG("2010=", age);
	DateTime dAge = DateTime.Parse(age);
	if( (DateTime.UtcNow.AddHours(12) - dAge).Days > 7)
		return false;
	return true;
}

string ShowLogo()
{
	string sc = " SELECT * FROM cat_logo ";
	sc += " WHERE s_cat = '" + EncodeQuote(s_cat) + "' ";
	sc += " ORDER by seq ";
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(ds, "logo") <= 0)
			return "";
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}

	StringBuilder sb = new StringBuilder();

	int columns = MyIntParse(GetSiteSettings("sub_cat_image_table_columns", "3"));
	if(columns > 30)
		columns = 30; //for protection

	int n = 0;
	sb.Append("<table cellspacing=10 cellpadding=10 border=0>");
	for(int i=0; i<ds.Tables["logo"].Rows.Count; i++)
	{
		DataRow dr = ds.Tables["logo"].Rows[i];
		string pic_name = dr["pic_name"].ToString();
		string uri = dr["uri"].ToString();
		int nColspan = MyIntParse(dr["colspan"].ToString());
		string title = dr["title"].ToString();
		if(n == 0)
		{
			if(i > 0)
				sb.Append("</tr>");
			sb.Append("<tr>");
		}

		if(nColspan > columns - n) //no enough columns
		{
			for(int m=columns-n; m>0; m--)
				sb.Append("<td>&nbsp;</td>");
			sb.Append("</tr><tr>");
			n = 0;
		}

		n++;
		if(n >= columns)
			n = 0;

		sb.Append("<td valign=bottom");
		if(nColspan > 1)
		{
			sb.Append(" colspan=" + nColspan);
			n += nColspan - 1;
			if(n >= columns)
				n = 0;
		}
		sb.Append(">");

		sb.Append("<table cellspacing=0 cellpadding=0 border=0 ");
		sb.Append(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
		sb.Append("<tr><td>");
//	//DEBUG("uri = ", uri);
		if(uri != "")
		{
			sb.Append("<a href=" + uri + "");
			if(Request.QueryString["ssid"] != null && Request.QueryString["ssid"] != "")
				sb.Append("&ssid="+ Request.QueryString["ssid"]+"");
			sb.Append(">");
		}
		sb.Append("<img src='/i/" + pic_name + "' border=0 style='width: 100%;height: 100%;' >");
		if(uri != "")
			sb.Append("</a>");
		sb.Append("</td></tr>");
		sb.Append("<tr><td><b>");
		sb.Append(title);
		sb.Append("</b></td></tr></table>");

		sb.Append("</td>");
	}
	sb.Append("</tr>");
	sb.Append("</table>");
	return sb.ToString();
}

bool DoAction(string code)
{
	if(m_action == "Phase Out")
	{
		//add to to product_skip table
		string sc = " IF EXISTS (SELECT code FROM product WHERE code=" + code + ") ";
		sc += " BEGIN ";
		sc += " INSERT INTO product_skip ";
		sc += " SELECT c.id, p.stock, p.eta, c.supplier_price, p.price, '' AS details ";
		sc += " FROM product p join code_relations c on c.code=p.code where c.code = " + code;
		sc += " UPDATE code_relations SET skip=1 WHERE code=" + code;
		sc += " DELETE FROM product WHERE code = " + code;
		sc += " END ";
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

string PrintFunctionButtons()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<input type=button class=\"button\"  value='View ");
	if(m_sBuyType == "purchase")
		sb.Append("Purchase Order");
	else if(m_sBuyType == "quote")
		sb.Append("Quote");
	else
		sb.Append(m_sBuyType);
	sb.Append("' onclick=window.location=('");
	if(m_sBuyType == "purchase")
		sb.Append("purchase.aspx");
	else if(m_sBuyType == "quote")
		sb.Append("q.aspx");
	else if(m_sBuyType == "sales")
		sb.Append("pos.aspx");
	else if(m_sBuyType == "quick_sales")
		sb.Append("pos_retail.aspx");
	else
		sb.Append(Session[m_sCompanyName + "_salesurl"]);
	if(m_ssid != "" && sb.ToString().IndexOf("ssid=") < 0)
		sb.Append("?ssid=" + m_ssid);
	sb.Append("') >");
	return sb.ToString();
}

bool GetKit()
{

	string sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
	sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
	sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
	for(int j=1; j<=9; j++)
		sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
	sc += ", price AS bottom_price ";
	sc += ", * FROM kit ";
	sc += " WHERE 1=1 ";
    bool aboveHas = true;
	if(m_sSite != "admin")
	{
        aboveHas = true;
        sc += " and inactive=0  ";
    }
   
    if(!String.IsNullOrEmpty(EncodeQuote(ds_cat))){
        if(aboveHas){
            sc += " and ";
        }
        sc += "  s_cat = '" + EncodeQuote(ds_cat) + "' ";
        aboveHas = true;
    }
	
	if(dss_cat != null && dss_cat != "")
	{
        if(aboveHas){
            sc += " and ";
        }
        sc += "  ss_cat = '" + EncodeQuote(dss_cat) + "' ";
        aboveHas = true;
    }
	if((Request.QueryString["ss"] == null || Request.QueryString["ss"] == "") && m_sSite != "admin")
	{
        //if(aboveHas){
        //    sc += " and ";
        //}
        //sc += "  hot = 1 ";
    }

	sc += " ORDER BY s_cat, ss_cat, name, id";
	try
	{
//DEBUG("2215sc=", sc);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
        if(rows_return <= 0){
                //DEBUG("", "Sorry no product under this category");
        }
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetSpecialKits()
{
	string sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
	sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
	sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
	for(int j=1; j<=9; j++)
		sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
	sc += ", k.price AS bottom_price ";
	sc += ", * FROM kit k ";
	sc += " JOIN specials_kit s ON k.id = s.code "; 
	sc += " WHERE 1=1 ";
	if(m_sSite != "admin")
		sc += " AND k.inactive=0 ";
	sc += " ORDER BY k.s_cat, k.ss_cat, k.name, k.id";
//DEBUG("2244sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetSpecialKits(string s, string ss)
{
	string sc = " SELECT '01/01/2001' AS price_age, '' AS supplier, '' AS supplier_code, 0 AS supplier_price ";
	sc += ", id AS code, '' AS brand, 1 AS stock, '" + m_sKitTerm + "' AS cat, '' AS eta ";
	sc += ", 0 AS price_dropped, 0 AS clearance, 1 AS currency, 0 AS foreign_supplier_price ";
	for(int j=1; j<=9; j++)
		sc += ", 1 AS level_rate" + j + ", 1 AS qty_break" + j + ", 0 AS qty_break_discount" + j + ", 0 AS price" + j;
	sc += ", k.price AS bottom_price ";
	sc += ", * FROM kit k ";
	sc += " JOIN specials_kit s ON k.id = s.code "; 
	sc += " WHERE 1=1 ";
    if(!String.IsNullOrEmpty(s)){
        sc += " AND k.s_cat = '"+s+"' " ;
    }else{
        sc += " AND 1 = 2 ";
    }
    if(!String.IsNullOrEmpty(ss)){
        sc += " AND k.ss_cat = '"+ss+"' ";
    }else{
        sc += " AND 1 = 2 ";
    }
	if(m_sSite != "admin")
		sc += " AND k.inactive=0 ";
	sc += " ORDER BY k.s_cat, k.ss_cat, k.name, k.id";
//DEBUG("2282sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows_return = myCommand.Fill(ds, "product");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

string TemplateParseCommand(string tp)
{
	StringBuilder sb = new StringBuilder();

	int line = 0;
	string sline = "";
	bool bRead = ReadLine(tp, line, ref sline);
	int protect = 999;
	while(bRead && protect-- > 0)
	{
		if(sline.IndexOf("IF_SPECIAL") >= 0)
		{
			sline = sline.Replace("IF_SPECIAL", "");
			if(bShowSpecial)
			{
				if(sline.IndexOf("@@DEFINE") >= 0)
				{
					string snItems = GetDefineValue("ITEMS_PER_ROW", sline);

					if(snItems != "")
						m_nItemsPerRow = MyIntParse(snItems);
				}
				else
					sb.Append(sline);
			}
		}
		else if(sline.IndexOf("IF_NOT_SPECIAL") >= 0)
		{
			sline = sline.Replace("IF_NOT_SPECIAL", "");
			if(!bShowSpecial && !m_bSearching)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_DISCONTINUED") >= 0)
		{
			sline = sline.Replace("IF_NOT_DISCONTINUED", "");
			if(!m_bDiscontinued)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_PURCHASE") >= 0)
		{
			sline = sline.Replace("IF_PURCHASE", "");
			if(m_sBuyType == "purchase")
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_PURCHASE") >= 0)
		{
			sline = sline.Replace("IF_NOT_PURCHASE", "");
			if(m_sBuyType != "purchase")
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_ADMIN") >= 0)
		{
			sline = sline.Replace("IF_ADMIN", "");
			if(m_bAdmin)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_NOT_ADMIN") >= 0)
		{
			sline = sline.Replace("IF_NOT_ADMIN", "");
			if(!m_bAdmin)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_PAGING") >= 0)
		{
			sline = sline.Replace("IF_PAGING", "");
			if(m_bPaging)
				sb.Append(sline);
		}
		else if(sline.IndexOf("IF_LOGGEDIN") >= 0)
		{
			sline = sline.Replace("IF_LOGGEDIN", "");
			if(TS_UserLoggedIn())
				sb.Append(sline);
		}
		else if(sline.IndexOf("@@DEFINE") >= 0)
		{
			string snItems = GetDefineValue("ITEMS_PER_ROW", sline);
			if(snItems != "")
				m_nItemsPerRow = MyIntParse(snItems);
		}
		else if(sline.IndexOf("IF_SEARCHING") >= 0)
		{

			sline = sline.Replace("IF_SEARCHING", "");
			if(m_bSearching)
				sb.Append(sline);
		}
		else
		{
			sb.Append(sline);
		}

		line++;
		bRead = ReadLine(tp, line, ref sline);
	}
	return sb.ToString();
}

string GetDefineValue(string sDef, string sline)
{
	int p = sline.IndexOf(sDef);
	string sValue = "";
	if(p > 0)
	{
		p += sDef.Length + 1;
		for(; p<sline.Length; p++)
		{
			if(sline[p] == ' ' || sline[p] == '\r' || sline[p] == '\n')
				break;
			sValue += sline[p];
		}
	}
	return sValue;
}

string RowParseCommand(string s, bool bFirstGroup)
{
	StringBuilder sb = new StringBuilder();

	int line = 0;
	string sline = "";
	bool bRead = ReadLine(s, line, ref sline);
	int protect = 999;
	while(bRead && protect-- > 0)
	{
		if(sline.IndexOf("IF_FIRST_GROUP") >= 0)
		{
			sline = sline.Replace("IF_FIRST_GROUP", "");
			if(bFirstGroup)
				sb.Append(sline);
		}
		else
		{
			sb.Append(sline);
		}
		line++;
		bRead = ReadLine(s, line, ref sline);
	}
	return sb.ToString();
}

//for search options
string ShowKeywords(string sIn)
{
	string s = sIn;
	for(int i=0; i<words; i++)
	{
		s = showkw(s, kws[i]);
	}
	return s;
}

string showkw(string sIn, string kw)
{
	if(kw.Length <= 0)
	{
		return sIn;
	}

	string s = "";
	string slow = sIn.ToLower();
	kw = kw.ToLower();
	int p = slow.IndexOf(kw);
////DEBUG("keyword="+keyword, " p=" + p.ToString());
	int start = 0;

	while(p >= 0)
	{
		s += sIn.Substring(start, p - start) ;//+ "<b>";
		s += sIn.Substring(p, kw.Length);
		//s += "</b>";
		start = p + kw.Length;
//		int pp = p;
		p = sIn.IndexOf(kw, p + kw.Length);
//		if(p
	}
	if(start < sIn.Length)
	{
		s += sIn.Substring(start, sIn.Length - start);
	}
	if(s == "")
		return sIn;

	return s;
}

string sDoGetProductHightLight(ref string code, string sColumn)
{
	string stext = "";
	if(ds.Tables["hightlight"] != null)
		ds.Tables["hightlight"].Clear();
	string sc = " SELECT  CONVERT(varchar(80), "+ sColumn +") AS "+ sColumn +" FROM product_details ";
	sc += " WHERE code = "+ code ;
	sc += " UNION SELECT  CONVERT(varchar(80), details) AS "+ sColumn +" FROM kit ";
	sc += " WHERE id = "+ code ;
////DEBUG("sc = ", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		if(myCommand.Fill(ds, "hightlight") == 1)
			stext = ds.Tables["hightlight"].Rows[0][""+ sColumn +""].ToString();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return "";
	}
	return stext;
}
string doShowIteminCart()
{
	string stext = "";
	CheckShoppingCart();
		
	for(int i=0; i<dtCart.Rows.Count && i<10 ; i++)
	{
		if(dtCart.Rows[i]["site"].ToString() != m_sCompanyName)
			continue;
        string item_name = "";
		DataRow drp = null;
		string code = dtCart.Rows[i]["code"].ToString();
		string name = dtCart.Rows[i]["name"].ToString();
		string supplier = dtCart.Rows[i]["supplier"].ToString();
		string supplier_code = dtCart.Rows[i]["supplier_code"].ToString();
		stext += "<tr><td valign=top>"+ (i+1) +".</td><td>";
		
		if(name.Length > 20)
		{
			for(int j=0; j<20; j++)
				item_name += name[j].ToString();
			
			item_name = item_name +"...";
		}
		stext += "<a title='view details' href='p.aspx?"+ code +"' class=o>"+ item_name +"</a></td></tr>";

	}
	if(dtCart.Rows.Count > 10){
		stext += "<tr><td><a title='view your renting list' href='cart.aspx' class=o>more<a></td></tr>";
    }
	return stext;
}

</script>

