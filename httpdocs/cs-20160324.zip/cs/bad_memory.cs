////////////////////////////////////////////////////////////////////////////////////
//this file stores some function names, terms that I can never remember
//bad memory am I? indeed !
////////////////////////////////////////////////////////////////////////////////////
System.Threading.Thread.Sleep(10);

Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?\">");
HttpUtility.UrlEncode(cat);
DateTime.UtcNow.AddHours(12).ToOADate(); //time now in milliseconds as a random seeds for page no-cache
Request.ServerVariables

CompareInfo ci = CompareInfo.GetCompareInfo(1);
if(ci.IndexOf(s, "philips", CompareOptions.IgnoreCase) >= 0)

	Response.Write("<table align=center cellspacing=0 cellpadding=0 border=1 ");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-style:Solid;border-collapse:collapse;fixed\">");

alter table account add id int identity NOT FOR REPLICATION NOT NULL

//paging bind
<!-- #include file="page_index.cs" -->
	
	string tableName = "";

	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);

	int rows = 0;
	if(ds.Tables[tableName] != null)
		rows = ds.Tables[tableName].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?" + Request.ServerVariables["QUERY_STRING"];
	int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	Response.Write("<table width=100% cellspacing=0 cellpadding=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>");
	Response.Write("<th></th>");
	Response.Write("<th></th>");
	Response.Write("<th></th>");
	Response.Write("<th></th>");
	Response.Write("</tr>");

	if(rows <= 0)
	{
		Response.Write("</table>");
		return;
	}

	bool bAlterColor = false;
	for(; i < rows && i < end; i++)
	{
		DataRow dr = ds.Tables[tableName].Rows[i];
		string  = dr[""].ToString();

		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" bgcolor=#EEEEEE");
		bAlterColor = !bAlterColor;
		Response.Write(">");
		
		Response.Write("<td>" +  + "</td>");
		Response.Write("</tr>");
	}
	Response.Write("<tr><td>" + sPageIndex + "</td></tr>");
	Response.Write("</table>");


//blink text
<script>
msg ='<a href=print.aspx class=o><font size=+1 color=red blink><b>Free Digital Photo Print</b></font></a>';
toggle=true;
speed = 900;
function BLINK() {
  toggle=!toggle
  document.all('msgDiv').innerHTML=(toggle)?msg:'';
  setTimeout('BLINK()',speed);
}
if (document.all) {
  document.write('<div id="msgDiv">'+msg+'</div>');
  BLINK();
}
else document.write('<BLINK>'+msg+'</BLINK>');
</script>

//sql to shrink transaction log file, can be used in tools.aspx, 
//change demo_log to database log file name(can be found in sysfiles table 'select name from sysfiles')
DBCC SHRINKFILE(demo_log, 1)
DBCC SHRINKFILE(demo_log, 1, TRUNCATEONLY)

//for DOTNET 1.2
	<system.web>
		<pages validateRequest="false" />


//command to change ident seed
DBCC CHECKIDENT ('orders', RESEED, 20500)
DBCC CHECKIDENT ('invoice', RESEED, 10000)
