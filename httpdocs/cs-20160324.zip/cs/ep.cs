<script runat=server>

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
DataRow[] dracr;	//for sorting code_relations
//string m_type = "";
string m_action = "";
string m_code = "";
string m_highlight = "";
string m_spec = "";
string m_manufacture = "";
string m_pic = "";
string m_rev = "";
string m_warranty = "";
string m_director = "";
string m_title_zone = "4";
string m_discs = "1";
string m_cast_member = "";
string m_rating = "3";
string m_classification = "1";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("editor"))
		return;

	GetQueryStrings();
	PrintAdminHeader();
	PrintAdminMenu();

	if(m_action == "save")
	{
		if(DoSave())
		{
			TSRemoveCache(m_sCompanyName + "_" + m_sHeaderCacheName);
            string _code = Request.QueryString["code"] ;
            if(String.IsNullOrEmpty(_code)){
                _code = "";
            }
			string s = "done. ";//<br><a href=editp.aspx?t=new class=d>Add another one</a>";
            //s += "<br><a href=";
            //if(Session["LastPage"] != null)
            //{
            //    s += Session["LastPage"];
            //    s += ">Go back where you came from: ";
            //    s += Session["LastPage"];
            //    s += "</a>";
            //}
            //else
            //{
            //    s += "default.aspx";
            //    s += ">Home</a>";
            //}
            //Response.Write(s);

            //Response.Write("<meta http-equiv=\"location\" content=\"URL=liveedit.aspx?code="+_code+"\" />");
            Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=ep.aspx?code=" + _code + "\">");
		}
		return;
	}

	if(!GetOldData())
		return;
	PrintForm();
	PrintAdminFooter();
}

Boolean GetOldData()
{
	string sc = "SELECT * FROM product_details WHERE code=";
	sc += m_code;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "ret") <= 0)
		{
			return InsertNew();
		}
		else
		{
			m_highlight = dst.Tables["ret"].Rows[0]["highlight"].ToString();
			m_highlight = m_highlight;
			m_spec = dst.Tables["ret"].Rows[0]["spec"].ToString();
			m_spec = m_spec;
			m_manufacture = dst.Tables["ret"].Rows[0]["manufacture"].ToString();
			m_pic = dst.Tables["ret"].Rows[0]["pic"].ToString();
			m_rev = dst.Tables["ret"].Rows[0]["rev"].ToString();
			m_warranty = dst.Tables["ret"].Rows[0]["warranty"].ToString();
			m_warranty = m_warranty;
			m_cast_member = dst.Tables["ret"].Rows[0]["cast_member"].ToString();
			m_director = dst.Tables["ret"].Rows[0]["director"].ToString();
			m_discs = dst.Tables["ret"].Rows[0]["discs"].ToString();
			m_title_zone = dst.Tables["ret"].Rows[0]["title_zone"].ToString();
			m_classification = dst.Tables["ret"].Rows[0]["classification"].ToString();
			m_rating = dst.Tables["ret"].Rows[0]["rating"].ToString();
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	
	return true;
}

Boolean InsertNew()
{
	string sc = "INSERT INTO product_details (code, highlight, manufacture, spec, pic, rev, warranty";
	sc += ") VALUES(";
	sc += m_code;
	sc += ", '', '', '', '', '', '')";

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void GetQueryStrings()
{
//	m_type = Request.QueryString["t"];
	m_action = Request.QueryString["a"];
	m_code = Request.QueryString["code"];
}

void PrintForm()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<form action=ep.aspx?a=save&code=" + m_code);
//	sb.Append(m_type);
	sb.Append(" method=POST>");
	sb.Append("<table cellpadding=3>");
	sb.Append("<tr><td colspan=2>");

	sb.Append("&nbsp;<img src='r.gif' />&nbsp;<a href=addpic.aspx?code=" + m_code + "><font size=+1 class=linkButton>Edit Photo</font></a>&nbsp;<img src='r.gif' />&nbsp;<a href=liveedit.aspx?code=" + m_code + "><font size=+1 class=linkButton>Edit Product Details</font></a>");

    sb.Append("<br /><br /><font size=+1><b>Product Details of ");
	sb.Append(m_code + "</b></font></td></tr>");

//	sb.Append("<tr><td><b>Photo</b> (link)</td></tr>");
//	sb.Append("<tr><td><textarea name=pic cols=90 rows=1>");
//	sb.Append(m_pic);
//	sb.Append("</textarea></td></tr>");

	sb.Append("<tr><td><b>High Light</b> (text/html)</td></tr>");
	sb.Append("<tr><td><textarea name=highlight cols=90 rows=7>");
	sb.Append(m_highlight);
	sb.Append("</textarea></td></tr>");

	sb.Append("<tr><td><b>");
	//if(!g_bRentalVersion)
	sb.Append("Manufacture");
	//else
	//	sb.Append("Studio");
	sb.Append("</b> (link)</td></tr>");
	sb.Append("<tr><td><textarea name=manufacture cols=90 rows=1>");
	sb.Append(m_manufacture);
	sb.Append("</textarea></td></tr>");

	sb.Append("<tr><td><b>Spec</b> (text/html)</td></tr>");
	sb.Append("<tr><td><textarea name=spec cols=90 rows=7>");
	sb.Append(m_spec);
	sb.Append("</textarea></td></tr>");

	sb.Append("<tr style='display: none;'><td><b>Reviews</b> (text/html)</td></tr>");
	sb.Append("<tr style='display: none;'><td><textarea name=rev cols=90 rows=7>");
	sb.Append(m_rev);
	sb.Append("</textarea></td></tr>");

	//if(!g_bRentalVersion)
	//{
	sb.Append("<tr><td><b>Warranty</b> (text/html)</td></tr>");
	sb.Append("<tr><td><textarea name=warranty cols=90 rows=3>");
	sb.Append(m_warranty);
	sb.Append("</textarea></td></tr>");
	//}
	if(g_bRentalVersion)
	{
		sb.Append("<tr style='display: none;'><td><b>Cast Member</b> (text/html)</td></tr>");
		sb.Append("<tr style='display: none;'><td><textarea name=cast_member cols=90 rows=7>");
		sb.Append(m_cast_member);
		sb.Append("</textarea></td></tr>");
			
        sb.Append("<tr style='display: none;'><td><b>Director</b> (text/html)</td></tr>");
		sb.Append("<tr style='display: none;'><td><textarea name=director cols=90 rows=7>");
		sb.Append(m_director);
		sb.Append("</textarea></td></tr>");
		
		sb.Append("<tr style='display: none;'><td><b>Discs</b> (number)</td></tr>");
		sb.Append("<tr style='display: none;'><td><textarea name=discs cols=90 rows=1>");
		sb.Append(m_discs);
		sb.Append("</textarea></td></tr>");
			
        sb.Append("<tr style='display: none;'><td><b>Title Zone</b> (number)</td></tr>");
		sb.Append("<tr style='display: none;'><td><textarea name=title_zone cols=90 rows=1>");
		sb.Append(m_title_zone);
		sb.Append("</textarea></td></tr>");

        if(m_rating == null || m_rating == "")
            m_rating = "3";
		sb.Append("<tr style='display: none;'><td><b>Rating</b> (number)</td></tr>");
		sb.Append("<tr style='display: none;'><td><select name=rating> ");
		for(int i=1; i<6; i++)
		{
			sb.Append("<option value="+ i +"");
			if(i == int.Parse(m_rating))
				sb.Append(" selected ");
			sb.Append(">"+ i +"</option>");
		}
		sb.Append("</select>");
		
		sb.Append("</td></tr>");
			
        sb.Append("<tr style='display: none;'><td><b>Classification</b> (number)</td></tr>");
		sb.Append("<tr style='display: none;'><td><select name=classification >");
		sb.Append(GetEnumOptions("item_classification", m_classification));		
		sb.Append("</select>");
		sb.Append("</td></tr>");
		
	}
		sb.Append("<input type=hidden name=code value=");
	sb.Append(m_code);
	sb.Append(">");
	sb.Append("<tr><td align=right><input type=submit value=' &nbsp; Save &nbsp; ' class=saveButton></tr></table></form>");
	Response.Write(sb.ToString());
}

Boolean DoSave()
{
	if(Request.Form["code"] == null || Request.Form["code"] == "")
	{
		Response.Write("<h3>No Item Code Provided, Cannot Update</h3>");
		return false;
	}
	string shl = EncodeQuote(Request.Form["highlight"]);
	string sman = EncodeQuote(Request.Form["manufacture"]);
	string sspec = EncodeQuote(Request.Form["spec"]);
	string srev = EncodeQuote(Request.Form["rev"]);
	string swarr = EncodeQuote(Request.Form["warranty"]);
    string scast_member = EncodeQuote(Request.Form["cast_member"]);
    string sdirector = EncodeQuote(Request.Form["director"]);
    string sdiscs = Request.Form["discs"];
    string szone = Request.Form["title_zone"];
    string srating = Request.Form["rating"];
    string sclassification = Request.Form["classification"];
	if(srev.Length >= 1024)
		srev = srev.Substring(0, 1023);
/*
	int len = sman.Length + srev.Length + swarr.Length;
	int lenLeft = 8000 - len;
	if(shl.Length > lenLeft)
	{
		if(lenLeft > 0)
			shl = shl.Substring(0, lenLeft);
		else
		{
			Response.Write("<h3>Too many reviews, cannot store that much</h3>");
			return false;
		}
	}
	len += shl.Length;
	lenLeft = 8000 - len;
	if(sspec.Length > lenLeft)
	{
		if(lenLeft > 0)
		{
			Response.Write("<h3>spec's too long, tail's truncated, check out.</h3>");
			sspec = sspec.Substring(0, lenLeft);
		}
		else
		{
			Response.Write("<h3>Too many highlights, cannot store that much</h3>");
			return false;
		}
	}
*/
	string sc = "BEGIN TRANSACTION UPDATE product_details SET highlight='";
	sc += shl;
	sc += "', manufacture='";
	sc += sman;
	sc += "', spec='";
	sc += sspec;
	sc += "', rev='";
	sc += srev;
	sc += "', warranty='";
	sc += swarr +"'";
	if(g_bRentalVersion)
	{
		sc += ", director='";
		sc += sdirector;
		sc += "', cast_member='";
		sc += scast_member;
		sc += "', discs=";
		sc += sdiscs;
		sc += ", title_zone='";
		sc += szone;
		sc += "', rating=";
		sc += srating +", classification = '"+ sclassification +"'";
	}
	sc += " WHERE code=";
	sc += Request.Form["code"];	
	if(g_bRentalVersion)
	{
        //sc += "UPDATE code_relations SET rating='";
        //sc += srating +"', classification = '"+ sclassification +"'";
        //sc += " WHERE code=";
        //sc += Request.Form["code"];
	}
	sc += " COMMIT ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void WriteHeaders()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("<html><style type=\"text/css\">td{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}");
	sb.Append("body{FONT-WEIGHT:300;FONT-SIZE:8PT;FONT-FAMILY:verdana;}</style>");
	sb.Append("<body marginwidth=0 marginheight=0 topmargin=0 leftmargin=0>\r\n");

	Response.Write(sb.ToString());
	Response.Flush();
}

void WriteFooter()
{
	StringBuilder sb = new StringBuilder();
	sb.Append("</body></html>");
	Response.Write(sb.ToString());
}
</script>
