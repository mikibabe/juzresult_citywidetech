<!-- #include file="stat_fun.cs" -->
<!-- #include file="page_index.cs" -->
<script runat=server>

string m_periodindex = "1";
string m_Tbalance = "0";

//double m_dCardBalance = 0;
double m_dUnPaidTotal = 0;

void SPage_Load()
{
	if(Request.QueryString["ci"] != null && Request.QueryString["ci"] != "")
		m_custID = Request.QueryString["ci"];

    if(m_timeOpt != Request.QueryString["p"])
		m_timeOpt = Request.QueryString["p"];

	if(m_sSite != "admin")
		m_custID = Session["card_id"].ToString(); //customer can only view his own statment, of course

	if(Request.QueryString["t"] != null && Request.QueryString["t"] != "")
	{
		//m_timeOpt = "4";  //turn off show all invoice in statement
	    
		if(!GetSelectedCust(m_custID))
			return;
		if(!GetInvRecords(m_custID))
			return;

		Response.Write(PrintStatmentDetails());
		return;
	}
	if(Request.QueryString["tt"] != null && Request.QueryString["tt"] != "")
	{
        int ii = 1;
        string fromDateS = "";
        string toDateS = "";
        try 
	    {	
		    string t = Request["fromDate"].ToString();
            string[] temp = t.Split('/');
            fromDateS = temp[2] + "-" + temp[1] + "-" + temp[0];

            int year = int.Parse (temp[2]);
            int month = int.Parse (temp[1]);
            int day = int.Parse (temp[0]);
            DateTime ddtt = new DateTime(year,month,day);

            t = Request["toDate"].ToString();
            temp = t.Split('/');
            toDateS = temp[2] + "-" + temp[1] + "-" + temp[0];
            
             year = int.Parse (temp[2]);
             month = int.Parse (temp[1]);
             day = int.Parse (temp[0]);
             ddtt = new DateTime(year,month,day);

            //if(!int.TryParse(Request["PaidSelect"].ToString(), out ii)){
            //    return;
            //}
	    }
	    catch (global::System.Exception ex)
	    {
               Response.Write("Invalid date format please try again");
               Response.Write(" <br /><A class='linkButton' HREF='javascript:history.go(-1)'> [Go Back]</A>");
               return;
	    }
        
		m_timeOpt = "4";
	
		if(!GetSelectedCust(m_custID))
			return;
		if(!GetInvRecords(m_custID, fromDateS, toDateS, ii))
			return;

		Response.Write(PrintStatmentDetails());
		return;
	}
	else if(Request.QueryString["fpaid"] == "1")
	{
		if(!GetFullyPaidInvoices())
			return;
		BindFullyPaid();
		return;
	}

	

	PrintStatHeader();

	if(m_custID != "")
	{
		PrintCustStats();
		PrintBalDetails();
/*		if(m_dUnPaidTotal != m_dCardBalance)
		{
			if(Session["email"] != null && m_sSite == "admin")
			{
				if(Session["email"].ToString() == "darcy@ezsoft.com")
				{
					Response.Write("<a href=statement.aspx?ci=" + m_custID + "&rb=1 class=o>Reset Balance</a>");
				}
			}
		}
*/
	}

	if(Request.QueryString["rb"] == "1")
	{
		if(Session["email"] != null && m_sSite == "admin")
		{
			if(Session["email"].ToString() == "darcy@ezsoft.com")
			{
				DoResetBalance();
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=statement.aspx?ci=" + m_custID + "\">");
			}
		}
	}
}

void PrintStatHeader()
{
	string uri = Request.ServerVariables["URL"] + "?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"";
	Response.Write("<br><br><center><h3><font size=+1><b>Customer Statement</b></font></h3>");

	if(m_sSite == "admin")
	{
		Response.Write("<form id=search name=search action=" + uri + " method=post>");
		Response.Write("<table width=100/%><tr><td><b>Customer :</b></td><td>");
		Response.Write("<input type=editbox size=20 name=ckw></td><td>");

		Response.Write("<script");
		Response.Write(">");
		Response.Write("document.search.ckw.focus();");
		Response.Write("</script");
		Response.Write(">");
/*string supid = Request.QueryString["sup_id"];
if(supid == null || supid == "")
supid = "1";
*/
		Response.Write("<input type=submit name=cmd value=Search class=searchButton2 title='Search'> </td>" );
		Response.Write("<td><input type=button name=cmd value='Cancel' class=cancelButton2 title='Cancel'");
		Response.Write(" onClick=window.location=('statement.aspx?r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "')>");
		Response.Write("</td>");
	/*	Response.Write("<td><select name=card_type onchange=\"window.location=('"+ uri +"&sup_id=' + this.options[this.selectedIndex].value)\" >");
		Response.Write("<option value=''>All");
	Response.Write(GetEnumOptions("card_type", supid , false, true));
	Response.Write("</select></td>");
	*/
		Response.Write("<td><a title='click to list all suppliers' href='statement.aspx?&sup_id=3&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "' class=linkButton>Suppliers</a>|</td>");
		Response.Write("<td><a title='click to list all dealers' href='statement.aspx?&sup_id=2&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "' class=linkButton>Dealers</a>|</td>");
		Response.Write("<td><a title='click to list all customers' href='statement.aspx?&sup_id=1&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "' class=linkButton>Customers</a></td>");
//		Response.Write("<td><a title='click to list all Others' href='statement.aspx?&sup_id=5&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "' class=o>Others</a></td>");
		Response.Write("</tr></table></form>\r\n");

		if(Request.QueryString["ci"] == null || Request.QueryString["ci"] == "")
		{
			if(!DoCustomerSearchAndList())
				return;
		}
	}
}

void PrintCustStats()
{
	Response.Write("<br><table width=75% class='table'><tr class=tableHeader><th width=120>Customer Name</th><th width=120>Credit Terms</th>");
	Response.Write("<th width=200>PH</th><th>");
	Response.Write("Company Name: </th></tr>");
//	Response.Write("Total Balance: </td></tr>\r\n");

	if(!GetSelectedCust(m_custID))
		return;
	m_scredit_terms_id = dst.Tables["cust_gen"].Rows[0]["terms_id"].ToString();
	m_scredit_terms = dst.Tables["cust_gen"].Rows[0]["credit_terms"].ToString();
	Response.Write("<tr><td><b>" + dst.Tables["cust_gen"].Rows[0]["name"].ToString() + "</b></td><td>");
	Response.Write("<b>" + m_scredit_terms + "</b></td><td>");
	Response.Write(dst.Tables["cust_gen"].Rows[0]["phone"].ToString());
	if(dst.Tables["cust_gen"].Rows[0]["phone"].ToString() != "")
		Response.Write("; Fax: " + dst.Tables["cust_gen"].Rows[0]["fax"].ToString());
	Response.Write("</td><td>");
	Response.Write(dst.Tables["cust_gen"].Rows[0]["trading_name"].ToString() + "</td>");
	Response.Write("</tr>");

//	m_dCardBalance = double.Parse(dst.Tables["cust_gen"].Rows[0]["balance"].ToString());
//	Response.Write(m_dCardBalance.ToString("c") + "</td></tr>\r\n");

	//Customer Address

	string s_address = dst.Tables["cust_gen"].Rows[0]["nameB"].ToString();
	if(dst.Tables["cust_gen"].Rows[0]["companyB"].ToString() != "")
		s_address += "<br>" + dst.Tables["cust_gen"].Rows[0]["companyB"].ToString();
	if(dst.Tables["cust_gen"].Rows[0]["address1B"].ToString() != "")
		s_address += "<br>" + dst.Tables["cust_gen"].Rows[0]["address1B"].ToString();
	if(dst.Tables["cust_gen"].Rows[0]["address2B"].ToString() != "")
		s_address += "<br>" + dst.Tables["cust_gen"].Rows[0]["address2B"].ToString();
	if(dst.Tables["cust_gen"].Rows[0]["cityB"].ToString() != "")
		s_address += "<br>" + dst.Tables["cust_gen"].Rows[0]["cityB"].ToString();
	if(dst.Tables["cust_gen"].Rows[0]["countryB"].ToString() != "")
		s_address += "  " + dst.Tables["cust_gen"].Rows[0]["countryB"].ToString();
	if(s_address != "")
	{
		Response.Write("<tr><td colspan=4><hr></td></tr><tr class=tableHeader><td colspan=2><b>Billing Address:</b></td></tr>");
		Response.Write("<tr><td colspan=2>" + s_address + "</td></tr>");
	}
	Response.Write("<tr><td colspan=4><hr></td></tr></table>\r\n");

	//Option table
	string s_checked1 = "";
	string s_checked2 = "";
	string s_checked3 = "";
	string s_checked4 = "";
	string s_checked5 = "";
	string s_checked6 = "";
	string s_colbgc1 = "";
	string s_colbgc2 = "";
	string s_colbgc3 = "";
	string s_colbgc4 = "";
	string s_colbgc5 = "";
	string s_colbgc6 = "";

	if(m_timeOpt == "0")
	{
		s_checked1 = " checked";
		s_colbgc1 = " class=rowColor";
	}
	else if(m_timeOpt =="1")
	{
		s_checked2 = " checked";
		s_colbgc2 = " class=rowColor";
	}	
	else if(m_timeOpt =="2")
	{
		s_checked3 = " checked";	
		s_colbgc3 = " class=rowColor";
	}
	else if(m_timeOpt =="3")
	{
		s_checked4 = " checked";	
		s_colbgc4 = " class=rowColor";
	}
	else if(m_timeOpt =="4")
	{
		s_checked5 = " checked";	
		s_colbgc5 = " class=rowColor";
	}
	else
	{
		s_checked6 = " checked";
		s_colbgc6 = " class=rowColor";
	}
	string s_url = Request.ServerVariables["URL"] + "?ci=" + Request.QueryString["ci"];
	Response.Write("&nbsp;&nbsp;&nbsp;<font color=blue><b>To: " + DateTime.UtcNow.AddHours(12).ToString("dd-MM-yyyy HH:mm") + "</b></font>");
	Response.Write("<form name=timeOptfrm action=" + s_url + "&p=" + m_timeOpt + "method=post>");
	Response.Write("<table class='table'>");
	Response.Write("<tr><th class=tableHeader><b>Days:&nbsp;&nbsp;&nbsp;</b></th>");
	
	Response.Write("<td" + s_colbgc1 + ">&nbsp;<input type=radio name=period value='0'" + s_checked1);
	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[0].value)\"");
	Response.Write(">");
	Response.Write("&nbsp;<b>Current &nbsp; </b></td>\r\n");
	
	Response.Write("<td" + s_colbgc2 + ">&nbsp;<input type=radio name=period value='1'" + s_checked2);
	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[1].value)\"");
	Response.Write(">");
	//Response.Write(">&nbsp;<b>30 Days &nbsp; </b></td>\r\n");
	if(m_scredit_terms_id == "4")
		Response.Write("&nbsp;<b>7 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		Response.Write("&nbsp;<b>14 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "7")
		Response.Write("&nbsp;<b>14 Days &nbsp; </b></td>\r\n");
	else
		Response.Write("&nbsp;<b>30 Days &nbsp; </b></td>\r\n");
	
	Response.Write("<td" + s_colbgc3 + ">&nbsp;<input type=radio name=period value='2'" + s_checked3);
	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[2].value)\"");
	Response.Write(">");
	//Response.Write("&nbsp;<b>60 Days &nbsp; </b></td>\r\n");
	if(m_scredit_terms_id == "4")
		Response.Write("&nbsp;<b>14 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		Response.Write("&nbsp;<b>30 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "7")
		Response.Write("&nbsp;<b>30 Days &nbsp; </b></td>\r\n");
	else
		Response.Write("&nbsp;<b>60 Days &nbsp; </b></td>\r\n");
	
	
	Response.Write("<td" + s_colbgc4 + ">&nbsp;<input type=radio name=period value='3'" + s_checked4);
	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[3].value)\"");
	Response.Write(">");
	//Response.Write("&nbsp;<b>90 Days &nbsp; </b></td>\r\n");
	if(m_scredit_terms_id == "4")
		Response.Write("&nbsp;<b>30 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "5")
		Response.Write("&nbsp;<b>60 Days &nbsp; </b></td>\r\n");
	else if(m_scredit_terms_id == "7")
		Response.Write("&nbsp;<b>60 Days &nbsp; </b></td>\r\n");
	else
		Response.Write("&nbsp;<b>90 Days &nbsp; </b></td>\r\n");
	
	
	Response.Write("<td" + s_colbgc5 + ">&nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name=period value='4'" + s_checked5);
	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[4].value)\"");
	Response.Write(">");
	Response.Write("&nbsp;<b>All&nbsp;&nbsp;&nbsp;</b></td>\r\n");
	Response.Write("<td><b>&nbsp&nbsp; Credits &nbsp&nbsp;</b></td>");
	Response.Write("<td><b>&nbsp&nbsp; Total_Due &nbsp&nbsp;</b></td>");

	Response.Write("</tr>");

//	Response.Write("<td" + s_colbgc6 + ">&nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name=period value='5'" + s_checked6);
//	Response.Write(" onclick=\"window.location=('"+s_url+"&p='+document.timeOptfrm.period[5].value)\"");
//	Response.Write(">");
//	Response.Write("&nbsp;<b>To Be Billed/Emailed&nbsp;&nbsp;&nbsp;</b></td></tr>\r\n");
	
	//DateTime d_date1 = new DateTime(); //DateTime.Parse("dd-mm-yyyy"); DateTime.UtcNow.AddHours(12);
	double[] dSubBalance = new double[5];
	//sub-"total balance"
	for(int i = 0; i<5; i++)
	{
		if(!GetSubBalance(i, m_custID, ref dSubBalance[i]))
			return;		
//DEBUG("i = ", i);
//DEBUG("dSubBalance = ", dSubBalance[i].ToString());
	}		

	double dRowTotal = dSubBalance[0] + dSubBalance[1] + dSubBalance[2] + dSubBalance[3];
	m_dUnPaidTotal = dRowTotal;
	double dCreditTotal = GetTotalCredit(m_custID);
	double dTotalDue = dRowTotal - dCreditTotal;

	Response.Write("<tr ><th class=tableHeader><b>Sub Balance:&nbsp;</b></th>");
	Response.Write("<td align=center" + s_colbgc1 + ">" + dSubBalance[0].ToString("c") + "</td>");
	Response.Write("<td align=center" + s_colbgc2 + ">" + dSubBalance[1].ToString("c") + "</td>");
	Response.Write("<td align=center" + s_colbgc3 + ">" + dSubBalance[2].ToString("c") + "</td>");
	Response.Write("<td align=center" + s_colbgc4 + ">" + dSubBalance[3].ToString("c") + "</td>");
	Response.Write("<td align=right" + s_colbgc5 + ">&nbsp;&nbsp;" + dRowTotal.ToString("c") + "</td>");
	Response.Write("<td align=right" + s_colbgc5 + ">&nbsp;&nbsp;" + dCreditTotal.ToString("c") + "</td>");
	Response.Write("<td align=right" + s_colbgc5 + ">&nbsp;&nbsp;" + dTotalDue.ToString("c") + "</td>");
//	Response.Write("<td align=center" + s_colbgc6 + ">" + dSubBalance[5].ToString("c") + "</td>"); //to be billed
	Response.Write("</tr></table></form>\r\n");
}

void PrintBalDetails()
{
//	if(Request.QueryString["p"] != null && Request.QueryString["p"] != "")
	{	
		if(!GetInvRecords(m_custID))
			return;
	}
	string sTimeLbl = "";
	
    if(m_scredit_terms_id == "4")
    {
	    if(m_timeOpt == "0")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;Current</b></font>";
	    if(m_timeOpt == "1")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 7 Days</b></font>";
	    if(m_timeOpt == "2")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 14 Days</b></font>";
	    if(m_timeOpt == "3")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 30 Days</b></font>";
	    if(m_timeOpt == "4")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp; All</b></font>";
    }
    else if(m_scredit_terms_id == "5")
    {
	    if(m_timeOpt == "0")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;Current</b></font>";
	    if(m_timeOpt == "1")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 14 Days</b></font>";
	    if(m_timeOpt == "2")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 30 Days</b></font>";
	    if(m_timeOpt == "3")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 60 Days</b></font>";
	    if(m_timeOpt == "4")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp; All</b></font>";
    }
    else
    {
	    if(m_timeOpt == "0")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;Current</b></font>";
	    if(m_timeOpt == "1")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 30 Days</b></font>";
	    if(m_timeOpt == "2")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 60 Days</b></font>";
	    if(m_timeOpt == "3")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp;in 90 Days</b></font>";
	    if(m_timeOpt == "4")
		    sTimeLbl = "<font color=blue><b>&nbsp;&nbsp; All</b></font>";
    }
//	if(m_timeOpt == "5")
//		sTimeLbl = "<font color=blue><b>&nbsp;&nbsp; To Be Billed/Emailed </b><i>( >=30 days)</i></font>";

	if(dst.Tables["invoice_rec"].Rows.Count == 0)
	{
		Response.Write("&nbsp;&nbsp;<font color=red><b>0</b></font><b>&nbsp;Records found:</b>" + sTimeLbl);
		if(m_sSite == "admin")
		{
			Response.Write("&nbsp;&nbsp;<input type=button value='Fully Paid Invoices' class=linkButtonCenter title='Fully Paid Invoices'");
			Response.Write(" onclick=window.location=('statement.aspx?ci=" + m_custID + "&fpaid=1&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "')>");
		}
		return;
	}
	
	Response.Write("<table class='table'><tr><td colspan=2><font color=red><b>" + dst.Tables["invoice_rec"].Rows.Count.ToString());
	Response.Write("</b></font><b>&nbsp;Records found</b>" + sTimeLbl);
	string s_vdUrl = Request.ServerVariables["URL"] + "?" + Request.ServerVariables["QUERY_STRING"];
	Response.Write("&nbsp;&nbsp;&nbsp;<br /><input type=button class='red_btn' title=' Printable Copy ' onclick=window.open('"+ s_vdUrl + "&t=vd') value='Printable Copy'></td><td colspan=3>");

	if(m_sSite == "admin")
	{
		Response.Write("&nbsp;&nbsp;<input type=button class=linkButtonCenter title='Order Trace'");
		Response.Write(" onclick=window.location=('status.aspx?ci=" + m_custID + "&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value='Order Trace'>");

		Response.Write("&nbsp;&nbsp;<input type=button class=linkButtonCenter title='e-mail Statement'");
		Response.Write(" onclick=window.location=('broadmail.aspx?ci=" + m_custID + "&t=m&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value='e-mail Statement'>");

		Response.Write("&nbsp;&nbsp;<input type=button class=linkButtonCenter title='Fully Paid Invoices'");
		Response.Write(" onclick=window.location=('statement.aspx?ci=" + m_custID + "&fpaid=1&r=" + DateTime.UtcNow.AddHours(12).ToOADate() + "') value='Fully Paid Invoices'>");
	}
	Response.Write("</td></tr>\r\n");
    Response.Write("<tr><td colspan='6' >");
    
    Response.Write("<div>");
    Response.Write("<form name='myForm' method='post' action='statement.aspx?ci=" + m_custID + "&tt=vvdd' target='_blank'>");
    Response.Write("From Date: (dd/MM/yyyy)");
    Response.Write("<input id='fromDate' type='text' name='fromDate' />");
    Response.Write("<br />To Date: (dd/MM/yyyy)");
    Response.Write("<input id='toDate' type='text' name='toDate' />");
    //Response.Write("Paid:");
    //Response.Write("<select id='PaidSelect' name='PaidSelect'>");
    //Response.Write("<option value='1' selected='selected'>Paid</option>");
    //Response.Write("<option value='0'>Unpaid</option>");
    //Response.Write("</select>");
    Response.Write("<input id='Submit1' type='submit' value='Show invoice' onclick='submitFun();' />");
    Response.Write("<script type='text/javascript'>");
    Response.Write("function submitFun() {");
    Response.Write(" myForm.submit();");
    Response.Write(" }");
    Response.Write("</");
    Response.Write("script>");
    Response.Write("</form>");
    Response.Write("</div>");
    Response.Write("");

    Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=6><hr></td></tr>");
	//Row headers
	Response.Write("<tr class=tableHeader><td width=15% align=center><b>Date</b></td>");
	Response.Write("<td width=15% align=center><b>Invoice No.</b></td>");
	Response.Write("<td width=15% align=center><b>PO No.</b></td>");
	Response.Write("<td width=15% align=right><b>Charge</b></td>");
	Response.Write("<td width=15% align=right><b>Amount Paid</b></td>");
	Response.Write("<td width=20% align=right><b>Balance</b></td></tr>");
	//Print Rows
	double dCharge = 0;
	
	for(int i = 0; i < dst.Tables["invoice_rec"].Rows.Count; i++)
	{
		Response.Write("<tr>");
		DataRow dr = dst.Tables["invoice_rec"].Rows[i];
		Response.Write("<td align=center>" + DateTime.Parse(dr["commit_date"].ToString()).ToString("dd/MM/yy") + "</td>");
		Response.Write("<td align=center><a href=");
		if(!bCardType(ref m_custID))
			Response.Write("invoice.aspx?n=" + dr["invoice_number"].ToString() + "");
		else
			Response.Write("purchase.aspx?t=pp&n=" + dr["pid"].ToString() + "");
		Response.Write(" target=_blank>"); 

		Response.Write(dr["invoice_number"].ToString() + "</a></td>");
		Response.Write("<td align=center>" + dr["cust_ponumber"].ToString() + "</td>");
		//total chargeable amount "ship + price"(GST excl.) 
		dCharge = double.Parse(dr["total"].ToString());
		Response.Write("<td align=right>" + dCharge.ToString("c") + "</td>");
		
		if(double.Parse(dr["amount_paid"].ToString()) > 0)
			Response.Write("<td align=right>" + double.Parse(dr["amount_paid"].ToString()).ToString("c") + "</td>");
		else
			Response.Write("<td align=center>&nbsp;</td>");

		Response.Write("<td align=right>" + double.Parse(dr["cur_bal"].ToString()).ToString("c") + "</td>");
	}
	Response.Write("</tr>");
	Response.Write("</table>");
}

bool DoCustomerSearchAndList()
{
	string uri = Request.ServerVariables["URL"] + "?";	// + Request.ServerVariables["QUERY_STRING"];
	int rows = 0;
	string kw = "'%" + EncodeQuote(Request.Form["ckw"]) + "%'";
	if(Request.Form["ckw"] == null || Request.Form["ckw"] == "")
		kw = "'%%'";
	//string sc = "SELECT *, '" + uri + "' + '&ci=' + LTRIM(STR(id)) + '&p=0' AS uri FROM card ";
	string sc = "SELECT e.name AS credit_term, c.*,  '" + uri + "' + '&ci=' + LTRIM(STR(c.id)) + '&p=0' AS uri ";
	sc += " ,'ecard.aspx?id=' + LTRIM(STR(c.id)) + '' AS ecard ";

	sc += ", ";
	sc += " ISNULL((SELECT SUM(total - amount_paid) ";
	sc += " FROM invoice ";
	sc += " WHERE card_id = c.id), (SELECT ISNULL(SUM(total_amount - amount_paid),0) FROM purchase WHERE supplier_id = c.id)) ";
	sc += " - ";
	sc += " ISNULL((SELECT SUM(amount - amount_applied) ";
	sc += " FROM credit ";
	sc += " WHERE card_id = c.id), 0) ";
	sc += " AS total_balance ";

	sc += "FROM card c JOIN enum e ON e.id = c.credit_term";
	sc += " WHERE main_card_id is null AND (";
	if(IsInteger(Request.Form["ckw"]))
		sc += " c.id=" + Request.Form["ckw"];
	else
		sc += " c.name LIKE " + kw + " OR c.email LIKE " + kw + " OR c.company LIKE " + kw;
	//sc += ") ORDER BY c.balance DESC";
	sc += ") ";
	sc += " AND e.class = 'credit_terms' ";
	if(Request.QueryString["sup_id"] != null && Request.QueryString["sup_id"] != "")
		sc += " AND c.type = "+ Request.QueryString["sup_id"] +"";
	
	sc += " ORDER BY total_balance DESC ";
//DEBUG("sc=", sc);
	try
	{
//		SqlConnection myConnection = new SqlConnection("Initial Catalog=ezsoft" + m_sDataSource + m_sSecurityString);
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "card");
		if(rows == 1)
		{
			string search_id = dst.Tables["card"].Rows[0]["id"].ToString();
			Trim(ref search_id);
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=statement.aspx?p=0&ci=" + search_id + "\">");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	BindGrid();

	return true;
}

void BindGrid()
{
	DataView source = new DataView(dst.Tables["card"]);
	MyDataGrid.DataSource = source ;
	MyDataGrid.DataBind();
}

void MyDataGrid_PageA(object sender, DataGridPageChangedEventArgs e) 
{
	MyDataGrid.CurrentPageIndex = e.NewPageIndex;
	BindGrid();
}

bool GetFullyPaidInvoices()
{
	string sc = " ";
	if(!bCardType(ref m_custID))
	{
	    sc = " SELECT DISTINCT '0' AS pid, i.invoice_number, i.commit_date, i.amount_paid ";
	    sc += ", i.cust_ponumber, d.trans_date, d.payment_method, d.payment_ref, tt.amount AS paidAmount  ";
	    sc += " FROM invoice i JOIN tran_detail d ON d.invoice_number LIKE '%' + CONVERT(varchar(50), i.invoice_number) + '%'";
	    sc += " JOIN trans tt ON tt.id=d.id ";
        sc += " WHERE i.paid = 1 AND i.card_id = " + m_custID;
	    sc += " ORDER BY i.commit_date DESC";
	}
	else
	{
		sc = " SELECT DISTINCT i.id AS pid, i.po_number AS invoice_number, i.date_invoiced AS commit_date, i.amount_paid, i.po_number AS cust_ponumber, d.trans_date ";
		sc += ", d.payment_method, d.payment_ref  ";
		sc += " FROM purchase i INNER JOIN ";
		sc += " tran_detail d ON d.invoice_number LIKE '%' + CONVERT(varchar(50), i.id) + '%' ";
		sc += " WHERE (i.supplier_id = 1069 AND i.date_invoiced is not null)  ";
		sc += " ORDER BY i.date_invoiced DESC"; 
	}
/*	string sc = "SELECT DISTINCT i.invoice_number, i.commit_date, ti.amount_applied AS amount_paid ";
	sc += ", i.cust_ponumber, d.trans_date, d.payment_method, d.payment_ref ";
	sc += " FROM invoice i JOIN tran_detail d ON d.invoice_number LIKE '%' + CONVERT(varchar(50), i.invoice_number) + '%'";
	sc += " JOIN tran_invoice ti ON ti.tran_id = d.id ";
	sc += " WHERE i.paid = 1 AND i.card_id = " + m_custID;
	sc += " ORDER BY i.commit_date DESC";
*/
//DEBUG("sc=", sc);
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		myCommand.Fill(dst, "invoice");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void BindFullyPaid()
{
	//paging class
	PageIndex m_cPI = new PageIndex(); //page index class
	if(Request.QueryString["p"] != null)
		m_cPI.CurrentPage = int.Parse(Request.QueryString["p"]);
	if(Request.QueryString["spb"] != null)
		m_cPI.StartPageButton = int.Parse(Request.QueryString["spb"]);

	int rows = 0;
	if(dst.Tables["invoice"] != null)
		rows = dst.Tables["invoice"].Rows.Count;
	m_cPI.TotalRows = rows;
	m_cPI.URI = "?fpaid=1&ci=" + m_custID;
	int i = m_cPI.GetStartRow();
	int end = i + m_cPI.PageSize;
	string sPageIndex = m_cPI.Print();

	string company = TSGetUserCompanyByID(m_custID);

	Response.Write("<br><center><h3>FULLY PAID INVOICES - <font class=blueFont2>" + company + "</font></h3>");

	Response.Write("<table width=100%  align=center valign=center cellspacing=0 cellpadding=0 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");

	Response.Write("<tr class=tableHeader>");
	Response.Write("<td>Date</td>");
	Response.Write("<td>Invoice #</td>");
	Response.Write("<td>PO #</td>");
	Response.Write("<td >Amount Paid</th>");
	Response.Write("<td>Date Paid</td>");
	Response.Write("<td>Payment</td>");
	Response.Write("<td>Reference</td>");
	Response.Write("</tr>");

	if(rows <= 0)
	{
		Response.Write("</table>");
		return;
	}

	bool bAlterColor = false;
	for(; i < rows && i < end; i++)
	{
		DataRow dr = dst.Tables["invoice"].Rows[i];
		string idate = DateTime.Parse(dr["commit_date"].ToString()).ToString("dd-MM-yyyy");
		string invoice_number = dr["invoice_number"].ToString();
		string po_number = dr["cust_ponumber"].ToString();
		string amount_paid = dr["amount_paid"].ToString();
        string paidAmount = dr["paidAmount"].ToString();
		string date_paid = dr["trans_date"].ToString();
        DateTime _date_paid = DateTime.Now;
        try{
            _date_paid = DateTime.Parse(date_paid);
        }catch(Exception){

        }
		string payment = GetEnumValue("payment_method", dr["payment_method"].ToString());
		string reference = dr["payment_ref"].ToString();
		string pid = dr["pid"].ToString();

		Response.Write("<tr");
		if(bAlterColor)
			Response.Write(" class=rowColor");
		bAlterColor = !bAlterColor;
		Response.Write(">");
		Response.Write("<td>" + idate + "</td>");
		Response.Write("<td><a href=");
		if(!bCardType(ref m_custID))
			Response.Write("invoice.aspx?" + invoice_number + "");
		else
			Response.Write("purchase.aspx?t=pp&n=" + pid + "");
		Response.Write(" class=o>" + invoice_number + "</a></td>");
		Response.Write("<td>" + po_number + "</td>");
		Response.Write("<td>" + MyDoubleParse(paidAmount).ToString("c") + "</td>");
		Response.Write("<td>" + _date_paid.ToString("dd-MM-yyyy") + "</td>");
		Response.Write("<td>" + payment + "</td>");
		Response.Write("<td>" + reference + "</td>");
		Response.Write("</tr>");
	}
	Response.Write("<tr><td>" + sPageIndex + "</td></tr>");
	Response.Write("</table>");
}

bool DoResetBalance()
{
	if(m_custID == null || m_custID == "")
		return false;

	string sc = " UPDATE card SET balance = " + m_dUnPaidTotal + " WHERE id = " + m_custID;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myCommand.Connection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

</script>

<form runat=server >
<asp:DataGrid id=MyDataGrid
	runat=server 
	AutoGenerateColumns=false
	BackColor=White 
	BorderWidth=0px 
	BorderStyle=Solid 
	BorderColor=#EEEEEE
	CellPadding=1
	CellSpacing=0
	Font-Name=Verdana 
	Font-Size=8pt 
	width=100% 
	style=fixed
	HorizontalAlign=center
	AllowPaging=True
	PageSize=20
	PagerStyle-PageButtonCount=10
	PagerStyle-Mode=NumericPages
	PagerStyle-HorizontalAlign=Left
    OnPageIndexChanged=MyDataGrid_PageA
	>

	<HeaderStyle CssClass=tableHeader ForeColor=White Font-Bold=true/>
	<ItemStyle ForeColor=DarkSlateBlue/>
	<AlternatingItemstyle CssClass=rowColor/>
    
	<Columns>
		<asp:HyperLinkColumn
			 HeaderText=ID
			 DataNavigateUrlField=ecard
			 DataNavigateUrlFormatString="{0}"
			 DataTextField=id/>
		<asp:HyperLinkColumn
			 HeaderText=Select
			 DataNavigateUrlField=uri
			 DataNavigateUrlFormatString="{0}"
			 DataTextField=name/>
		<asp:HyperLinkColumn
			 HeaderText="Trading Name"
			 DataNavigateUrlField=uri
			 DataNavigateUrlFormatString="{0}"
			 DataTextField=trading_name/>
		<asp:HyperLinkColumn
			 HeaderText=Company
			 DataNavigateUrlField=uri
			 DataNavigateUrlFormatString="{0}"
			 DataTextField=company/>
		<asp:BoundColumn HeaderText="Credit Term" DataField=credit_term DataFormatString="{0}"/>
		<asp:BoundColumn HeaderText="Credit Limit" DataField=credit_limit DataFormatString="{0:c}"/>
		<asp:BoundColumn HeaderText=Balance DataField=total_balance DataFormatString="{0:c}"/>
	</Columns>
</asp:DataGrid>

</form>

<asp:Label id=LFooter runat=server/>
