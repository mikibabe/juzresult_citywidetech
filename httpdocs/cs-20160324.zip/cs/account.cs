<script runat=server>
const string tableTitle = "Bank Account";
const string thisurl = "bankacc.aspx";

string m_sClass1 = "";
string m_sClass2 = "";
string m_sClass3 = "";
string m_sClass4 = "";
string m_sClass1New = "";
string m_sClass2New = "";
string m_sClass3New = "";
string m_sClass4New = "";
string m_sName1 = "";
string m_sName2 = "";
string m_sName3 = "";
string m_sName4 = "";
string m_sName1New = "";
string m_sName2New = "";
string m_sName3New = "";
string m_sName4New = "";
string m_account_id = "";
string m_retained_earning_account = "3221";

double m_dOtherIncome = 0;
double m_dOpenBal = 0;
double m_dBalance = 0;
double m_dSalesIncome = 0;
double m_dStockLost = 0;
double m_dSalesCost = 0;
double m_dFinance = 0;
double m_dCurrencyLoss = 0;
double m_dSalesFreight = 0;
double m_dPurchaseFreight = 0;
bool m_bActive = true;
bool m_bShowBalance = true;
bool m_bNoDeleteAccount = true;
bool m_bDebitAccountType = true;
bool m_bNewFinancialYear = false;

string m_branchID = "1";
string m_uri = "account.aspx"; //Request.ServerVariables["URL"] +"?"+ Request.ServerVariables["QUERY_STRING"];
int page = 1;
const int m_nPageSize = 15;	//how many rows in one page

string m_monthOfYTD = "4";
string m_HowManymonthOfYTD = "12";
string m_nextmonthfYTD = "5";
bool m_bCheckAccess = false;

DataSet dst = new DataSet();		//for creating Temp tables templated on an existing sql table
//=======================================================================================
void Page_Load(Object Src, EventArgs E)
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("accountant"))
		return;
	m_uri += "?r="+ DateTime.UtcNow.AddHours(12).ToOADate();
	m_bCheckAccess = bCheckAccessLevel(m_bCheckAccess);
	m_monthOfYTD = GetSiteSettings("month_of_financial_year", "4", false);
//DEBUG("m_monthofye =", m_monthOfYTD);
	m_HowManymonthOfYTD = GetSiteSettings("how_many_month_of_financial_year", "12", false);
//DEBUG("m_HowManymonthOfYTD =", m_HowManymonthOfYTD);
	if(!TSIsDigit(m_monthOfYTD))
		m_monthOfYTD = "4";
	if(int.Parse(m_monthOfYTD) <= 0 && int.Parse(m_monthOfYTD) > 12)
		m_monthOfYTD = "4";
	if(!TSIsDigit(m_HowManymonthOfYTD))
		m_HowManymonthOfYTD = "12";
	if(int.Parse(m_HowManymonthOfYTD) < 11 && int.Parse(m_HowManymonthOfYTD) > 15)
		m_HowManymonthOfYTD = "12";
	int nswapMonth = 0;

	if(Session["account_rp_session"] != null)   //clear session when back from account report.
		Session["account_rp_session"] = null;
	if(Request.QueryString["luri"] != null && Request.QueryString["luri"] != "")
		Session["luri_acc"] = Request.QueryString["luri"];

	for(int i=int.Parse(m_monthOfYTD); i<=int.Parse(m_HowManymonthOfYTD) + int.Parse(m_monthOfYTD); i++)
	{
		if(i>=12)
			nswapMonth++;
	}
	m_nextmonthfYTD = nswapMonth.ToString();

	if(m_nextmonthfYTD == int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")).ToString())
		m_bNewFinancialYear = true;
	
	DoQueryAccountID();
//DEBUG("m_bCheckAcces = ", m_bCheckAccess.ToString());

	Session["branch_support"] = null;
	if(Session["branch_support"] != null)
	{
		if(Request.Form["branch"] != null)
			m_branchID = Request.Form["branch"];
		else if(Request.QueryString["b"] != null && Request.QueryString["b"] != "")
			m_branchID = Request.QueryString["b"];
		else if(Session["branch_id"] != null)
			m_branchID = Session["branch_id"].ToString();
	}
	
	m_sClass1 = Request.QueryString["c"];
	m_sClass2 = Request.QueryString["c2"];
	m_sClass3 = Request.QueryString["c3"];
	m_sClass4 = Request.QueryString["c4"];
	if(m_sClass1 == null || m_sClass1 == "")
		m_sClass1 = "1";
	if(m_sClass2 == null || m_sClass2 == "")
		m_sClass2 = "1";
	if(m_sClass3 == null || m_sClass3 == "")
		m_sClass3 = "1";
	if(m_sClass4 == null || m_sClass4 == "")
		m_sClass4 = "1";

	if(m_sClass1 != "")
		m_uri += "&c="+m_sClass1;
	if(Session["branch_support"] != null)
	{
	if(m_branchID != "")
		m_uri += "&b=";
	}
/*	if(m_sClass2 != "")
		m_uri += "&c="+m_sClass2;
	if(m_sClass3 != "")
		m_uri += "&c="+m_sClass3;
	if(m_sClass4 != "")
		m_uri += "&c="+m_sClass4;
*/
	m_sClass1New = m_sClass1;
	m_sClass2New = m_sClass2;
	m_sClass3New = m_sClass3;
	m_sClass4New = m_sClass4;
	if(Request.QueryString["new_c"] != null && Request.QueryString["new_c"] != "")
		m_sClass1New = Request.QueryString["new_c"];
	if(Request.QueryString["new_c2"] != null && Request.QueryString["new_c2"] != "")
		m_sClass2New = Request.QueryString["new_c2"];
	if(Request.QueryString["new_c3"] != null && Request.QueryString["new_c3"] != "")
		m_sClass3New = Request.QueryString["new_c3"];
	if(Request.QueryString["new_c4"] != null && Request.QueryString["new_c4"] != "")
		m_sClass4New = Request.QueryString["new_c4"];

	PrintAdminHeader();
	PrintAdminMenu();

	string type = Request.QueryString["t"];
	string cmd = Request.Form["cmd"];
	string cur_acc="";

	if(Request.QueryString["luri"] != null && Request.QueryString["luri"] != "")
		Session["acc_l_uri"] = Request.QueryString["luri"];
	if(!GetCurrentAccounts(ref cur_acc))
	{
		type="e";
	}
	if(type == "m")
	{
		string ru = "account.aspx?t=e&edit=1&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4;
		ru += "&new_c=" + Request.QueryString["new_c"];
		ru += "&new_c2=" + Request.QueryString["new_c2"];
		ru += "&new_c3=" + Request.QueryString["new_c3"];
//		ru += "&new_c4=" + Request.QueryString["new_c4"];
		if(cmd == "Move")
		{
			if(DoMoveAccount())
			{
				ru = "account.aspx?t=m&c=" + m_sClass1New + "&c2=" + m_sClass2New;
				ru += "&c3=" + m_sClass3New + "&c4=" + m_sClass4New;
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=" + ru + "\">");
			}
		}
		else
		{
			DrawMoveTable();
		}
		return;
	}
	if(type == "e")
	{
		if(cmd == "Update")
		{
			if(DoUpdateAccount()) //false means update
			{
				string ru = "account.aspx?t=e&edit=1&c=" + m_sClass1 + "&c2=" + m_sClass2;
				ru += "&c3=" + m_sClass3 + "&c4=" + m_sClass4;
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=" + ru + "\">");
			}
			return;
		}
		else if(cmd == "Delete")
		{
			if(Request.Form["confirm_delete"] != "on")
			{
				Response.Write("<br><center><h3>Please tick confirm delete</h3>");
				Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
			}
			if(DoDeleteAccount()) 
				Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=account.aspx?c=" + m_sClass1 + "\">");
			return;
		}
		else if(cmd =="Add")
		{
			if(DoAddNewAccount())
			{
				Response.Write("<br><center><h3>New account added, please wait 1 second...</h3>");
				Response.Write("<meta http-equiv=\"refresh\" content=\"1; URL=account.aspx?c=" + m_sClass1 + "\">");
				return;
			}
		}
		else if(cmd =="Back")
		{
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=account.aspx\">");
		}
		else
		{
			if(Request.QueryString["edit"] == "1")
				DrawEditTable();
			else
				DrawAddNewTable();
		}
		
		return;
	}
	
	DrawBrowseTable();

	//PrintAdminFooter();
	LFooter.Text = m_sAdminFooter;

}

void DoQueryAccountID()
{
	string class1 = Request.QueryString["c"];
	//*** get total value *****
	GetCurrentSalesCost(0); // 0 = current year sales income
	double dsalescost = m_dSalesCost;
	double dsalesincome = m_dSalesIncome;
	double dliability = GetCurrentLiabilities();
	double dstockvalue = GetCurrentStockValue();	
	double dgstpaid = GetCurrenGSTPaid();
	double dgstcollect = GetCurrenGSTCollect();
	double dexpense = GetCurrenExpense(0);
	double ddebtor = GetCurrentTradeDebtor();
	double dCurrentYearEarning = dsalesincome - dsalescost + m_dCurrencyLoss + m_dFinance - m_dPurchaseFreight; // - dexpense;
//DEBUG("dcurrenteyare = ", dCurrentYearEarning);
//DEBUG("dsalesincome = ", dsalesincome);
//DEBUG("dsalescost = ", dsalescost);
	GetCurrentSalesCost(1); // 1 = previous year sales income
	double dretain_expense = GetCurrenExpense(1);

	double dretained_salescost = m_dSalesCost;
	double dretained_salesincome = m_dSalesIncome;
	double dRetainedYearEarning = dretained_salesincome - dretained_salescost + m_dCurrencyLoss + m_dFinance - m_dPurchaseFreight; // - dretain_expense;
	GetCurrentSalesCost(2);  // 2 = before previous year sales income
	double dhistory_expense = GetCurrenExpense(2);
	double dhistory_salescost = m_dSalesCost;
	double dhistory_salesincome = m_dSalesIncome;
	double dHistoryYearEarning = dhistory_salesincome - dhistory_salescost + m_dCurrencyLoss + m_dFinance - m_dPurchaseFreight; // - dhistory_expense;

	//*** end here ***
	
	if(class1 == "1" || (class1 == null) || class1 == "all")
	{
	//	m_account_id = GetSiteSettings("account_stock_on_hand", "1121", true);
	//	DoAccountBalanceUpdate(dstockvalue,m_account_id);

		m_account_id = GetSiteSettings("account_trade_debtors", "1411", true);
		DoAccountBalanceUpdate(ddebtor,m_account_id);
	}
	
	if(class1 == "2" || class1 == null || class1 == "all")
	{
		m_account_id = GetSiteSettings("account_trade_creditors", "2111", true);
		//DoAccountBalanceUpdate(dliability,m_account_id);

		m_account_id = GetSiteSettings("account_gst_collect", "2311", true);
		DoAccountBalanceUpdate(dgstcollect,m_account_id);

		m_account_id = GetSiteSettings("account_gst_paid", "2312", true);
		//DoAccountBalanceUpdate(dgstpaid,m_account_id);
	}
	
	if(class1 == "3" || class1 == null || class1 == "all")
	{
		m_account_id = GetSiteSettings("account_current_year_earning", "3211", true);
		DoAccountBalanceUpdate(dCurrentYearEarning,m_account_id);
		
		m_account_id = GetSiteSettings("account_retained_earning", "3221", true);
		m_retained_earning_account = m_account_id;
		DoAccountBalanceUpdate(dRetainedYearEarning,m_account_id);

		m_account_id = GetSiteSettings("account_historical_balancing", "3231", true);
		DoAccountBalanceUpdate(dHistoryYearEarning,m_account_id);
		
	}
	
/*	if(class1 == "4" || class1 == null || class1 == "all")
	{
		m_account_id = GetSiteSettings("account_sales_income", "4111", true);
		DoAccountBalanceUpdate(dsalesincome,m_account_id);
	}

	if(class1 == "5" || class1 == null || class1 == "all")
	{
//DEBUG("msae scost = ", dsalescost);
		m_account_id = GetSiteSettings("account_cost_of_sales", "5111", true);
//	DEBUG("m_accountid = ", m_account_id);
		DoAccountBalanceUpdate(dsalescost,m_account_id);
	}*/
	
}

bool DoAccountLog(double new_openbalance, double last_openbalance, ref string accountid)
{
	string sc = " INSERT INTO account_adjust_log (record_date, record_by, last_amount, new_amount, account_id) ";
	sc += " VALUES(getdate(), "+ Session["card_id"] +", "+ last_openbalance +", "+ new_openbalance +", '"+ accountid +"') ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}
bool DoAccountBalanceUpdate(double dbalance, string account_id)
{
	string sc =  " UPDATE account SET balance = " + dbalance +"";
	sc += " WHERE (class1 * 1000) + (class2 * 100) + (class3 * 10) + (class4) = "+ account_id +"";

	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

double GetCurrentStockValue()
{
	double dValue = 0;
	if(dst.Tables["stockvalue"] != null)
		dst.Tables["stockvalue"].Clear();
/*	string sc = " SET DATEFORMAT dmy SELECT ISNULL(SUM(DISTINCT pi.price * pi.qty - s.qty),0) AS total_stockvalue ";
	sc += " FROM code_relations c INNER JOIN ";
    sc += " stock_qty s ON s.code = c.code AND s.qty <> 0  JOIN ";
	sc += " purchase_item pi ON pi.code = s.code AND pi.code = c.code ";
	sc += " JOIN purchase p on p.id = pi.id and p.type = 4 ";
	sc += " WHERE (c.cat <> 'ServiceItem') ";
*/	
	string sc = " SET DATEFORMAT dmy SELECT ISNULL(SUM(sc.cost),0) AS total_stockvalue ";
	sc += " FROM code_relations c INNER JOIN ";
    sc += " stock_cost sc ON sc.code = c.code AND sc.instock = 1 ";
	sc += " WHERE (c.cat <> 'ServiceItem') ";
//	if(Session["branch_support"] != null)
//		sc += " AND s.branch_id = " + m_branchID;
	int rows = 0;
//DEBUG("sc =", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "stockvalue")==1)
			dValue = double.Parse(dst.Tables["stockvalue"].Rows[0][0].ToString());					
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}

	return dValue;
}

double GetCurrentSalesCost(int nYear)
{
	double dValue = 0;
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
//DEBUG("syear = ", syear);
if(dst.Tables["sales"] != null)
		dst.Tables["sales"].Clear();
	string sc = " SET DATEFORMAT dmy ";
	sc += " SELECT ";
	//income
	sc += " ( SELECT ISNULL(SUM(i.price),0) FROM invoice i JOIN orders o ON o.invoice_number = i.invoice_number ";
	sc += " WHERE 1=1 ";
	if(nYear == 0 )
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";   
//		sc += " AND DATEDIFF(year, i.commit_date, '1-"+ m_monthOfYTD +"-"+ syear +"' ) = 1 ";   
//		sc += " AND DATEDIFF(year, i.commit_date, '1-"+ m_monthOfYTD +"-"+ syear +"' ) > 1 ";   

	if(Session["branch_support"] != null)
		sc += " AND i.branch = " + m_branchID;
	sc += " ) ";
	sc += " AS sales_income ";

	//freight
	sc += ", ( SELECT isnull(SUM(i.freight),0) FROM invoice i JOIN orders o ON o.invoice_number = i.invoice_number ";
	sc += " WHERE 1=1 ";
	/*if(nYear)
		sc += " AND i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"' ";   
	else
		sc += " AND i.commit_date < '1-"+ m_monthOfYTD +"-"+ syear +"'";   
	*/
	if(nYear == 0 )
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";   

	if(Session["branch_support"] != null)
		sc += " AND i.branch = " + m_branchID;
	sc += ") ";
	sc += " AS freight ";

	//cost
	sc += ", ( SELECT isnull(SUM(c.supplier_price * c.quantity),0) FROM sales c JOIN invoice i ON c.invoice_number = i.invoice_number ";
	sc += " WHERE 1=1 ";
	/*if(nYear)
		sc += " AND i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"' ";   
	else
		sc += " AND i.commit_date < '1-"+ m_monthOfYTD +"-"+ syear +"' ";   
	*/
	if(nYear == 0 )
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";   
	if(Session["branch_support"] != null)
		sc += " AND i.branch = " + m_branchID;
	sc += ") ";
	sc += " AS sales_cost ";
	
	//stock loss
	sc += ", ( SELECT isnull(SUM(c.cost * c.qty),0) FROM stock_loss c JOIN stock_adj_log i ON c.id = i.id ";
	sc += " WHERE 1=1 ";
/*	if(nYear)
		sc += " AND i.log_time >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.log_time < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"' ";   
	else
		sc += " AND i.log_time < '1-"+ m_monthOfYTD +"-"+ syear +"' ";   
	*/
	if(nYear == 0 )
		sc += " AND (i.log_time >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.log_time < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (i.log_time >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND i.log_time < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND i.log_time < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";     
	if(Session["branch_support"] != null)
		sc += " AND i.branch_id = " + m_branchID;
	sc += ") ";
	
	sc += " AS stock_loss ";

		//currency_loss
	sc += ", ( SELECT isnull(SUM(td.currency_loss),0) FROM tran_detail td JOIN trans t ON t.id = td.id ";
	sc += " WHERE 1=1 ";
	if(nYear == 0 )
		sc += " AND (td.trans_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (td.trans_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";     
	if(Session["branch_support"] != null)
		sc += " AND t.branch = " + m_branchID;
	sc += ") ";	
	sc += " AS currencyloss ";

	//finance
	sc += ", ( SELECT isnull(SUM(td.finance),0) FROM tran_detail td JOIN trans t ON t.id = td.id ";
	sc += " WHERE 1=1 ";
	if(nYear == 0 )
		sc += " AND (td.trans_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (td.trans_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND td.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";     
	if(Session["branch_support"] != null)
		sc += " AND t.branch = " + m_branchID;
	sc += ") ";	
	sc += " AS finance ";

	//purchase freight
	sc += ", ( SELECT isnull(SUM(p.freight),0) FROM purchase p ";
	sc += " WHERE p.type = 4 ";
	if(nYear == 0 )
		sc += " AND (p.date_invoiced >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND p.date_invoiced < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (p.date_invoiced >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND p.date_invoiced < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND p.date_invoiced < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";     
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = " + m_branchID;
	sc += ") ";	
	sc += " AS purchase_freight ";

	//sales freight
	sc += ", ( SELECT isnull(SUM(i.freight),0) FROM invoice i ";
	sc += " WHERE 1=1 ";
	if(nYear == 0 )
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";     
	if(Session["branch_support"] != null)
		sc += " AND i.branch = " + m_branchID;
	sc += ") ";	
	sc += " AS sales_freight ";

//DEBUG("sc sales=", sc);
	double dsalescost = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "sales") > 0)
		{		
			double dfreight = double.Parse(dst.Tables["sales"].Rows[0]["freight"].ToString());
			m_dSalesIncome = double.Parse(dst.Tables["sales"].Rows[0]["sales_income"].ToString()) + dfreight;
				
			//double dStockloss = double.Parse(dst.Tables["sales"].Rows[0]["stock_loss"].ToString());
			m_dStockLost = double.Parse(dst.Tables["sales"].Rows[0]["stock_loss"].ToString());
//			DEBUG("stokc lost = ", m_dStockLost);
			m_dSalesCost = double.Parse(dst.Tables["sales"].Rows[0]["sales_cost"].ToString()) + m_dStockLost;
			m_dFinance = double.Parse(dst.Tables["sales"].Rows[0]["finance"].ToString()) + m_dStockLost;
			m_dCurrencyLoss = double.Parse(dst.Tables["sales"].Rows[0]["currencyloss"].ToString()) + m_dStockLost;
			m_dPurchaseFreight = double.Parse(dst.Tables["sales"].Rows[0]["purchase_freight"].ToString()) + m_dStockLost;
			m_dSalesFreight = double.Parse(dst.Tables["sales"].Rows[0]["sales_freight"].ToString()) + m_dStockLost;
		}
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return 0;
	}

	return dValue;
}


double GetCurrentTradeDebtor()
{
	if(dst.Tables["tradedebtor"] != null)
		dst.Tables["tradedebtor"].Clear();
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();

	double	dValue = 0;
	string sc  = " SET DATEFORMAT dmy SELECT DISTINCT ";
//	sc += " (SELECT ISNULL(SUM(amount - amount_applied), 0) ";
  //  sc += " FROM credit WHERE card_id = i.card_id) AS total_credit, ";
    sc += " (SELECT isnull(SUM(total - amount_paid), 0)  ";
    sc += " FROM invoice WHERE card_id = i.card_id) AS totaldue ";
	sc += " FROM invoice i JOIN card c ON c.id = i.card_id ";
	sc += " WHERE (total IS NOT NULL AND i.card_id IS NOT NULL) ";
	sc += " AND (i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND i.branch = "+ m_branchID +"";
	sc += " GROUP BY i.card_id ";
//	sc += " HAVING (SUM(i.total - i.amount_paid) > 0) ";
	sc += " ORDER BY totaldue desc ";
	int rows = 0;
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "tradedebtor");
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}

//	if(rows > 0)
	for(int i=0; i<rows; i++)
	{
		//double dcredit = double.Parse(dst.Tables["tradedebtor"].Rows[i]["total_credit"].ToString());
		dValue += double.Parse(dst.Tables["tradedebtor"].Rows[i]["totaldue"].ToString()); // - dcredit;
	}
	return dValue;
}

double GetCurrentLiabilities()
{
	if(dst.Tables["liability"] != null)
		dst.Tables["liability"].Clear();
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
	double dValue =0;
	string sc = "SET DATEFORMAT Dmy  SELECT ISNULL(sum((p.total_amount - p.amount_paid) / (Case  when CONVERT(money,s.value) = 0 then 1.00 else CONVERT(money,s.value) END)),0)  ";
	sc += " AS total_liability ";
	sc += " , ISNULL((SELECT sum(total) FROM expense WHERE ispaid = 0 ";
	if(Session["branch_support"] != null)
		sc += " AND branch = "+ m_branchID +"";
	sc += " ),0) AS total_unpaid_expense ";
	sc += " , ISNULL((SELECT sum(total-amount_paid) FROM assets WHERE 1=1 ";
//	sc += " , ISNULL((SELECT sum(total-amount_paid-tax) FROM assets WHERE 1=1 ";
	if(Session["branch_support"] != null)
		sc += " AND branch = "+ m_branchID +"";
	sc += " ),0) AS total_unpaid_assets ";
	sc += " , ISNULL((SELECT sum(amount-amount_applied) FROM credit ";
	//if(Session["branch_support"] != null)
	//	sc += " AND branch = "+ m_branchID +"";
	sc += " ),0) AS total_credit ";
	sc += " FROM purchase p join enum e ON e.id=p.currency AND e.class='currency' ";
	sc += " JOIN settings s ON s.name = 'exchange_rate_' + e.name ";
	sc += " WHERE p.type=4 AND p.payment_status=1 ";
	sc += " AND (p.date_invoiced >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND p.date_invoiced < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = "+ m_branchID +"";
	int rows = 0;
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "liability")==1)
		{
			dValue = double.Parse(dst.Tables["liability"].Rows[0][2].ToString()) + double.Parse(dst.Tables["liability"].Rows[0][0].ToString()) + double.Parse(dst.Tables["liability"].Rows[0][1].ToString()) + double.Parse(dst.Tables["liability"].Rows[0][3].ToString());
		}
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
//DEBUG("svae  =", dValue);
	return dValue;
	
}

double GetCurrentFinancialCharge()
{
	if(dst.Tables["financialcharge"] != null)
		dst.Tables["financialcharge"].Clear(); 
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
	double dValue =0;
	string sc = "SET DATEFORMAT Dmy SELECT (SELECT ISNULL(sum(t.finance) ,0)  ";
	sc += " FROM tran_detail t JOIN tran_invoice ti ON ti.tran_id = t.id ";
	sc += " WHERE  ti.purchase = 0 AND  (t.trans_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND t.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = "+ m_branchID +"";
	sc += " ) AS tsales ";
	
	sc += ", (SELECT ISNULL(sum(t.finance) ,0)  ";
	sc += " FROM tran_detail t JOIN tran_invoice ti ON ti.tran_id = t.id ";
	sc += " WHERE ti.purchase = 1 AND (t.trans_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND t.trans_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = "+ m_branchID +"";
	sc += " ) AS tpurchase , sum(finance) as finance ";
	sc += " FROM tran_detail ";
	int rows = 0;
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "financialcharge")==1)
		{
			dValue = double.Parse(dst.Tables["financialcharge"].Rows[0]["tsales"].ToString()) - double.Parse(dst.Tables["financialcharge"].Rows[0]["tpurchase"].ToString());
		}			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
//DEBUG("svae  =", dValue);
	return dValue;
	
}

double GetCurrenGSTPaid()
{
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
	double dValue = 0;
	if(dst.Tables["gst_paid"] != null)
		dst.Tables["gst_paid"].Clear();

	string sc = " SET DATEFORMAT dmy ";
    sc += "	SELECT isnull(SUM(p.tax / p.exchange_rate),0) ";
	sc += " AS tax, isnull(SUM(p.total / p.exchange_rate),0) AS total, isnull(SUM(p.total_amount / p.exchange_rate),0) AS total_amount ";
    sc += " FROM purchase p LEFT OUTER JOIN ";
	sc += " card c ON c.id = p.supplier_id ";
	sc += " WHERE p.date_received IS NOT NULL ";  //AND p.tax_date is NOT NULL ";
	sc += " AND (p.tax_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND p.tax_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND p.branch_id = "+ m_branchID +"";

	sc += " UNION ";
	sc += " SELECT isnull(SUM(ei.tax),0) , isnull(SUM(ei.total),0)  , isnull(SUM(e.total),0)  ";
	sc += " FROM expense e LEFT OUTER JOIN ";
	sc += " expense_item ei ON ei.id = e.id LEFT OUTER JOIN ";
	sc += " card c ON c.id = e.card_id LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = e.recorded_by INNER JOIN ";
	sc += " account a ON a.id = e.to_account ";
	sc += " WHERE (e.payment_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND e.payment_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND e.branch = "+ m_branchID +"";

/*	sc += " UNION ";
	sc += " SELECT ISNULL(SUM(ct.total_gst), 0) AS tax, 0 AS total, ISNULL(SUM(ct.total_gst), 0)  ";
	sc += " AS total_amount ";
	sc += " FROM custom_tax ct LEFT OUTER JOIN ";
	sc += " card c ON c.id = ct.payee LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = ct.recorded_by";
	sc += " WHERE (ct.statement_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND ct.statement_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND ct.branch = "+ m_branchID +"";
*/
	sc += " UNION ";
	sc += " SELECT ISNULL(SUM(a.tax), 0) AS tax, ISNULL(SUM(a.total), 0) AS total,  ";
	sc += " ISNULL(SUM(a.total), 0) AS total_amount ";
	sc += " FROM assets a LEFT OUTER JOIN ";
	sc += " card c ON c.id = a.card_id LEFT OUTER JOIN ";
	sc += " card c1 ON c1.id = a.recorded_by";
	sc += " WHERE (a.date_recorded >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND a.date_recorded < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(Session["branch_support"] != null)
		sc += " AND a.branch = "+ m_branchID +"";

	int rows = 0;
//DEBUG(" GST sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "gst_paid");
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
	for(int i=0; i<rows; i++)
		dValue += double.Parse(dst.Tables["gst_paid"].Rows[i][0].ToString());
	

	return dValue;
	
}

double GetCurrenExpense(int nYear)
{
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");

	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
//DEBUG("syear =", syear);
	double dValue = 0;
	if(dst.Tables["expense"] != null)
		dst.Tables["expense"].Clear();
	string sc = " SET DATEFORMAT dmy "; 
//	sc += " SELECT ISNULL(SUM(e.total - e.tax), 0) AS total  ";
	sc += " SELECT ISNULL(SUM(e.total), 0) AS total  ";
	sc += " FROM expense e JOIN ";
	sc += " account a ON a.id = e.to_account ";
	sc += " WHERE e.tax > 0 ";
	if(Session["branch_support"] != null)
		sc += " AND e.branch = "+ m_branchID +"";
	/*if(nYear)
		sc += " AND e.payment_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND e.payment_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"' ";   
	else
		sc += " AND e.payment_date < '1-"+ m_monthOfYTD +"-"+ syear +"' ";   
	*/
	if(nYear == 0 )
		sc += " AND (e.payment_date >= '1-"+ m_monthOfYTD +"-"+ syear +"' AND e.payment_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"') ";   
	if(nYear == 1)
		sc += " AND (e.payment_date >= '1-"+ m_monthOfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"' AND e.payment_date < '1-"+ m_nextmonthfYTD +"-"+ syear.ToString() +"') ";   
	if(nYear == 2)
		sc += " AND e.payment_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) - 1).ToString() +"'";    
	sc += " ORDER BY total DESC ";
	int rows = 0;
//DEBUG(" expense sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "expense")>0)
			dValue = double.Parse(dst.Tables["expense"].Rows[0][0].ToString());
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}
//	DEBUG("dsveal =", dValue.ToString());
	return dValue;
}
double GetCurrenGSTCollect()
{
	string syear = DateTime.UtcNow.AddHours(12).ToString("yyyy");
	if(int.Parse(m_monthOfYTD) <= int.Parse(DateTime.UtcNow.AddHours(12).ToString("MM")) && !m_bNewFinancialYear)
		syear = (int.Parse(syear) - 1).ToString();
	double dValue = 0;
	string sc = " SET DATEFORMAT dmy ";
    sc += " SELECT isnull(SUM(i.tax),0) AS gst_collect, isnull(SUM(i.total),0) AS total  ";
    sc += " FROM invoice i LEFT OUTER JOIN ";
    sc += " card c ON c.id = i.card_id ";
	sc += " WHERE   c.gst_rate <> 0 ";
	if(Session["branch_support"] != null)
		sc += " AND  i.branch = "+ m_branchID +" ";
	sc += " AND i.commit_date >= '1-"+ m_monthOfYTD +"-"+ syear +"'AND i.commit_date < '1-"+ m_nextmonthfYTD +"-"+ (int.Parse(syear) + 1).ToString() +"' ";   
	int rows = 0;
//DEBUG(" gst collect sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "gst_collect")>0)
			dValue = double.Parse(dst.Tables["gst_collect"].Rows[0][0].ToString());
			
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return 0;
	}

	return dValue;
	
}


//--------------------------------------------------------------------------------
void DrawBrowseTable()
{
	if(!GetAllTopClassAccount())
		return;
	
	string s = "";
	if(GetPartAccount(ref s))
		DrawTable(s);
	return;
}
//--------------------------------------------------------------------------------
bool GetAllTopClassAccount()
{
	string sc = "SELECT DISTINCT(class1), name1";
	sc += " FROM account ";
	sc += " ORDER BY class1, name1 ";//class2, class3, class4 ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "topclass") > 0)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return false;
}
//--------------------------------------------------------------------------------
bool DrawTable(string ACCNAME)
{
	Boolean bRet = true;
	//Table Tile
	//Response.Write("<br><center><h3>" + tableTitle + "</center></h3>");
	//Response.Write("<br><img border=0 src='../../i/ba.gif'>");
	Response.Write("<br><center><h4><b>CHART OF ACCOUNT</b></h4><p>");
	Response.Write("<b>for Current Year: "+ DateTime.UtcNow.AddHours(12).ToString("yyyy") +"<br>");
	if(Session["branch_support"] != null)
	{
		Response.Write("<br>Branch : </b>");
		PrintBranchNameOptions(m_branchID, m_uri); Response.Write("</center>");
	}
	//Class1 list
	DrawTopClassLink();
	//Account browse table starts

	DrawTableHeader(ACCNAME);
	//Account details
	DataRow dr;
	Boolean alterColor = true;

	double dTotalDebit = 0;
	double dTotalCredit = 0;
	
	for(int m=0; m<dst.Tables["partaccount"].Rows.Count; m++)
	{
	string titlelvl1 = dst.Tables["partaccount"].Rows[m]["class1"].ToString() + "000" + " - ";
	titlelvl1 += dst.Tables["partaccount"].Rows[m]["name1"].ToString();
	Response.Write("<tr><td colspan=5><b><font color=darkred>" + titlelvl1.ToUpper() + "</b></td></tr>");

	string class_flag = dst.Tables["partaccount"].Rows[m]["class1"].ToString();
	string id = "";
	if(!GetLevel2PartAccount(class_flag))
	{
		return false;
	}
	else
	{
		bool bAlter = true;
		for(int i=0; i<dst.Tables["lvl2PaAcc"].Rows.Count; i++)
		{
			dr = dst.Tables["lvl2PaAcc"].Rows[i];
			string class_flag2 = dr["class2"].ToString();
		
			Response.Write("<tr");
			if(bAlter)
				Response.Write(" bgcolor=#EEEEEE ");
			bAlter = !bAlter;
			Response.Write("><td colspan=5 ");
			Response.Write("><b>\t" + class_flag + class_flag2 + "00");
			//Response.Write("><b>&nbsp;&nbsp;&nbsp" + class_flag + class_flag2 + "00");
			Response.Write(" - " + dr["name2"].ToString() + "</b></td></tr>");

			if(!GetLevel3PartAccount(class_flag, class_flag2))
				return false;
			else
			{
				for(int j=0; j<dst.Tables["lvl3PaAcc"].Rows.Count; j++)
				{
					DataRow dr2 = dst.Tables["lvl3PaAcc"].Rows[j];
					string class_flag3 = dr2["class3"].ToString();
					Response.Write("<tr");
					if(bAlter)
						Response.Write(" bgcolor=#EEEEEe ");
					bAlter = !bAlter;
					Response.Write(" ><td colspan=5><b><blockquote>");
					//Response.Write(" ><td colspan=5><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp");
					Response.Write(class_flag + class_flag2 + class_flag3 + "0");
					Response.Write(" - " + dr2["name3"].ToString() + "</b></td></tr>");
										
					if(!GetLevel4PartAccount(class_flag, class_flag2, class_flag3))
						return false;
					else
					{
						for(int k=0; k<dst.Tables["lvl4PaAcc"].Rows.Count; k++)
						{
							DataRow dr3 = dst.Tables["lvl4PaAcc"].Rows[k];
							string acc = class_flag + class_flag2 + class_flag3 + dr3["class4"].ToString();
							string isdebit_acc = dr3["isdebit_acc"].ToString();

							id = dr3["id"].ToString();
							bool bShowBalance = MyBooleanParse(dr3["show_balance"].ToString());
							
							Response.Write("<tr");
							//if(bAlter)
							//	Response.Write(" bgcolor=#EEEEEE ");
							//bAlter = !bAlter;
							Response.Write("><td><blockquote><blockquote>");
							//Response.Write("><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp");
							//Response.Write("<a href="+ Request.ServerVariables["URL"] +"?t=e&a="+ class_flag +"");
							//Response.Write("&a2="+ class_flag2 +"&a3="+ class_flag3 +"&a4="+ dr3["class4"].ToString() +"");
							
							Response.Write("<a title='view account type report' href='acc_report.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&uri="+ HttpUtility.UrlEncode(Request.ServerVariables["URL"]) +"?"+ HttpUtility.UrlEncode(Request.ServerVariables["QUERY_STRING"]) +"&id="+ dr3["id"].ToString() +"' class=o>");
							Response.Write(acc + "</a> - ");
							Response.Write("<a title='change/edit account' href="+ Request.ServerVariables["URL"] +"?t=e&edit=1&c="+ class_flag +"");
							Response.Write("&c2="+ class_flag2 +"&c3="+ class_flag3 +"&c4="+ dr3["class4"].ToString() +"");
							Response.Write(" class=o>");
							Response.Write(dr3["name4"].ToString() + "</a>");
							Response.Write("&nbsp; </td>");
							Response.Write("<td>&nbsp;");
							Response.Write("</td>");
							/*Response.Write("<td><a title='View Transaction History' href=acc_report.aspx?id="+ id + "&date_time=1&r="+DateTime.UtcNow.AddHours(12).ToOADate()+" class=o target=_blank><font color=green>Trans_History</a>");
							Response.Write("</td>");
							*/
							string activity = dr3["active"].ToString();
							if(activity=="True")
								activity = "Active";
							else
								activity = "Inactive";
							//string balance = double.Parse(dr3["balance"].ToString()).ToString("c");
							double dbalance = double.Parse(dr3["balance"].ToString());
					
							/*if(dbalance < 0)
							{
								if(isdebit_acc.ToLower() == "false")
									isdebit_acc = "true";
								else
									isdebit_acc = "false";
							}
							*/
							string open_balance = double.Parse(dr3["opening_balance"].ToString()).ToString();
					//	DEBUG("open_balance ="+open_balance, "balcne ="+ dbalance);
						
						//	dbalance = dbalance + MyDoubleParse(open_balance);
						
						/*	//if(dr3["name4"].ToString().ToLower().IndexOf("trade creditors") >= 0)	
							if(acc == "2111")
								dbalance = dliability;
	
							if(acc == "3211")
								dbalance = dCurrentYearEarning;
							if(acc == "3221")
								dbalance = dRetainedYearEarning;
		
							//if(dr3["name4"].ToString().ToLower().IndexOf("sales income") >= 0)	
							if(acc == "4111")
								dbalance = m_dSalesIncome;
								
							//if(dr3["name4"].ToString().ToLower().IndexOf("cost of sales") >= 0)	
							if(acc == "5111")
								dbalance = dsalescost;
															
							//if(dr3["name4"].ToString().ToLower().IndexOf("trade debtors") >= 0)	
							if(acc == "1410")
								dbalance = ddebtor;
								
							//if(dr3["name4"].ToString().ToLower().IndexOf("stock on hand") >= 0)	
							if(acc == "1121")
								dbalance = dstockvalue;	
								
							//if(dr3["name4"].ToString().ToLower().IndexOf("gst paid") >= 0)
							if(acc == "2312")
								 dbalance = dgstpaid;
							
							if(acc == "2311")
								dbalance = dgstcollect;
	*/
					//		Response.Write("<td align=right>" + activity + "</td>");
							/*
							Response.Write("<td align=right>" + open_balance + "</td>");
							*/
							if(acc == "4112")
								dbalance = dbalance + GetCurrentFinancialCharge();
							if(MyBooleanParse(isdebit_acc))
							{
								Response.Write("<td align=right>" + dbalance.ToString("c") + "</td><td align=right>&nbsp;</td>");
								dTotalDebit += dbalance;
							}
							else
							{
								Response.Write("<td align=right>&nbsp;</td><td align=right>" + dbalance.ToString("c") + "</td></tr>");
								if(dr3["name4"].ToString().IndexOf("Cost") >= 0 || dr3["name4"].ToString().IndexOf("Income") >= 0)
									dTotalCredit = dTotalCredit;
								else
									dTotalCredit += dbalance;
				
							}
							/*if(bShowBalance)
								Response.Write("<td align=right>" + balance + "</td></tr>");
							else
								Response.Write("<td align=right>Check Transaction History</td></tr>");
							*/
							//Response.Write("<td align=right><a title='view current balance' href='acc_report.aspx?st="+ id +"&r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"' target=_blank class=o>View</a></td></tr>");
							
						}
						dst.Tables["lvl4PaAcc"].Clear();
					}
				}
		
				dst.Tables["lvl3PaAcc"].Clear();
			}
		}
		dst.Tables["lvl2PaAcc"].Clear();
	
	}
	}
	Response.Write("<tr ><th colspan=2 align=right valign=bottom><br><br></td>");
	Response.Write("</tr>");
	Response.Write("<tr bgcolor=#EEEEE ><th colspan=2 align=right><h5>SUB TOTAL: </td><th align=right><font color=green>"+ dTotalDebit.ToString("c") +"</td><th align=right><font color=red>"+ dTotalCredit.ToString("c") +"</td>");
	Response.Write("</tr>");
	//add new button
/*	
	Response.Write("<tr><td>");
	Response.Write("</td>");
	Response.Write("<td colspan=4 align=right>");
	Response.Write("<button onclick=\"window.location=('account.aspx?t=e&c="+ Request.QueryString["c"] +"')\" "+ Session["button_style"] +">Add New</button>");
	Response.Write("</td></tr>");
*/
	Response.Write("</table>\r\n");
	Response.Write("</form><br><br>");
	
	return true;
}
//--------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
bool GetLevel2PartAccount(string sflag)
{
	string sc = "SELECT DISTINCT class1, class2, name2 FROM account WHERE class1 =" + sflag;
	sc += " ORDER BY class1, class2 ";
//DEBUG("sc2 = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "lvl2PaAcc") > 0)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return false;
}

//--------------------------------------------------------------------------------

bool GetLevel3PartAccount(string flag1, string flag2)
{
	string sc = "SELECT DISTINCT class1, class2, class3, name3 FROM account ";
	sc += " WHERE (class1 = " + flag1 +") AND (class2 = " + flag2 +")";
	sc += " ORDER BY class1, class2, class3 ";
//DEBUG("sc3 =", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "lvl3PaAcc") > 0)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return false;
}

//--------------------------------------------------------------------------------
bool GetLevel4PartAccount(string flag1, string flag2, string flag3)
{
	string sc = "SELECT id, class1, class2, class3, class4, name4, active, (balance + opening_balance) AS balance, opening_balance, show_balance, isdebit_acc FROM account ";
	sc += "WHERE (class1 = " + flag1 +") AND (class2 = " + flag2 +") AND (class3 = " + flag3 + ")";
	sc += " ORDER BY class1, class2, class3, class4 ";
//DEBUG("sc4 = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "lvl4PaAcc") > 0)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return false;
}

//--------------------------------------------------------------------------------
string DrawTopClassLink()
{
	Response.Write("<form name=frm method=post>");
	Response.Write("<table width=96%  align=center valign=center cellspacing=0 cellpadding=1 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>\r\n");
	Response.Write("<tr>");
	Response.Write("<td>");
//	Response.Write("<input type=submit name=cmd value='New Finance Year'  "+ Session["button_style"] +" >");
	Response.Write("<input type=button onclick=\"window.location=('account.aspx?t=e&c="+ Request.QueryString["c"] +"')\"  class=addNewButton  value='Add New'>");
	Response.Write("<input type=button onclick=\"window.location=('transfer.aspx?luri="+ HttpUtility.UrlEncode(Request.ServerVariables["URL"] +"?"+ Request.ServerVariables["QUERY_STRING"]) +"')\"  class=transferMoneyButton  value='Transfer Money'>");
	Response.Write("<input type=button onclick=\"window.location=('acc_report.aspx?luri="+ HttpUtility.UrlEncode(Request.ServerVariables["URL"] +"?"+ Request.ServerVariables["QUERY_STRING"]) +"')\"  class=accountReportButton  value='Account Report'>");
	Response.Write("</td>");
	if(Session["luri"] != null)
		Session["luri"] = null;

	Response.Write("<td width=100% align=right>");
	string sname = "";
	Response.Write("<b>SELECT ACC:</b> <select name=slt_type onchange=\"window.location=('"+Request.ServerVariables["URL"]+"?");
	if(Request.QueryString["t"] != "" && Request.QueryString["t"] != null)
		Response.Write("t="+ Request.QueryString["t"] +"&");
	//if(Request.QueryString["b"] != "" && Request.QueryString["t"] != null)
	if(Session["branch_support"] != null)
	{
	if(m_branchID != "")
		Response.Write("b="+ m_branchID +"&");
	}
	Response.Write("c='+this.options[this.selectedIndex].value)\" >\r\n");
	//if(Request.QueryString["t"] != "" && Request.QueryString["t"] != null)
		Response.Write(" <option value='all'>ALL</option>");
	for(int i=0; i<dst.Tables["topclass"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["topclass"].Rows[i];
		Response.Write("<option value=" + dr["class1"].ToString() + "");
		if(Request.QueryString["c"] == dr["class1"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name1"].ToString();
		}
		Response.Write(">" + dr["name1"].ToString() + "</option>");
		//Response.Write("<a href=account.aspx?c=" + dr["class1"].ToString() + ">" + dr["name1"].ToString() + "</a>&nbsp;&nbsp;");
		
	
//DEBUG("Rows=", i);	
	}

	Response.Write("</select>");
	Response.Write("</td></tr>");
	Response.Write("</table>");
	//Response.Write("</form>");
	return sname;
}

string DrawSecondClassLink()
{
	string class2 = "";
	string class1 = "";
	if(Request.QueryString["c"] != "" && Request.QueryString["c"] != null)
		class1 = Request.QueryString["c"];
	if(Request.QueryString["c2"] != "" && Request.QueryString["c2"] != null)
		class2 = Request.QueryString["c2"];

	string sc = "SELECT DISTINCT(class2), name2";
	sc += " FROM account ";
	if(class1 != "" && class1 != "all")
		sc += " WHERE class1 = "+ class1 +" ";
	//if(class2 != "" && class2 != "all")
	//	sc += " AND class2 = "+ class2 +" ";
	sc += " ORDER BY class2, name2";
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "secondclass");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		//return;
	}

	string sname = "";
	Response.Write("<form name=frm method=post>");
	//Response.Write("<table width=96%  align=center valign=center cellspacing=0 cellpadding=1 border=1 bordercolor=#EEEEEE bgcolor=white");
	//Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	//Response.Write("<tr class=tableHeader>\r\n");
	//Response.Write("<tr><td>");
	Response.Write("<div align=right>");
	Response.Write("<select name=slt_type onchange=\"window.location=('"+Request.ServerVariables["URL"]+"?");
	if(Request.QueryString["t"] != "" && Request.QueryString["t"] != null)
		Response.Write("t="+ Request.QueryString["t"] +"&");
	if(Request.QueryString["c"] != "" && Request.QueryString["c"] != null)
		Response.Write("c="+ Request.QueryString["c"] +"&");
	Response.Write("c2='+this.options[this.selectedIndex].value)\" >\r\n");
	Response.Write(" <option value='all'>ALL</option>");
	for(int i=0; i<dst.Tables["secondclass"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["secondclass"].Rows[i];
		Response.Write("<option value=" + dr["class2"].ToString() + "");
		if(Request.QueryString["c2"] == dr["class2"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name2"].ToString();
		}
		Response.Write(">" + dr["name2"].ToString() + "</option>");

	}
	Response.Write("</select>");
	Response.Write("</div>");
	//Response.Write("</td></tr>");
	//Response.Write("</table>");
	return sname;
}
string DrawThirdClassLink()
{
	string class2 = "";
	string class1 = "";
	string class3 = "";
	if(Request.QueryString["c"] != "" && Request.QueryString["c"] != null)
		class1 = Request.QueryString["c"];
	if(Request.QueryString["c2"] != "" && Request.QueryString["c2"] != null)
		class2 = Request.QueryString["c2"];
	if(Request.QueryString["c3"] != "" && Request.QueryString["c3"] != null)
		class3 = Request.QueryString["c3"];
	string sc = "SELECT DISTINCT(class3), name3";
	sc += " FROM account "; 
	if(class1 != "" && class1 != "all")
		sc += " WHERE class1 = "+ class1 +" ";
	if(class2 != "" && class2 != "all")
		sc += " AND class2 = "+ class2 +" ";
	//if(class3 != "" && class3 != "all")
	//	sc += " AND class3 = "+ class3 +" ";
	sc += " ORDER BY class3, name3";
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "thirdclass");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		//return;
	}
	
	string sname = "";
	Response.Write("<form name=frm method=post>");
	//Response.Write("<table width=96%  align=center valign=center cellspacing=0 cellpadding=1 border=1 bordercolor=#EEEEEE bgcolor=white");
	//Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	//Response.Write("<tr><td>");
	Response.Write("<div align=right>");
	Response.Write("<select name=slt_type onchange=\"window.location=('"+Request.ServerVariables["URL"]+"?");

	if(Request.QueryString["t"] != "" && Request.QueryString["t"] != null)
		Response.Write("t="+ Request.QueryString["t"] +"&");
	if(Request.QueryString["edit"] != null && Request.QueryString["edit"] != "")
		Response.Write("edit=1");
	if(Request.QueryString["c"] != "")
		Response.Write("c="+ Request.QueryString["c"] +"&");
	if(Request.QueryString["c2"] != "")
		Response.Write("c2="+ Request.QueryString["c2"] +"&");
	Response.Write("c3='+this.options[this.selectedIndex].value)\" >\r\n");
	Response.Write(" <option value='all'>ALL</option>");
	for(int i=0; i<dst.Tables["thirdclass"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["thirdclass"].Rows[i];
		Response.Write("<option value=" + dr["class3"].ToString() + "");
		if(Request.QueryString["c3"] == dr["class3"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name3"].ToString();
		}
		
		Response.Write(">" + dr["name3"].ToString() + "</option>");
		
	}
	Response.Write("</select>");
	Response.Write("</div>");
	//Response.Write("</td></tr>");
	//Response.Write("</table>");
	return sname;
}

string DrawForthClassLink()
{
	string class2 = "";
	string class1 = "";
	string class3 = "";
	string class4 = "";
	string sname = "";
	if(Request.QueryString["c"] != "" && Request.QueryString["c"] != null)
		class1 = Request.QueryString["c"];
	if(Request.QueryString["c2"] != "" && Request.QueryString["c2"] != null)
		class2 = Request.QueryString["c2"];
	if(Request.QueryString["c3"] != "" && Request.QueryString["c3"] != null)
		class3 = Request.QueryString["c3"];
	if(Request.QueryString["c4"] != "" && Request.QueryString["c4"] != null)
		class4 = Request.QueryString["c4"];

	string sc = "SELECT DISTINCT(class4), name4 ";
	sc += " FROM account "; 
	if(class1 != "" && class1 != "all")
		sc += " WHERE class1 = "+ class1 +" ";
	if(class2 != "" && class2 != "all")
		sc += " AND class2 = "+ class2 +" ";
	if(class3 != null && class3 != "" && class3 != "all")
		sc += " AND class3 = "+ class3 +" ";
	//if(class4 != "" && class4 != "all")
	//	sc += " AND class4 = "+ class4 +" ";
	sc += " ORDER BY class4, name4";
//DEBUG(" sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "forthclass");
//DEBUG("rows=", rows);
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		//return;
	}

	Response.Write("<form name=frm method=post>");
	Response.Write("<select name=slt_type onchange=\"window.location=('"+Request.ServerVariables["URL"]+"?");
	if(Request.QueryString["t"] != "" && Request.QueryString["t"] != null)
		Response.Write("t="+ Request.QueryString["t"] +"&");
	if(Request.QueryString["c"] != "")
		Response.Write("c="+ Request.QueryString["c"] +"&");
	if(Request.QueryString["c2"] != "")
		Response.Write("c2="+ Request.QueryString["c2"] +"&");
	if(Request.QueryString["c3"] != "")
		Response.Write("c3="+ Request.QueryString["c3"] +"&");
	Response.Write("c4='+this.options[this.selectedIndex].value)\" >\r\n");
	Response.Write(" <option value='all'>ALL</option>");
	for(int i=0; i<dst.Tables["forthclass"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["forthclass"].Rows[i];
		Response.Write("<option value=" + dr["class4"].ToString() + "");
		if(Request.QueryString["c4"] == dr["class4"].ToString())
		{
			sname = dr["name4"].ToString();
			Response.Write(" selected ");
		}
		Response.Write(">" + dr["name4"].ToString() + "</option>");
		
	}
	Response.Write("</select>");
	Response.Write("</div>");
	//Response.Write("</td></tr>");
	//Response.Write("</table>");
	return sname;
}

//--------------------------------------------------------------------------------
void DrawTableHeader(string ACCNAME)
{

	Response.Write("<table width=96%  align=center valign=center cellspacing=0 cellpadding=2 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:Solid;border-collapse:collapse;fixed\">");
	
	//Response.Write("<tr style=\"color:white;background-color:#666698;font-weight:bold;\">\r\n");
	Response.Write("<tr><td colspan=5><hr size=1 color=black></td></tr>");
	Response.Write("<tr>");
	Response.Write("<th align=left>&nbsp;&nbsp;ACCOUNT NAME - ");
	if(Request.QueryString["c"] == "all" || Request.QueryString["c"] == "")
		Response.Write("ALL");
	else
	Response.Write(ACCNAME.ToUpper());
	Response.Write("</td><td></td><th align=right>DEBIT</td><th align=right>CREDIT</td></tr>");
	Response.Write("<tr><td colspan=5><hr size=1 color=black></td></tr>");
/*	Response.Write("</td><td></td><th align=right>STATUS</td><th align=right>OPEN BALANCE</td><th align=right>CURRENT BALANCE</td></tr>");
	Response.Write("<tr><td colspan=5><hr size=1 color=black></td></tr>");
*/
//	DEBUG("accname=", ACCNAME);
	//Response.Write("</table>");

}

//--------------------------------------------------------------------------------
bool GetPartAccount(ref string ACCNAME)
{	//Get sub class accounts under selected 'class1' //HG 13.Aug.2002	
	string class1 = "";

	if(Request.QueryString["c"] != null)
		class1 = Request.QueryString["c"];
	string sc = "SELECT DISTINCT name1, class1 ";

	sc += " FROM account  ";

	if(class1 != "" && class1 != "all")
	{
		sc += " WHERE class1=" + class1 + " ";
//		sc += " ORDER BY class2, class3, class4";
	}
	sc += " ORDER BY class1 ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "partaccount") > 0)
		{
			ACCNAME = dst.Tables["partaccount"].Rows[0]["name1"].ToString();
			return true;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e); 
		return false;
	}
	return false;
}
//--------------------------------------------------------------------------------
bool GetCurrentAccounts(ref string cur_acc)
{
	string sc = "SELECT * FROM account ";
	sc += " WHERE 1=1 ";
	if(Request.QueryString["c"] != null && Request.QueryString["c"] != "" && Request.QueryString["c"] != "all")
		sc += " AND class1 = "+ Request.QueryString["c"];
	if(Request.QueryString["c2"] != null && Request.QueryString["c2"] != "" && Request.QueryString["c2"] != "all")
		sc += " AND class2 = "+ Request.QueryString["c2"];
	if(Request.QueryString["c3"] != null && Request.QueryString["c3"] != "" && Request.QueryString["c3"] != "all")
		sc += " AND class3 = "+ Request.QueryString["c3"];
	//if(Request.QueryString["c4"] != null && Request.QueryString["c4"] != "" && Request.QueryString["c4"] != "all")
	//	sc += " AND class4 = "+ Request.QueryString["c4"];

	sc += " GROUP BY id, class1, class2, class3, class4, name1, name2, name3, ";
	sc += " name4, active, opening_balance, balance, branch_id , show_balance, nodelete, isdebit_acc ";
	sc += " ORDER BY class1, class2, class3, class4 ";
//DEBUG("sc = ",sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "allaccount");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	int irows = dst.Tables["allaccount"].Rows.Count;
	if(irows > 0)
	{
		cur_acc = dst.Tables["allaccount"].Rows[0]["name1"].ToString();
		return true;
	}
	else
		return false;	
}

bool CheckClass4()
{
	if(dst.Tables["checkclass4"] != null)
		dst.Tables["checkclass4"].Clear();

	int nRows = 0;
	string sc = " SELECT class4 FROM account ";
	sc += " WHERE class1 = " + m_sClass1New;
	sc += " AND class2 = " + m_sClass2New;
	sc += " AND class3 = " + m_sClass3New;
	sc += " ORDER BY class4 ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		nRows = myAdapter.Fill(dst, "checkclass4");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	string next_number = "1";
	for(int i=1; i<=nRows; i++)
	{
		DataRow dr = dst.Tables["checkclass4"].Rows[i-1];
		int nNumber = MyIntParse(dr["class4"].ToString());
		if(nNumber > i)
		{
			next_number = (nNumber - 1).ToString();
			break;
		}
		if(i == nRows)
			next_number = (nNumber + 1).ToString();
//DEBUG("i="+i.ToString(), "number="+nNumber.ToString());
	}

	m_sClass4New = next_number;
	return true;
}

bool GetNewClassNames()
{
	if(dst.Tables["getnewclassname"] != null)
		dst.Tables["getnewclassname"].Clear();

	string sc = " SELECT TOP 1 * FROM account ";
	sc += " WHERE class1 = " + m_sClass1New;
	sc += " AND class2 = " + m_sClass2New;
	sc += " AND class3 = " + m_sClass3New;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "getnewclassname") <= 0)
		{
//DEBUG("sc=", sc);
			Response.Write("<h3>Error detination class not found, please try again.</h3>");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	DataRow dr = dst.Tables["getnewclassname"].Rows[0];
	m_sName1New = dr["name1"].ToString();
	m_sName2New = dr["name2"].ToString();
	m_sName3New = dr["name3"].ToString();

	//check duplicates for name4
	for(int i=0; i<dst.Tables["getnewclassname"].Rows.Count; i++)
	{
		dr = dst.Tables["getnewclassname"].Rows[i];
		string name = dr["name4"].ToString();
		if(name == m_sName4) //already had a class4 called this name?
		{
			Response.Write("<br><br><center><h4>Error, the destination class already have an entry called " + m_sName4 + ", please change the name first or delete this class</h4>");
			Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
			return false;
		}
	}
	return true;
}

bool DoMoveAccount()
{
	m_sClass1New = Request.Form["class1"];
	m_sClass2New = Request.Form["class2"];
	m_sClass3New = Request.Form["class3"];

	if(m_sClass1 == m_sClass1New	&& m_sClass2 == m_sClass2New	&& m_sClass3 == m_sClass3New)
		return true; //no changes

	if(!CheckClass4())
		return false;

	if(!GetNewClassNames())
		return false;

	string sc = " UPDATE account SET ";
	sc += " class1 = " + m_sClass1New;
	sc += ", class2 = " + m_sClass2New;
	sc += ", class3 = " + m_sClass3New;
	sc += ", class4 = " + m_sClass4New;
	sc += ", name1 = '" + EncodeQuote(m_sName1New) + "' ";
	sc += ", name2 = '" + EncodeQuote(m_sName2New) + "' ";
	sc += ", name3 = '" + EncodeQuote(m_sName3New) + "' ";
	sc += " WHERE class1 = " + m_sClass1;
	sc += " AND class2 = " + m_sClass2;
	sc += " AND class3 = " + m_sClass3;
	sc += " AND class4 = " + m_sClass4;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool DoUpdateAccount()
{
	if(Request.Form["sName1"] != "")
	{
		if(!DoChangeClassName(1))
			return false;
	}
	if(Request.Form["sName2"] != "")
	{
		if(!DoChangeClassName(2))
			return false;
	}
	if(Request.Form["sName3"] != "")
	{
		if(!DoChangeClassName(3))
			return false;
	}
	if(Request.Form["sName4"] != "")
	{
		if(!DoChangeClassName(4))
			return false;
	}

	m_dOpenBal = MyMoneyParse(Request.Form["opening_balance"]);
	double dOpenBalOld = MyMoneyParse(Request.Form["opening_balance_old"]);
string accountid = m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4;
if(m_dOpenBal != dOpenBalOld)
	DoAccountLog(m_dOpenBal, dOpenBalOld, ref accountid);

	string sIsDebitAcc = "1";
	sIsDebitAcc = Request.Form["acc_type"];

	string sActive = "1";
	if(Request.Form["active"] != "on")
		sActive = "0";
	string sShowbalance = "1";
	if(Request.Form["showbalance"] != "on")
		sShowbalance = "0";
	string nodelete = Request.Form["nodelete"];

	if(nodelete == "on")
		nodelete = "1";
	else
		nodelete = "0";

	string sc = " BEGIN TRANSACTION UPDATE account SET ";
	sc += " opening_balance = " + m_dOpenBal;
//	if(m_dOpenBal != dOpenBalOld)e
//		sc += ", balance = balance + " + (m_dOpenBal - dOpenBalOld).ToString();

	sc += ", active = " + sActive;
	if(m_bCheckAccess)
		sc += ", show_balance = " + sShowbalance;
	sc += ", isdebit_acc = "+ sIsDebitAcc;
	if(nodelete != "")
		sc += ", nodelete = "+ nodelete +"";
	sc += " WHERE class1 = " + m_sClass1;
	sc += " AND class2 = " + m_sClass2;
	sc += " AND class3 = " + m_sClass3;
	sc += " AND class4 = " + m_sClass4;

//	if(m_dOpenBal > 0 || m_dOpenBal < 0)
	if(m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4 != m_retained_earning_account)
	{
		sc += " UPDATE account SET opening_balance = opening_balance ";
		if(m_dOpenBal < 0)
			sc += " + ";
		if(m_dOpenBal >= 0)
			sc += " - ";
		sc += m_dOpenBal;
		sc += " WHERE (class1 * 1000)+ (class2 * 100) + (class3 * 10) + (class4) = "+ m_retained_earning_account + " ";
	}

	sc += " COMMIT ";
//DEBUG("sc = ", sc);	
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool ClassNameOK(int nClass)
{
	string sc = "";
	if(nClass == 1)
	{
		sc = " SELECT * FROM account WHERE name1 = '" + m_sName1 + "' ";
	}
	else if(nClass == 2)
	{
		sc = " SELECT * FROM account WHERE class1 = " + m_sClass1;
		sc += " AND name2 = '" + m_sName2 + "' ";
	}
	else if(nClass == 3)
	{
		sc = " SELECT * FROM account WHERE class1 = " + m_sClass1 + " AND class2 = " + m_sClass2;
		sc += " AND name3 = '" + m_sName3 + "' ";
	}
	else
	{
		sc = " SELECT * FROM account WHERE class1 = " + m_sClass1 + " AND class2 = " + m_sClass2;
		sc += " AND class3 = " + m_sClass3 + " AND name4 = '" + m_sName4 + "' ";
	}
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "classnameexits") > 0)
			return false;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetNextClass(int nClass)
{
	if(dst.Tables["getnextclass"] != null)
		dst.Tables["getnextclass"].Clear();

	int nRows = 0;
	string next_number = "1";
	string sc = "";
	if(nClass == 1)
	{
		sc = " SELECT DISTINCT class1 AS next_number FROM account ";
		sc += " ORDER BY class1 ";
	}
	else if(nClass == 2)
	{
		sc = " SELECT DISTINCT class2 AS next_number FROM account ";
		sc += " WHERE class1 = " + m_sClass1;
		sc += " ORDER BY class2 ";
	}
	else if(nClass == 3)
	{
		sc = " SELECT DISTINCT class3 AS next_number FROM account ";
		sc += " WHERE class1 = " + m_sClass1;
		sc += " AND class2 = " + m_sClass2;
		sc += " ORDER BY class3 ";
	}
	else
	{
		sc = " SELECT DISTINCT class4 AS next_number FROM account ";
		sc += " WHERE class1 = " + m_sClass1;
		sc += " AND class2 = " + m_sClass2;
		sc += " AND class3 = " + m_sClass3;
		sc += " ORDER BY class4 ";
	}
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		nRows = myAdapter.Fill(dst, "getnextclass");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(nRows >= 9 && nClass != 4)
	{
		Response.Write("<br><center><h3>Error, class " + nClass.ToString() + " is full.</h3>");
		return false;
	}
	for(int i=1; i<=nRows; i++)
	{
		DataRow dr = dst.Tables["getnextclass"].Rows[i-1];
		int nNumber = MyIntParse(dr["next_number"].ToString());
		if(nNumber > i)
		{
			next_number = (nNumber - 1).ToString();
			break;
		}
		if(i == nRows)
			next_number = (nNumber + 1).ToString();
//DEBUG("i="+i.ToString(), "number="+nNumber.ToString());
	}

	switch(nClass)
	{
	case 1:
		m_sClass1 = next_number;
		break;
	case 2:
		m_sClass2 = next_number;
		break;
	case 3:
		m_sClass3 = next_number;
		break;
	case 4:
		m_sClass4 = next_number;
		break;
	default:
		break;
	}
	return true;
}

bool DoAddNewAccount()
{
	m_sClass1 = Request.Form["class1"];
	m_sClass2 = Request.Form["class2"];
	m_sClass3 = Request.Form["class3"];
	m_sClass4 = Request.Form["class4"];

	m_sName1 = EncodeQuote(Request.Form["sname1"]);
	m_sName2 = EncodeQuote(Request.Form["sname2"]);
	m_sName3 = EncodeQuote(Request.Form["sname3"]);
	m_sName4 = EncodeQuote(Request.Form["sname4"]);
	m_dOpenBal = MyMoneyParse(Request.Form["opening_balance"]);
	string sActive = "1";
	if(Request.Form["active"] != "on")
		sActive = "0";
	string sIsDebitAcc = "1";
	sIsDebitAcc = Request.Form["acc_type"];

	if(m_sClass1 == "9999" && m_sName1 == "")
	{
		Response.Write("<br><br><center><h3>Please enter 1st class name</h3>");
		Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
		return false;
	}
	if(m_sClass2 == "9999" && m_sName2 == "")
	{
		Response.Write("<br><br><center><h3>Please enter 2nd class name</h3>");
		Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
		return false;
	}
	if(m_sClass3 == "9999" && m_sName3 == "")
	{
		Response.Write("<br><br><center><h3>Please enter 3rd class name</h3>");
		Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
		return false;
	}
	if(m_sClass4 == "9999" && m_sName4 == "")
	{
		Response.Write("<br><br><center><h3>Please enter 4th class name</h3>");
		Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
		return false;
	}

	if(m_sClass1 == "9999") //new
	{
		if(ClassNameOK(1))
		{
			if(!GetNextClass(1))
				return false;
		}
		else
		{
			Response.Write("<br><center><h3>Error, this 1st class name \"" + m_sName1 + "\" already exists.</h3>");
			return false;
		}
	}
	else
	{
		m_sName1 = Request.Form["selected_name1"];
	}

	if(m_sClass2 == "9999")
	{
		if(ClassNameOK(2))
		{
			if(!GetNextClass(2))
				return false;
		}
		else
		{
			Response.Write("<br><center><h3>Error, this 2nd class name \"" + m_sName2 + "\" already exists.</h3>");
			return false;
		}
	}
	else //no new name2
	{
		m_sName2 = Request.Form["selected_name2"];
	}

	if(m_sClass3 == "9999")
	{
		if(ClassNameOK(3))
		{
			if(!GetNextClass(3))
				return false;
		}
		else
		{
			Response.Write("<br><center><h3>Error, this 3rd class name \"" + m_sName3 + "\" already exists.</h3>");
			return false;
		}
	}
	else //now new name3
	{
		m_sName3 = Request.Form["selected_name3"];
	}

	if(m_sClass4 == "9999")
	{
		if(ClassNameOK(4))
		{
			if(!GetNextClass(4))
				return false;
		}
		else
		{
			Response.Write("<br><center><h3>Error, this 4th class name \"" + m_sName4 + "\" already exists.</h3>");
			return false;
		}
	}

	string sc = "";
	sc += " INSERT INTO account (class1, class2, class3, class4 ";
	sc += ", name1, name2, name3, name4, opening_balance, balance, active, isdebit_acc) VALUES (";
	sc += m_sClass1 + ", " + m_sClass2 + ", " + m_sClass3 + ", " + m_sClass4;
	sc += ", '" + m_sName1 + "', '" + m_sName2 + "', '" + m_sName3 + "', '" + m_sName4 + "'";
	sc += ", " + m_dOpenBal + ", " + m_dOpenBal + ", " + sActive + ", "+ sIsDebitAcc +") ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

//-----------------------------------------------------------------------------------------------------
bool DoUpdateAccount_old(bool bIsNew)
{
	string sName1 = EncodeQuote(Request.Form["eName1"]);
	string sName2 = EncodeQuote(Request.Form["eName2"]);
	string sName3 = EncodeQuote(Request.Form["eName3"]);
	string sName4 = EncodeQuote(Request.Form["eName4"]);
	string sName1_old = EncodeQuote(Request.Form["eName1_old"]);
	string sName2_old = EncodeQuote(Request.Form["eName2_old"]);
	string sName3_old = EncodeQuote(Request.Form["eName3_old"]);
	string sName4_old = EncodeQuote(Request.Form["eName4_old"]);
	string sClass1 = Request.Form["eClass1"];
	string sClass2 = Request.Form["eClass2"];
	string sClass3 = Request.Form["eClass3"];
	string sClass4 = Request.Form["eClass4"];
	string sClass1_old = Request.Form["sClass1_old"];
	string sClass2_old = Request.Form["sClass2_old"];
	string sClass3_old = Request.Form["sClass3_old"];
	string sClass4_old = Request.Form["sClass4_old"];

	//string sOpenBal = Request.Form["eOpenBal"];
	string sBalance = Request.Form["eBalance"];


//	double dBalance = double.Parse(sBalance, NumberStyles.Currency, null);

	int iActivity;
	//string branch = Request.Form["branch"];

	if(Request.Form["eActive"] == "on")
		iActivity = 1;
	else
		iActivity = 0;

	bool bUpdateClassNumber = false;
	if(sClass1 != sClass1_old || sClass2 != sClass2_old || sClass3 != sClass3_old || sClass4 != sClass4_old)
		bUpdateClassNumber = true;

	string sc = "";
	if(bIsNew || bUpdateClassNumber)
	{
		if(ClassExists(sClass1, sClass2, sClass3, sClass4))
		{
			//Response.Write("<h3>ERROR, This Account <font color=red>");
			//Response.Write(sClass1 + sClass2 + sClass3 + sClass4 +"</font> ALREADY EXISTS</h3>");
			string stext = "ERROR, This Account: "+ sClass1 + sClass2 + sClass3 + sClass4 +" ALREADY EXISTS ";
			Response.Write("<script language=javascript>window.alert('"+ stext +"'); window.history.go(-1);</script");
			Response.Write(">");
			return false;
		}
		else if(sClass1 + sClass2 + sClass3 + sClass4 == "0000")
		{
			//Response.Write("<h3>ERROR, This Account <font color=red>");
			//Response.Write(sClass1 + sClass2 + sClass3 + sClass4 +"</font> IS NOT VALID!</h3>");
			string stext = "ERROR, This Account: "+ sClass1 + sClass2 + sClass3 + sClass4 +" IS NOT VALID! ";
			Response.Write("<script language=javascript>window.alert('"+ stext +"'); window.history.go(-1);</script");
			Response.Write(">");
			return false;
		}
	}
	
	if(bIsNew)
	{
		string sOpenBal = Request.Form["eOpenBal"];
		double dOpenBal = 0;

		try
		{
			dOpenBal = MyMoneyParse(sOpenBal);
		}
		catch(Exception e)
		{
			Response.Write("Error, incorrect currency format.");
			return false;
		}
		sc = "INSERT INTO account (class1, name1, class2, name2, class3, name3, class4, name4, opening_balance, active) ";
		sc += " VALUES(" + sClass1 + ",'" + sName1 + "'," + sClass2 + ",'" + sName2 + "'," + sClass3 + ",'" + sName3 + "'," + sClass4 + ",'";
		sc += sName4 + "', " + dOpenBal + ", " + iActivity +")";

		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
		return true;
	}

	//update level names
	if(sName1 != sName1_old)
	{
		sc = " UPDATE account SET name1='" + EncodeQuote(sName1) + "' ";
		sc += "	WHERE class1=" + sClass1_old;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	if(sName2 != sName2_old)
	{
		sc = " UPDATE account SET name2='" + EncodeQuote(sName2) + "' ";
		sc += "	WHERE class1=" + sClass1_old;
		sc += " AND class2=" + sClass2_old;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	if(sName3 != sName3_old)
	{
		sc = " UPDATE account SET name3='" + EncodeQuote(sName3) + "' ";
		sc += "	WHERE class1=" + sClass1_old;
		sc += " AND class2=" + sClass2_old;
		sc += " AND class3=" + sClass3_old;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	if(sName4 != sName4_old)
	{
		sc = " UPDATE account SET name4='" + EncodeQuote(sName4) + "' ";
		sc += "	WHERE class1=" + sClass1_old + " ";
		sc += " AND class2=" + sClass2_old;
		sc += " AND class3=" + sClass3_old;
		sc += " AND class4=" + sClass4_old;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}

	//update opening balance
	if(Request.Form["eOpenBal"] != Request.Form["eOpenBal_old"])
	{
		string sOpenBal = Request.Form["eOpenBal"];
		double dOpenBal = MyMoneyParse(sOpenBal);
		
		sc = "BEGIN TRANSACTION UPDATE account SET opening_balance=" + dOpenBal;
		sc += "	WHERE class1=" + sClass1_old + " ";
		sc += " AND class2=" + sClass2_old;
		sc += " AND class3=" + sClass3_old;
		sc += " AND class4=" + sClass4_old;
		sc += " COMMIT ";
//	DEBUG("sc = ", sc);
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}

	//update level number
	if(bUpdateClassNumber)
	{
		sc = "UPDATE account SET ";
		sc += " class1='" + sClass1 +"'";
		sc += ", class2='" + sClass2 + "'";
		sc += ", class3='" + sClass3 +"'";
		sc += ", class4='" + sClass4 + "'";
		sc += "	WHERE class1=" + sClass1_old;
		sc += " AND class2=" + sClass2_old;
		sc += " AND class3=" + sClass3_old;
		sc += " AND class4=" + sClass4_old;
		try
		{
			myCommand = new SqlCommand(sc);
			myCommand.Connection = myConnection;
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myCommand.Connection.Close();
		}
		catch(Exception e) 
		{
			ShowExp(sc, e);
			return false;
		}
	}
	return true;
}

//----------------------------------------------------------------------------------------------------
bool ClassExists(string c1, string c2, string c3, string c4)
{
	if(dst.Tables["AllClass"] != null)
		dst.Tables["AllClass"].Clear();

	string sc = "SELECT class1, class2, class3, class4 FROM account";
	sc += " WHERE class1 =" + c1 + "AND class2 =" + c2 + "AND class3 =" + c3 + "AND class4 =" + c4;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "AllClass");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	int iClass = dst.Tables["AllClass"].Rows.Count;
	if(iClass > 0)
		return true;
	else
		return false;
}

//----------------------------------------------------------------------------------------------------
bool DoDeleteAccount()
{
	string sc = " SELECT balance FROM account "; 
	sc += " WHERE class1 = " + m_sClass1 +" AND class2 = " + m_sClass2;
	sc += " AND class3 = " + m_sClass3 + " AND class4 = " + m_sClass4;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "checkbalance") <= 0)
			return true; //target not found, nothing to delete
		double dBalance = MyDoubleParse(dst.Tables["checkbalance"].Rows[0]["balance"].ToString());
		if(dBalance != 0)
		{
			Response.Write("<br><br><br><br><center><h4><font color=red>This account could not be deleted because current balance is not zero.</font></h4>");
			Response.Write("<h4>Current Balance : " + dBalance.ToString("c") + "</h4>");
			Response.Write("<input type=button value=Back onclick=history.go(-1)  "+ Session["button_style"] +" >");
			return false;
		}
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	sc = " DELETE FROM account"; 
	sc += " WHERE class1 = " + m_sClass1 +" AND class2 = " + m_sClass2;
	sc += " AND class3 = " + m_sClass3 + " AND class4 = " + m_sClass4;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool GetAllClasses()
{
	if(dst.Tables["class1"] != null)
		dst.Tables["class1"].Clear();
	if(dst.Tables["class2"] != null)
		dst.Tables["class2"].Clear();
	if(dst.Tables["class3"] != null)
		dst.Tables["class3"].Clear();
	if(dst.Tables["class4"] != null)
		dst.Tables["class4"].Clear();

	//class1
	string sc = " SELECT DISTINCT(class1), name1";
	sc += " FROM account ";
	sc += " ORDER BY class1, name1 ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "class1");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	// class2
	sc = " SELECT DISTINCT(class2), name2";
	sc += " FROM account ";
	if(Request.QueryString["c"] != "all")
	sc += " WHERE class1 = " + m_sClass1New;
	sc += " ORDER BY class2, name2";

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "class2");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	// class3
	// check if class2 changed, apply new class2 if true
	if(m_sClass1New != m_sClass1)
	{
		m_sClass2New = "0";
		if(dst.Tables["class2"].Rows.Count > 0)
			m_sClass2New = dst.Tables["class2"].Rows[0]["class2"].ToString(); //use the first one as new
	}
	sc = " SELECT DISTINCT(class3), name3";
	sc += " FROM account ";
	if(Request.QueryString["c"] != "all")
	sc += " WHERE class1 = " + m_sClass1New + " AND class2 = " + m_sClass2New;
	sc += " ORDER BY class3, name3";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "class3");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	// class4
	sc = " SELECT DISTINCT(class4), name4";
	sc += " FROM account ";
	if(Request.QueryString["c"] != "all")
	sc += " WHERE class1 = " + m_sClass1New + " AND class2 = " + m_sClass2New + " AND class3 = " + m_sClass3New;
	sc += " ORDER BY class4, name4";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "class4");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	//get accoun name
	if(dst.Tables["editRecord"] != null)
		dst.Tables["editRecord"].Clear();
	sc = " SELECT * FROM account ";
	if(Request.QueryString["c"] != "all")
	{
	sc += " WHERE class1 = " + m_sClass1;
	sc += " AND class2 = " + m_sClass2;
	sc += " AND class3 = " + m_sClass3;
	sc += " AND class4 = " + m_sClass4;
	}
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		if(myAdapter.Fill(dst, "editRecord") <= 0)
			return true;
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	DataRow dr = dst.Tables["editRecord"].Rows[0];
	m_sName1 = dr["name1"].ToString();
	m_sName2 = dr["name2"].ToString();
	m_sName3 = dr["name3"].ToString();
	m_sName4 = dr["name4"].ToString();
	m_dOpenBal = MyDoubleParse(dr["opening_balance"].ToString());
	m_dBalance = MyDoubleParse(dr["balance"].ToString());
	m_bActive = MyBooleanParse(dr["active"].ToString());
	m_bShowBalance = MyBooleanParse(dr["show_balance"].ToString());
	m_bNoDeleteAccount = MyBooleanParse(dr["nodelete"].ToString());
	m_bDebitAccountType = MyBooleanParse(dr["isdebit_acc"].ToString());
//DEBUG("mdebibaotutn =", m_bNoDeleteAccount.ToString());
	return true;
}

bool DrawEditTable()
{
	Response.Write("<br><center><h3>Edit Account</h3>");
	if(!GetAllClasses())
		return false;
	Response.Write("<form name=frm action='account.aspx?t=e&edit=1");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("' method=post>");
bool bNotAllowEdit = false;
if(m_account_id == m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4)
	bNotAllowEdit = true;
	Response.Write("<br><table align=center cellspacing=1 cellpadding=5 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:hash;border-collapse:collapse;fixed\">");
	Response.Write("<tr><th colspan=2>");
	Response.Write("<b>ACC# <font color=red>" + m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4 + "</font>");
	Response.Write(" " + m_sName1 + " - " + m_sName2 +" - " + m_sName3 +" - " + m_sName4);
	Response.Write("<tr><td colspan=2><hr size=1 color=black></td></tr>");

	Response.Write("<tr><td colspan=2>");

	Response.Write("<table align=center cellspacing=0 cellpadding=3 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:hash;border-collapse:collapse;fixed\">");
	Response.Write("<tr><th width=50>Class</th><th width=150 nowrap>Current Name</th><th nowrap>New Name</th></tr>");
	Response.Write("<tr><td align=center>" + m_sClass1 + "</td><td>" + m_sName1 + "</td><td><input type=text name=sName1 ");
	if(bNotAllowEdit)
		Response.Write(" readonly ");
	Response.Write("></td></tr>");
	Response.Write("<tr><td align=center>" + m_sClass2 + "</td><td>" + m_sName2 + "</td><td><input type=text name=sName2 ");
	if(bNotAllowEdit)
		Response.Write(" readonly ");
	Response.Write("></td></tr>");
	Response.Write("<tr><td align=center>" + m_sClass3 + "</td><td>" + m_sName3 + "</td><td><input type=text name=sName3 ");
	if(bNotAllowEdit)
		Response.Write(" readonly ");
	Response.Write("></td></tr>");
	Response.Write("<tr><td align=center>" + m_sClass4 + "</td><td>" + m_sName4 + "</td><td><input type=text name=sName4 ");
	if(bNotAllowEdit)
		Response.Write(" readonly ");
	Response.Write("></td></tr>");
	Response.Write("</table>");
	
	Response.Write("</td></tr>");

	Response.Write("<tr><td colspan=2 align=center>");
	Response.Write("<table>");
	Response.Write("<tr><td>");
	Response.Write("<b>Opening Balance : <a title='view opening balance log' href='acc_report.aspx?r="+ DateTime.UtcNow.AddHours(12).ToOADate() +"&accid="+ m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4 +"' class=o target=blank>V</a> </b><input type=text size=5 name=opening_balance ");
	Response.Write(" style=text-align:right value='" + m_dOpenBal + "'>");
	Response.Write("<input type=hidden name=opening_balance_old value='" + m_dOpenBal + "'>");
//	Response.Write(" &nbsp;&nbsp;&nbsp; <b>Active : </b><input type=checkbox name=active ");
	Response.Write("&nbsp; <b>Active : </b><input type=checkbox name=active ");
	
	if(m_bActive)
		Response.Write(" checked");
	Response.Write(">");
//***is credit or debit account
//	DEBUG("mdebibaotutn =", m_bDebitAccountType.ToString());
	Response.Write("&nbsp; <b>Account Type : </b><select name=acc_type>");
	Response.Write("<option value=0 ");
	if(!m_bDebitAccountType)	
		Response.Write(" selected ");
	Response.Write(">CR");
	Response.Write("<option value=1 ");
	if(m_bDebitAccountType)
		Response.Write(" selected ");
	Response.Write(">DR");
	Response.Write("</select>");

	//only admin to change the view balance setting..
	if(m_bCheckAccess)
	{
//		Response.Write(" &nbsp;&nbsp;&nbsp; Show Balance : </b><input type=checkbox name=showbalance ");
		Response.Write("&nbsp; Show Balance : </b><input type=checkbox name=showbalance ");
		if(m_bShowBalance)
			Response.Write(" checked");
		Response.Write(">");
	}
	Response.Write("</td>");
	Response.Write("</table>");
	Response.Write("</td></tr>");

	Response.Write("<tr><td align=right colspan=2 >");

	string sButtonName = "<< Back to";
	string sLastURI = "";
	if(Session["luri_acc"] != null)
	{
		sLastURI = Session["luri_acc"].ToString();
		if(Session["luri_acc"].ToString().IndexOf("acc_owner.aspx") >=0)
			sButtonName += " Shareholder Trans";
		else if(Session["luri_acc"].ToString().IndexOf("custdep.aspx") >=0)
			sButtonName += " Other Deposit";
		else if(Session["luri_acc"].ToString().IndexOf("expense") >=0)
			sButtonName += " Expense";
		else if(Session["luri_acc"].ToString().IndexOf("custax") >=0)
			sButtonName += " GST Trans";

		Response.Write("<input type=button value='"+ sButtonName +"'  class=linkButton title='"+sButtonName+"'  onclick=window.location=('"+ sLastURI +"')>");
	}
	if(!bNotAllowEdit)
	{
	if(Session["email"] != null)
	{
		string semail = Session["email"].ToString();
		if(semail.IndexOf("tee@ezsoft.com") >=0 || semail.IndexOf("darcy@ezsoft.com") >=0 || semail.IndexOf("jerry@ezsoft.com") >=0 || semail.IndexOf("neo@ezsoft.com") >=0 || semail.IndexOf("admin@ezsoft.com") >=0 )
		{
			Response.Write(" <input type=checkbox name=nodelete ");
			if(m_bNoDeleteAccount)
				Response.Write(" checked ");
			Response.Write(" > <font color=purple><i>Allow Delete Account?</i> ");
		}
	}
	else
		Response.Write("<input type=hidden name=nodelete >");
	}
	Response.Write("<input type=submit name=cmd value=Update "+ Session["button_style"] +">");
	
	Response.Write("<input type=button value=Finish  class=linkButton title='Finish'  onclick=window.location=('account.aspx?c=" + m_sClass1 + "&r="+ DateTime.UtcNow.AddHours(12).ToOADate()+"')>");
	Response.Write("</td></tr><tr><td colspan=2 align=right>");
	if(!bNotAllowEdit)
	{
	Response.Write("<input type=checkbox name=confirm_delete>Confirm delete ");
	Response.Write("<input type=submit name=cmd value=Delete  "+ Session["button_style"] +" ");
	if(m_bNoDeleteAccount)
		Response.Write(" onclick=\"window.alert('This Account is unable to Delete!!!'); return false;\" ");
		
	Response.Write(">");
	

	Response.Write("<input type=button value='Move Account'  "+ Session["button_style"] +"  onclick=window.location=('");
	Response.Write("account.aspx?t=m&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4 + "')>");
	}
	Response.Write("</td></tr>");

	Response.Write("</table>");
	Response.Write("</form>");
	return true;
}

bool DrawMoveTable()
{
	Response.Write("<br><center><h3>Move Account</h3>");
	if(!GetAllClasses())
		return false;

	Response.Write("<form name=frm action='account.aspx?t=m");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c=" + Request.QueryString["new_c"]);
	Response.Write("&new_c2=" + Request.QueryString["new_c2"]);
	Response.Write("&new_c3=" + Request.QueryString["new_c3"]);
	Response.Write("' method=post>");

	Response.Write("<br><table align=center valign=center cellspacing=1 cellpadding=3 border=0 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:hash;border-collapse:collapse;fixed\">");
	Response.Write("<tr><th align=left colspan=2>");
	Response.Write("<b>ACC# <font color=red>" + m_sClass1 + m_sClass2 + m_sClass3 + m_sClass4 + "</font>");
	Response.Write(" " + m_sName1 + " - " + m_sName2 +" - " + m_sName3 +" - " + m_sName4);
	Response.Write("<tr><td colspan=2><hr size=1 color=black></td></tr>");

	Response.Write("<tr><td colspan=2><b>Detination class to move to : </b></td></tr>");

	string sname = "";

	//class 1
	Response.Write("<tr>");
	Response.Write("<td align=center>");
	if(m_sClass1New == "9999" || dst.Tables["class1"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b> ");
	else
		Response.Write("<b>" + m_sClass1New + "</b> ");
	Response.Write("</td><td>");
	Response.Write("<select name=class1 onchange=\"window.location=('account.aspx?t=m");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c2=" + Request.QueryString["new_c2"]);
	Response.Write("&new_c3=" + Request.QueryString["new_c3"]);
	Response.Write("&new_c='+this.options[this.selectedIndex].value)\" >\r\n");
	for(int i=0; i<dst.Tables["class1"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class1"].Rows[i];
		sname = dr["name1"].ToString();
		if(sname == "")
			sname = "(no name)";
		string sel = m_sClass1;
		Response.Write("<option value=" + dr["class1"].ToString() + "");
		if(m_sClass1New == dr["class1"].ToString())
			Response.Write(" selected ");
		Response.Write(">" + sname + "</option>");
	}
	Response.Write("</select>");
	Response.Write("</tr>");

	//class 2
	string destClass2 = m_sClass2New;
	if(m_sClass1New != m_sClass1)
	{
		destClass2 = dst.Tables["class2"].Rows[0]["class2"].ToString();
	}
	Response.Write("<tr>");
	Response.Write("<td align=center>");
	if(m_sClass2New == "9999" || dst.Tables["class2"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b> ");
	else
		Response.Write("<b>" + destClass2 + "</b> ");
	Response.Write("</td><td>");
	Response.Write("<select name=class2 onchange=\"window.location=('account.aspx?t=m");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c=" + Request.QueryString["new_c"]);
	Response.Write("&new_c3=" + Request.QueryString["new_c3"]);
	Response.Write("&new_c2='+this.options[this.selectedIndex].value)\" >\r\n");
	for(int i=0; i<dst.Tables["class2"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class2"].Rows[i];
		sname = dr["name2"].ToString();
		Response.Write("<option value=" + dr["class2"].ToString() + "");
		if(m_sClass2New == dr["class2"].ToString())
			Response.Write(" selected ");
		Response.Write(">" + sname + "</option>");
	}
	Response.Write("</select>");
	Response.Write("</tr>");

	//class 3
	string destClass3 = m_sClass3New;
	if(m_sClass1New != m_sClass1 || m_sClass2New != m_sClass2)
	{
		if(dst.Tables["class3"].Rows.Count > 0)
			destClass3 = dst.Tables["class3"].Rows[0]["class3"].ToString();
	}
	Response.Write("<tr>");
	Response.Write("<td align=center>");
	if(m_sClass3New == "9999" || dst.Tables["class3"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b> ");
	else
		Response.Write("<b>" + destClass3 + "</b> ");
	Response.Write("</td><td>");
	Response.Write("<select name=class3 onchange=\"window.location=('account.aspx?t=m");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c=" + Request.QueryString["new_c"]);
	Response.Write("&new_c2=" + Request.QueryString["new_c2"]);
	Response.Write("&new_c3='+this.options[this.selectedIndex].value)\" >\r\n");
	for(int i=0; i<dst.Tables["class3"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class3"].Rows[i];
		sname = dr["name3"].ToString();
		if(sname == "")
			sname = "(no name)";
		Response.Write("<option value=" + dr["class3"].ToString() + "");
		if(m_sClass3New == dr["class3"].ToString())
			Response.Write(" selected ");
		Response.Write(">" + sname + "</option>");
	}
	Response.Write("</select>");
	Response.Write("</tr>");

	//class 4
	Response.Write("<tr>");
	Response.Write("<td align=center>");
	if(m_sClass4New == "9999" || dst.Tables["class4"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b> ");
	else
		Response.Write("<b>" + m_sClass4New + "</b> ");
	Response.Write("</td><td>");
	Response.Write("<select name=class4 onchange=\"window.location=('account.aspx?t=m");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c2=" + Request.QueryString["new_c2"]);
	Response.Write("&new_c3=" + Request.QueryString["new_c3"]);
	Response.Write("&new_c=" + Request.QueryString["new_c"]);
	Response.Write("')\">\r\n");
	Response.Write("<option value=" + m_sName4 + ">" + m_sName4 + "</option>");
	Response.Write("</select>");
	Response.Write("</tr>");

	Response.Write("<tr><td>");
	Response.Write("<input type=button value='Edit Account'  "+ Session["button_style"] +"  onclick=window.location=('");
	Response.Write("account.aspx?t=e&edit=1&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4 + "')>");
	Response.Write("</td><td align=right>");
	Response.Write("<input type=submit name=cmd value=Move  "+ Session["button_style"] +" >");
	Response.Write("<input type=button value=Finish  "+ Session["button_style"] +"  onclick=window.location=('account.aspx?c=" + m_sClass1 + "')>");
	Response.Write("</td></tr>");

	Response.Write("</table>");
	Response.Write("</form>");
	return true;
}

bool DrawAddNewTable()
{
	Response.Write("<br><center><h3>Add New Account</h3>");
	if(!GetAllClasses())
		return false;

	Response.Write("<form name=frm action='account.aspx?t=e' method=post>");

	Response.Write("<br><table align=center valign=center cellspacing=0 cellpadding=1 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:0px;border-style:hash;border-collapse:collapse;fixed\">");

	Response.Write("<tr>");
	Response.Write("<td colspan=5>");
	Response.Write("<b>Select existing class or enter new at text box</b> ");
if(m_sClass1New == "all")
m_sClass1New = "1";
	//class 1
	Response.Write("<tr>");
	Response.Write("<td colspan=4>");
	if(m_sClass1New == "9999" || dst.Tables["class1"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b>");
	else
		Response.Write("<b>" + m_sClass1New + ".</b>");
	Response.Write("</td><td> ");
	Response.Write("<select name=class1 onchange=\"window.location=('account.aspx?t=e");
	Response.Write("&c='+this.options[this.selectedIndex].value)\" >\r\n");
//	Response.Write(" <option value=9999>New(Enter class name at right)</option>");
	string sname = "";
	for(int i=0; i<dst.Tables["class1"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class1"].Rows[i];
		string sel = m_sClass1;
		Response.Write("<option value=" + dr["class1"].ToString() + "");
		if(m_sClass1New == dr["class1"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name1"].ToString();
		}
		Response.Write(">" + dr["name1"].ToString() + "</option>");
	}
	Response.Write("</select>");
	Response.Write("<input type=hidden name=selected_name1 value='" + sname + "'>");
//	Response.Write("<input type=text name=sName1 size=20>");
	Response.Write("</tr>");

	//class 2
	Response.Write("<tr>");
	Response.Write("<td colspan=4>");
	if(m_sClass2New == "9999" || dst.Tables["class2"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b>");
	else
		Response.Write("<b>" + m_sClass2New + ".</b>");
	Response.Write("</td><td> ");
	Response.Write("<select name=class2 onchange=\"window.location=('account.aspx?t=e");
	Response.Write("&c=" + m_sClass1);
	Response.Write("&c2='+this.options[this.selectedIndex].value)\" >\r\n");
	Response.Write(" <option value=9999>New(Enter class name at right)</option>");
	for(int i=0; i<dst.Tables["class2"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class2"].Rows[i];
		Response.Write("<option value=" + dr["class2"].ToString() + "");
		if(m_sClass2New == dr["class2"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name2"].ToString();
		}
		Response.Write(">" + dr["name2"].ToString() + "</option>");
	}
	Response.Write("</select>");
	Response.Write("<input type=hidden name=selected_name2 value='" + sname + "'>");
	Response.Write("<input type=text name=sName2 size=20>");
	Response.Write("</tr>");

	//class 3
	Response.Write("<tr>");
	Response.Write("<td colspan=4>");
	if(m_sClass3New == "9999" || dst.Tables["class3"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b>");
	else
		Response.Write("<b>" + m_sClass3New + ".</b>");
	Response.Write("</td><td> ");
	Response.Write("<select name=class3 onchange=\"window.location=('account.aspx?t=e");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2);
	Response.Write("&c3='+this.options[this.selectedIndex].value)\" >\r\n");
	Response.Write(" <option value=9999>New(Enter class name at right)</option>");
	for(int i=0; i<dst.Tables["class3"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["class3"].Rows[i];
		Response.Write("<option value=" + dr["class3"].ToString() + "");
		if(m_sClass3New == dr["class3"].ToString())
		{
			Response.Write(" selected ");
			sname = dr["name3"].ToString();
		}
		Response.Write(">" + dr["name3"].ToString() + "</option>");
	}
	Response.Write("</select>");
	Response.Write("<input type=hidden name=selected_name3 value='" + sname + "'>");
	Response.Write("<input type=text name=sName3 size=20>");
	Response.Write("</tr>");

	//class 4
	Response.Write("<tr>");
	Response.Write("<td colspan=4>");
	if(m_sClass4New == "9999" || dst.Tables["class4"].Rows.Count <= 0)
		Response.Write("<b> &nbsp;&nbsp; </b>");
	else
		Response.Write("<b>" + m_sClass4New + ".</b>");
	Response.Write("</td><td> ");
	Response.Write("<select name=class4 onchange=\"window.location=('account.aspx?t=e");
	Response.Write("&c=" + m_sClass1 + "&c2=" + m_sClass2 + "&c3=" + m_sClass3 + "&c4=" + m_sClass4);
	Response.Write("&new_c2=" + Request.QueryString["new_c2"]);
	Response.Write("&new_c3=" + Request.QueryString["new_c3"]);
	Response.Write("&new_c=" + Request.QueryString["new_c"]);
	Response.Write("')\">\r\n");
	Response.Write(" <option value=9999>New(Enter class name at right)</option>");
	Response.Write("</select>");
	Response.Write("<input type=text name=sName4 size=20>");
	Response.Write("</tr>");

	Response.Write("<tr><td colspan=5>");
	Response.Write("<table>");
	Response.Write("<tr><td>");
	Response.Write("<b>Opening Balance : </b><input type=text size=5 name=opening_balance ");
	Response.Write(" style=text-align:right value=0>");
	Response.Write(" &nbsp;&nbsp;&nbsp; <b>Active : </b><input type=checkbox name=active checked>");
	Response.Write("</td>");
	Response.Write("</table>");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=5>");
	Response.Write("<table>");
	Response.Write("<tr><td>");
	Response.Write("<b>Account Type : <select name=acc_type><option value=0>CR<option value=1>DR</select>");
	Response.Write("</td></tr>");
	Response.Write("</table>");
	Response.Write("</td></tr>");
	Response.Write("<tr><td colspan=5>");
	if(m_sClass1 == "9999")
m_sClass1 = "all";
	string sButtonName = "<< Back to";
	string sLastURI = "";
	if(Session["luri_acc"] != null)
	{
		sLastURI = Session["luri_acc"].ToString();
//	DEBUG("slateru = ", sLastURI);
		if(Session["luri_acc"].ToString().IndexOf("acc_owner.aspx") >=0)
			sButtonName += " Shareholder Trans";
		else if(Session["luri_acc"].ToString().IndexOf("custdep.aspx") >=0)
			sButtonName += " Other Deposit";
		else if(Session["luri_acc"].ToString().IndexOf("expense") >=0)
			sButtonName += " Expense";
		else if(Session["luri_acc"].ToString().IndexOf("custax") >=0)
			sButtonName += " GST Trans";
		Response.Write("<input type=button value='"+ sButtonName +"'  class=linkButton title='"+sButtonName+"'  onclick=window.location=('"+ sLastURI +"')>");
	}
//	Response.Write("<input type=button value='<<Back'  "+ Session["button_style"] +"  onclick=window.location=('account.aspx?c=" + m_sClass1 + "&r="+ DateTime.UtcNow.AddHours(12).ToOADate()+"')>");
	Response.Write("<input type=button value=Finish  class=linkButton title='Finish'  onclick=window.location=('account.aspx?c=" + m_sClass1 + "&r="+ DateTime.UtcNow.AddHours(12).ToOADate()+"')>");
	Response.Write("<input type=submit name=cmd value=Add  class=linkButton title='Add' >");
	
	
	Response.Write("</td></tr>");

	Response.Write("</table>");
	Response.Write("</form>");
	return true;
}

bool DoChangeClassName(int nClass)
{
	string name = EncodeQuote(Request.Form["sName" + nClass.ToString()]);
	if(name == "")
	{
		Response.Write("<h3>Please enter new calss name</h3>");
		return false;
	}

	string sc = " UPDATE account SET name" + nClass.ToString() + " = '" + name + "' WHERE 1=1 ";
	switch(nClass)
	{
	case 1:
		sc += " AND class1 = " + m_sClass1;
		break;
	case 2:
		sc += " AND class1 = " + m_sClass1;
		sc += " AND class2 = " + m_sClass2;
		break;
	case 3:
		sc += " AND class1 = " + m_sClass1;
		sc += " AND class2 = " + m_sClass2;
		sc += " AND class3 = " + m_sClass3;
		break;
	case 4:
		sc += " AND class1 = " + m_sClass1;
		sc += " AND class2 = " + m_sClass2;
		sc += " AND class3 = " + m_sClass3;
		sc += " AND class4 = " + m_sClass4;
		break;
	default:
		break;
	}
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

//----------------------------------------------------------------------------------------------------
bool DrawAccountIndex()
{
	string sindex1 = "";
	string sindex2 = "";
	string sindex3 = "";
	string sindex4 = "";

	string sindex1_old = "";
	string sindex2_old = "";
	string sindex3_old = "";
	string sindex4_old = "";

	string s1 = "";
	string s2 = "";
	string s3 = "";
	string s4 = "";
	
	string select1 = "";
	string select2 = "";
	string select3 = "";
	string select4 = "";
	string bgCol = "";
	
	if(Request.QueryString["c"] != null && Request.QueryString["c"] != "" && Request.QueryString["c"] != "all")
		select1 = Request.QueryString["c"];
	if(Request.QueryString["c2"] != null && Request.QueryString["c2"] != "" && Request.QueryString["c2"] != "all")
		select2 = Request.QueryString["c2"];
	if(Request.QueryString["c3"] != null && Request.QueryString["c3"] != "" && Request.QueryString["c3"] != "all")
		select3 = Request.QueryString["c3"];
	if(Request.QueryString["c4"] != null && Request.QueryString["c4"] != "" && Request.QueryString["c4"] != "all")
		select4 = Request.QueryString["c4"];
	string ss1 = "";
	string ss2 = "";
	string ss3 = "";
	string ss4 = "";

	int irows = dst.Tables["allaccount"].Rows.Count;
	if(irows == 0)
		return false;
	bool bAlter = false;
	for(int i=0; i<irows; i++)
	{
		DataRow dr = dst.Tables["allaccount"].Rows[i];
		sindex1 = dr["class1"].ToString() + " - " + dr["name1"].ToString();
		sindex2 = dr["class2"].ToString() + " - " + dr["name2"].ToString();
		sindex3 = dr["class3"].ToString() + " - " + dr["name3"].ToString();
		sindex4 = dr["class4"].ToString() + " - " + dr["name4"].ToString();
					
		if(sindex1 != sindex1_old)
		{
			sindex1_old = sindex1;
			s1 = sindex1;
			ss1 = dr["class1"].ToString();
		}
		else
			s1 = "";

		if(sindex2 != sindex2_old)
		{
			sindex2_old = sindex2;
			s2 = sindex2;
			ss2 = dr["class2"].ToString();

		}
		else
			s2 = "";

		if(sindex3 != sindex3_old)
		{
			sindex3_old = sindex3;
			s3 = sindex3;
			ss3 = dr["class3"].ToString();
		}
		else
			s3 = "";
		if(sindex4 != sindex4_old)
		{
			sindex4_old = sindex4;
			s4 = sindex4;
			ss4 = dr["class4"].ToString();
		}
		else
			s4 = "";
		
		Response.Write("<tr");
		if(bAlter)
			Response.Write(" bgcolor=#EEEEEE ");
		bAlter = !bAlter;
		Response.Write("><td ");
		if(s1 != "" && ss1 == select1)
			Response.Write(" bgcolor= "+ bgCol +" ");
		Response.Write("><b>" + s1 + "</b></td><td ");
		if(s2 != "" && ss2 == select2)
			Response.Write(" bgcolor= "+ bgCol +" ");
		Response.Write("><b>" + s2 + "</b></td>");
		Response.Write("<td ");
		if(s3 != "" && ss3 == select3)
			Response.Write(" bgcolor= "+ bgCol +" ");
		Response.Write(" ><b>" + s3 + "</b></td><td ");
		if(s4 != "" && ss4 == select4)
			Response.Write(" bgcolor= "+ bgCol +" ");
		Response.Write("><b>" + sindex4 + "</b></td></tr>");
	}
	Response.Write("</table></td></tr><br>");
	return true;
}
//----------------------------------------------------------------------------------------------------
bool GetCurAccBalance(string accNum, ref string sCurrBal)
{
	DataRow dr = null;

	if(accNum == null || accNum == "")
		return false;
	else 
	{
		if(GetAccLastTran(accNum, ref dr))
		{
			if(accNum == dr["source"].ToString())
			{
				sCurrBal = double.Parse(dr["source_balance"].ToString()).ToString("c");
			}
			else if(accNum == dr["dest"].ToString())
				{
//DEBUG("dest_bal = ", dr["dest"].ToString());
//DEBUG("dest_bal = ", dr["dest_balance"].ToString());
					sCurrBal = double.Parse(dr["dest_balance"].ToString()).ToString("c");
				}
			return true;
		}
		else 
		{
			string c1 = accNum[0].ToString();
			string c2 = accNum[1].ToString();
			string c3 = accNum[2].ToString();
			string c4 = accNum[3].ToString();
//DEBUG("accNum = ", accNum);
			string sc = "SELECT opening_balance FROM account ";
			sc += "WHERE class1 =" + c1 + " AND class2 =" + c2 + " AND class3 =" + c3 + " AND class4 =" + c4;
			try
			{
				myAdapter = new SqlDataAdapter(sc, myConnection);
				int rows = myAdapter.Fill(dst, "single_balance_record");
			}
			catch(Exception e) 
			{
				ShowExp(sc, e);
				return false;
			}
			
			DataRow ds = dst.Tables["single_balance_record"].Rows[0];
			sCurrBal = double.Parse(ds["opening_balance"].ToString()).ToString("c");
			dst.Tables["single_balance_record"].Clear();
			return true;
		}
	}
	return true;
}
//----------------------------------------------------------------------------------------------------
bool GetAccLastTran(string accNum, ref DataRow dr)
{
	string sc = "SELECT TOP 1 t.trans_date, t.source, t.dest, d.source_balance, d.dest_balance ";
	sc += "FROM trans t JOIN tran_detail d ON t.id = d.id ";
	sc += "WHERE t.source =" + accNum + " OR t.dest =" + accNum;
	sc += " ORDER BY t.trans_date, t.source, t.dest, d.source_balance, d.dest_balance DESC";
//DEBUG("sc = ", sc);
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int rows = myAdapter.Fill(dst, "trans_rec");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	int irows = dst.Tables["trans_rec"].Rows.Count;
	if(irows > 0)
	{
		dr = dst.Tables["trans_rec"].Rows[0];
		return true;
	}
	else
		return false;
}


bool bCheckAccessLevel(bool bAllow)
{
	string access_level = "1";
	string sc = " SELECT access_level FROM card ";
	sc += " WHERE id = "+ Session["card_id"];
//DEBUG("sc = ", sc);
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dst, "access");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows == 1)
		access_level = dst.Tables["access"].Rows[0]["access_level"].ToString();

	if(int.Parse(access_level) > 9)
		bAllow = true;
	return bAllow;
}
</script>

<asp:Label id=LFooter runat=server/>
