<script runat=server>
DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table
string m_code = "";

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("technician"))
		return;

	if(Request.QueryString["c"] == null || Request.QueryString["c"] == "")
	{
		Response.Write("<h4>Item code not found</h4>");
		return;
	}
	m_code = Request.QueryString["c"];

	DoAnalyzeStock();
}

bool DoAnalyzeStock()
{
	int rows = 0;
	string sc = " SELECT ";
	sc += " (SELECT SUM(i.qty) ";
	sc += " FROM purchase_item i JOIN purchase p ON p.id = i.id ";
	sc += " WHERE i.code = " + m_code;
	sc += " AND p.status = 2) AS received_purchase "; //received status
	sc += ", ";
	sc += " (SELECT SUM(i.qty) ";
	sc += " FROM purchase_item i JOIN purchase p ON p.id = i.id ";
	sc += " WHERE i.code = " + m_code;
	sc += " AND p.status IN(1,3)) AS on_order_purchase "; //received status
	sc += ", ";
	sc += " (SELECT isnull(SUM(quantity),0) FROM sales WHERE code = " + m_code + ") ";
	sc += " AS total_sales ";
	sc += ", (SELECT isnull(sum(approved_qty),0)  FROM stock_borrow WHERE code = " + m_code + " AND approved=1) ";
	sc += " AS approved_qty ";
	sc += ", (SELECT isnull(SUM(return_qty),0) FROM stock_borrow WHERE code = " + m_code + " AND approved=1) ";
	sc += " AS return_qty ";
	sc += ", (SELECT ISNULL(SUM(replace_qty),0) FROM stock_borrow WHERE code = " + m_code + " AND approved=1) ";
	sc += " AS replace_qty ";
	sc += ", (SELECT isnull(SUM(approved_qty - return_qty - replace_qty),0) FROM stock_borrow WHERE code = " + m_code + " AND approved=1) ";
	sc += " AS total_borrow ";

	sc += ", name FROM code_relations WHERE code=" + m_code;
	try
	{
		SqlDataAdapter myCommand = new SqlDataAdapter(sc, myConnection);
		rows = myCommand.Fill(dst, "stock");

	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	if(rows <= 0)
	{
		Response.Write("<center><h5><font color=Red>Item " + m_code + " not found.</h5></font></center>");
		return false;
	}

	DataRow dr = dst.Tables["stock"].Rows[0];
	string received_purchase = dr["received_purchase"].ToString();
	string on_order_purchase = dr["on_order_purchase"].ToString();
	string total_sales = dr["total_sales"].ToString();
	string total_borrow = dr["total_borrow"].ToString();
	string approved_qty = dr["approved_qty"].ToString();
	string return_qty = dr["return_qty"].ToString();
	string replace_qty = dr["replace_qty"].ToString();
	string name = dr["name"].ToString();
	
	Response.Write("<table align=center cellspacing=0 cellpadding=0 border=0  bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader><th colspan=2>Purchase & Sales Total</th></tr>");
	Response.Write("<tr><td colspan=2>&nbsp;</td></tr>");
	Response.Write("<tr><td align=right >Item Code:</th><td class=blueFont2> " + m_code + "</td></tr>");
	Response.Write("<tr class=rowColor><td align=right >Name:</th><td class=blueFont2> "+ name +"</td></tr>");
	Response.Write("<tr><td align=right >Stocked Purchase:</th><td class=blueFont2> "+ received_purchase +"</td></tr>");
	Response.Write("<tr class=rowColor><td align=right >On Order Purchase:</th><td class=blueFont2> "+ on_order_purchase +"</td></tr>");
	Response.Write("<tr><td align=right >Sales:</th><td class=blueFont2> "+ total_sales +"</td></tr>");
	Response.Write("<tr class=rowColor><td align=center  colspan=2><br>On RMA BORROW STOCK STATUS:</th></tr>");
	Response.Write("<tr><td align=right >APPROVED_QTY:</th><td class=blueFont2> "+ approved_qty +"</td></tr>");
	Response.Write("<tr class=rowColor><td align=right >RETURNED_QTY:</th><td class=blueFont2> "+ return_qty +"</td></tr>");
	Response.Write("<tr><td align=right >REPLACED_QTY:</th><td class=blueFont2> "+ replace_qty +"</td></tr>");
	Response.Write("<tr class=rowColor><td align=right >TOTAL QTY on RMA Borrow:</th><td class=blueFont2> "+ total_borrow +"</td></tr>");
	Response.Write("<tr><td colspan=2 align=center><input type=button value='    close   ' class=closeButton title='Close'  onclick='window.close();'>");
	Response.Write("</table>");
	return true;
}

</script>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html>
<head>
    <title>--- Purchase & Sales Total---</title> 
</head>
