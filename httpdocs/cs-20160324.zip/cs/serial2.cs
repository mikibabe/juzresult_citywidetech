<script runat="server">

bool m_bEnd = false;

string m_quoteNumber = "";

int m_iTatalOrdrItems = 0;
int m_nSearchReturn = 0;
int m_nSerialReturn = 0;
int m_SearchSupplier = 0;
int m_nPurchaseReturn = 0;

string m_last_invno = "";
string m_last_supp = "";
string m_last_warrant ="";
string m_last_key = "";
string m_last_prodcode = "";

//
string m_checkProduct_code = "";
int m_ncheckQty = 0; 

DataSet dst = new DataSet();	//for creating Temp talbes templated on an existing sql table

//Current Row
string m_ponumber = "";
string m_supplier = "";
string m_supplier_code = "";
string m_cost = "";
string m_prod_desc = "";
string m_prod_code = "";
string m_qty = ""; 
string m_date_create = "";

string m_end = "";
int m_step = 1;

void Page_Load(Object Src, EventArgs E ) 
{
	TS_PageLoad(); //do common things, LogVisit etc...
	if(!SecurityCheck("sales"))
		return;
	//RememberLastPage();
	m_quoteNumber = Request.QueryString["n"];
	if(Request.Form["txtInvoice"] != null)
		m_last_invno=Request.Form["txtInvoice"].ToString();


//DEBUG("m_quoteNumber = ", m_quoteNumber);
	PrintAdminHeader();
	PrintAdminMenu();
	RememberLastPage();
	if(Request.QueryString["qty"] != null)
		m_ncheckQty = int.Parse(Request.QueryString["qty"]);

	if(m_quoteNumber != null || m_nPurchaseReturn >0)
	{
	//	Response.Write("YOu Know what i'm gona do with the shit ");

		if(!getPurchaseItem())
			return;
		if(Request.QueryString["prodcode"] != null)
		{
			if(!GetCurrentProduct())
				return;
		}

		BindISTable();
		//DEBUG("m_nreturn = ", m_nPurchaseReturn);
		if(m_nPurchaseReturn <= 0)
			Response.Redirect("purchase.aspx?n='"+m_quoteNumber+"'");

	}
	else
	{
		PrintForm();
	/*if(Request.QueryString["sn"]=="v")
	{
		if(!GetInsertedSerial())
			return;
		BindGrid();
	}*/
	}
	//else
	//{
		//PrintForm();
		
		if(Request.Form["cmd"] == "Update SerialNO" || Request.Form["txtSerial"] != null)
		{
			if(TS_UserLoggedIn())
			{
			
			string s_sn = Request.Form["txtSerial"].ToString();
			string s_supp = Request.Form["optSupp"].ToString();
			
		
			int ilength = 0;
			string s_tmp = "";
			for(int i=0; i<s_supp.Length; i++)
			{
				s_tmp = s_supp[i].ToString();
				if(s_tmp == "=")
					ilength=i+1;
			}
		
			string s_last2 = "";
			for(int i=ilength; i<s_supp.Length; i++)
				s_last2 += s_supp[i].ToString();

			s_supp = s_last2;
			string s_inv = Request.Form["txtInvoice"].ToString();
			string s_prod = Request.Form["txtProdDesc"].ToString();
			string s_snend1 = Request.Form["txtEnd1"].ToString();
			string s_date = Request.Form["txtDate"].ToString();
			string s_warrant = Request.Form["optWarrant"].ToString();
			string s_prodcode = Request.Form["optProdCode"].ToString();
			string s_cost = Request.Form["txtCost"].ToString();
			
			string s_suppcode = "";
			if(Request.Form["txtSuppCode"] != null)
				s_suppcode = Request.Form["txtSuppCode"].ToString();

			if(s_sn != null || s_sn != "")
				m_bEnd = true;

			if(m_bEnd)
			{
				if(s_snend1 != null  && s_snend1 != "")
				{
					m_end = Request.Form["txtEnd1"];
					string s_i =Request.Form["optSelect"].ToString();
					//DEBUG("option = ", i);
					m_step=int.Parse(s_i);
				}
				if(m_end != "")
				{
						//string for extract serial number
					string prefix = "";	string startAt = ""; string endAt = "";
					if(!DoMassiveInput(ref prefix, ref startAt))
						return;

					if(!DoMassInputEnd(m_end,  ref endAt))
							return;

					if(!MassInsertSerial(endAt, m_step, prefix, startAt, s_supp, s_inv, 
												s_cost, s_suppcode, s_prod, s_date, s_warrant, s_prodcode))
							return;
				}
				else
				{
					if(!InsertSerial(s_sn,s_supp,s_inv, s_cost, s_suppcode, s_prod, s_date, s_warrant, s_prodcode))
						return;
				}
				
			}
			}
			else
			{
				Response.Redirect("login.aspx");
			}
	//	}
	//	}
	}
		if(Request.QueryString["del"] != null)
		{
			string s_sn=Request.QueryString["del"].ToString();
			//m_sn=Request.QueryString["del"].ToString();

			if(!DelSerial(s_sn))
				return;
		}
		if(!GetInsertedSerial())
			return;
			
		//BindSNGrid();
		BindGrid();
		

	//}
	//}
	LFooter.Text = m_sAdminFooter;
}


bool getPurchaseItem()
{
	m_quoteNumber = Request.QueryString["n"];
	string sc = " SELECT p.po_number, pi.supplier, pi.supplier_code, pi.price, pi.qty, pd.name, pi.product_code,p.date_create ";
	sc += " FROM purchase p INNER JOIN purchase_item pi ";
	sc += " ON p.po_number = pi.po_number INNER JOIN product pd ";
	sc += " ON pi.product_code = pd.code ";
	sc += " WHERE p.po_number='" +m_quoteNumber + "'";    
		
	//string sc ="Select * From code_relations c INNER JOIN purchase_item p ON c.supplier_code=p.supplier_code ";
	//sc += " Where p.po_number='" +m_quoteNumber + "'";
	
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_nPurchaseReturn = myAdapter.Fill(dst, "purchase_serial");

	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}
	//DEBUG("Total Items = ",dst.Tables["serial"].Rows.Count.ToString());

	Response.Write("<table border=0 cellspacing=3 cellpadding=2>");
	Response.Write("<tr><td colspan=7 align=center><b>-Serial Page-</b></td></tr>");
	Response.Write("<tr bgcolor=#E7F3DC><td>PO Number</td>");
	Response.Write("<td>Product Code</td>");
	Response.Write("<td>Supplier</td>");
	Response.Write("<td>Supplier Code</td>");
	Response.Write("<td>Unit Price</td>");
	Response.Write("<td>Quantity</td>");
	Response.Write("<td>Product Description</td>");
	Response.Write("</tr>");
	bool bCheck = true;
	string s_ponumber = "";
	string s_supplier = "";
	string s_supp_code = "";
	string s_cost = "";
	string s_qty = "";
	string s_prod_desc = "";
	string s_product_code = "";
	string s_date_create = "";
	for(int i=0; i<dst.Tables["purchase_serial"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["purchase_serial"].Rows[i];
		/*string s_ponumber = dr["po_number"].ToString();
		string s_supplier = dr["supplier"].ToString();
		string s_supp_code = dr["supplier_code"].ToString();
		string s_cost = dr["price"].ToString();
		string s_qty = dr["qty"].ToString();
		string s_prod_desc = dr["name"].ToString();
		string s_product_code = dr["product_code"].ToString();
		string s_date_create = dr["date_create"].ToString();
*/
		s_ponumber = dr["po_number"].ToString();
		s_supplier = dr["supplier"].ToString();
		s_supp_code = dr["supplier_code"].ToString();
		s_cost = dr["price"].ToString();
		s_qty = dr["qty"].ToString();
		s_prod_desc = dr["name"].ToString();
		s_product_code = dr["product_code"].ToString();
		s_date_create = dr["date_create"].ToString();
		
		m_ponumber = s_ponumber;
		m_supplier = s_supplier;
		m_supplier_code = s_supp_code;
		m_cost = s_cost;
		m_prod_desc = s_prod_desc;
		m_prod_code = s_product_code;
		m_qty =	s_qty;
		m_date_create = DateTime.Parse(s_date_create).ToString("dd/MM/yyyy");
		
		string s_pcode_tmp = "";
//DEBUG("m_ncheckQty=", m_ncheckQty);
//DEBUG("m_checkProduct = ", m_checkProduct_code);
			if(Request.QueryString["prodcode"] != null)
			{
				s_pcode_tmp = Request.QueryString["prodcode"].ToString();
				if(m_prod_code == s_pcode_tmp )
					Response.Write("<tr bgcolor=lightblue>");
					bCheck = false;
			}
			else if(bCheck && i == dst.Tables["purchase_serial"].Rows.Count -1)
			{
				Response.Write("<tr bgcolor=lightblue>");
				bCheck = false;
			}
			else
				Response.Write("<tr>");
	
			Response.Write("<td>"+s_ponumber+"</td>");
			//Response.Write("<td><a href='serial2.aspx?n="+m_quoteNumber+"&prodid="+s_product_code+"&qty="+s_qty+"'>-->"+s_product_code+"<--</a></td>");
			Response.Write("<td><a href='serial2.aspx?n="+m_quoteNumber+"&prodcode="+s_product_code+"'>-->"+s_product_code+"<--</a></td>");
			Response.Write("<td>"+s_supplier+"</td>");
			Response.Write("<td>"+s_supp_code+"</td>");
			Response.Write("<td>"+double.Parse(s_cost).ToString("c")+"</td>");
			Response.Write("<td>"+s_qty+"</td>");
			Response.Write("<td>"+s_prod_desc+"</td></tr>");
		
		
	
	}


	for(int i=0; i< dst.Tables["purchase_serial"].Rows.Count; i++)
	{
		m_iTatalOrdrItems += int.Parse(dst.Tables["purchase_serial"].Rows[i]["qty"].ToString());
	}

	
	return true;
}


bool GetCurrentProduct()
{
	string s_pcode = "";
	if(Request.QueryString["prodcode"] != null)
		s_pcode = Request.QueryString["prodcode"].ToString();

	m_quoteNumber = Request.QueryString["n"];
	string sc = " SELECT p.po_number, pi.supplier, pi.supplier_code, pi.price, pi.qty, pd.name, pi.product_code,p.date_create ";
	sc += " FROM purchase p INNER JOIN purchase_item pi ";
	sc += " ON p.po_number = pi.po_number INNER JOIN product pd ";
	sc += " ON pi.product_code = pd.code ";
	sc += " WHERE p.po_number='" +m_quoteNumber + "'"; 
	sc += " AND pi.product_code = '"+s_pcode+"'";

	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "selected_serial");

	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}
	

	return true;
}

bool BindISTable()
{
	Response.Write("<script Language=javascript");
	Response.Write(">");
	Response.Write("<!-- hide from older browser");
	const string jav = @"
	function checkform() 
	{	
		var snEnd1=document.frmSerial.txtEnd1;
		var snS=document.frmSerial.txtSerial;
		if(document.frmSerial.chk.checked){
			if(snS.value.length<2){
			window.alert ('At least 2 digits need to input!');
			snS.focus();
			return false;
			}
			if(snEnd1.value==''){
				snEnd1.focus();
			return false;
			}
		}
		else{
			if(snS.value.length<2){
			window.alert ('At least 2 digits need to input!');
			snS.focus();
			return false;
			}
		}
		
		if(document.frmSerial.txtInvoice.value==''){
			window.alert('Please enter Invoice Number');
			document.frmSerial.txtInvoice.focus();
			return false;
		}
		
	}	
	
	";
	Response.Write("--> "); 
	Response.Write(jav);
	Response.Write("</script");
	Response.Write("> ");
	if(Request.QueryString["prodcode"] != null)
	{
		DataRow dr = dst.Tables["selected_serial"].Rows[0];
		m_ponumber = dr["po_number"].ToString();
		m_supplier = dr["supplier"].ToString();
		m_supplier_code = dr["supplier_code"].ToString();
		m_cost = dr["price"].ToString();
		m_qty = dr["qty"].ToString();
		m_prod_desc = dr["name"].ToString();
		m_prod_code = dr["product_code"].ToString();
		m_date_create = DateTime.Parse(dr["date_create"].ToString()).ToString("dd/MM/yyyy");;
	}

	
	Response.Write("<tr><td colspan=4>Current Item to be Entered Serial Number</td></tr>");
	Response.Write("<tr bgcolor=lightgreen><td>"+m_ponumber+"</td>");
	Response.Write("<td>"+m_prod_code+"</td>");
	
	Response.Write("<td>"+m_supplier+"</td>");
	Response.Write("<td>"+m_supplier_code+"</td>");
	Response.Write("<td>"+double.Parse(m_cost).ToString("C")+"</td>");
	Response.Write("<td>"+m_qty+"</td>");
	
	Response.Write("<td>"+m_prod_desc+"</td></tr>");
	
	if(Request.QueryString["qty"] != null)
		Response.Write("<form name=frmSerial method=post action='serial2.aspx?n="+m_quoteNumber+"&prodcode="+m_prod_code+"&qty="+m_ncheckQty+"'>");
	else
		Response.Write("<form name=frmSerial method=post action='serial2.aspx?n="+m_quoteNumber+"&prodcode="+m_prod_code+"&qty="+m_qty+"'>");
	Response.Write("<table border=0 cellspacing=3 cellpadding=2>");

	Response.Write("<tr><td align=right>Supplier Name:</td>");
	Response.Write("<td><input type=text name=optSupp value='"+m_supplier+"'");
	Response.Write("</td>");

	Response.Write("<td align=right>Purchase Date (DD/MM/YYYY):</td><td bgcolor=#E2E2E2> ");
	Response.Write("<input type=text name=txtDate value='"+m_date_create+"'></td></tr>");
	Response.Write("<tr><td align=right>Invoice No:</td><td><input type=text name=txtInvoice value='"+m_ponumber+"'></td>");

	Response.Write("<td align=right>Warranty Period :</td>");
	Response.Write("<td><select name=optWarrant>");
	Response.Write("<option value=1>1<option value=2>2<option value=3>3<option value=4>4<option value=5>5");
	Response.Write("</select></td></tr>");
	
	Response.Write("<tr><td align=right>Product Code:</td>");
	Response.Write("<td><input type=text name=optProdCode value='"+m_prod_code+"'></td>");
	Response.Write("<td align=right>Quantity:</td><td><input type=text name=txtQty value='"+m_qty+"'></td>");
	Response.Write("</tr>");

	Response.Write("<tr><td align=right>Supplier Code:</td>");
	Response.Write("<td><input type=text name=txtSuppCode value='"+m_supplier_code+"'></td>");
	Response.Write("<td align=right>Cost:</td><td><input type=text name=txtCost value='"+m_cost+"'></td>");
	Response.Write("</tr>");
	
	Response.Write("<tr><td align=right>Product Description:</td><td><input type=text name=txtProdDesc value='"+m_prod_desc+"'></td> ");
	Response.Write("<td align=right>Product Status : </td> ");
	Response.Write("<td><select name=status><option value=1>Sold<option value=2 selected>In Stock<option value=3>Lost<option value=4>RMA</select></td>");
	Response.Write("</tr>");

	Response.Write("<tr bgcolor=#E3E3E3><td>&nbsp;</td><td>-Select Number to be increased-</td>");
	Response.Write("<td>-Start Serial Number-</td><td>-End Serial Number-</td>");
	Response.Write("</tr>");


	int n_qty = 0;
	if(Request.QueryString["qty"] != null )
		n_qty = int.Parse(Request.QueryString["qty"]);
	else
		n_qty = int.Parse(m_qty);

	if(n_qty == 1 )
	{
		Response.Write("<tr><td align=right>Input Serial NO:</td><td align=right><input type=hidden name=chk>");
		Response.Write("<td><input type=text name=txtSerial value=''></td>");
		Response.Write("<script");
		Response.Write(">\r\ndocument.frmSerial.txtSerial.focus();\r\n</script");
		Response.Write(">\r\n");
		Response.Write("<td><input type=hidden name=txtEnd1 value=''></td>");
	}
	else
	{
		string s_i="";
		Response.Write("<tr><td align=right>Input Serial NO:</td><td align=right>Tick to use Generate Serial<input type=checkbox name=chk>");
		Response.Write("<select name=optSelect>");
		
		for(int i=1;i<11; i++)
		{
			s_i=i.ToString();
			if(m_last_key == s_i)
				Response.Write("<option selected>"+m_last_key+"");
			else
				Response.Write("<option>"+i+"");
		}
		Response.Write("</select></td>");
		Response.Write("<td><input type=text name=txtSerial value=''></td>");
		Response.Write("<script");
		Response.Write(">\r\ndocument.frmSerial.txtSerial.focus();\r\n</script");
		Response.Write(">\r\n");
		Response.Write("<td><input type=text name=txtEnd1 value=''></td>");
		//Response.Write(" name=txtEnd1 value=''></td><td><input type=text name=txtEnd2 value='not yet function'></td></tr>");
	}	
	Response.Write("<tr><td colspan=4 align=right>");
	Response.Write("<input type=submit name='cmd' value='Update SerialNO' Onclick='return checkform()'> ");
	Response.Write("<input type=reset name=cmd value=Reset></td></tr>");
	//Response.Write("<tr><td>&nbsp;</td></tr>");
	//Response.Write("<tr><td colspan=5 align=right><font color=#999EEE>*status (1)sold (2)in stock (3)lost (4)rma </font></td></tr>");
	Response.Write("<tr><td colspan=5> <hr color=black size=1 ></td></tr>");
	Response.Write("</table></form>");
	
	return true;
}

void PrintForm()
{
	Response.Write("<script Language=javascript");
	Response.Write(">");
	Response.Write("<!-- hide from older browser");
	const string jav = @"
	function checkform() 
	{	
		var snEnd1=document.frmSerial.txtEnd1;
		var snS=document.frmSerial.txtSerial;
		if(document.frmSerial.chk.checked){
			if(snS.value.length<2){
			window.alert ('At least 2 digits need to input!');
			snS.focus();
			return false;
			}
			if(snEnd1.value==''){
				snEnd1.focus();
			return false;
			}
		}
		else{
			if(snS.value.length<2){
			window.alert ('At least 2 digits need to input!');
			snS.focus();
			return false;
			}
		}
		
		if(document.frmSerial.txtInvoice.value==''){
			window.alert('Please enter Invoice Number');
			document.frmSerial.txtInvoice.focus();
			return false;
		}
		
		/*if (!IsNumberic(document.frmSerial.txtInvoice.value)) { 
			  window.alert('Please enter only numbers in the invoice number field'); 
			  document.frmSerial.txtInvoice.focus();
			  return false; 
		}*/

	}	
	
	function IsNumberic(sText)
	{
		   var ValidChars = '0123456789';
		   var IsNumber=true;
		   var Char;
 	   for (i = 0; i < sText.length && IsNumber == true; i++) 
	   { 
		  Char = sText.charAt(i); 
		  if (ValidChars.indexOf(Char) == -1) 
		  {
			 IsNumber = false;
		  }
	   }
		   return IsNumber;
	}

	";
	Response.Write("--> "); 
	Response.Write(jav);
	Response.Write("</script");
	Response.Write("> ");
	if(!GetSupplierName())
		return;
	
	string sCurrentDate = DateTime.UtcNow.AddHours(12).ToString("dd/MM/yyyy");
	Response.Write("<form name=frmSerial method=post action=serial2.aspx>");
	Response.Write("<table border=0 cellspacing=3 cellpadding=2>");
	Response.Write("<tr bgcolor=#E7F3DC><td colspan=6 align=center><b>-Serial Page-</b></td></tr>");
	Response.Write("<tr><td align=right>Supplier Name:(*)</td>");
	Response.Write("<td><Select name=optSupp>");
	string s_supplier="", s_supp_name="";

	if(Request.Form["optSupp"] != null)
		m_last_supp=Request.Form["optSupp"].ToString();

	string s_tmp = "";
	int ilength = 0;
	for(int i=0; i<m_last_supp.Length; i++)
	{
		s_tmp = m_last_supp[i].ToString();
		if(s_tmp == "=")
			ilength=i;
	}

	string s_swap = "";
	//int ilength = m_last_supp.Length-3;
	for(int i=0; i<ilength-1; i++)
		s_swap += m_last_supp[i].ToString();

	m_last_supp = s_swap;
	for(int i=0; i<m_SearchSupplier; i++)
	{
		DataRow dr = dst.Tables["supplier"].Rows[i];
		s_supplier=dr["short_name"].ToString();
		s_supp_name=dr["name"].ToString();

		//if(m_last_supp==s_supplier)
		if(m_last_supp==s_supp_name)
		{
			Response.Write("<option selected>"+s_supp_name+" ="+s_supplier+"");
			//Response.Write("<option selected>"+s_supplier+"");
		}
		else
		{
			//Response.Write("<option>"+s_supplier+"");
			Response.Write("<option>"+s_supp_name+" ="+s_supplier+"");
		}
	}

	Response.Write("</td>");
//DEBUG(" m last uspp= ", m_last_supp);	
//DEBUG(" temp = ", last_supp);
	if(Request.Form["optWarrant"] !=null)
		m_last_warrant = Request.Form["optWarrant"].ToString();

	Response.Write("<td align=right>Purchase Date (DD/MM/YYYY):</td><td bgcolor=#E2E2E2><input type=text name=txtDate value='"+sCurrentDate+"'></td></tr>");
	Response.Write("<tr><td align=right>Invoice No:(*)</td><td><input type=text name=txtInvoice value='"+m_last_invno+"'></td>");
	

	Response.Write("<td align=right>Warranty Period :</td>");
	Response.Write("<td><select name=optWarrant>");
	for(int i=1; i<6; i++)
	{
		if(m_last_warrant==i.ToString())
			Response.Write("<option selected>"+m_last_warrant+"");
		else
			Response.Write("<option>"+i.ToString()+"");
	}
	
	Response.Write("</select></td></tr>");

	Response.Write("</tr>");
	/*if(!GetProductCode())
		return;
	*/
	Response.Write("<tr><td align=right>Product Code:</td>");
	string s_prodcode="";
	if(Request.Form["optProdCode"] != null)
		m_last_prodcode=Request.Form["optProdCode"].ToString();
	Response.Write("<td><input type=text name=optProdCode value='"+s_prodcode+"'></td>");
	//Response.Write("<td><Select name=optProdCode><option>");


	/*for(int i=0; i<dst.Tables["code"].Rows.Count; i++)
	{
		DataRow dr = dst.Tables["code"].Rows[i];
		s_prodcode=dr["product_code"].ToString();
		if(m_last_prodcode==s_prodcode)
			Response.Write("<option selected>"+s_prodcode+"");
		else
			Response.Write("<option>"+s_prodcode+"");
	
	}

	Response.Write("</select> "); //&nbsp; <a href='createpcode.aspx'><u><b>Create new Product Code<b></u></a></td>");
	*/
	Response.Write("<td align=right>Quantity:</td> ");
	Response.Write("<td><input type=text name=txtQty value='1'></td>");
	Response.Write("</tr>");
	Response.Write("<tr><td align=right>Supplier Code:</td>");
	Response.Write("<td><input type=text name=txtSuppCode value=''></td>");
	Response.Write("<td align=right>Cost:</td><td><input type=text name=txtCost value=''></td>");
	Response.Write("</tr>");
	//sponse.Write("<input type=hidden name=txtQty value=''>");
	Response.Write("<tr><td align=right>Product Description:</td><td><input type=text name=txtProdDesc value=''></td> ");
	Response.Write("<td align=right>Product Status : </td> ");
	Response.Write("<td><select name=status><option value=1>Sold<option value=2 selected>In Stock<option value=3>Lost<option value=4>RMA</select></td>");
	Response.Write("</tr>");

	Response.Write("<tr bgcolor=#E3E3E3><td>&nbsp;</td><td>-Select Number to be increased-</td>");
	Response.Write("<td>-Start Serial Number-</td><td>-End Serial Number-</td>");
	Response.Write("</tr>");

	string s_i="";
	Response.Write("<tr><td align=right>Input Serial NO:</td><td align=right>Tick to use Generate Serial<input type=checkbox name=chk>");
	Response.Write("<select name=optSelect>");
	if(Request.Form["optSelect"] != null)
		m_last_key=Request.Form["optSelect"].ToString();

	for(int i=1;i<11; i++)
	{
		s_i=i.ToString();
		if(m_last_key == s_i)
			Response.Write("<option selected>"+m_last_key+"");
		else
			Response.Write("<option>"+i+"");
	}
	Response.Write("</select></td>");
	Response.Write("<td><input type=text name=txtSerial value=''></td>");
	Response.Write("<script");
	Response.Write(">\r\ndocument.frmSerial.txtSerial.focus();\r\n</script");
	Response.Write(">\r\n");
	Response.Write("<td><input type=text name=txtEnd1 value=''></td>");
	//Response.Write(" name=txtEnd1 value=''></td><td><input type=text name=txtEnd2 value='not yet function'></td></tr>");
	
	Response.Write("<tr><td colspan=4 align=right>");
	Response.Write("<input type=submit name='cmd' value='Update SerialNO' Onclick='return checkform()'> ");
	Response.Write("<input type=reset name=cmd value=Reset></td></tr>");
	//Response.Write("<tr><td>&nbsp;</td></tr>");
	//Response.Write("<tr><td colspan=5 align=right><font color=#999EEE>*status (1)sold (2)in stock (3)lost (4)rma </font></td></tr>");
	Response.Write("<tr><td colspan=5> <hr color=black size=1 ></td></tr>");
	Response.Write("</table></form>");
	
	

}

bool GetSupplierName()
{	
	string sc = "SELECT short_name, name FROM card ";
	sc += " WHERE type = 3 ";
	sc += " ORDER BY name ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		m_SearchSupplier=myAdapter.Fill(dst, "supplier");
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;

}

bool GetProductCode()
{
	string sc = " SELECT product_code FROM product_code ";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "code");
	}
	catch(Exception e)
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}


bool InsertSerial(string sSerial, string sSupplier, string sInvoice, string sCost, string sSuppCode,
				  string sProd_Desc, string sDate, string sWarrant, string sProdCode)
{

	if(Request.QueryString["qty"] != null)
	{
		m_qty = Request.QueryString["qty"].ToString();
		m_qty = (int.Parse(m_qty) - 1).ToString();
		m_ncheckQty = int.Parse(m_qty);
	DEBUG("m_ncheckQty = ", m_ncheckQty);
	}

	//string sc = "SELECT serial_number FROM stock2 ";
	string sc = "SELECT sn FROM stock ";
	sc += " WHERE sn = '"+sSerial+"'";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		int i = myAdapter.Fill(dst, "serialtable");
//DEBUG("Date = ", sDate);
		if(i<1)
		{
			string s_status = "";
			s_status = Request.Form["status"].ToString();
			string ssc = "set DATEFORMAT dmy ";
			ssc +=" INSERT INTO stock (sn, po_number, supplier, purchase_date, warranty, prod_desc, ";
			ssc += " status, product_code, cost, supplier_code) ";
			ssc += "VALUES ('"+sSerial+"','"+sInvoice+"','"+sSupplier+"','"+sDate+"',"+sWarrant+", ";
			ssc += " '"+sProd_Desc+"',"+s_status+", '"+sProdCode+"', "+sCost+", '"+sSuppCode+"') ";
			try
			{
				myCommand = new SqlCommand(ssc);
				myCommand.Connection = myConnection;
				myConnection.Open();
				myCommand.ExecuteNonQuery();
				myCommand.Connection.Close();
				
			}
			catch(Exception e)
			{
				ShowExp(ssc, e);
				return false;
			}
		}
		else
		{
			Response.Write("<embed src=/wav/09.mp3 volume=100 hidden=true autostart=true>");
			Response.Write("<script language=javascript> <!--");
			const string jav = @"
				window.alert('Serial number already Exist, PLEASE TRY AGAIN');
			";
			Response.Write("-->");
			Response.Write(jav);
			Response.Write("</script");
			Response.Write(">");
			
			return false;
		}
	
	}
	catch (Exception e)
	{
		ShowExp(sc,e);
		return false;
	}
	return true;
}

bool GetInsertedSerial()
{
	
	//string sc = " set DATEFORMAT dmy ";
	//string sc = " SELECT *  FROM  stock ";
	string sc = " SELECT TOP 100 ";
	sc += " s.product_code 'Product Code', s.sn 'Serial Number', s.branch_id 'Brnach ID', ";
	sc += " s.supplier 'Supplier', s.supplier_code 'Supplier Code', s.purchase_date 'Purchase Date', ";
	sc += " s.po_number 'PO Number', s.cost 'Cost', s.warranty 'Warranty', e.name 'Status', s.prod_desc 'Product Description', s.id " ;
	sc += " FROM stock s INNER JOIN enum e ON ";
	sc += " e.id=s.status ";
	sc += " WHERE e.class = 'stock_status' ";
	//sc += " SELECT *  FROM  stock2 ";
	sc += " ORDER BY update_time DESC";
	
	try
	{
		myAdapter =  new SqlDataAdapter(sc, myConnection);
		m_nSearchReturn = myAdapter.Fill(dst,"currentserial");

	}
	catch (Exception e)
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}

bool DoMassInputEnd(string s_end,  ref string s_endAt)
{
	char[] cb = s_end.ToCharArray();
	int p=0;
	for(p=s_end.Length-1; p>=0; p--)
	{
		if(!Char.IsDigit(cb[p]))
			break;
	}
	p++;
	if(p<s_end.Length-1)
	{
		for(;p<s_end.Length;p++)
			s_endAt += cb[p];
	}
//DEBUG("end=", s_endAt);
	return true;
}
bool DoMassiveInput(ref string prefix, ref string sb)
{
	string sBegin = Request.Form["txtSerial"];

	prefix = "";
	sb = "";
	char[] cb = sBegin.ToCharArray();	
	int p = 0;
	for(p=sBegin.Length-1; p>=0; p--)
	{
		if(!Char.IsDigit(cb[p]))
			break;
	}
	p++;
	for(int i=0; i<p; i++)
		prefix += cb[i];

	if(p<sBegin.Length-1)
	{
		for(;p<sBegin.Length;p++)
			sb += cb[p];
	}
	else
		return false;
//DEBUG("begin =", sb);
//DEBUG("prefix =", prefix);
	return true;
}
bool MassInsertSerial(string sEnd, int iStep, string sPrefix, string sSb, string sSupplier, string sInv,
				 string sCost, string sSuppCode, string sProd, string sDate, string sWarrant, string sProdCode)
{

	//int iStart = int.Parse(sSb);
	//int iEnd   = int.Parse(sEnd);
	long iStart = long.Parse(sSb);
	long iEnd   = long.Parse(sEnd);
	//int qty = int.Parse(Request.Form["sOrderQty"].ToString());
	int countTimes = 0;

	//int nBeginLen = Request.Form["txtEnd1"].Length;
	long nBeginLen = Request.Form["txtEnd1"].Length;
	int nNumLen = 0;
	//for(int i=iStart;i<=iEnd;i+=iStep)
	for(long i=iStart;i<=iEnd;i+=iStep)
	{
		string s_serial = sPrefix;
		nNumLen = i.ToString().Length;
		long pad = nBeginLen - sPrefix.Length - i.ToString().Length;
		//for(int j=0; j<pad; j++)
		for(long j=0; j<pad; j++)
			s_serial += "0";
		s_serial += i.ToString();
		
		countTimes+=1;

		InsertSerial(s_serial,sSupplier,sInv,sCost, sSuppCode, sProd,sDate, sWarrant, sProdCode);
			
	}
	return true;	
}

bool DelSerial(string s_id)
{
	string sc = "DELETE FROM stock ";
	sc += " WHERE id = '"+ s_id +"'";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch (Exception e)
	{
		ShowExp(sc, e);
		return false;
	}

	return true;
}

void BindSNGrid()
{
	string sBoldO = "<b>";
	string sBoldC = "</b>";
	string sBkColor = "bgcolor=yellow";
//DEBUG("returned rows=",m_nSearchReturn);
	Response.Write("<table align valign=center cellspacing=1 cellpadding=2 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:9pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	
	Response.Write("<tr><td colspan=3 bgcolor=#E3E3E3>Display the latest 20 rows only</td>");
	//Response.Write("<td align=right colspan=3><a href='serial2.aspx?sn=v' target='_blank'>Click here to List all products in Stock--></td></tr>");
	Response.Write("<td align=right colspan=3><a href='stock.aspx' target='_blank'>Click here to List all products in Stock--></td></tr>");
	Response.Write("<tr style=\"color:black;background-color:#E3E3E3;font-weight:bold;\">\r\n");
	
	Response.Write("<td>Serial NO</td>");
	Response.Write("<td>Supplier</td>");
	Response.Write("<td>Invoice NO</td>");
	Response.Write("<td>Purchase Date</td>");
	Response.Write("<td>Product Desc</td>");
	Response.Write("<td>Warranty(yr)");
	Response.Write("<td>&nbsp;</td>");
	Response.Write("</tr>");
	int j=0;
	j=m_nSearchReturn;
	//for(int i=0; i<m_nSearchReturn; i++)
	for(int i=0; i<j; i++)
	{
		DataRow dr = dst.Tables["currentserial"].Rows[i];
		string sn=dr["Serial Number"].ToString();
		string ssupp=dr["Supplier"].ToString();
		string sinv=dr["PO Number"].ToString();
		string spurchase_date=dr["Purchase Date"].ToString();
		string sprod_desc=dr["Product Description"].ToString();
		string swarranty = dr["Warranty"].ToString();
		string s_id = dr["id"].ToString();
		if(i>0)
		{
			sBoldO = "";
			sBoldC = "";
			sBkColor = "";
		}
		Response.Write("<tr bgcolor=lightyellow fontcolor=red><td >"+sBoldO+sn+sBoldO+"</td>");
		Response.Write("<td>"+sBoldO+ssupp+sBoldO+"</td>");
		Response.Write("<td>"+sBoldO+sinv+sBoldO+"</td>");
		Response.Write("<td>"+sBoldO+spurchase_date+sBoldO+"</td>");
		Response.Write("<td>"+sBoldO+sprod_desc+sBoldO+"</td>");
		Response.Write("<td>"+sBoldO+swarranty+sBoldO+"</td>");
		//Response.Write("<td><input type=textbox name=chnage value='"+swarranty+"'></td>");
		//Response.Write("<td><a href='serial2.aspx?del="+sn+"'>del</td></tr>");
		Response.Write("<td><a href='serial2.aspx?del="+s_id+"'>del</td></tr>");
		if(i==20)
			j=20;

	}
	Response.Write("<tr><td colspan=6 align=right>");
	Response.Write("<a href='stock.aspx' target='_blank'>Click here to List all products in Stock--></td>");
	//Response.Write("<tr><td colspan=6 align=right><input type=button name=update value='Update'></td>");

	Response.Write("</tr>");

	Response.Write("</table>");
}


void BindGrid()
{
	DataView source = new DataView(dst.Tables["currentserial"]);

	MyDataGrid.DataSource = source ;
	MyDataGrid.DataBind();
}

void MyDataGrid_Page(object sender, DataGridPageChangedEventArgs e) 
{
	MyDataGrid.CurrentPageIndex = e.NewPageIndex;
	BindGrid();
}

</script>
<form runat=server> 
<b>Inserted Product -Display only the Top 100 Items-</b><br>

<asp:DataGrid id=MyDataGrid
	runat=server 
	AutoGenerateColumns=true
	BackColor=White 
	BorderWidth=1px 
	BorderStyle=Solid 
	BorderColor=#E3E3E3
	CellPadding=2
	CellSpacing=0
	Font-Name=Verdana 
	Font-Size=8pt 
	width=100% 
	style=fixed
	HorizontalAlign=left
	AllowPaging=True
	PageSize=20
	PagerStyle-PageButtonCount=10
	PagerStyle-Mode=NumericPages
	PagerStyle-HorizontalAlign=left
    OnPageIndexChanged=MyDataGrid_Page
	>
	
	<HeaderStyle BackColor=#E3E3E3 ForeColor=black Font-Bold=true/>
	<ItemStyle ForeColor=DarkSlateBlue/>
	<AlternatingItemstyle BackColor=#EEEEEE/>
	

	<Columns>
		<asp:HyperLinkColumn
			 HeaderText=""
			 DataNavigateUrlField=id
			 DataNavigateUrlFormatString="serial2.aspx?Del={0}"
			 Text=Delete
			 />
	</Columns>

</asp:DataGrid>

</form>
<asp:Label id=LFooter runat=server/>