<script runat=server>

void Page_Load(Object Src, EventArgs E ) 
{
	Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=autoupdate.aspx\">");
}
</script>