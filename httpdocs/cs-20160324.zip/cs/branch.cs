<script runat=server>
DataSet dst = new DataSet();
DataSet dsi = new DataSet();

void Page_Load(Object Src, EventArgs E)
{
	TS_PageLoad(); //do common things, LogVisit etc...

	string s_cmd = "";
	if(Request.Form["cmd"] != null)
	{
		s_cmd = Request.Form["cmd"];
		Trim(ref s_cmd);
	}

	if(s_cmd == "Add")
	{
		if(DoAddNewBranch())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?" + "\">");
		return;
	}
	else if(s_cmd =="Modify")
	{
		if(UpdateBranch())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?" + "\">");
		return;
	}
	else if(s_cmd =="Delete")
	{
		if(DeleteBranch())
			Response.Write("<meta http-equiv=\"refresh\" content=\"0; URL=?" + "\">");
		return;
	}

	PrintAdminHeader();
	PrintAdminMenu();

	Response.Write("<br><hr3><center><b><font size=+1>Branch List</font></b></center></h3>");
	Response.Write("<table width=90%  align=center valign=top cellspacing=0 cellpadding=0 border=1 bordercolor=#EEEEEE bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr><td width=60% align=center valign=top>");
	LoadExistingBranch();
	Response.Write("</td><td width=40% align=center valign=top>");

	PrintOneBranch();

	Response.Write("</td></tr></table>");

	PrintAdminFooter();
}

bool DoAddNewBranch()
{
	string id = "";
	string name = Request.Form["name"];
	string address1 = Request.Form["address1"];
	string address2 = Request.Form["address2"];
	string address3 = Request.Form["address3"];
	string city = Request.Form["city"];
	string country = Request.Form["country"];
	string phone = Request.Form["phone"];
	string fax = Request.Form["fax"];
	string postal1 = Request.Form["postal1"];
	string postal2 = Request.Form["postal2"];
	string postal3 = Request.Form["postal3"];

	if(name.Length >= 49)
		name = name.Substring(0, 49);
	if(address1.Length >= 49)
		address1 = address1.Substring(0, 49);
	if(address2.Length >= 49)
		address2 = address2.Substring(0, 49);
	if(address3.Length >= 49)
		address3 = address3.Substring(0, 49);
	if(city.Length >= 49)
		city = city.Substring(0, 49);
	if(country.Length >= 49)
		country = country.Substring(0, 49);
	if(phone.Length >= 49)
		phone = phone.Substring(0, 49);
	if(fax.Length >= 49)
		fax = fax.Substring(0, 49);
	if(postal1.Length >= 49)
		postal1 = postal1.Substring(0, 49);
	if(postal2.Length >= 49)
		postal2 = postal2.Substring(0, 49);
	if(postal3.Length >= 49)
		postal3 = postal3.Substring(0, 49);

	string sc = " IF NOT EXISTS(SELECT * FROM branch WHERE name='" + EncodeQuote(name) + "') ";
	sc += " INSERT INTO branch (name, address1, address2, address3, city, country, phone, fax, postal1, postal2, postal3) ";
	sc += " VALUES( ";
	sc += "'" + EncodeQuote(name) + "' ";
	sc += ", '" + EncodeQuote(address1) + "' ";
	sc += ", '" + EncodeQuote(address2) + "' ";
	sc += ", '" + EncodeQuote(address3) + "' ";
	sc += ", '" + EncodeQuote(city) + "' ";
	sc += ", '" + EncodeQuote(country) + "' ";
	sc += ", '" + EncodeQuote(phone) + "' ";
	sc += ", '" + EncodeQuote(fax) + "' ";
	sc += ", '" + EncodeQuote(postal1) + "' ";
	sc += ", '" + EncodeQuote(postal2) + "' ";
	sc += ", '" + EncodeQuote(postal3) + "' ";
	sc += ") ";
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

bool UpdateBranch()
{
	string id = Request.Form["id"];
	string name = Request.Form["name"];
	string address1 = Request.Form["address1"];
	string address2 = Request.Form["address2"];
	string address3 = Request.Form["address3"];
	string city = Request.Form["city"];
	string country = Request.Form["country"];
	string phone = Request.Form["phone"];
	string fax = Request.Form["fax"];
	string postal1 = Request.Form["postal1"];
	string postal2 = Request.Form["postal2"];
	string postal3 = Request.Form["postal3"];

	if(name.Length >= 49)
		name = name.Substring(0, 49);
	if(address1.Length >= 49)
		address1 = address1.Substring(0, 49);
	if(address2.Length >= 49)
		address2 = address2.Substring(0, 49);
	if(address3.Length >= 49)
		address3 = address3.Substring(0, 49);
	if(city.Length >= 49)
		city = city.Substring(0, 49);
	if(country.Length >= 49)
		country = country.Substring(0, 49);
	if(phone.Length >= 49)
		phone = phone.Substring(0, 49);
	if(fax.Length >= 49)
		fax = fax.Substring(0, 49);
	if(postal1.Length >= 49)
		postal1 = postal1.Substring(0, 49);
	if(postal2.Length >= 49)
		postal2 = postal2.Substring(0, 49);
	if(postal3.Length >= 49)
		postal3 = postal3.Substring(0, 49);

	if(id == null || id == "")
	{
		Response.Write("<br><center><h3>Error, no ID</h3>");
		return false;
	}

	string sc = "UPDATE branch SET ";
	sc += " name='" + EncodeQuote(name) + "' ";
	sc += ", address1 = '" + EncodeQuote(address1) + "' ";
	sc += ", address2 = '" + EncodeQuote(address2) + "' ";
	sc += ", address3 = '" + EncodeQuote(address3) + "' ";
	sc += ", city = '" + EncodeQuote(city) + "' ";
	sc += ", country = '" + EncodeQuote(country) + "' ";
	sc += ", phone = '" + EncodeQuote(phone) + "' ";
	sc += ", fax = '" + EncodeQuote(fax) + "' ";
	sc += ", postal1 = '" + EncodeQuote(postal1) + "' ";
	sc += ", postal2 = '" + EncodeQuote(postal2) + "' ";
	sc += ", postal3 = '" + EncodeQuote(postal3) + "' ";
	sc += " WHERE id = " + id;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;	
}

bool DeleteBranch()
{
	string id = Request.Form["id"];
	if(id == null || id == "")
	{
		Response.Write("<br><center><H3>Error, no id");
		return false;
	}

	string sc = "DELETE FROM branch WHERE id = " + id;
	try
	{
		myCommand = new SqlCommand(sc);
		myCommand.Connection = myConnection;
		myConnection.Open();
		myCommand.ExecuteNonQuery();
		myCommand.Connection.Close();
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

void LoadExistingBranch()
{
	if(!GetExistingBranch())
		return;
	
	Response.Write("<table width=100% valign=top cellspacing=1 cellpadding=1 border=0 bordercolor=#000000 bgcolor=white");
	Response.Write(" style=\"font-family:Verdana;font-size:8pt;border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>");
	Response.Write("<th width=5%>ID</th>");
	Response.Write("<th nowrap>Name</th>");
	Response.Write("<th>City</th>");
	Response.Write("<th>Country</th>");
	Response.Write("<th>&nbsp;</th>");
	Response.Write("</tr>\r\n");

	for(int i=0; i<dst.Tables["branch"].Rows.Count;i++)
	{
		DataRow dr = dst.Tables["branch"].Rows[i];
		string id = dr["id"].ToString();
		string name = dr["name"].ToString();
		string city = dr["city"].ToString();
		string country = dr["country"].ToString();
        
        if(i % 2 == 0){
            Response.Write("<tr>");
        }else{
            Response.Write("<tr  class=rowColor>");
        }

		
		Response.Write("<td>" + id + "</td>");
		Response.Write("<td>" + name + "</td>");
		Response.Write("<td>" + city + "</td>");
		Response.Write("<td>" + country + "</td>");
		Response.Write("<td align=right><a href=?t=m&i=" + id + " class=o>Edit</a></td>");
		Response.Write("</tr>\r\n");
	}
	Response.Write("</table>");

	return;
}

void PrintOneBranch()
{
	string id = "";
	string name = "";
	string address1 = "";
	string address2 = "";
	string address3 = "";
	string city = "";
	string country = "";
	string phone = "";
	string fax = "";
	string postal1 = "";
	string postal2 = "";
	string postal3 = "";

	string s_TblName = "Add";

	if(Request.QueryString["t"] == "m" && Request.QueryString["i"] != null && Request.QueryString["i"] != "")
	{
		s_TblName = "Modify";
		if(Request.QueryString["i"] != null && Request.QueryString["i"] != "")
		{
			if(!GetSelectedRow())
				return;
			DataRow dr = dsi.Tables["selected"].Rows[0];
			id = dr["id"].ToString();
			name = dr["name"].ToString();
			address1 = dr["address1"].ToString();
			address2 = dr["address2"].ToString();
			address3 = dr["address3"].ToString();
			city = dr["city"].ToString();
			country = dr["country"].ToString();
			phone = dr["phone"].ToString();
			fax = dr["fax"].ToString();
			postal1 = dr["postal1"].ToString();
			postal2 = dr["postal2"].ToString();
			postal3 = dr["postal3"].ToString();
		}
	}
	Response.Write("<form name=frmAdd method=post action=branch.aspx>");
	Response.Write("<table width=95% valign=top align=right cellspacing=1 cellpadding=1 border=1 bordercolor=#000000 ");
	Response.Write(" style=\"border-width:1px;border-style:Solid;border-collapse:collapse;fixed\">");
	Response.Write("<tr class=tableHeader>");
	Response.Write("<td colspan=2 align=center>" + s_TblName + " Branch</td></tr>");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD class=blueFont>Name:</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=name value='");
	Response.Write(name + "'></td></tr>\r\n");

	Response.Write("<script");
	Response.Write(">");
	Response.Write("document.frmAdd.name.focus();");
	Response.Write("</script");
	Response.Write(">");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Address</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=address1 value='");
	Response.Write(address1 + "'></td></tr>\r\n");
	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Address</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=address2 value='");
	Response.Write(address2 + "'></td></tr>\r\n");
	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Address</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=address3 value='");
	Response.Write(address3 + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>City</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=city value='");
	Response.Write(city + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Country</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=country value='");
	Response.Write(country + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Phone</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=phone value='");
	Response.Write(phone + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Fax</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=fax value='");
	Response.Write(fax + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Postal</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=postal1 value='");
	Response.Write(postal1 + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Postal</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=postal2 value='");
	Response.Write(postal2 + "'></td></tr>\r\n");

	Response.Write("<tr><td width=30% align=left bgcolor=#DDDDDD nowrap class=blueFont>Postal</td>");
	Response.Write("<td width=70% align=center><input type=editbox size=30 name=postal3 value='");
	Response.Write(postal3 + "'></td></tr>\r\n");

	Response.Write("<tr><td colspan=2 bgcolor=#FFFFFF align=center><br>");

    Trim(ref s_TblName);
    String buttonStyle = "";
    if(s_TblName == "Add"){
       buttonStyle =  "addButton";
    }else if(s_TblName == "Modify"){
        buttonStyle = "saveButton";
    }

	Response.Write("<input type=submit style='font-size:8pt;font-weight:bold' name=cmd value=' " + s_TblName + " ' class='"+buttonStyle+"' title='"+s_TblName+"'>");

	Response.Write("&nbsp;&nbsp;&nbsp");


	if(Request.QueryString["t"] == "m" && Request.QueryString["i"] != null && Request.QueryString["i"] != "")
	{
		Response.Write("&nbsp;&nbsp;&nbsp");
		Response.Write("<input type=submit style='font-size:8pt;font-weight:bold' name=cmd value=' Delete ' class=deleteButton3 title='Delete'>");
		Response.Write("<input type=hidden name=id value='" + Request.QueryString["i"] + "'>");
	}
    Response.Write("&nbsp;&nbsp;&nbsp");
	Response.Write("<input type=button style='font-size:8pt;font-weight:bold' name=clear value=' Cancel '");
	Response.Write(" class=cancelButton2 title='Cancel' OnClick=window.location=('branch.aspx')>");
	Response.Write("</td></tr>");
	Response.Write("</table></form>");

	return;
}

bool GetSelectedRow()
{
	string sc = "SELECT * FROM branch WHERE id = " + Request.QueryString["i"];
	int rows = 0;
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		rows = myAdapter.Fill(dsi, "selected");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}

	if(rows != 1)
		return false;

	return true;
}

bool GetExistingBranch()
{
	string sc = "SELECT * FROM branch ORDER BY id";
	try
	{
		myAdapter = new SqlDataAdapter(sc, myConnection);
		myAdapter.Fill(dst, "branch");
	}
	catch(Exception e) 
	{
		ShowExp(sc, e);
		return false;
	}
	return true;
}

</script>